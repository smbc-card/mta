'use strict';
// cmd/send - 发送邮件命令（Sprint 2 完整实现，对应 Go cmd/send.go）
//
// 流程：
//   1. 加载配置文件
//   2. 应用命令行 flag 覆盖
//   3. 验证必需字段（收件人文件 / 模板文件 / 发件人地址）
//   4. 生成 job ID（未指定时）
//   5. 打印启动摘要
//   6. 初始化 graceful / reporter / dispatcher
//   7. dispatcher.run() → result
//   8. reporter.saveResult(result)
//   9. 打印结果摘要
//
// Sprint 3+ 会在此基础上层叠反指纹相关初始化（Received/DKIM/…），但主流程稳定。

const fs = require('fs');
const path = require('path');
const config = require('../config/config');
const dispatcherMod = require('../core/dispatcher');
const gracefulMod = require('../core/graceful');
const reporterMod = require('../reporter/reporter');

function register(program, globalOpts) {
  const sub = program
    .command('send')
    .description('发送邮件');

  sub
    .option('-r, --recipients <path>', '收件人文件路径 (CSV/JSON/TXT)')
    .option('-t, --template <path>', '邮件模板文件路径')
    .option('-s, --subject <text>', '邮件主题')
    .option('-f, --from <addr>', '发件人地址')
    .option('--from-name <name>', '发件人显示名')
    .option('--envelope-from <addr>', '信封发件人（用于退信）')
    .option('--vmta <name>', '虚拟 MTA 名称')
    .option('--job-id <id>', '任务 ID（留空自动生成）')
    .option('-w, --workers <n>', '并发工作数', (v) => parseInt(v, 10), 0)
    .option('--rate-limit <n>', '每秒最大发送数（0=不限制）', (v) => parseInt(v, 10), 0)
    .option('--pickup-dir <path>', 'Pickup 目录路径')
    .option('--temp-dir <path>', '临时目录路径')
    .option('--progress-file <path>', '进度文件路径')
    .option('--result-file <path>', '结果文件路径')
    .option('--dry-run', '模拟运行（不实际写入）', false)
    // 【Sprint 5 R5 P1 修复】--resume dead flag,声明但方法体从未消费 opts.resume
    //   用户加 --resume 期望断点续发,实际每次从头 → 重复投递前 N 封,Gmail 送达率扣分
    //   目前请用 --skip-lines <N> 手动跳过
    .option('--resume', '[尚未实现] 断点续发模式,请改用 --skip-lines <N>', false)
    .option('--skip-lines <n>', '跳过前 N 行', (v) => parseInt(v, 10), 0)
    .action(async (opts) => {
      // ── 1. 加载配置 ──
      let cfg;
      try {
        cfg = globalOpts.configFile
          ? config.loadFromFile(globalOpts.configFile)
          : config.defaults();
      } catch (e) {
        throw new Error(`加载配置失败: ${e.message}`);
      }

      // ── 2. 命令行覆盖 ──
      _applyOverrides(cfg, opts);

      // ── 3. 验证 ──
      _validate(cfg);

      // ── 4. 生成 job ID ──
      if (!cfg.job.id) {
        cfg.job.id = `${cfg.job.id_prefix || 'job'}-${_ymdhms(new Date())}`;
      }

      // ── 5. 打印启动信息 ──
      if (!globalOpts.quiet) _printStart(cfg);

      // ── 6. 初始化 graceful / reporter ──
      // STOP 文件放在 progress_file 所在目录（对齐 Go send.go 行为）
      const stopFile = cfg.output.progress_file
        ? path.join(path.dirname(cfg.output.progress_file), 'STOP')
        : path.join(process.cwd(), 'STOP');
      const graceful = gracefulMod.init(stopFile);
      const reporter = reporterMod.create(cfg);

      // ── 7. 创建并运行调度器 ──
      const dispatcher = dispatcherMod.create(cfg, reporter, graceful);

      let result;
      try {
        result = await dispatcher.run();
      } catch (e) {
        process.stderr.write(`\n发送失败: ${e.message}\n`);
        // 【Sprint 5 R5 P1 修复】dispatcher.run 抛错时也保存 partial result,
        //   否则 result.json / errors.log 完全丢失 → C# GetTaskStatusAsync 判"任务失败无结果" →
        //   已投递成功的 N 封邮件无人知晓 + 用户看不到错误原因
        //   即使 dispatcher 未完全初始化,写一个 fatal result 让 C# 端有可读文件
        try {
          const fatalResult = {
            total: 0, success: 0, failed: 0, durationSeconds: 0, averageRate: 0,
            startTime: new Date(), endTime: new Date(),
            errors: [{ line: 0, email: '', error: 'FATAL: ' + e.message }],
            status: 'failed', fatalError: e.message,
          };
          await reporter.saveResult(fatalResult);
        } catch (_) { /* saveResult 若也 fail 就无办法,退出前尽力而为 */ }
        process.exit(1);
      }

      // ── 8. 保存结果 ──
      try {
        await reporter.saveResult(result);
      } catch (e) {
        process.stderr.write(`保存结果失败: ${e.message}\n`);
      }

      // ── 9. 打印结果 ──
      if (!globalOpts.quiet) _printResult(result);
    });
}

// ═════════════════════════════════════════════════════════════
// 命令行 override（对齐 Go send.go::applyCommandLineOverrides）
// ═════════════════════════════════════════════════════════════
function _applyOverrides(cfg, opts) {
  if (opts.recipients)   cfg.recipients.file_path = opts.recipients;
  if (opts.template)     cfg.email.template_path = opts.template;
  if (opts.subject)      cfg.email.subject = opts.subject;
  if (opts.from)         cfg.sender.from_address = opts.from;
  if (opts.fromName)     cfg.sender.from_name = opts.fromName;
  if (opts.envelopeFrom) cfg.sender.envelope_from = opts.envelopeFrom;
  if (opts.vmta)         cfg.pmta.virtual_mta = opts.vmta;
  if (opts.jobId)        cfg.job.id = opts.jobId;
  if (opts.workers > 0)  cfg.performance.workers = opts.workers;
  if (opts.rateLimit > 0) cfg.performance.rate_limit = opts.rateLimit;
  if (opts.pickupDir)    cfg.pmta.pickup_dir = opts.pickupDir;
  if (opts.tempDir)      cfg.pmta.temp_dir = opts.tempDir;
  if (opts.progressFile) cfg.output.progress_file = opts.progressFile;
  if (opts.resultFile)   cfg.output.result_file = opts.resultFile;
  if (opts.dryRun)       cfg.dry_run = true;
  if (opts.skipLines > 0) cfg.recipients.skip_lines = opts.skipLines;
  // envelope_from 兜底
  if (!cfg.sender.envelope_from) cfg.sender.envelope_from = cfg.sender.from_address;
}

function _validate(cfg) {
  if (!cfg.recipients.file_path) {
    throw new Error('未指定收件人文件');
  }
  if (!fs.existsSync(cfg.recipients.file_path)) {
    throw new Error(`收件人文件不存在: ${cfg.recipients.file_path}`);
  }
  if (!cfg.email.template_path) {
    throw new Error('未指定模板文件');
  }
  if (!fs.existsSync(cfg.email.template_path)) {
    throw new Error(`模板文件不存在: ${cfg.email.template_path}`);
  }
  if (!cfg.sender.from_address) {
    throw new Error('未指定发件人地址');
  }
  // SMTP 配置校验（非 dry_run 时）
  if (!cfg.dry_run && cfg.smtp.enabled) {
    if (!cfg.smtp.host) throw new Error('未指定 SMTP 服务器地址');
    if (!cfg.smtp.port || cfg.smtp.port <= 0) throw new Error(`无效的 SMTP 端口: ${cfg.smtp.port}`);
  }
}

function _ymdhms(d) {
  const pad2 = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}-` +
         `${pad2(d.getHours())}${pad2(d.getMinutes())}${pad2(d.getSeconds())}`;
}

function _printStart(cfg) {
  const bar = '═══════════════════════════════════════════════════════════════';
  process.stdout.write(bar + '\n');
  process.stdout.write('                    PMTA Injector 启动 (Node)\n');
  process.stdout.write(bar + '\n');
  process.stdout.write(`  任务ID:       ${cfg.job.id}\n`);
  process.stdout.write(`  收件人文件:   ${cfg.recipients.file_path}\n`);
  process.stdout.write(`  模板文件:     ${cfg.email.template_path}\n`);
  process.stdout.write(`  发件人:       ${cfg.sender.from_name} <${cfg.sender.from_address}>\n`);
  process.stdout.write(`  主题:         ${cfg.email.subject}\n`);
  process.stdout.write(`  虚拟MTA:      ${cfg.pmta.virtual_mta}\n`);
  process.stdout.write(`  SMTP:         ${cfg.smtp.enabled ? `${cfg.smtp.host}:${cfg.smtp.port}` : 'disabled'}\n`);
  process.stdout.write(`  Pickup目录:   ${cfg.pmta.pickup_dir}\n`);
  process.stdout.write(`  并发数:       ${cfg.performance.workers}\n`);
  process.stdout.write(`  速率限制:     ${cfg.performance.rate_limit > 0 ? cfg.performance.rate_limit + '/秒' : '无限制'}\n`);
  if (cfg.cc.enabled)  process.stdout.write(`  CC 池文件:    ${cfg.cc.file_path} (每封 ${cfg.cc.per_email} 个)\n`);
  if (cfg.bcc.enabled) process.stdout.write(`  BCC 池文件:   ${cfg.bcc.file_path} (每封 ${cfg.bcc.per_email} 个)\n`);
  if (cfg.dry_run)     process.stdout.write(`  模式:         [模拟运行]\n`);
  process.stdout.write(bar + '\n\n');
}

function _printResult(result) {
  const bar = '═══════════════════════════════════════════════════════════════';
  process.stdout.write('\n' + bar + '\n');
  process.stdout.write('                      发送完成\n');
  process.stdout.write(bar + '\n');
  process.stdout.write(`  总数:         ${result.total}\n`);
  process.stdout.write(`  成功:         ${result.success}\n`);
  process.stdout.write(`  失败:         ${result.failed}\n`);
  process.stdout.write(`  耗时:         ${result.durationSeconds.toFixed(2)} 秒\n`);
  process.stdout.write(`  平均速率:     ${result.averageRate.toFixed(2)} 封/秒\n`);
  if (result.startTime instanceof Date) {
    process.stdout.write(`  开始时间:     ${result.startTime.toISOString()}\n`);
  }
  if (result.endTime instanceof Date) {
    process.stdout.write(`  结束时间:     ${result.endTime.toISOString()}\n`);
  }
  if (result.errors && result.errors.length > 0) {
    process.stdout.write(`  错误样本(前 5):\n`);
    for (const e of result.errors.slice(0, 5)) {
      process.stdout.write(`    Line ${e.line}: ${e.email} - ${e.error}\n`);
    }
  }
  process.stdout.write(bar + '\n');
}

module.exports = { register };
