'use strict';
// email/headers - 邮件头生成器（对应 Go pmta-injector-clean/email/headers.go 2895 行）
//
// 覆盖内容:
//   - HeaderGenerator 类（每 worker 独立实例）
//   - Received 头生成（1/2/3 hop + 5 ESP + Received 随机模板）
//   - DKIM-Signature 伪签名（方案 B 外部域池）
//   - Message-ID 25 风格
//   - P0 送达刚需 5 头（List-Unsubscribe/Post/List-ID/Feedback-ID/Precedence）
//   - P1 反指纹 9 头 + P2 Outlook 4 头 + P2 行为 3 头 + P3 营销 3 头
//   - P3 联动组（X-TMAS 6 头 / X-SFMC 2 头）
//   - 4 企业网关联动（Barracuda 6 / Proofpoint 4 / Mimecast 4 / Symantec 4）
//   - v2 5 独立头（List-ID / X-Originating-Email / X-MimeOLE / X-Mailer-Version / X-OriginalArrivalTime）
//   - Reply-To / Return-Path / X-Priority / Importance / Accept-Language / Content-Language
//   - Worker 级 50-200 封寿命反指纹抽样机制
//   - 122 条 Yahoo Japan CIDR 池 + 9 段非公网排除的公网随机 IP
//   - GenerateAllReceived 按 D1 方案 A 拼接 6 类 Received

const crypto = require('crypto');
const randSafe = require('./rand_safe');
const dkimPool = require('./dkim_pool');
const xmailer = require('./xmailer');
const foldMod = require('./fold');
const varsExt = require('./variables_ext');

// ═════════════════════════════════════════════════════════════
// 【122 条】Yahoo Japan CIDR 池（byte-level 对齐 Go yahooCidrStrings）
// ═════════════════════════════════════════════════════════════
const yahooCidrStrings = [
  '43.223.91.0/24', '43.223.90.0/24', '43.223.89.0/24', '43.223.88.0/24',
  '43.223.87.0/24', '43.223.86.0/24', '43.223.85.0/24', '43.223.84.0/24',
  '43.223.83.0/24', '43.223.82.0/24', '43.223.81.0/24', '43.223.80.0/24',
  '43.223.79.0/24', '43.223.78.0/24', '43.223.77.0/24', '43.223.76.0/24',
  '43.223.75.0/24', '43.223.74.0/24', '43.223.73.0/24', '43.223.72.0/24',
  '43.223.71.0/24', '43.223.70.0/24', '43.223.7.0/24', '43.223.69.0/24',
  '43.223.68.0/24', '43.223.67.0/24', '43.223.66.0/24', '43.223.65.0/24',
  '43.223.64.0/24', '43.223.6.0/24', '43.223.5.0/24', '43.223.47.0/24',
  '43.223.46.0/24', '43.223.45.0/24', '43.223.44.0/24', '43.223.43.0/24',
  '43.223.42.0/24', '43.223.41.0/24', '43.223.40.0/24', '43.223.4.0/24',
  '43.223.39.0/24', '43.223.38.0/24', '43.223.37.0/24', '43.223.36.0/24',
  '43.223.35.0/24', '43.223.34.0/24', '43.223.33.0/24', '43.223.32.0/24',
  '43.223.31.0/24', '43.223.30.0/24', '43.223.3.0/24', '43.223.29.0/24',
  '43.223.28.0/24', '43.223.25.0/24', '43.223.24.0/24', '43.223.23.0/24',
  '43.223.22.0/24', '43.223.21.0/24', '43.223.20.0/24', '43.223.2.0/24',
  '43.223.19.0/24', '43.223.18.0/24', '43.223.17.0/24', '43.223.16.0/24',
  '43.223.1.0/24', '43.223.0.0/24', '43.223.0.0/16',
  '103.2.244.0/22', '103.2.28.0/24', '103.2.30.0/23', '103.2.30.0/24',
  '103.2.31.0/24',
  '104.145.16.0/20', '114.110.48.0/20', '114.111.64.0/18', '118.151.224.0/19',
  '119.235.236.0/24', '119.235.237.0/24', '119.235.236.0/23',
  '119.235.224.0/24', '119.235.232.0/24', '119.235.235.0/24',
  '124.83.128.0/17',
  '147.92.130.0/24', '147.92.129.0/24', '147.92.128.0/24', '147.92.128.0/17',
  '147.92.169.0/24', '147.92.202.0/24', '147.92.201.0/24', '147.92.200.0/24',
  '147.92.188.0/24', '147.92.168.0/24', '147.92.167.0/24', '147.92.166.0/24',
  '147.92.165.0/24', '147.92.164.0/24', '147.92.135.0/24', '147.92.134.0/24',
  '147.92.133.0/24', '147.92.132.0/24', '147.92.131.0/24',
  '182.22.0.0/17', '183.79.0.0/16',
  '202.239.0.0/20', '202.93.64.0/19',
  '203.104.156.0/23', '203.104.128.0/20', '203.104.144.0/21', '203.104.152.0/22',
  '203.141.32.0/20', '203.141.54.0/24',
  '203.216.224.0/19',
  '210.171.36.0/22', '210.171.60.0/22', '210.229.224.0/19', '210.250.224.0/19',
  '210.252.64.0/19',
  '211.14.28.0/23', '211.14.26.0/23', '211.14.12.0/22', '211.14.8.0/24',
];

// 9 段非公网可路由段（RFC 5735 + RFC 6598 + 组播 + 保留 E）
const nonRoutableCidrs = [
  '0.0.0.0/8',
  '10.0.0.0/8',
  '100.64.0.0/10',
  '127.0.0.0/8',
  '169.254.0.0/16',
  '172.16.0.0/12',
  '192.168.0.0/16',
  '224.0.0.0/4',
  '240.0.0.0/4',
];

// yahooNets / nonRoutableNets / softbank172Net 由 init 阶段解析
// 每个 net 表示为 {networkU32, maskU32}（IPv4 语义）
const yahooNets = [];
const nonRoutableNets = [];
let softbank172Net = null;

// ═════════════════════════════════════════════════════════════
// TLS ciphers 池
// ═════════════════════════════════════════════════════════════
const tlsCiphers = [
  'cipher=TLS_RSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);',
  'cipher=TLS_RSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);',
  'cipher=TLS_RSA_WITH_AES_128_CBC_SHA (authenticated bits=0);',
  'cipher=TLS_RSA_WITH_AES_256_CBC_SHA (authenticated bits=0);',
  'cipher=TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);',
  'cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);',
  'cipher=TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA (authenticated bits=0);',
  'cipher=TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA (authenticated bits=0);',
  'cipher=TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);',
  'cipher=TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);',
  'cipher=TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);',
  'cipher=TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);',
  'cipher=TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 (authenticated bits=0);',
  'cipher=TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 (authenticated bits=0);',
  'cipher=TLS_AES_128_GCM_SHA256 (authenticated bits=0);',
  'cipher=TLS_AES_256_GCM_SHA384 (authenticated bits=0);',
  'cipher=TLS_CHACHA20_POLY1305_SHA256 (authenticated bits=0);',
];

// ═════════════════════════════════════════════════════════════
// 域名生成用数据池
// ═════════════════════════════════════════════════════════════
const domainTLDs = [
  'com', 'net', 'org', 'jp', 'ne.jp', 'co.jp', 'or.jp', 'ac.jp', 'ad.jp', 'ed.jp',
  'go.jp', 'gr.jp', 'lg.jp', 'edu', 'gov', 'app', 'blog', 'shop', 'online', 'site',
  'store', 'tech', 'cloud', 'email', 'news', 'media', 'agency', 'company', 'business',
  'services', 'aichi.jp', 'akita.jp', 'aomori.jp', 'chiba.jp', 'ehime.jp', 'fukui.jp',
  'fukuoka.jp', 'fukushima.jp', 'gifu.jp', 'gunma.jp', 'hiroshima.jp', 'hokkaido.jp',
  'hyogo.jp', 'ibaraki.jp', 'ishikawa.jp', 'iwate.jp', 'kagawa.jp', 'kagoshima.jp',
  'kanagawa.jp', 'kochi.jp', 'kumamoto.jp', 'kyoto.jp', 'mie.jp', 'miyagi.jp',
  'miyazaki.jp', 'nagano.jp', 'nagasaki.jp', 'nara.jp', 'niigata.jp', 'oita.jp',
  'okayama.jp', 'okinawa.jp', 'osaka.jp', 'saga.jp', 'saitama.jp', 'shiga.jp',
  'shimane.jp', 'shizuoka.jp', 'tochigi.jp', 'tokushima.jp', 'tokyo.jp', 'tottori.jp',
  'toyama.jp', 'wakayama.jp', 'yamagata.jp', 'yamaguchi.jp', 'yamanashi.jp',
  'yokohama.jp', 'kawasaki.jp', 'sapporo.jp', 'sendai.jp',
  'pref.aichi.jp', 'pref.osaka.jp', 'pref.kanagawa.jp', 'pref.saitama.jp',
  'pref.chiba.jp', 'pref.fukuoka.jp', 'pref.hiroshima.jp', 'pref.hokkaido.jp',
  'pref.hyogo.jp', 'pref.kyoto.jp',
  'waseda.jp', 'keio.jp', 'u-tokyo.jp', 'kyoto-u.jp', 'osaka-u.jp',
  'ntt.jp', 'softbank.jp', 'kddi.jp', 'docomo.jp', 'rakuten.jp',
  'smbc.jp', 'mufg.jp', 'mizuho.jp', 'japanpost.jp',
  'nerima.tokyo.jp', 'shibuya.tokyo.jp', 'shinjuku.tokyo.jp', 'minato.tokyo.jp',
];

const domainWords = [
  'care', 'mail', 'tech', 'data', 'info', 'auto', 'plan', 'node', 'core', 'form',
  'sync', 'push', 'base', 'bank', 'auth', 'main', 'flow', 'tool', 'link', 'user',
  'help', 'pool', 'email', 'promo', 'event', 'stats', 'batch', 'queue', 'guide',
  'route', 'agent', 'chain', 'reply', 'vault', 'store', 'group', 'order', 'entry',
  'setup', 'blast', 'stage', 'score', 'cache', 'proxy', 'admin', 'token', 'audit',
  'reset', 'office', 'notify', 'alerts', 'system', 'notice', 'report', 'mailer',
  'sender', 'signal', 'client', 'search', 'config', 'update', 'member', 'action',
  'verify', 'stream', 'crypto', 'daemon', 'policy', 'server', 'branch', 'filter',
  'access', 'record', 'source', 'broker', 'worker', 'engine', 'portal', 'assist',
  'ticket', 'status', 'health', 'secure', 'manage', 'safety', 'shield', 'custom',
  'signup', 'backup', 'repair', 'noreply', 'manager', 'premium', 'monitor', 'network',
  'traffic', 'checker', 'mailbot', 'cleaner', 'reports', 'content', 'archive',
  'account', 'billing', 'payment', 'profile', 'confirm', 'welcome', 'service',
  'gateway', 'support',
];

const domainSuffixes = [
  'corp', 'solutions', 'systems', 'services', 'group', 'tech', 'resolve', 'contact',
  'process', 'inquiry', 'checking', 'verifier', 'computer', 'security', 'reminder',
  'messages', 'recovery', 'dispatch', 'delivery', 'tracking', 'solution', 'benefits',
  'endpoint', 'notifier', 'campaign', 'priority', 'packages', 'progress', 'customer',
  'platform', 'feedback', 'settings', 'database', 'research', 'helpdesk', 'response',
  'resource', 'pipeline', 'workflow', 'engineer', 'accounts', 'firewall', 'protocol',
  'incident', 'sentinel', 'guardian', 'operator', 'broadcast', 'scheduler', 'publisher',
  'processor', 'connector', 'framework', 'component', 'dashboard', 'analytics',
  'collector', 'community', 'validator', 'operation', 'management', 'onboarding',
  'encryption', 'technology', 'specialist', 'membership', 'automation', 'middleware',
  'newsletter', 'compliance', 'statistics', 'activation', 'checkpoint', 'dispatcher',
  'monitoring', 'foundation', 'protection', 'diagnostic', 'maintenance', 'integration',
  'coordinator', 'application', 'performance', 'information', 'confirmation',
  'administrator', 'communication', 'notifications', 'infrastructure', 'authentication',
];

// ═════════════════════════════════════════════════════════════
// mailServerSoftware 池（600+ 条，用于 Received 头 by 行的软件标识）
// 与 Go 版顺序对齐（分组内可能微调，但语义等价）
// ═════════════════════════════════════════════════════════════
const mailServerSoftware = [
  // ESP API
  'Google API', 'Google SMTP', 'Google Mail Service', 'Gmail SMTP',
  'Google Workspace SMTP', 'Google Apps SMTP', 'Google Cloud SMTP',
  'Google Relay', 'Google Mail Relay',
  'Microsoft SMTP', 'Microsoft SMTP Server', 'Microsoft Exchange Online',
  'Microsoft 365 SMTP', 'Office 365 SMTP', 'Outlook SMTP', 'Outlook.com SMTP',
  'Exchange SMTP Gateway', 'Microsoft Exchange Server', 'Microsoft Exchange Transport',
  'Amazon SES', 'Amazon SES API', 'Amazon Simple Email Service',
  'AWS SES SMTP', 'AWS Mail Service', 'Amazon SES Relay',
  'SendGrid', 'SendGrid API', 'SendGrid SMTP', 'SendGrid Mail Service', 'Twilio SendGrid',
  'Mailgun', 'Mailgun API', 'Mailgun SMTP', 'Mailgun Relay', 'Mailgun Mail Service',
  'Mailchimp', 'Mailchimp API', 'Mailchimp Transactional',
  'Mandrill', 'Mandrill API', 'Mandrill SMTP',
  'Postmark', 'Postmark API', 'Postmark SMTP', 'Postmark Mail Service',
  'SparkPost', 'SparkPost API', 'SparkPost SMTP', 'SparkPost Relay',
  'Brevo SMTP', 'Brevo API', 'Brevo Mail Service',
  'Sendinblue', 'Sendinblue API', 'Sendinblue SMTP',
  'Elastic Email', 'Elastic Email API', 'Elastic Email SMTP',
  'MailerSend', 'MailerSend API', 'MailerSend SMTP',
  'Mailjet', 'Mailjet API', 'Mailjet SMTP', 'Mailjet Relay',
  'Constant Contact', 'Constant Contact SMTP',
  'Campaign Monitor', 'Campaign Monitor SMTP',
  'GetResponse', 'GetResponse SMTP',
  'AWeber', 'AWeber SMTP',
  'ConvertKit', 'ConvertKit SMTP',
  'ActiveCampaign', 'ActiveCampaign SMTP',
  'Drip', 'Drip SMTP',
  'Klaviyo', 'Klaviyo SMTP',
  'HubSpot SMTP', 'HubSpot Mail Service',
  'Salesforce SMTP', 'Salesforce Marketing Cloud',
  'Oracle Email Delivery', 'Oracle Cloud SMTP',
  'IBM Cloud Email',
  'SocketLabs', 'SocketLabs SMTP', 'SocketLabs API',
  'SMTP2GO', 'SMTP2GO SMTP', 'SMTP2GO API',
  'Pepipost', 'Pepipost SMTP', 'Pepipost API',
  'Moosend', 'Moosend SMTP',
  'Omnisend', 'Omnisend SMTP',
  'Customer.io', 'Customer.io SMTP',
  'Intercom Mail', 'Intercom SMTP',
  'Zendesk SMTP', 'Zendesk Mail Service',
  'Freshdesk SMTP', 'Freshdesk Mail',
  // MTA
  'Postfix', 'Postfix MTA', 'Postfix SMTP', 'Postfix/smtpd',
  'Sendmail', 'Sendmail MTA', 'Sendmail/8.15.2', 'Sendmail/8.16.1', 'Sendmail/8.17.1',
  'Exim', 'Exim SMTP', 'Exim 4.94', 'Exim 4.96', 'Exim 4.97', 'Exim MTA',
  'Dovecot', 'Dovecot LMTP', 'Dovecot SMTP', 'Dovecot/2.3',
  'Zimbra', 'Zimbra SMTP', 'Zimbra 8.8', 'Zimbra 9.0', 'Zimbra Collaboration', 'Zimbra MTA',
  'hMailServer', 'hMailServer 5.6', 'hMailServer SMTP',
  'Haraka', 'Haraka SMTP', 'Haraka MTA', 'Haraka/2.8',
  'OpenSMTPD', 'OpenSMTPD 6.8', 'OpenSMTPD 7.0',
  'qmail', 'qmail SMTP', 'qmail-smtpd',
  'Courier', 'Courier Mail Server', 'Courier MTA', 'Courier SMTP',
  'MailEnable', 'MailEnable SMTP', 'MailEnable Professional', 'MailEnable Enterprise',
  'Kerio Connect', 'Kerio Connect SMTP', 'Kerio Connect 9.4',
  'IceWarp', 'IceWarp SMTP', 'IceWarp Server', 'IceWarp 13',
  'Axigen', 'Axigen SMTP', 'Axigen Mail Server',
  'CommuniGate Pro', 'CommuniGate Pro SMTP', 'CommuniGate Pro 6.3',
  'MDaemon', 'MDaemon SMTP', 'MDaemon Mail Server', 'MDaemon 21.5', 'MDaemon 23.0',
  'Lotus Domino', 'Lotus Domino SMTP', 'HCL Domino', 'HCL Domino SMTP',
  'Novell GroupWise', 'GroupWise SMTP', 'GroupWise Internet Agent',
  'PowerMTA', 'PowerMTA SMTP', 'PowerMTA/5.0',
  'Apache James', 'Apache James SMTP', 'Apache James 3.7',
  'Open-Xchange', 'Open-Xchange SMTP',
  'Maildrop', 'Maildrop SMTP',
  'Prosody SMTP', 'Cyrus SMTP', 'Cyrus/IMAPd',
  'MailCow', 'MailCow SMTP', 'Mailcow Dockerized',
  'Mail-in-a-Box', 'iRedMail', 'iRedMail SMTP',
  'Modoboa', 'Modoboa SMTP', 'Kolab', 'Kolab SMTP',
  'Citadel', 'Citadel SMTP', 'Hmailserver',
  // 企业/云平台
  'Zoho Mail', 'Zoho Mail SMTP', 'Zoho SMTP', 'Zoho ZeptoMail',
  'Yahoo SMTP', 'Yahoo Mail SMTP', 'Yahoo Mail Service',
  'Rackspace Email', 'Rackspace SMTP', 'Rackspace Cloud Email',
  'GoDaddy SMTP', 'GoDaddy Email', 'GoDaddy Workspace',
  'Fastmail', 'Fastmail SMTP', 'Fastmail MTA',
  'ProtonMail', 'ProtonMail SMTP', 'ProtonMail Bridge', 'Proton Mail SMTP',
  'Tutanota', 'Tutanota SMTP',
  'GMX SMTP', 'GMX Mail',
  'Mail.Ru SMTP', 'Mail.Ru',
  'Yandex SMTP', 'Yandex Mail', 'Yandex Cloud SMTP',
  'Apple Mail', 'Apple iCloud Mail', 'iCloud SMTP',
  'Tencent Mail', 'Tencent SMTP', 'QQ Mail SMTP',
  'NetEase Mail', 'NetEase SMTP', '163 Mail SMTP',
  'Alibaba Mail', 'Alibaba Cloud Mail', 'Alibaba DirectMail',
  'Naver SMTP', 'Naver Mail', 'Daum SMTP', 'Daum Mail',
  'OVH SMTP', 'OVH Mail', 'OVH Cloud Email',
  'Hetzner SMTP', 'Hetzner Mail',
  'DigitalOcean SMTP', 'Linode SMTP', 'Vultr SMTP', 'Scaleway SMTP',
  'Gandi SMTP', 'Gandi Mail', 'Namecheap SMTP', 'Namecheap Email',
  'Bluehost SMTP', 'HostGator SMTP', 'SiteGround SMTP', 'DreamHost SMTP',
  'Ionos SMTP', '1and1 SMTP', 'Aruba SMTP', 'Register.it SMTP',
  // 日本邮件服务
  'Sakura Internet', 'Sakura SMTP', 'Sakura Mail',
  'GMO SMTP', 'GMO Mail', 'GMO Cloud SMTP',
  'KAGOYA SMTP', 'KAGOYA Mail', 'KAGOYA Internet',
  'Xserver SMTP', 'Xserver Mail', 'Xserver MTA',
  'ConoHa SMTP', 'ConoHa Mail', 'ConoHa MTA',
  'IIJ SMTP', 'IIJ Mail', 'IIJ Secure MX',
  'BIGLOBE SMTP', 'BIGLOBE Mail',
  'OCN SMTP', 'OCN Mail',
  'Nifty SMTP', 'Nifty Mail',
  'So-net SMTP', 'So-net Mail',
  'KDDI Mail', 'KDDI SMTP', 'au Mail SMTP',
  'NTT Mail SMTP', 'NTT Communications SMTP',
  'Plala SMTP', 'Plala Mail',
  'DTI SMTP', 'DTI Mail',
  'Interlink SMTP', 'WebARENA SMTP', 'WADAX SMTP', 'CPI SMTP',
  'Lolipop SMTP', 'Lolipop Mail', 'MuuMuu SMTP',
  'Onamae SMTP', 'Onamae Mail',
  'ValueServer SMTP', 'Core Server SMTP', 'Heteml SMTP',
  // 安全网关
  'Barracuda', 'Barracuda SMTP', 'Barracuda Email Gateway', 'Barracuda Spam Firewall',
  'Proofpoint', 'Proofpoint SMTP', 'Proofpoint Protection', 'Proofpoint Essentials', 'Proofpoint Gateway',
  'Sophos Email', 'Sophos SMTP', 'Sophos Email Appliance',
  'Symantec Messaging Gateway', 'Symantec SMTP', 'Broadcom Email Security',
  'FortiMail', 'FortiMail SMTP', 'Fortinet FortiMail',
  'Cisco IronPort', 'Cisco ESA', 'Cisco Email Security', 'Cisco SMTP',
  'Trend Micro', 'Trend Micro SMTP', 'Trend Micro Email Security', 'Trend Micro IMSVA',
  'SpamAssassin',
  'Amavis', 'Amavisd-new', 'Amavis SMTP',
  'Mimecast', 'Mimecast SMTP', 'Mimecast Gateway', 'Mimecast Email Security',
  'Cloudmark', 'Cloudmark SMTP',
  'McAfee Email Gateway', 'McAfee SMTP', 'Trellix Email Security',
  'FireEye SMTP', 'FireEye Email Security',
  'Palo Alto SMTP', 'Juniper SMTP',
  'F-Secure SMTP', 'ESET Mail Security', 'ESET SMTP',
  'Kaspersky SMTP', 'Kaspersky Security for Mail',
  'Bitdefender SMTP', 'Avira SMTP',
  'ClamAV SMTP', 'Rspamd', 'Rspamd SMTP',
  'MailScanner', 'MailScanner SMTP',
  'SpamTitan', 'SpamTitan SMTP',
  'MailGuard SMTP', 'N-able Mail Assure', 'SolarWinds Mail Assure',
  'Hornetsecurity', 'Hornetsecurity SMTP',
  'Retarus SMTP', 'Retarus Email Security',
  'Zix SMTP', 'Zix Email Encryption', 'Virtru SMTP', 'Egress SMTP',
  'Libraesva SMTP', 'Libraesva ESG',
  'GFI MailEssentials', 'GFI SMTP',
  'Spam Experts', 'SpamExperts SMTP',
  // 开发框架
  'PHPMailer', 'PHPMailer SMTP',
  'SwiftMailer', 'SwiftMailer SMTP',
  'Symfony Mailer', 'Laravel SMTP', 'Django SMTP', 'Rails SMTP',
  'Nodemailer', 'Nodemailer SMTP',
  'JavaMail', 'JavaMail SMTP', 'Jakarta Mail', 'Jakarta Mail SMTP',
  'Spring Mail', 'Spring SMTP',
  'Python smtplib', 'Go net/smtp', 'Ruby Net::SMTP', 'Perl Net::SMTP',
  // 通用
  'SMTP Gateway', 'SMTP Relay', 'SMTP Service',
  'Mail Gateway', 'Mail Relay', 'Mail Service',
  'Mail Transfer Agent',
  'MTA Gateway', 'MTA Relay', 'MTA Service',
  'Email Gateway', 'Email Relay', 'Email Service',
  'Outbound SMTP', 'Outbound Relay', 'Inbound SMTP',
  'Cloud SMTP', 'Cloud Mail', 'Cloud Relay',
  'Managed SMTP', 'Managed Mail Service',
  'Secure SMTP', 'Secure Mail Gateway',
  'Enterprise SMTP', 'Enterprise Mail',
  'Corporate SMTP', 'Corporate Mail Gateway',
  'Dedicated SMTP', 'Hosted SMTP', 'Hosted Mail Service',
  'Private SMTP', 'Internal SMTP', 'Local MTA',
  'Relay SMTP', 'Smarthost SMTP', 'Submission SMTP', 'MSA SMTP',
  'MX Gateway', 'MX Relay', 'MX Service',
  'Mail Hub', 'Mail Proxy', 'Mail Router', 'Mail Bridge',
  'Mail Dispatcher', 'Mail Processor', 'Mail Handler',
  'SMTP Processor', 'SMTP Dispatcher', 'SMTP Handler',
  'SMTP Forwarder', 'SMTP Router', 'SMTP Proxy', 'SMTP Bridge', 'SMTP Hub',
  'Messaging Gateway', 'Messaging Service', 'Messaging Relay',
  'Message Transfer', 'Message Router', 'Message Gateway',
  'Delivery Service', 'Delivery Gateway', 'Delivery Agent', 'Delivery Relay',
  'Transaction Mail', 'Transactional SMTP',
  'Bulk Mail Service', 'Mass Mail Service',
  'Notification Service', 'Notification SMTP',
  'Alert Service', 'Alert SMTP',
];

// ═════════════════════════════════════════════════════════════
// Yahoo Received 用的 EHLO/BY 域池
// ═════════════════════════════════════════════════════════════
const yahooEhloSubdomains = ['kks', 'kth', 'ssk'];

// 6 种 by 域范式（对齐 Go yahooByPool）
const yahooByPool = [
  { template: 'mta%04d.mail.otm.ynwp.yahoo.co.jp', startNum: 1, endNum: 160, pad: 4 },
  { template: 'mta%04d.mail.snz.ynwp.yahoo.co.jp', startNum: 2001, endNum: 2160, pad: 4 },
  { template: 'mtaat%04d.mail.otm.ynwp.yahoo.co.jp', startNum: 1, endNum: 160, pad: 4 },
  { template: 'mtaat%04d.mail.snz.ynwp.yahoo.co.jp', startNum: 2001, endNum: 2160, pad: 4 },
  { template: 'mta%03d.kks.gm.yahoo.co.jp', startNum: 1, endNum: 160, pad: 3 },
  { template: 'mta%03d.ssk.gm.yahoo.co.jp', startNum: 1, endNum: 160, pad: 3 },
];

// ═════════════════════════════════════════════════════════════
// Message-ID 25 风格 key（顺序 = Go 版顺序，字节级契约）
// ═════════════════════════════════════════════════════════════
const messageIDStyleKeys = [
  'uuid_v4_lower', 'hex32', 'javamail', 'uuid_v4_upper', 'ts_uuid_counter',
  'base64url', 'readable_ts', 'uuid_seq', 'hex40', 'hex_underscore',
  'ms_ts_hex', 'uuid_v1', 'biz_prefix', 'hex64', 'enterprise_multiseg',
  'epoch_counter', 'bigint_hex', 'mixed_alnum', 'compact_date_ns', 'tag_uuid',
  'ns_hex', 'hex16', 'exim', 'sendmail', 'becky',
];

const messageIDBizPrefixes = ['mkt', 'promo', 'news', 'notify', 'sys', 'mail', 'camp', 'info', 'noreply', 'alert'];
const messageIDPlatformLabels = ['promo', 'news', 'txn', 'sys', 'camp', 'mkt', 'bulk', 'auto'];
const messageIDTags = ['notify', 'alert', 'txn', 'sys', 'msg', 'info', 'mail', 'auto', 'noreply'];

// Worker 级随机组合寿命：50-200 封
const HEADER_RANDOM_LIFESPAN_MIN = 50;
const HEADER_RANDOM_LIFESPAN_GAP = 151; // 上限 = min + gap - 1 = 200

// ═════════════════════════════════════════════════════════════
// CIDR 解析（init 阶段一次性，失败 throw）
// 内部结构：{network: uint32, prefix: number}
// ═════════════════════════════════════════════════════════════
function _parseCIDR(cidr) {
  const parts = cidr.split('/');
  if (parts.length !== 2) throw new Error(`invalid CIDR: ${cidr}`);
  const ipParts = parts[0].split('.').map((s) => parseInt(s, 10));
  if (ipParts.length !== 4 || ipParts.some((n) => !Number.isFinite(n) || n < 0 || n > 255)) {
    throw new Error(`invalid CIDR IP: ${cidr}`);
  }
  const prefix = parseInt(parts[1], 10);
  if (!Number.isFinite(prefix) || prefix < 0 || prefix > 32) throw new Error(`invalid CIDR prefix: ${cidr}`);
  const ip = ((ipParts[0] << 24) | (ipParts[1] << 16) | (ipParts[2] << 8) | ipParts[3]) >>> 0;
  const mask = prefix === 0 ? 0 : (0xFFFFFFFF << (32 - prefix)) >>> 0;
  const network = (ip & mask) >>> 0;
  return { network, prefix };
}

function _cidrContains(net, ipU32) {
  const mask = net.prefix === 0 ? 0 : (0xFFFFFFFF << (32 - net.prefix)) >>> 0;
  return ((ipU32 & mask) >>> 0) === net.network;
}

// init
for (const s of yahooCidrStrings) {
  try { yahooNets.push(_parseCIDR(s)); }
  catch (e) { throw new Error(`ESP Received: 雅虎 CIDR 池解析失败 ${s}: ${e.message}`); }
}
for (const s of nonRoutableCidrs) {
  try { nonRoutableNets.push(_parseCIDR(s)); }
  catch (e) { throw new Error(`ESP Received: 非公网排除段解析失败 ${s}: ${e.message}`); }
}
try { softbank172Net = _parseCIDR('172.16.0.0/12'); }
catch (e) { throw new Error(`ESP Received: softbank 172.16.0.0/12 解析失败: ${e.message}`); }

// ═════════════════════════════════════════════════════════════
// IP 工具
// ═════════════════════════════════════════════════════════════
function _u32ToIPv4(u) {
  return `${(u >>> 24) & 0xFF}.${(u >>> 16) & 0xFF}.${(u >>> 8) & 0xFF}.${u & 0xFF}`;
}

// 在 CIDR 段内随机 IP，避开网络号（.0）和广播号
// /31、/32 直接返回段基地址
function randomIPInCIDR(rng, net) {
  const hostBits = 32 - net.prefix;
  if (hostBits <= 1) return _u32ToIPv4(net.network);
  const size = 1 << hostBits >>> 0;
  // 可用偏移 [1, size-2]
  const offset = randSafe.safeIntn(rng, size - 2) + 1;
  return _u32ToIPv4((net.network + offset) >>> 0);
}

// 122 条池均匀随机
function randomYahooIP(rng) {
  if (yahooNets.length === 0) return '183.79.0.1';
  const idx = randSafe.safeIntn(rng, yahooNets.length);
  return randomIPInCIDR(rng, yahooNets[idx]);
}

// 全球随机公网 IPv4（排除 9 段非公网，拒绝采样）
function randomPublicIP(rng) {
  for (let tries = 0; tries < 100; tries++) {
    const u = (randSafe.safeIntn(rng, 0x7FFFFFFF) * 2 + randSafe.safeIntn(rng, 2)) >>> 0;
    let excluded = false;
    for (const n of nonRoutableNets) {
      if (_cidrContains(n, u)) { excluded = true; break; }
    }
    if (!excluded) return _u32ToIPv4(u);
  }
  return '203.0.114.1';
}

// 软银 172.16.0.0/12 内随机 IP
function randomSoftbank172IP(rng) {
  return randomIPInCIDR(rng, softbank172Net);
}

// 注入到 variables_ext 的 3 个 IP helper（Sprint 3B 占位替换）
varsExt.setIPHelpers({ randomYahooIP, randomSoftbank172IP, randomPublicIP });

// ═════════════════════════════════════════════════════════════
// 模块级辅助函数（用 crypto/rand 而非 vp.random —— 与 Go 版一致）
// ═════════════════════════════════════════════════════════════

function randomHexString(n) {
  // Go: hex.EncodeToString(b)[:n]，b 长 n 字节 → hex 有 2n 字符 → 取前 n 字符
  const bytes = Math.max(1, Math.ceil(n / 2));
  return crypto.randomBytes(bytes).toString('hex').slice(0, n);
}

function generateGUID() {
  const b = crypto.randomBytes(16);
  const hex = b.toString('hex').toUpperCase();
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20,32)}`;
}

function generateRandomBase64(n) {
  return crypto.randomBytes(n).toString('base64');
}

// 生成多行 Base64（每行 72 字符，续行前缀 "\r\n   "）
function generateRandomBase64Multiline(n) {
  const encoded = crypto.randomBytes(n).toString('base64');
  const lines = [];
  const lineLen = 72;
  for (let i = 0; i < encoded.length; i += lineLen) {
    lines.push(encoded.slice(i, Math.min(i + lineLen, encoded.length)));
  }
  return lines.join('\r\n   ');
}

// Message-ID: UUID v4（upper=true 大写）
function messageIDUUIDv4(upper) {
  const b = crypto.randomBytes(16);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const hex = b.toString('hex');
  const s = `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20,32)}`;
  return upper ? s.toUpperCase() : s;
}

// Message-ID: UUID v1（时间型）
function messageIDUUIDv1() {
  const GREGORIAN_OFFSET = 122192928000000000n;
  const nowNs = BigInt(Date.now()) * 1000000n; // ms→ns
  const ts = (nowNs / 100n) + GREGORIAN_OFFSET;
  const timeLow  = Number(ts & 0xFFFFFFFFn);
  const timeMid  = Number((ts >> 32n) & 0xFFFFn);
  const timeHiVer = Number((ts >> 48n) & 0x0FFFn) | 0x1000; // version 1

  const rb = crypto.randomBytes(8);
  const clockSeq = (((rb[0] << 8) | rb[1]) & 0x3FFF) | 0x8000; // variant 10xx
  const node = Buffer.from(rb.slice(2, 8));
  node[0] |= 0x01; // 组播位

  const hex4 = (n) => n.toString(16).padStart(4, '0');
  const hex8 = (n) => (n >>> 0).toString(16).padStart(8, '0');
  return `${hex8(timeLow)}-${hex4(timeMid)}-${hex4(timeHiVer)}-${hex4(clockSeq)}-${node.toString('hex')}`;
}

// Message-ID: 混合大小写字母数字随机 n 字符
function messageIDRandAlnum(n) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const b = crypto.randomBytes(n);
  let out = '';
  for (let i = 0; i < n; i++) out += alphabet.charAt(b[i] % alphabet.length);
  return out;
}

// base64url 无 padding
function _base64URLNoPad(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

// ═════════════════════════════════════════════════════════════
// 格式化 helpers
// ═════════════════════════════════════════════════════════════

const _DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const _MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const JST_OFFSET_MIN = 9 * 60; // +540

function _pad(n, w) { return String(n).padStart(w, '0'); }

// 强制转 JST 显示（不依赖服务器本地 TZ）
function _dateInJST(d) {
  return new Date(d.getTime() + JST_OFFSET_MIN * 60000);
}

// "Mon, 02 Jan 2006 15:04:05 +0900"（tOffMin 分钟偏移，默认 JST）
function _formatRFC2822Local(d, tzOffMin) {
  const adj = new Date(d.getTime() + tzOffMin * 60000);
  const day = _DAYS[adj.getUTCDay()];
  const dd = _pad(adj.getUTCDate(), 2);
  const mon = _MONTHS[adj.getUTCMonth()];
  const yyyy = adj.getUTCFullYear();
  const HH = _pad(adj.getUTCHours(), 2);
  const MM = _pad(adj.getUTCMinutes(), 2);
  const SS = _pad(adj.getUTCSeconds(), 2);
  const sign = tzOffMin >= 0 ? '+' : '-';
  const abs = Math.abs(tzOffMin);
  const oh = _pad(Math.floor(abs / 60), 2);
  const om = _pad(abs % 60, 2);
  return `${day}, ${dd} ${mon} ${yyyy} ${HH}:${MM}:${SS} ${sign}${oh}${om}`;
}

function formatReceivedJSTDate(d) {
  return _formatRFC2822Local(d, JST_OFFSET_MIN);
}

function formatReceivedJSTDateWithJST(d) {
  return _formatRFC2822Local(d, JST_OFFSET_MIN) + ' (JST)';
}

// 17 位时间戳 yyyyMMddHHmmssfff（应先转 JST）
function format17Timestamp(d) {
  const adj = new Date(d.getTime() + JST_OFFSET_MIN * 60000);
  return `${adj.getUTCFullYear()}${_pad(adj.getUTCMonth()+1,2)}${_pad(adj.getUTCDate(),2)}` +
         `${_pad(adj.getUTCHours(),2)}${_pad(adj.getUTCMinutes(),2)}${_pad(adj.getUTCSeconds(),2)}` +
         `${_pad(adj.getUTCMilliseconds(),3)}`;
}

function random4UpperLetters(rng) {
  let out = '';
  for (let i = 0; i < 4; i++) out += String.fromCharCode(65 + randSafe.safeIntn(rng, 26));
  return out;
}

function random5Digits(rng) {
  return _pad(randSafe.safeIntn(rng, 100000), 5);
}

function random11AlphaNumUpper(rng) {
  const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let out = '';
  for (let i = 0; i < 11; i++) out += charset.charAt(randSafe.safeIntn(rng, charset.length));
  return out;
}

// sprintf-like %d / %04d / %03d 填充（用于 yahooByPool 模板）
function _fmtNum(tpl, num) {
  return tpl.replace(/%(0?)(\d*)d/, (m, zero, width) => {
    const w = width ? parseInt(width, 10) : 0;
    const s = String(num);
    return zero && s.length < w ? s.padStart(w, '0') : s;
  });
}

// ═════════════════════════════════════════════════════════════
// HeaderGenerator 类
// ═════════════════════════════════════════════════════════════
class HeaderGenerator {
  /**
   * @param {Object} cfg - config.headers 子对象
   * @param {number} workerId
   */
  constructor(cfg, workerId) {
    this.cfg = cfg || {};
    this.workerId = workerId | 0;
    this.random = randSafe.cryptoSeed(this.workerId);

    // 伪 DKIM 反指纹环形缓冲区（8 槽，-1 表示空）
    this.dkimRecent = dkimPool.newRecentBuffer();
    this.dkimRecentPosRef = { pos: 0 };

    // Worker 级 50-200 封寿命抽样
    this.headerCurrentSet = [];
    this.headerEmailsLeft = 0;

    // Received（随机）顺序模式索引
    this.receivedRandomSeqIdx = 0;

    // Message-ID 计数类风格用的独立计数器
    this.messageIDSeqIdx = 0;

    // List-Unsubscribe 三套模板池各自独立顺序索引
    this.listUnsubRealSeqIdx = 0;
    this.listUnsubCustomSeqIdx = 0;
    this.listUnsubRandomSeqIdx = 0;
  }

  // ─────────────────────────────────────────────────────────────
  // GenerateHeaders 主入口（不含 Received / DKIM / Message-ID，那些由 builder 单独处理）
  // ─────────────────────────────────────────────────────────────
  generateHeaders(fromAddress, toAddress, domain, vp, recipient) {
    if (!this.cfg || !this.cfg.enabled) return '';
    const parts = [];

    if (this.cfg.reply_to) {
      parts.push(`Reply-To: ${this._getReplyToAddress(fromAddress, domain)}\r\n`);
    }
    if (this.cfg.return_path) {
      parts.push(`Return-Path: <${this._getReturnPathAddress(fromAddress, domain)}>\r\n`);
    }
    if (this.cfg.x_mailer) {
      parts.push(`X-Mailer: ${xmailer.getRandomXMailer(this.random)}\r\n`);
    }
    if (this.cfg.x_priority) {
      parts.push(`X-Priority: ${this._getXPriorityValue()}\r\n`);
    }
    if (this.cfg.importance) {
      parts.push(`Importance: ${this._getImportanceValue()}\r\n`);
    }
    if (this.cfg.accept_language) {
      parts.push(`Accept-Language: ${this._getAcceptLanguageValue()}\r\n`);
    }
    if (this.cfg.content_language) {
      parts.push(`Content-Language: ${this._getContentLanguageValue()}\r\n`);
    }

    // 扩展头（P0 强制 + P1/P2/P3 抽样）
    let emitDomain = domain;
    const at = fromAddress.lastIndexOf('@');
    if (at >= 0 && at < fromAddress.length - 1) emitDomain = fromAddress.slice(at + 1);
    parts.push(this._emitExtendedHeaders(emitDomain, vp, recipient));

    return parts.join('');
  }

  // ─────────────────────────────────────────────────────────────
  // Received 头（1/2/3 hop 加权抽样）
  // ─────────────────────────────────────────────────────────────
  generateReceived(fromAddress, toAddress, domain) {
    void fromAddress;
    const now = new Date();
    const tlsVersion = this._randomChoice(['TLS1_2,', 'TLS1_3,']);
    const cipher = this._randomChoice(tlsCiphers);

    // hop 加权抽样：1 hop 20% / 2 hop 50% / 3 hop 30%
    const r = randSafe.safeIntn(this.random, 100);
    let hopCount;
    if (r < 20) hopCount = 1;
    else if (r < 70) hopCount = 2;
    else hopCount = 3;

    // 时序链：times[0]=top=now，每往下减 1-30 秒
    const times = new Array(hopCount);
    times[0] = now;
    for (let i = 1; i < hopCount; i++) {
      const deltaSec = randSafe.safeIntn(this.random, 29) + 1;
      times[i] = new Date(times[i-1].getTime() - deltaSec * 1000);
    }

    const clientDomain = this._generateRandomDomain();
    const clientIP = this._generateRandomIPRealistic();
    const username = this._generateRandomUsername();

    if (hopCount === 1) {
      return _formatReceivedClientSubmit(
        clientDomain, clientIP, username, domain,
        domain, this._randomChoice(mailServerSoftware), this._generateMailID(),
        toAddress, tlsVersion, cipher, now
      );
    }

    const internalDomain = this._generateRandomDomain();
    const internalIP = this._generateRandomIPRealistic();
    let relayDomain = '', relayIP = '';
    if (hopCount === 3) {
      relayDomain = this._generateRandomDomain();
      relayIP = this._generateRandomIPRealistic();
    }

    const chunks = [];
    // top hop
    const topFromDomain = hopCount === 3 ? relayDomain : internalDomain;
    const topFromIP     = hopCount === 3 ? relayIP     : internalIP;
    chunks.push(_formatReceivedMxAccept(
      topFromDomain, topFromIP,
      domain, this._randomChoice(mailServerSoftware), this._generateMailID(),
      toAddress, tlsVersion, cipher, times[0]
    ));

    // middle hop（仅 3 hop）
    if (hopCount === 3) {
      chunks.push(_formatReceivedInternalRelay(
        internalDomain, internalIP,
        relayDomain, relayIP,
        this._generateMailID(),
        toAddress, tlsVersion, cipher, times[1]
      ));
    }

    // bottom hop
    chunks.push(_formatReceivedClientSubmit(
      clientDomain, clientIP, username, domain,
      internalDomain, this._randomChoice(mailServerSoftware), this._generateMailID(),
      toAddress, tlsVersion, cipher, times[hopCount - 1]
    ));

    return chunks.join('');
  }

  // ─────────────────────────────────────────────────────────────
  // DKIM 伪签名
  // ─────────────────────────────────────────────────────────────
  generateDkimSignature(fromAddress, domain) {
    void fromAddress; void domain;

    const picked = dkimPool.pickDkimExternalSource(this.random, this.dkimRecent, this.dkimRecentPosRef);
    const src = picked.source;

    let selector;
    if (src.isSESLike) selector = dkimPool.generateSESLikeSelector(this.random);
    else if (src.selectors && src.selectors.length > 0) {
      selector = src.selectors[randSafe.safeIntn(this.random, src.selectors.length)];
    } else selector = 'default';

    const canonicalization = dkimPool.pickDkimCanonicalization(this.random);
    const hFields = dkimPool.pickDkimHFields(
      this.random, src.domain,
      !!(this.cfg && this.cfg.dkim_h_fields_custom_enabled),
      this.cfg && this.cfg.dkim_h_fields_list
    );
    const bByteCount = dkimPool.dkimSignatureByteCount(src.rsaBits);

    const bh = generateRandomBase64(32);
    const sig = generateRandomBase64Multiline(bByteCount);
    const timestamp = Math.floor(Date.now() / 1000);

    return `DKIM-Signature: v=1; a=rsa-sha256; c=${canonicalization};\r\n` +
           ` d=${src.domain}; s=${selector}; t=${timestamp};\r\n` +
           ` h=${hFields};\r\n` +
           ` bh=${bh};\r\n` +
           ` b=${sig}\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // 扩展头总入口（P0 强制 + P1/P2/P3 抽样）
  // ─────────────────────────────────────────────────────────────
  _emitExtendedHeaders(domain, vp, recipient) {
    const cfg = this.cfg;
    if (!cfg) return '';
    const parts = [];

    // ─ P0 送达刚需 ─
    if (cfg.list_unsubscribe) {
      parts.push(this._getListUnsubscribe(domain, vp, recipient));
    }
    // 真实退订模式自动加 Post（C6 决策）
    if (cfg.list_unsubscribe_post ||
        (cfg.list_unsubscribe && String(cfg.list_unsub_mode || '').trim().toLowerCase() === 'real')) {
      parts.push('List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n');
    }
    if (cfg.list_id) parts.push(this._getListID(domain));
    if (cfg.feedback_id) parts.push(this._getFeedbackID(domain));
    if (cfg.precedence) parts.push(this._getPrecedence());

    // ─ P1/P2/P3 候选池 ─
    const candidates = [];
    for (let i = 0; i < EXTENDED_HEADER_SLOTS.length; i++) {
      if (EXTENDED_HEADER_SLOTS[i].enabled(cfg)) candidates.push(i);
    }
    if (candidates.length === 0) return parts.join('');

    if (!cfg.random_enabled) {
      // 非随机模式：勾了的都加
      for (const idx of candidates) {
        parts.push(EXTENDED_HEADER_SLOTS[idx].generate(this, domain));
      }
      return parts.join('');
    }

    // 随机模式 + Worker 级抽样寿命
    if (this.headerEmailsLeft <= 0 || this.headerCurrentSet.length === 0) {
      this._refreshRandomHeaderSet(candidates);
    }
    this.headerEmailsLeft--;
    for (const idx of this.headerCurrentSet) {
      if (idx >= 0 && idx < EXTENDED_HEADER_SLOTS.length &&
          EXTENDED_HEADER_SLOTS[idx].enabled(cfg)) {
        parts.push(EXTENDED_HEADER_SLOTS[idx].generate(this, domain));
      }
    }
    return parts.join('');
  }

  _refreshRandomHeaderSet(candidates) {
    if (candidates.length === 0) {
      this.headerCurrentSet = [];
      this.headerEmailsLeft = 0;
      return;
    }
    let rmin = this.cfg.random_min || 1;
    let rmax = this.cfg.random_max || 10;
    if (rmin < 1) rmin = 1;
    if (rmax > 10) rmax = 10;
    if (rmax < rmin) rmax = rmin;
    if (rmin > candidates.length) rmin = candidates.length;
    if (rmax > candidates.length) rmax = candidates.length;

    let n;
    if (rmin === rmax) n = rmin;
    else n = rmin + randSafe.safeIntn(this.random, rmax - rmin + 1);
    if (n > candidates.length) n = candidates.length;
    if (n < 0) n = 0;

    // 部分 Fisher-Yates 抽 n 个
    const pool = candidates.slice();
    for (let i = 0; i < n; i++) {
      const j = i + randSafe.safeIntn(this.random, pool.length - i);
      const tmp = pool[i]; pool[i] = pool[j]; pool[j] = tmp;
    }
    this.headerCurrentSet = pool.slice(0, n);
    this.headerEmailsLeft = HEADER_RANDOM_LIFESPAN_MIN + randSafe.safeIntn(this.random, HEADER_RANDOM_LIFESPAN_GAP);
  }

  // ─────────────────────────────────────────────────────────────
  // Message-ID
  // ─────────────────────────────────────────────────────────────
  generateCustomMessageID(domain) {
    if (!domain) domain = '';
    const at = domain.indexOf('@');
    if (at !== -1) domain = domain.slice(at + 1);

    let candidates = messageIDStyleKeys;
    if (this.cfg && !this.cfg.message_id_random_all &&
        Array.isArray(this.cfg.message_id_styles) && this.cfg.message_id_styles.length > 0) {
      const sel = new Set(this.cfg.message_id_styles.map((s) => String(s).trim()));
      const filtered = [];
      for (const k of messageIDStyleKeys) if (sel.has(k)) filtered.push(k);
      if (filtered.length > 0) candidates = filtered;
    }
    const key = candidates[randSafe.safeIntn(this.random, candidates.length)];
    return this._buildMessageIDByStyle(key, domain);
  }

  _buildMessageIDByStyle(key, d) {
    const now = new Date();
    // 强制 JST，与 Go 版 time.FixedZone("JST", 9*3600) 对齐，不依赖服务器本地 TZ
    // 用于 ts_uuid_counter / readable_ts / enterprise_multiseg 的 y/m/d/H/M/S/ms 字段
    // now.getTime() 保持 epoch ms（时区无关）用于 javamail / ms_ts_hex / enterprise_multiseg / epoch_counter
    const jst = _dateInJST(now);
    switch (key) {
      case 'uuid_v4_lower': return `${messageIDUUIDv4(false)}@${d}`;
      case 'hex32':         return `${randomHexString(32)}@${d}`;
      case 'javamail': {
        this.messageIDSeqIdx++;
        const num = 1000000000 + randSafe.safeIntn(this.random, 9000000000);
        return `${num}.${this.messageIDSeqIdx}.${now.getTime()}@${d}`;
      }
      case 'uuid_v4_upper': return `${messageIDUUIDv4(true)}@${d}`;
      case 'ts_uuid_counter': {
        this.messageIDSeqIdx++;
        const ymdT = `${jst.getUTCFullYear()}${_pad(jst.getUTCMonth()+1,2)}${_pad(jst.getUTCDate(),2)}t` +
                     `${_pad(jst.getUTCHours(),2)}${_pad(jst.getUTCMinutes(),2)}${_pad(jst.getUTCSeconds(),2)}`;
        return `${ymdT}-${messageIDUUIDv4(false)}-${_pad(this.messageIDSeqIdx, 6)}@${d}`;
      }
      case 'base64url': {
        const b = crypto.randomBytes(16);
        return `${_base64URLNoPad(b)}@${d}`;
      }
      case 'readable_ts': {
        const ms3 = _pad(jst.getUTCMilliseconds(), 3);
        const ts17 = `${jst.getUTCFullYear()}${_pad(jst.getUTCMonth()+1,2)}${_pad(jst.getUTCDate(),2)}` +
                     `${_pad(jst.getUTCHours(),2)}${_pad(jst.getUTCMinutes(),2)}${_pad(jst.getUTCSeconds(),2)}${ms3}`;
        return `${ts17}.${randomHexString(4)}@${d}`;
      }
      case 'uuid_seq':
        this.messageIDSeqIdx++;
        return `${messageIDUUIDv4(false)}.${this.messageIDSeqIdx}@${d}`;
      case 'hex40': return `${randomHexString(40)}@${d}`;
      case 'hex_underscore':
        return `${randomHexString(13)}_${randomHexString(13)}@${d}`;
      case 'ms_ts_hex':
        return `${now.getTime()}.${randomHexString(12)}@${d}`;
      case 'uuid_v1': return `${messageIDUUIDv1()}@${d}`;
      case 'biz_prefix':
        return `${this._randomChoice(messageIDBizPrefixes)}_${randomHexString(32)}@${d}`;
      case 'hex64': return `${randomHexString(64)}@${d}`;
      case 'enterprise_multiseg': {
        this.messageIDSeqIdx++;
        const ymd = `${jst.getUTCFullYear()}${_pad(jst.getUTCMonth()+1,2)}${_pad(jst.getUTCDate(),2)}`;
        return `${now.getTime()}.${ymd}.${this._randomChoice(messageIDPlatformLabels)}.` +
               `${this.messageIDSeqIdx}.${_pad(randSafe.safeIntn(this.random, 1000000), 6)}.` +
               `${_pad(randSafe.safeIntn(this.random, 1000000), 6)}@${d}`;
      }
      case 'epoch_counter': {
        const sec = Math.floor(now.getTime() / 1000);
        return `${sec}.${_pad(randSafe.safeIntn(this.random, 100000000), 8)}@${d}`;
      }
      case 'bigint_hex': {
        // Go 用 Int63() 返回 int64 正随机；JS 用 crypto 生成 8 字节转 BigInt（保正）
        const b = crypto.randomBytes(8);
        b[0] &= 0x7F; // clear sign
        const bi = BigInt('0x' + b.toString('hex'));
        return `${bi.toString()}.${randomHexString(8)}@${d}`;
      }
      case 'mixed_alnum': {
        const n = 32 + randSafe.safeIntn(this.random, 9); // 32-40
        return `${messageIDRandAlnum(n)}@${d}`;
      }
      case 'compact_date_ns': {
        const ymd = `${jst.getUTCFullYear()}${_pad(jst.getUTCMonth()+1,2)}${_pad(jst.getUTCDate(),2)}`;
        // 用 hrtime 拿纳秒余量（模拟 UnixNano%1e12）
        const ns = process.hrtime.bigint() % 1000000000000n;
        return `${ymd}${_pad(Number(ns), 12)}${randomHexString(6)}@${d}`;
      }
      case 'tag_uuid':
        return `${this._randomChoice(messageIDTags)}-${messageIDUUIDv4(false)}@${d}`;
      case 'ns_hex': {
        const ns = BigInt(now.getTime()) * 1000000n + (process.hrtime.bigint() % 1000000n);
        return `${ns.toString()}.${randomHexString(12)}@${d}`;
      }
      case 'hex16': return `${randomHexString(16)}@${d}`;
      case 'exim': {
        const part1 = randomHexString(7).toUpperCase();
        const part2 = randomHexString(6).toUpperCase();
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let last = '';
        for (let i = 0; i < 2; i++) last += letters.charAt(randSafe.safeIntn(this.random, 26));
        return `E1${part1}-${part2}-${last}@${d}`;
      }
      case 'sendmail': {
        const ts14 = `${jst.getUTCFullYear()}${_pad(jst.getUTCMonth()+1,2)}${_pad(jst.getUTCDate(),2)}` +
                     `${_pad(jst.getUTCHours(),2)}${_pad(jst.getUTCMinutes(),2)}${_pad(jst.getUTCSeconds(),2)}`;
        return `${ts14}.${randomHexString(6)}@${d}`;
      }
      case 'becky': {
        const b = crypto.randomBytes(4);
        return `${b[0].toString(16).toUpperCase().padStart(2,'0')}.` +
               `${b[1].toString(16).toUpperCase().padStart(2,'0')}.` +
               `${b[2].toString(16).toUpperCase().padStart(2,'0')}.` +
               `${b[3].toString(16).toUpperCase().padStart(2,'0')}@${d}`;
      }
      default: {
        // 未知 key 兜底：纳秒风
        const ns = BigInt(now.getTime()) * 1000000n + (process.hrtime.bigint() % 1000000n);
        return `${ns.toString()}.${randomHexString(12)}@${d}`;
      }
    }
  }

  // ─────────────────────────────────────────────────────────────
  // P0 组
  // ─────────────────────────────────────────────────────────────

  _getListUnsubscribe(domain, vp, recipient) {
    const mode = String(this.cfg.list_unsub_mode || '').trim().toLowerCase();
    if (mode === 'real') {
      const s = this._renderListUnsubFromPool(this.cfg.list_unsub_real_templates, this.cfg.list_unsub_real_mode,
                                              'listUnsubRealSeqIdx', vp, recipient);
      if (s) return s;
    } else if (mode === 'custom') {
      const s = this._renderListUnsubFromPool(this.cfg.list_unsub_custom_templates, this.cfg.list_unsub_custom_mode,
                                              'listUnsubCustomSeqIdx', vp, recipient);
      if (s) return s;
    } else if (mode === 'random') {
      const s = this._renderListUnsubFromPool(this.cfg.list_unsub_random_templates, this.cfg.list_unsub_random_mode,
                                              'listUnsubRandomSeqIdx', vp, recipient);
      if (s) return s;
    }
    // default 或池空兜底
    const token = randomHexString(16);
    return `List-Unsubscribe: <mailto:unsubscribe-${token}@${domain}>\r\n`;
  }

  _renderListUnsubFromPool(tpls, mode, seqField, vp, recipient) {
    if (!tpls || tpls.length === 0 || !vp || !recipient) return '';
    let tpl;
    const n = tpls.length;
    if (String(mode || '').trim().toLowerCase() === 'sequential') {
      tpl = tpls[this[seqField] % n];
      this[seqField]++;
    } else {
      tpl = tpls[randSafe.safeIntn(this.random, n)];
    }
    tpl = String(tpl || '').trim();
    if (!tpl) return '';
    const rendered = vp.process(tpl, recipient);
    const folded = foldMod.foldHeaderValue(rendered, 'List-Unsubscribe: '.length);
    return `List-Unsubscribe: ${folded}\r\n`;
  }

  _getListID(domain) {
    const prefixes = ['newsletter', 'promo', 'notification', 'list', 'campaign', 'updates'];
    return `List-ID: <${this._randomChoice(prefixes)}.${domain}>\r\n`;
  }

  _getFeedbackID(domain) {
    const campaign = 100000 + randSafe.safeIntn(this.random, 900000);
    const categories = ['newsletter', 'promo', 'tx', 'campaign'];
    const cat = this._randomChoice(categories);
    const senderID = randomHexString(8);
    return `Feedback-ID: ${campaign}:${domain}:${cat}:${senderID}\r\n`;
  }

  _getPrecedence() {
    const choices = ['bulk', 'list', 'auto_reply', 'junk'];
    return `Precedence: ${this._randomChoice(choices)}\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // P1 组
  // ─────────────────────────────────────────────────────────────

  _getErrorsTo(domain) {
    return `Errors-To: bounce-${randomHexString(12)}@${domain}\r\n`;
  }

  _getSender(domain) {
    const prefixes = ['noreply', 'mailer', 'no-reply', 'info', 'newsletter', 'notify'];
    return `Sender: ${this._randomChoice(prefixes)}@${domain}\r\n`;
  }

  _getOrganization() {
    const orgs = [
      'Customer Service', 'Marketing Department', 'Notifications',
      'Mail Service', 'Newsletter Team', 'Support Team',
      'Communications', 'Member Services', 'Contact Center',
      'Online Service', 'Account Service', 'Promotions',
    ];
    return `Organization: ${this._randomChoice(orgs)}\r\n`;
  }

  _getXOriginatingIP() {
    return `X-Originating-IP: [${this._generateRandomIPRealistic()}]\r\n`;
  }

  _getComments() {
    const comments = [
      'Authenticated sender',
      'Mass mailer notification',
      'Subscriber notification',
      'Promotional email',
      'Automated delivery',
      'Transactional notification',
    ];
    return `Comments: ${this._randomChoice(comments)}\r\n`;
  }

  _getKeywords() {
    const sets = [
      'newsletter, promotion',
      'notification, account',
      'marketing, offer',
      'announcement, update',
      'transactional',
      'campaign, news',
    ];
    return `Keywords: ${this._randomChoice(sets)}\r\n`;
  }

  _getXReportAbuse(domain) {
    return `X-Report-Abuse: Please report abuse to abuse@${domain}\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // P2 Outlook / 行为标识 / P3 营销
  // ─────────────────────────────────────────────────────────────

  _getXMSMailPriority() {
    return `X-MSMail-Priority: ${this._randomChoice(['High', 'Normal', 'Low'])}\r\n`;
  }

  _getThreadIndex() {
    const n = 22 + randSafe.safeIntn(this.random, 9);
    const b = Buffer.alloc(n);
    for (let i = 0; i < n; i++) b[i] = randSafe.safeIntn(this.random, 256);
    return `Thread-Index: ${b.toString('base64')}\r\n`;
  }

  _getThreadTopic() {
    const topics = ['Information', 'Notification', 'Important Update', 'Newsletter',
                    'Service Update', 'Account Activity', 'Subscription'];
    return `Thread-Topic: ${this._randomChoice(topics)}\r\n`;
  }

  _getXAutoResponseSuppress() {
    const choices = ['OOF', 'AutoReply', 'All', 'DR', 'NRN', 'RN'];
    return `X-Auto-Response-Suppress: ${this._randomChoice(choices)}\r\n`;
  }

  _getReturnReceiptTo(domain) {
    const prefixes = ['noreply', 'receipt', 'delivery'];
    return `Return-Receipt-To: <${this._randomChoice(prefixes)}@${domain}>\r\n`;
  }

  _getDispositionNotificationTo(domain) {
    const prefixes = ['noreply', 'read-receipt', 'notification'];
    return `Disposition-Notification-To: <${this._randomChoice(prefixes)}@${domain}>\r\n`;
  }

  _getXCampaignID() {
    return `X-Campaign-ID: cmp-${randomHexString(8)}\r\n`;
  }

  _getXMailerLID() {
    return `X-Mailer-LID: lid-${_pad(randSafe.safeIntn(this.random, 1000000), 6)}\r\n`;
  }

  _getCampaignID() {
    return `Campaign-ID: ${_pad(randSafe.safeIntn(this.random, 1000000), 6)}\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // 联动组
  // ─────────────────────────────────────────────────────────────

  _getXTMASGroup() {
    const productVer = 'IMSS-9.1.0.1195-8.1.0.1062-29286.002';
    let gconf = '00';
    if (randSafe.safeIntn(this.random, 10) === 0) gconf = '01';
    const score = 5.0 + this.random() * 5.0;
    const matchedRID = generateRandomBase64Multiline(256);
    const snap1 = 800000 + randSafe.safeIntn(this.random, 200000);
    const snap2 = randSafe.safeIntn(this.random, 10000);
    const snapN = 1 + randSafe.safeIntn(this.random, 50);
    const snapM = 1 + randSafe.safeIntn(this.random, 50);
    const snapK = 1 + randSafe.safeIntn(this.random, 50);
    return `X-TM-AS-GCONF: ${gconf}\r\n` +
           `X-TM-AS-Product-Ver: ${productVer}\r\n` +
           `X-TMASE-Version: ${productVer}\r\n` +
           `X-TMASE-Result: 10--${score.toFixed(6)}-10.000000\r\n` +
           `X-TMASE-MatchedRID: ${matchedRID}\r\n` +
           `X-TMASE-SNAP-Result: 1.${snap1}.${_pad(snap2,4)}-0-1-${snapN}:0,${snapM}:0,${snapK}:0-0\r\n`;
  }

  _getXSFMCGroup() {
    const stack = 1 + randSafe.safeIntn(this.random, 7);
    const job1 = 7000000 + randSafe.safeIntn(this.random, 1000000);
    const job2 = 2000000 + randSafe.safeIntn(this.random, 1000000);
    return `X-SFMC-Stack: ${stack}\r\n` +
           `x-job: ${job1}_${job2}\r\n`;
  }

  _getXBarracudaGroup() {
    const connectDomain = this._generateRandomDomain();
    const connectIP = this._generateRandomIPRealistic();
    const sourceIP = this._generateRandomIPRealistic();
    const startTime = Math.floor(Date.now() / 1000);
    const port = 8000 + randSafe.safeIntn(this.random, 1000);
    const spamScore = this.random() * 2.0;
    const scanTimeFrac = randSafe.safeIntn(this.random, 100);
    return `X-Barracuda-Connect: ${connectDomain}[${connectIP}]\r\n` +
           `X-Barracuda-Start-Time: ${startTime}\r\n` +
           `X-Barracuda-URL: https://${connectIP}:${port}/cgi-mod/markup.cgi\r\n` +
           `X-Barracuda-Apparent-Source-IP: ${sourceIP}\r\n` +
           `X-Barracuda-Spam-Score: ${spamScore.toFixed(2)}\r\n` +
           `X-Barracuda-Spam-Status: No, SCORE=${spamScore.toFixed(2)} using global-scores tests=BSF_SC0_MISMATCH_TO autolearn=disabled scantime=0.${_pad(scanTimeFrac,2)}\r\n`;
  }

  _getXProofpointGroup() {
    const engineMain = 10000 + randSafe.safeIntn(this.random, 1000);
    const engineSub1 = 100 + randSafe.safeIntn(this.random, 900);
    const engineSub2 = 100 + randSafe.safeIntn(this.random, 900);
    const score = randSafe.safeIntn(this.random, 101);
    const suspect = randSafe.safeIntn(this.random, 21);
    const guid = randomHexString(32).toUpperCase();
    const origGuid = randomHexString(32).toUpperCase();
    return `X-Proofpoint-Virus-Version: vendor=fsecure engine=2.50.${engineMain}:6.0.${engineSub1}, 1.0.${engineSub2}, db=signed\r\n` +
           `X-Proofpoint-Spam-Details: rule=outbound_notspam policy=outbound score=${score} suspectscore=${suspect} spamscore=0 malwarescore=0 phishscore=0 lowpriorityscore=0 mlxscore=0 adultscore=0 mlxlogscore=0 classifier=spam adjust=0 reason=mlx scancount=1 engineversion=8.0.1-2202160000 definitions=main-2202170025\r\n` +
           `X-Proofpoint-GUID: ${guid}\r\n` +
           `X-Proofpoint-ORIG-GUID: ${origGuid}\r\n`;
  }

  _getXMimecastGroup() {
    const score = this.random() * 10.0;
    const spamSig = generateRandomBase64(24);
    const bulkSig = randomHexString(32);
    return `X-Mimecast-Spam-Score: ${score.toFixed(2)}\r\n` +
           `X-Mimecast-Spam-Signature: ${spamSig}\r\n` +
           `X-Mimecast-Bulk-Signature: ${bulkSig}\r\n` +
           'X-Mimecast-Impersonation-Protect: Policy=Outbound; Similar Internal Domain=false; Similar Monitored External Domain=false; Custom External Domain=false; Mimecast External Domain=false; Newly Observed Domain=false; Internal User Name=false; Reply-to Address Mismatch=false; Targeted Threat Dictionary=false; Mimecast Threat Dictionary=false; Custom Threat Dictionary=false\r\n';
  }

  _getXSymantecGroup() {
    const cmaeScore = this.random() * 3.0;
    const cv = generateRandomBase64(24);
    const c = 100 + randSafe.safeIntn(this.random, 100);
    const a = randomHexString(32);
    const rulesN = randSafe.safeIntn(this.random, 10);
    const rulesM = randSafe.safeIntn(this.random, 10);
    return `X-CMAE-Score: ${cmaeScore.toFixed(2)}\r\n` +
           `X-CMAE-Analysis: v=2.4 cv=${cv} c=${c} a=${a}\r\n` +
           'X-MessageSniffer-Scan-Result: 0\r\n' +
           `X-MessageSniffer-Rules: 0-0-0-${rulesN}-${rulesM}\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // v2 5 独立头
  // ─────────────────────────────────────────────────────────────

  _getXOriginatingEmail(domain) {
    const prefixes = ['noreply', 'sender', 'mailer', 'notify', 'info'];
    return `X-Originating-Email: [${this._randomChoice(prefixes)}@${domain}]\r\n`;
  }

  _getXMimeOLE() {
    const versions = [
      'Produced By Microsoft MimeOLE V6.00.2900.6157',
      'Produced By Microsoft MimeOLE V6.00.2900.6109',
      'Produced By Microsoft MimeOLE V6.00.2900.3138',
      'Produced By Microsoft MimeOLE V6.00.2900.2180',
      'Produced By Microsoft Exchange V14.0.694.0',
      'Produced By Microsoft Exchange V15.0.4569.1503',
    ];
    return `X-MimeOLE: ${this._randomChoice(versions)}\r\n`;
  }

  _getXMailerVersion() {
    const versions = [
      '16.0.5505.1000',
      '15.0.4569.1503',
      '14.0.7268.5000',
      '12.0.6612.1000',
      '16.0.16327.20214',
      '16.0.14931.20648',
    ];
    return `X-Mailer-Version: ${this._randomChoice(versions)}\r\n`;
  }

  _getXOriginalArrivalTime() {
    const now = new Date();
    const monthStr = _MONTHS[now.getUTCMonth()];
    // 用 crypto 生成两个 uint32
    const b = crypto.randomBytes(8);
    const high = b.readUInt32BE(0);
    const low = b.readUInt32BE(4);
    const hex8 = (n) => (n >>> 0).toString(16).toUpperCase().padStart(8, '0');
    return `X-OriginalArrivalTime: ${_pad(now.getUTCDate(),2)} ${monthStr} ${now.getUTCFullYear()} ` +
           `${_pad(now.getUTCHours(),2)}:${_pad(now.getUTCMinutes(),2)}:${_pad(now.getUTCSeconds(),2)}.0000 (UTC) ` +
           `FILETIME=[${hex8(high)}:${hex8(low)}]\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // X-Priority / Importance / Reply-To / Return-Path / Language
  // ─────────────────────────────────────────────────────────────

  _getXPriorityValue() {
    const val = this.cfg.x_priority_value;
    switch (val) {
      case '1 (Highest)': return '1';
      case '2 (High)':    return '2';
      case '3 (Normal)':  return '3';
      default:            return this._randomChoice(['1', '2', '3']);
    }
  }

  _getImportanceValue() {
    const val = this.cfg.importance_value;
    if (val === 'high' || val === 'normal' || val === 'low') return val;
    return this._randomChoice(['high', 'normal', 'low']);
  }

  _getReplyToAddress(fromAddress, domain) {
    if (this.cfg.reply_to_mode === 'random_prefix') {
      return this._generateRandomEmailPrefix() + '@' + domain;
    }
    return fromAddress;
  }

  _getReturnPathAddress(fromAddress, domain) {
    if (this.cfg.return_path_mode === 'random_prefix') {
      return this._generateRandomEmailPrefix() + '@' + domain;
    }
    return fromAddress;
  }

  _getAcceptLanguageValue() {
    const val = this.cfg.accept_language_value;
    if (['ja', 'en', 'ja-JP', 'en-US', 'zh-CN'].indexOf(val) !== -1) return val;
    return this._randomChoice(['ja', 'en', 'ja-JP', 'en-US', 'zh-CN']);
  }

  _getContentLanguageValue() {
    const val = this.cfg.content_language_value;
    if (['ja', 'en', 'ja-JP', 'en-US', 'zh-CN'].indexOf(val) !== -1) return val;
    return this._randomChoice(['ja', 'en', 'ja-JP', 'en-US', 'zh-CN']);
  }

  // ─────────────────────────────────────────────────────────────
  // 5 ESP Received
  // ─────────────────────────────────────────────────────────────

  _generateReceivedYahoo(toAddress, useYahooIP, t) {
    void toAddress;
    let ip1, ip2;
    if (useYahooIP) {
      ip1 = randomYahooIP(this.random);
      ip2 = randomYahooIP(this.random);
    } else {
      ip1 = randomPublicIP(this.random);
      ip2 = randomPublicIP(this.random);
    }
    const ehloSub = yahooEhloSubdomains[randSafe.safeIntn(this.random, yahooEhloSubdomains.length)];
    const ehloNum = randSafe.safeIntn(this.random, 600) + 1;
    const ehloDomain = `mta${_pad(ehloNum, 3)}.${ehloSub}.gm.yahoo.co.jp`;
    const byPat = yahooByPool[randSafe.safeIntn(this.random, yahooByPool.length)];
    const byNum = randSafe.safeIntn(this.random, byPat.endNum - byPat.startNum + 1) + byPat.startNum;
    const byDomain = _fmtNum(byPat.template, byNum);
    return `Received: from ${ip1}  (EHLO ${ehloDomain}) (${ip2})\r\n` +
           `  by ${byDomain} with SMTP; ${formatReceivedJSTDate(t)}\r\n`;
  }

  _generateReceivedAu(toAddress, t) {
    const eNum = randSafe.safeIntn(this.random, 99) + 1;
    const eStr = `e${_pad(eNum, 2)}`;
    const mtaSndDomain = `mta-snd-${eStr}.au.com`;
    const timestamp17 = format17Timestamp(t);
    const letters4 = random4UpperLetters(this.random);
    const digits5 = random5Digits(this.random);
    const idStr = `${timestamp17}.${letters4}.${digits5}.mail.au.com@${mtaSndDomain}`;
    let out = `Received: from mail.au.com by ${mtaSndDomain} with ESMTP\r\n`;
    out += `  id <${idStr}>\r\n`;
    if (toAddress) out += `  for <${toAddress}>;\r\n`;
    out += `  ${formatReceivedJSTDate(t)}\r\n`;
    return out;
  }

  _generateReceivedSoftbank(toAddress, t) {
    const indent = '          '; // 10 空格
    const ebmkyNum = randSafe.safeIntn(this.random, 50) + 101;
    const dimkyScNum = randSafe.safeIntn(this.random, 50) + 101;
    const dimkySbNum = randSafe.safeIntn(this.random, 50) + 101;
    const ebmkyDomain = `ebmky${_pad(ebmkyNum,3)}sc.i.softbank.jp`;
    const dimkyScDomain = `dimky${_pad(dimkyScNum,3)}sc.i.softbank.jp`;
    const dimkySbDomain = `dimky${_pad(dimkySbNum,3)}sb.mailsv.softbank.jp`;
    const ip = randomSoftbank172IP(this.random);
    const timestamp17 = format17Timestamp(t);
    const letters4 = random4UpperLetters(this.random);
    const digits5 = random5Digits(this.random);
    const idStr = `${timestamp17}.${letters4}.${digits5}.${dimkyScDomain}@${dimkySbDomain}`;
    let out = `Received: from ${ebmkyDomain} ([${ip}])\r\n`;
    out += `${indent}by ${dimkyScDomain} with ESMTP\r\n`;
    out += `${indent}id <${idStr}>\r\n`;
    if (toAddress) out += `${indent}for <${toAddress}>; ${formatReceivedJSTDate(t)}\r\n`;
    else           out += `${indent}${formatReceivedJSTDate(t)}\r\n`;
    return out;
  }

  _generateReceivedDocomo(toAddress, t) {
    const mailNum = randSafe.safeIntn(this.random, 10) + 1;
    const mailDomain = `mail${mailNum}.docomo-bill.ne.jp`;
    const queueID = random11AlphaNumUpper(this.random);
    let out = `Received: from ${mailDomain} (localhost [127.0.0.1])\r\n`;
    out += ` by localhost.docomo.ne.jp (Postfix) with ESMTP id ${queueID}\r\n`;
    if (toAddress) out += ` for <${toAddress}>; ${formatReceivedJSTDateWithJST(t)}\r\n`;
    else           out += ` ${formatReceivedJSTDateWithJST(t)}\r\n`;
    return out;
  }

  _generateReceivedMitsui(t) {
    return `Received: from mail.vpass.ne.jp by mail.smbc.co.jp;\r\n` +
           `   ${formatReceivedJSTDate(t)}\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // GenerateAllReceived - D1 方案 A 拼接
  // 顺序：三井 → docomo → au → softbank → 雅虎 → Received(随机) → 原 Received
  // 时间链：顶 = now(JST)，往下每 hop 减 1-30 秒（原 Received 独立时间）
  // ─────────────────────────────────────────────────────────────
  generateAllReceived(envelopeFrom, envelopeTo, fromDomain, vp, recipient) {
    if (!this.cfg || !this.cfg.enabled) return '';

    const tBase = new Date();
    const generators = [];

    if (this.cfg.received_mitsui) generators.push((t) => this._generateReceivedMitsui(t));
    if (this.cfg.received_docomo) generators.push((t) => this._generateReceivedDocomo(envelopeTo, t));
    if (this.cfg.received_au)     generators.push((t) => this._generateReceivedAu(envelopeTo, t));
    if (this.cfg.received_softbank) generators.push((t) => this._generateReceivedSoftbank(envelopeTo, t));
    if (this.cfg.received_yahoo) {
      const useYahooIP = this.cfg.received_yahoo_ip_mode !== 'random';
      generators.push((t) => this._generateReceivedYahoo(envelopeTo, useYahooIP, t));
    }
    // Received（随机）
    if (this.cfg.received_random_enabled &&
        Array.isArray(this.cfg.received_random_templates) &&
        this.cfg.received_random_templates.length > 0 &&
        vp && recipient) {
      generators.push((_t) => this._generateReceivedRandom(vp, recipient));
    }

    let currentTime = tBase;
    const parts = [];
    for (let i = 0; i < generators.length; i++) {
      if (i > 0) {
        const deltaSec = randSafe.safeIntn(this.random, 30) + 1;
        currentTime = new Date(currentTime.getTime() - deltaSec * 1000);
      }
      parts.push(generators[i](currentTime));
    }

    // 原 Received 独立时间
    if (this.cfg.received) {
      parts.push(this.generateReceived(envelopeFrom, envelopeTo, fromDomain));
    }

    return parts.join('');
  }

  _generateReceivedRandom(vp, recipient) {
    const tpls = this.cfg.received_random_templates;
    const n = tpls.length;
    if (n === 0) return '';
    let tpl;
    if (String(this.cfg.received_random_mode || '').trim().toLowerCase() === 'sequential') {
      tpl = tpls[this.receivedRandomSeqIdx % n];
      this.receivedRandomSeqIdx++;
    } else {
      tpl = tpls[randSafe.safeIntn(this.random, n)];
    }
    tpl = String(tpl || '').trim();
    if (!tpl) return '';
    const rendered = vp.process(tpl, recipient);
    const folded = foldMod.foldHeaderValue(rendered, 'Received: '.length);
    return `Received: ${folded}\r\n`;
  }

  // ─────────────────────────────────────────────────────────────
  // 辅助函数
  // ─────────────────────────────────────────────────────────────
  _randomChoice(arr) {
    if (!arr || arr.length === 0) return '';
    return arr[randSafe.safeIntn(this.random, arr.length)];
  }

  _generateRandomDomain() {
    if (randSafe.safeIntn(this.random, 2) === 0) {
      // 格式1: mail.random.tld
      return `mail.${randomHexString(7)}.${this._randomChoice(domainTLDs)}`;
    }
    // 格式2: smtp.word-suffix.tld
    return `smtp.${this._randomChoice(domainWords)}-${this._randomChoice(domainSuffixes)}.${this._randomChoice(domainTLDs)}`;
  }

  _generateRandomIPRealistic() {
    const validRanges = [[1, 9], [11, 126], [128, 169], [171, 171], [173, 191], [193, 223]];
    const r = validRanges[randSafe.safeIntn(this.random, validRanges.length)];
    const first = randSafe.safeIntn(this.random, r[1] - r[0] + 1) + r[0];
    const second = randSafe.safeIntn(this.random, 255);
    const third = randSafe.safeIntn(this.random, 255);
    const fourth = randSafe.safeIntn(this.random, 254) + 1;
    return `${first}.${second}.${third}.${fourth}`;
  }

  _generateMailID() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let head = '';
    // 8 字符主段
    const b = crypto.randomBytes(8);
    for (let i = 0; i < 8; i++) head += chars.charAt(b[i] % chars.length);
    const dash1 = randomHexString(4).toUpperCase();
    const dash2 = randomHexString(4).toUpperCase();
    const dash3 = randomHexString(4).toUpperCase();
    return `${head}-${dash1}-${dash2}-${dash3}.${randSafe.safeIntn(this.random, 9) + 1}`;
  }

  _generateRandomUsername() {
    const names = [
      'username', 'user', 'mail', 'admin', 'sender', 'client',
      'account', 'mailer', 'webmaster', 'system', 'daemon',
      'notification', 'postmaster', 'mailsystem', 'automated', 'monitor',
    ];
    return `${this._randomChoice(names)}${_pad(randSafe.safeIntn(this.random, 1000), 3)}`;
  }

  _generateRandomEmailPrefix() {
    const prefixes = [
      'noreply', 'no-reply', 'info', 'support', 'admin', 'contact',
      'service', 'notification', 'alert', 'mail', 'system', 'notice',
      'account', 'security', 'verify', 'update', 'billing', 'help',
    ];
    let prefix = this._randomChoice(prefixes);
    if (randSafe.safeIntn(this.random, 3) === 0) {
      prefix = `${prefix}${randSafe.safeIntn(this.random, 100)}`;
    }
    return prefix;
  }
}

// ═════════════════════════════════════════════════════════════
// Received 格式化函数（模块级）
// ═════════════════════════════════════════════════════════════

function _formatReceivedClientSubmit(fromDomain, fromIP, user, userDomain,
                                     byDomain, software, mailID, toAddress, tls, cipher, t) {
  return `Received: from ${fromDomain} ([${fromIP}])\r\n` +
         ` (Authenticated sender: ${user}@${userDomain})\r\n` +
         ` by ${byDomain} (${software}) with ESMTPSA id ${mailID}\r\n` +
         ` for <${toAddress}>;\r\n` +
         ` ${tls} ${cipher} ${formatReceivedJSTDate(t)}\r\n`;
}

function _formatReceivedInternalRelay(fromDomain, fromIP, byDomain, byIP,
                                      mailID, toAddress, tls, cipher, t) {
  return `Received: from ${fromDomain} (${fromDomain} [${fromIP}])\r\n` +
         ` by ${byDomain} ([${byIP}]) with ESMTP id ${mailID}\r\n` +
         ` for <${toAddress}>;\r\n` +
         ` ${tls} ${cipher} ${formatReceivedJSTDate(t)}\r\n`;
}

function _formatReceivedMxAccept(fromDomain, fromIP, byDomain, software, mailID,
                                 toAddress, tls, cipher, t) {
  return `Received: from ${fromDomain} ([${fromIP}])\r\n` +
         ` by ${byDomain} (${software}) with ESMTPS id ${mailID}\r\n` +
         ` for <${toAddress}>;\r\n` +
         ` ${tls} ${cipher} ${formatReceivedJSTDate(t)}\r\n`;
}

// ═════════════════════════════════════════════════════════════
// 扩展头 slot 注册表（26 个候选）
// 每个 slot: { enabled(cfg) → bool, generate(hg, domain) → string }
// 顺序对齐 Go extendedHeaderSlots
// ═════════════════════════════════════════════════════════════
const EXTENDED_HEADER_SLOTS = [
  // P1 (9)
  { enabled: (c) => c.errors_to,      generate: (h, d) => h._getErrorsTo(d) },
  { enabled: (c) => c.sender,         generate: (h, d) => h._getSender(d) },
  { enabled: (c) => c.organization,   generate: (h) => h._getOrganization() },
  { enabled: (c) => c.x_originating_ip, generate: (h) => h._getXOriginatingIP() },
  { enabled: (c) => c.auto_submitted, generate: () => 'Auto-Submitted: auto-generated\r\n' },
  { enabled: (c) => c.comments,       generate: (h) => h._getComments() },
  { enabled: (c) => c.keywords,       generate: (h) => h._getKeywords() },
  { enabled: (c) => c.x_report_abuse, generate: (h, d) => h._getXReportAbuse(d) },
  { enabled: (c) => c.x_csa_complaints, generate: () => 'X-CSA-Complaints: whitelist-complaints@eco.de\r\n' },
  // P2 Outlook (4)
  { enabled: (c) => c.x_msmail_priority, generate: (h) => h._getXMSMailPriority() },
  { enabled: (c) => c.thread_index,   generate: (h) => h._getThreadIndex() },
  { enabled: (c) => c.thread_topic,   generate: (h) => h._getThreadTopic() },
  { enabled: (c) => c.x_auto_response_suppress, generate: (h) => h._getXAutoResponseSuppress() },
  // P2 行为 (3)
  { enabled: (c) => c.return_receipt_to, generate: (h, d) => h._getReturnReceiptTo(d) },
  { enabled: (c) => c.disposition_notification_to, generate: (h, d) => h._getDispositionNotificationTo(d) },
  { enabled: (c) => c.x_entity_ref_id, generate: () => `X-Entity-Ref-ID: ${generateGUID()}\r\n` },
  // P3 营销 (3)
  { enabled: (c) => c.x_campaign_id,  generate: (h) => h._getXCampaignID() },
  { enabled: (c) => c.x_mailer_lid,   generate: (h) => h._getXMailerLID() },
  { enabled: (c) => c.campaign_id,    generate: (h) => h._getCampaignID() },
  // P3 联动组 (2)
  { enabled: (c) => c.x_tm_as_group,  generate: (h) => h._getXTMASGroup() },
  { enabled: (c) => c.x_sfmc_group,   generate: (h) => h._getXSFMCGroup() },
  // 4 企业网关联动
  { enabled: (c) => c.x_barracuda_group,  generate: (h) => h._getXBarracudaGroup() },
  { enabled: (c) => c.x_proofpoint_group, generate: (h) => h._getXProofpointGroup() },
  { enabled: (c) => c.x_mimecast_group,   generate: (h) => h._getXMimecastGroup() },
  { enabled: (c) => c.x_symantec_group,   generate: (h) => h._getXSymantecGroup() },
  // v2 5 独立头（list_id 属 P0 单独处理，不进池）
  { enabled: (c) => c.x_originating_email, generate: (h, d) => h._getXOriginatingEmail(d) },
  { enabled: (c) => c.x_mime_ole,     generate: (h) => h._getXMimeOLE() },
  { enabled: (c) => c.x_mailer_version, generate: (h) => h._getXMailerVersion() },
  { enabled: (c) => c.x_original_arrival_time, generate: (h) => h._getXOriginalArrivalTime() },
];

// ═════════════════════════════════════════════════════════════
// exports
// ═════════════════════════════════════════════════════════════
module.exports = {
  HeaderGenerator,
  // 池 / 辅助函数暴露给测试或其他模块
  randomYahooIP,
  randomSoftbank172IP,
  randomPublicIP,
  randomIPInCIDR,
  randomHexString,
  generateGUID,
  generateRandomBase64,
  generateRandomBase64Multiline,
  messageIDUUIDv4,
  messageIDUUIDv1,
  messageIDRandAlnum,
  format17Timestamp,
  formatReceivedJSTDate,
  formatReceivedJSTDateWithJST,
  random4UpperLetters,
  random5Digits,
  random11AlphaNumUpper,
  // 常量池导出（Sprint 3D 模板池会用到）
  messageIDStyleKeys,
  tlsCiphers,
  domainTLDs,
  domainWords,
  domainSuffixes,
  mailServerSoftware,
  yahooEhloSubdomains,
  yahooByPool,
  yahooNets,
  nonRoutableNets,
  softbank172Net,
};
