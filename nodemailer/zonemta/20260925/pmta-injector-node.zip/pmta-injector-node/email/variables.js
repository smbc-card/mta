'use strict';
// email/variables - 变量处理器（对应 Go pmta-injector-clean/email/variables.go）
//
// 30+ 基础变量类别：
//   1. 时间变量 14 个（{DATE_TIME}/{DATE}/{DATE_JP}/{WEEKDAY}/...）
//   2. 收件人变量 11 个（{TO_EMAIL}/{TO_USER}/{TO_NAME}/...）+ 自定义字段（8 种模式）
//   3. 发件人变量 4 个（{FROM_EMAIL}/{FROM_USER}/{FROM_DOMAIN}/{FROM_NAME}）
//   4. 随机字符串 11 类（{RANDOM}/{RANDOM_LOWER}/{RANDOM_CN}/{RANDOM_JP}/...）+ 长度参数
//   5. 金额 5 种（{AMOUNT}/{AMOUNT:x-y}/{AMOUNT_JP:...}/{AMOUNT_CN:...}/{AMOUNT_USD:...}）
//   6. IP 变量 4 个（{RANDOM_IP}/{RANDOM_IP_CN}/{RANDOM_IP_JP}/{RANDOM_IP_US}）
//   7. UUID / MD5 4 个（{UUID}/{UUID_SHORT}/{MD5:text}/{MD5_SHORT:text}）
//   8. 自定义变量（{CUSTOM:name} / {CUSTOM:name:seq} / {CUSTOM:name:random}）
//   9. 条件变量（{IF:field=value:trueVal:falseVal}）
//   10. 53 扩展变量 → 由 variables_ext.js::processExtendedVariables 处理
//
// 所有随机源走 vp.random（seedrandom + workerId）—— v62 修复关键设计。
// 所有变量支持大写和小写双形式（如 {TO_EMAIL} 和 {to_email} 都能替换）。

const fs = require('fs');
const randSafe = require('./rand_safe');
const utils = require('../utils/utils');
const ext = require('./variables_ext');

// ═════════════════════════════════════════════════════════════
// 预编译正则（Node 端全局 /gi 标志，对齐 Go (?i) case-insensitive）
// ═════════════════════════════════════════════════════════════

// 随机字符串（长度参数：{NAME} 或 {NAME:n} 或 {NAME:min-max}）
const RE_RANDOM        = /\{RANDOM(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_LOWER  = /\{RANDOM_LOWER(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_UPPER  = /\{RANDOM_UPPER(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_NUM    = /\{RANDOM_NUM(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_LOWERN = /\{RANDOM_LOWER_NUM(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_UPPERN = /\{RANDOM_UPPER_NUM(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_HEX    = /\{RANDOM_HEX(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_CN     = /\{RANDOM_CN(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_JP     = /\{RANDOM_JP(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_HIRA   = /\{RANDOM_HIRA(?::(\d+)(?:-(\d+))?)?\}/gi;
const RE_RANDOM_KATA   = /\{RANDOM_KATA(?::(\d+)(?:-(\d+))?)?\}/gi;

// 金额
const RE_AMOUNT      = /\{AMOUNT\}/gi;
const RE_AMOUNT_R    = /\{AMOUNT:(\d+)-(\d+)(?::(\d+))?\}/gi;
const RE_AMOUNT_JP   = /\{AMOUNT_JP:(\d+)-(\d+)\}/gi;
const RE_AMOUNT_CN   = /\{AMOUNT_CN:(\d+)-(\d+)(?::(\d+))?\}/gi;
const RE_AMOUNT_USD  = /\{AMOUNT_USD:(\d+)-(\d+)(?::(\d+))?\}/gi;

// IP
const RE_RANDOM_IP    = /\{RANDOM_IP\}/gi;
const RE_RANDOM_IP_CN = /\{RANDOM_IP_CN\}/gi;
const RE_RANDOM_IP_JP = /\{RANDOM_IP_JP\}/gi;
const RE_RANDOM_IP_US = /\{RANDOM_IP_US\}/gi;

// UUID / 哈希
const RE_UUID        = /\{UUID\}/gi;
const RE_UUID_SHORT  = /\{UUID_SHORT\}/gi;
const RE_MD5         = /\{MD5:([^}]+)\}/gi;
const RE_MD5_SHORT   = /\{MD5_SHORT:([^}]+)\}/gi;

// 自定义变量
const RE_CUSTOM_VAR  = /\{CUSTOM:(\w+)(?::(random|seq))?\}/gi;

// 条件变量
const RE_CONDITIONAL = /\{IF:(\w+)=([^:]+):([^:]*):([^}]*)\}/gi;

// 随机变量定义表（re + kind）
const RANDOM_VAR_DEFS = [
  { re: RE_RANDOM,        kind: 'alphanumeric' },
  { re: RE_RANDOM_LOWER,  kind: 'lower' },
  { re: RE_RANDOM_UPPER,  kind: 'upper' },
  { re: RE_RANDOM_NUM,    kind: 'numeric' },
  { re: RE_RANDOM_LOWERN, kind: 'lower_num' },
  { re: RE_RANDOM_UPPERN, kind: 'upper_num' },
  { re: RE_RANDOM_HEX,    kind: 'hex' },
  { re: RE_RANDOM_CN,     kind: 'cn' },
  { re: RE_RANDOM_JP,     kind: 'jp' },      // 假名（hira + kata 混）
  { re: RE_RANDOM_HIRA,   kind: 'hira' },
  { re: RE_RANDOM_KATA,   kind: 'kata' },
];

const WEEKDAY_CN = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
const WEEKDAY_EN = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// ═════════════════════════════════════════════════════════════
// VariableProcessor
// ═════════════════════════════════════════════════════════════

class VariableProcessor {
  constructor(cfg, workerId) {
    this.cfg = cfg;
    this.workerId = workerId | 0;
    this.customVars = {};
    this.customVarIndex = {};
    this.templateIndex = 0;
    this.subjectIndex = 0;
    this.displayNameIndex = 0;
    this.attachmentIndex = 0;
    this.random = randSafe.cryptoSeed(this.workerId);
    this._loadCustomVariables();
  }

  _loadCustomVariables() {
    const files = (this.cfg && this.cfg.variables && this.cfg.variables.custom_variable_files) || {};
    for (const name of Object.keys(files)) {
      const filePath = files[name];
      if (!filePath) continue;
      try {
        const raw = fs.readFileSync(filePath, 'utf8');
        // 剥 BOM
        const clean = raw.charCodeAt(0) === 0xFEFF ? raw.slice(1) : raw;
        const lines = clean.split(/\r?\n/).map((l) => l.trim()).filter((l) => l !== '');
        const key = String(name).toLowerCase();
        this.customVars[key] = lines;
        this.customVarIndex[key] = 0;
      } catch (e) {
        process.stderr.write(`Warning: Failed to load custom variable ${name}: ${e.message}\n`);
      }
    }
  }

  /**
   * process - 10 阶段变量替换主入口
   * @param {string} content
   * @param {Object} recipient {email, name, firstName, lastName, customFields}
   * @returns {string}
   */
  process(content, recipient) {
    if (!content) return content;
    content = this._processTimeVariables(content);
    content = this._processRecipientVariables(content, recipient);
    content = this._processSenderVariables(content);
    content = this._processRandomVariables(content);
    content = this._processAmountVariables(content);
    content = this._processIPVariables(content);
    content = this._processUuidHashVariables(content);
    content = this._processCustomVariables(content);
    content = this._processConditionalVariables(content, recipient);
    // 步骤 10: 53 扩展变量（放最后，避免嵌套）
    content = ext.processExtendedVariables(this, content);
    return content;
  }

  // ═════════════════════════════════════════════════════════════
  // 1. 时间变量
  // ═════════════════════════════════════════════════════════════
  _processTimeVariables(content) {
    const now = new Date();
    const pad2 = (n) => String(n).padStart(2, '0');
    // 强制 JST，与 Go 版 time.FixedZone("JST", 9*3600) 对齐，不依赖服务器本地 TZ
    // {TIMESTAMP} 保持 epoch 秒（时区无关）
    const jst = new Date(now.getTime() + 9 * 60 * 60000);
    const yyyy = jst.getUTCFullYear();
    const mm = pad2(jst.getUTCMonth() + 1);
    const dd = pad2(jst.getUTCDate());
    const HH = pad2(jst.getUTCHours());
    const MM = pad2(jst.getUTCMinutes());
    const SS = pad2(jst.getUTCSeconds());

    const replacements = {
      '{DATE_TIME}':  `${yyyy}-${mm}-${dd} ${HH}:${MM}:${SS}`,
      '{DATE}':       `${yyyy}-${mm}-${dd}`,
      '{TIME}':       `${HH}:${MM}:${SS}`,
      '{YEAR}':       String(yyyy),
      '{MONTH}':      mm,
      '{DAY}':        dd,
      '{HOUR}':       HH,
      '{MINUTE}':     MM,
      '{SECOND}':     SS,
      '{TIMESTAMP}':  String(Math.floor(now.getTime() / 1000)),
      '{DATE_JP}':    `${yyyy}年${mm}月${dd}日`,
      '{DATE_CN}':    `${yyyy}年${jst.getUTCMonth() + 1}月${jst.getUTCDate()}日`,
      '{WEEKDAY}':    WEEKDAY_CN[jst.getUTCDay()],
      '{WEEKDAY_EN}': WEEKDAY_EN[jst.getUTCDay()],
    };
    for (const k of Object.keys(replacements)) {
      content = _replaceAllLiteral(content, k, replacements[k]);
      content = _replaceAllLiteral(content, k.toLowerCase(), replacements[k]);
    }
    return content;
  }

  // ═════════════════════════════════════════════════════════════
  // 2. 收件人变量 + 自定义字段
  // ═════════════════════════════════════════════════════════════
  _processRecipientVariables(content, r) {
    if (!r) r = { email: '', name: '', firstName: '', lastName: '', customFields: {} };
    const email = r.email || '';
    const atIdx = email.indexOf('@');
    const user = atIdx >= 0 ? email.slice(0, atIdx) : email;
    const domain = atIdx >= 0 ? email.slice(atIdx + 1) : '';

    const replacements = {
      '{TO_EMAIL}':      email,
      '{TO_USER}':       user,
      '{TO_DOMAIN}':     domain,
      '{TO_NAME}':       r.name || '',
      '{TO_FIRST}':      r.firstName || '',
      '{TO_LAST}':       r.lastName || '',
      '{TO_USER_UPPER}': user.toUpperCase(),
      '{TO_USER_LOWER}': user.toLowerCase(),
      '{TO_USER_CAP}':   _capitalizeFirst(user),
      '{TO_NAME_UPPER}': (r.name || '').toUpperCase(),
      '{TO_NAME_LOWER}': (r.name || '').toLowerCase(),
    };
    for (const k of Object.keys(replacements)) {
      content = _replaceAllLiteral(content, k, replacements[k]);
      content = _replaceAllLiteral(content, k.toLowerCase(), replacements[k]);
    }

    // 自定义字段（8 种模式：{key}/{KEY}/{key} + {CUSTOM:key}/{CUSTOM:KEY}/{CUSTOM:key} + {TO_KEY}/{to_key}）
    const cf = r.customFields;
    if (cf && typeof cf === 'object') {
      for (const key of Object.keys(cf)) {
        const val = String(cf[key] == null ? '' : cf[key]);
        const patterns = [
          `{${key}}`,
          `{${key.toUpperCase()}}`,
          `{${key.toLowerCase()}}`,
          `{CUSTOM:${key}}`,
          `{CUSTOM:${key.toUpperCase()}}`,
          `{CUSTOM:${key.toLowerCase()}}`,
          `{TO_${key.toUpperCase()}}`,
          `{to_${key.toLowerCase()}}`,
        ];
        for (const pat of patterns) {
          if (content.indexOf(pat) !== -1) {
            content = _replaceAllLiteral(content, pat, val);
          }
        }
      }
    }
    return content;
  }

  // ═════════════════════════════════════════════════════════════
  // 3. 发件人变量
  // ═════════════════════════════════════════════════════════════
  _processSenderVariables(content) {
    const fromAddr = (this.cfg.sender && this.cfg.sender.from_address) || '';
    const atIdx = fromAddr.indexOf('@');
    const user = atIdx >= 0 ? fromAddr.slice(0, atIdx) : fromAddr;
    const domain = atIdx >= 0 ? fromAddr.slice(atIdx + 1) : '';
    const fromName = (this.cfg.sender && this.cfg.sender.from_name) || '';

    const replacements = {
      '{FROM_EMAIL}':  fromAddr,
      '{FROM_USER}':   user,
      '{FROM_DOMAIN}': domain,
      '{FROM_NAME}':   fromName,
    };
    for (const k of Object.keys(replacements)) {
      content = _replaceAllLiteral(content, k, replacements[k]);
      content = _replaceAllLiteral(content, k.toLowerCase(), replacements[k]);
    }
    return content;
  }

  // ═════════════════════════════════════════════════════════════
  // 4. 随机字符串
  // ═════════════════════════════════════════════════════════════
  _processRandomVariables(content) {
    for (const def of RANDOM_VAR_DEFS) {
      // 每次 replace 前重置 lastIndex（正则被 replace 用后仍需重置）
      def.re.lastIndex = 0;
      content = content.replace(def.re, (match, minStr, maxStr) => {
        const length = _parseRandomLength(minStr, maxStr, this.random);
        return this._generateRandomByKind(length, def.kind);
      });
    }
    return content;
  }

  _generateRandomByKind(length, kind) {
    switch (kind) {
      case 'alphanumeric':
      case 'lower':
      case 'upper':
      case 'numeric':
      case 'lower_num':
      case 'upper_num':
      case 'hex':
        return this._generateRandom(length, kind);
      case 'cn':   return this._generateRandomChinese(length);
      case 'jp':   return this._generateRandomJapanese(length, true, true);
      case 'hira': return this._generateRandomJapanese(length, true, false);
      case 'kata': return this._generateRandomJapanese(length, false, true);
      default:     return this._generateRandom(length, 'alphanumeric');
    }
  }

  _generateRandom(length, randType) {
    let chars;
    switch (randType) {
      case 'lower':        chars = 'abcdefghijklmnopqrstuvwxyz'; break;
      case 'upper':        chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; break;
      case 'numeric':      chars = '0123456789'; break;
      case 'alphanumeric': chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; break;
      case 'lower_num':    chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; break;
      case 'upper_num':    chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; break;
      case 'hex':          chars = '0123456789abcdef'; break;
      default:             chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    }
    return randSafe.randStringFrom(this.random, length, chars);
  }

  _generateRandomChinese(length) {
    // Unicode CJK 基本区 0x4E00-0x9FFF
    let out = '';
    const range = 0x9FFF - 0x4E00 + 1;
    for (let i = 0; i < length; i++) {
      const cp = 0x4E00 + randSafe.safeIntn(this.random, range);
      out += String.fromCodePoint(cp);
    }
    return out;
  }

  _generateRandomJapanese(length, hira, kata) {
    let out = '';
    const hiraRange = 0x309F - 0x3040 + 1;
    const kataRange = 0x30FF - 0x30A0 + 1;
    for (let i = 0; i < length; i++) {
      let cp;
      if (hira && kata) {
        if (randSafe.safeIntn(this.random, 2) === 0) {
          cp = 0x3040 + randSafe.safeIntn(this.random, hiraRange);
        } else {
          cp = 0x30A0 + randSafe.safeIntn(this.random, kataRange);
        }
      } else if (hira) {
        cp = 0x3040 + randSafe.safeIntn(this.random, hiraRange);
      } else {
        cp = 0x30A0 + randSafe.safeIntn(this.random, kataRange);
      }
      out += String.fromCodePoint(cp);
    }
    return out;
  }

  // ═════════════════════════════════════════════════════════════
  // 5. 金额
  // ═════════════════════════════════════════════════════════════
  _processAmountVariables(content) {
    const vc = this.cfg.variables || {};

    RE_AMOUNT.lastIndex = 0;
    content = content.replace(RE_AMOUNT, () => {
      return this._generateAmount(vc.amount_min || 10000, vc.amount_max || 100000,
        vc.amount_decimals || 0, !!vc.amount_use_separator, '');
    });

    RE_AMOUNT_R.lastIndex = 0;
    content = content.replace(RE_AMOUNT_R, (match, minStr, maxStr, decStr) => {
      const min = parseFloat(minStr);
      const max = parseFloat(maxStr);
      const dec = decStr ? parseInt(decStr, 10) : (vc.amount_decimals || 0);
      return this._generateAmount(min, max, dec, !!vc.amount_use_separator, '');
    });

    RE_AMOUNT_JP.lastIndex = 0;
    content = content.replace(RE_AMOUNT_JP, (match, minStr, maxStr) => {
      return this._generateAmount(parseFloat(minStr), parseFloat(maxStr), 0, true, '¥');
    });

    RE_AMOUNT_CN.lastIndex = 0;
    content = content.replace(RE_AMOUNT_CN, (match, minStr, maxStr, decStr) => {
      const dec = decStr ? parseInt(decStr, 10) : 2;
      return this._generateAmount(parseFloat(minStr), parseFloat(maxStr), dec, true, '￥');
    });

    RE_AMOUNT_USD.lastIndex = 0;
    content = content.replace(RE_AMOUNT_USD, (match, minStr, maxStr, decStr) => {
      const dec = decStr ? parseInt(decStr, 10) : 2;
      return this._generateAmount(parseFloat(minStr), parseFloat(maxStr), dec, true, '$');
    });

    return content;
  }

  _generateAmount(min, max, decimals, useSeparator, prefix) {
    if (!Number.isFinite(min)) min = 0;
    if (!Number.isFinite(max)) max = min;
    if (max < min) max = min;
    const amount = min + this.random() * (max - min);
    const formatted = decimals > 0 ? amount.toFixed(decimals) : amount.toFixed(0);
    return prefix + (useSeparator ? _addThousandSeparator(formatted) : formatted);
  }

  // ═════════════════════════════════════════════════════════════
  // 6. IP 变量
  // ═════════════════════════════════════════════════════════════
  _processIPVariables(content) {
    RE_RANDOM_IP.lastIndex = 0;
    content = content.replace(RE_RANDOM_IP, () =>
      this._generateRandomIP([[1, 9], [11, 126], [128, 169], [171, 191], [193, 223]]));
    RE_RANDOM_IP_CN.lastIndex = 0;
    content = content.replace(RE_RANDOM_IP_CN, () =>
      this._generateRandomIP([[116, 117], [119, 120], [121, 122], [222, 223]]));
    RE_RANDOM_IP_JP.lastIndex = 0;
    content = content.replace(RE_RANDOM_IP_JP, () =>
      this._generateRandomIP([[133, 134], [150, 151], [157, 158], [202, 203]]));
    RE_RANDOM_IP_US.lastIndex = 0;
    content = content.replace(RE_RANDOM_IP_US, () =>
      this._generateRandomIP([[64, 65], [66, 67], [69, 70], [98, 99]]));
    return content;
  }

  _generateRandomIP(ranges) {
    const r = ranges[randSafe.safeIntn(this.random, ranges.length)];
    const first = r[0] + randSafe.safeIntn(this.random, r[1] - r[0] + 1);
    const b = randSafe.safeIntn(this.random, 256);
    const c = randSafe.safeIntn(this.random, 256);
    const d = 1 + randSafe.safeIntn(this.random, 254);
    return `${first}.${b}.${c}.${d}`;
  }

  // ═════════════════════════════════════════════════════════════
  // 7. UUID / MD5
  // ═════════════════════════════════════════════════════════════
  _processUuidHashVariables(content) {
    RE_UUID.lastIndex = 0;
    content = content.replace(RE_UUID, () => this._generateUUID());

    RE_UUID_SHORT.lastIndex = 0;
    content = content.replace(RE_UUID_SHORT, () => this._generateUUID().replace(/-/g, ''));

    RE_MD5.lastIndex = 0;
    content = content.replace(RE_MD5, (match, txt) => utils.md5Hash(txt));

    RE_MD5_SHORT.lastIndex = 0;
    content = content.replace(RE_MD5_SHORT, (match, txt) => utils.md5Hash(txt).slice(0, 8));

    return content;
  }

  // 用 vp.random 生成的 UUID v4（与 Go 版对齐：不用 crypto.randomBytes，走 seed）
  _generateUUID() {
    const b = new Array(16);
    for (let i = 0; i < 16; i++) b[i] = randSafe.safeIntn(this.random, 256);
    // 设置版本 4 和 variant
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const hex = b.map((n) => n.toString(16).padStart(2, '0'));
    return `${hex.slice(0,4).join('')}-${hex.slice(4,6).join('')}-${hex.slice(6,8).join('')}-` +
           `${hex.slice(8,10).join('')}-${hex.slice(10,16).join('')}`;
  }

  // ═════════════════════════════════════════════════════════════
  // 8. 自定义变量（{CUSTOM:name} / {CUSTOM:name:seq} / {CUSTOM:name:random}）
  // ═════════════════════════════════════════════════════════════
  _processCustomVariables(content) {
    RE_CUSTOM_VAR.lastIndex = 0;
    return content.replace(RE_CUSTOM_VAR, (match, varName, mode) => {
      const key = String(varName).toLowerCase();
      const values = this.customVars[key];
      if (!values || values.length === 0) return '';
      const m = mode ? String(mode).toLowerCase() : 'random';
      if (m === 'seq') {
        const idx = this.customVarIndex[key] || 0;
        const val = values[idx % values.length];
        this.customVarIndex[key] = idx + 1;
        return val;
      }
      return values[randSafe.safeIntn(this.random, values.length)];
    });
  }

  // ═════════════════════════════════════════════════════════════
  // 9. 条件变量 {IF:field=value:trueValue:falseValue}
  // ═════════════════════════════════════════════════════════════
  _processConditionalVariables(content, r) {
    if (!r) r = { email: '', name: '' };
    const email = r.email || '';
    const atIdx = email.indexOf('@');
    const user = atIdx >= 0 ? email.slice(0, atIdx) : email;
    const domain = atIdx >= 0 ? email.slice(atIdx + 1) : '';

    RE_CONDITIONAL.lastIndex = 0;
    return content.replace(RE_CONDITIONAL, (match, field, compareValue, trueValue, falseValue) => {
      const fieldUpper = String(field).toUpperCase();
      let actual = '';
      switch (fieldUpper) {
        case 'TO_DOMAIN': actual = domain; break;
        case 'TO_USER':   actual = user; break;
        case 'TO_EMAIL':  actual = email; break;
        case 'TO_NAME':   actual = r.name || ''; break;
      }
      if (actual.toLowerCase() === String(compareValue).toLowerCase()) return trueValue;
      return falseValue;
    });
  }

  // ═════════════════════════════════════════════════════════════
  // Getters（多主题/多显示名/多模板顺序 or 随机选择）
  // ═════════════════════════════════════════════════════════════

  getNextTemplate() {
    const paths = (this.cfg.email && this.cfg.email.template_paths) || [];
    if (paths.length === 0) return this.cfg.email.template_path || '';
    if (this.cfg.email.template_mode === 'sequential') {
      const p = paths[this.templateIndex % paths.length];
      this.templateIndex++;
      return p;
    }
    return paths[randSafe.safeIntn(this.random, paths.length)];
  }

  getNextSubject() {
    const list = (this.cfg.email && this.cfg.email.subjects) || [];
    if (list.length === 0) return this.cfg.email.subject || '';
    if (this.cfg.email.subject_mode === 'sequential') {
      const s = list[this.subjectIndex % list.length];
      this.subjectIndex++;
      return s;
    }
    return list[randSafe.safeIntn(this.random, list.length)];
  }

  getNextDisplayName() {
    const list = (this.cfg.sender && this.cfg.sender.display_names) || [];
    if (list.length === 0) return this.cfg.sender.from_name || '';
    if (this.cfg.sender.display_name_mode === 'sequential') {
      const s = list[this.displayNameIndex % list.length];
      this.displayNameIndex++;
      return s;
    }
    return list[randSafe.safeIntn(this.random, list.length)];
  }

  getNextAttachmentIndex(total) {
    if (!total || total <= 0) return 0;
    const idx = this.attachmentIndex % total;
    this.attachmentIndex++;
    return idx;
  }
}

// ═════════════════════════════════════════════════════════════
// 内部工具
// ═════════════════════════════════════════════════════════════

/**
 * _parseRandomLength - 解析 {NAME:n} 或 {NAME:min-max} 里的长度
 * @param {string|undefined} minStr
 * @param {string|undefined} maxStr
 * @param {Function} rng
 */
function _parseRandomLength(minStr, maxStr, rng) {
  let length = 8; // 默认
  if (minStr) {
    const min = parseInt(minStr, 10);
    if (maxStr) {
      const max = parseInt(maxStr, 10);
      if (max > min) {
        length = min + randSafe.safeIntn(rng, max - min + 1);
      } else {
        length = min;
      }
    } else {
      length = min;
    }
  }
  if (length <= 0) length = 1;
  return length;
}

// 首字母大写（正确处理多字节字符 —— code point 迭代）
function _capitalizeFirst(s) {
  if (!s) return s;
  const first = String.fromCodePoint(s.codePointAt(0));
  const rest = s.slice(first.length);
  return first.toUpperCase() + rest.toLowerCase();
}

// 千位分隔符（对齐 Go addThousandSeparator，从后往前每 3 位加 ,）
function _addThousandSeparator(s) {
  const parts = String(s).split('.');
  const intPart = parts[0];
  let result = '';
  const len = intPart.length;
  for (let i = 0; i < len; i++) {
    if (i > 0 && (len - i) % 3 === 0) result += ',';
    result += intPart.charAt(i);
  }
  if (parts.length > 1) return result + '.' + parts.slice(1).join('.');
  return result;
}

/**
 * _replaceAllLiteral - 字面量全量替换（不解释正则元字符）
 * 对齐 Go strings.ReplaceAll 语义
 */
function _replaceAllLiteral(s, search, replace) {
  if (!search || search.length === 0) return s;
  // String.split + join 是字面量全量替换（不需要转义元字符）
  return s.split(search).join(replace);
}

// ═════════════════════════════════════════════════════════════
// HTML 转换 / 换行归一化（工具函数，非 Class 方法）
// ═════════════════════════════════════════════════════════════

function textToHTML(text, charset) {
  if (!text) return text;
  const urlRe = /https?:\/\/[^\s<>"'`]+/g;
  let processed = '';
  let lastIndex = 0;
  let m;
  urlRe.lastIndex = 0;
  while ((m = urlRe.exec(text)) !== null) {
    if (m.index > lastIndex) {
      processed += _escapeHTML(text.slice(lastIndex, m.index));
    }
    const rawUrl = m[0];
    const escUrl = _escapeHTML(rawUrl);
    processed += `<a href="${escUrl}" target="_blank">${escUrl}</a>`;
    lastIndex = m.index + rawUrl.length;
  }
  if (lastIndex < text.length) processed += _escapeHTML(text.slice(lastIndex));

  processed = processed.replace(/\r\n/g, '<br>\n').replace(/\n/g, '<br>\n');
  const cs = charset || 'UTF-8';
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="${cs}">
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6;">
${processed}
</body>
</html>`;
}

function normalizeLineEndings(text) {
  return String(text || '')
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\n/g, '\r\n');
}

// 对齐 Go html.EscapeString：& < > " '
function _escapeHTML(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&#34;')
    .replace(/'/g, '&#39;');
}

module.exports = {
  VariableProcessor,
  textToHTML,
  normalizeLineEndings,
  // 也暴露内部工具，便于 headers.js 复用
  _parseRandomLength,
  _addThousandSeparator,
  _replaceAllLiteral,
};
