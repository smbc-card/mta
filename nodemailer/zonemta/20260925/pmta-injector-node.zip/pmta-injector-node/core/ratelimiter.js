'use strict';
// core/ratelimiter - 令牌桶速率限制器（对应 Go pmta-injector-clean/core/ratelimiter.go）
//
// 语义与 Go 版一致：
//   - 每秒最多 N 个令牌产出
//   - 桶容量 = maxBurst = clamp(N/10, 10, 1000)
//   - wait(abortSignal) 阻塞到有令牌
//   - allow() 非阻塞检查
//
// Node 单线程无需 Mutex，Go 用 sync.Mutex 是为并发 goroutine，Node 事件循环天然序列化。
// 但异步 await 之间仍可能被其他任务插入，令牌读取/减少必须在同一同步块完成（本实现满足）。

class RateLimiter {
  /**
   * @param {number} ratePerSecond 每秒令牌数（≤0 时构造失败，返回 null）
   */
  constructor(ratePerSecond) {
    if (!ratePerSecond || ratePerSecond <= 0) {
      throw new Error('ratePerSecond must be > 0');
    }
    this.rate = ratePerSecond;
    // 补充间隔（毫秒），最少 1ms（Node setTimeout 最小精度约 1ms）
    this.intervalMs = Math.max(1, Math.floor(1000 / ratePerSecond));
    // maxBurst = clamp(rate/10, 10, 1000)
    let mb = Math.floor(ratePerSecond / 10);
    if (mb < 10) mb = 10;
    if (mb > 1000) mb = 1000;
    this.maxBurst = mb;
    this.tokens = mb;
    this.lastTime = Date.now();
  }

  // _refill 按经过时间补充令牌（内部使用）
  _refill() {
    const now = Date.now();
    const elapsedSec = (now - this.lastTime) / 1000;
    const newTokens = Math.floor(elapsedSec * this.rate);
    if (newTokens > 0) {
      this.tokens += newTokens;
      if (this.tokens > this.maxBurst) this.tokens = this.maxBurst;
      this.lastTime = now;
    }
  }

  // allow 非阻塞：有令牌则消耗返回 true，无则返回 false
  allow() {
    this._refill();
    if (this.tokens > 0) {
      this.tokens--;
      return true;
    }
    return false;
  }

  // wait 阻塞到有令牌
  // abortSignal 可选，触发时 wait 立即返回（不消耗令牌）
  async wait(abortSignal) {
    while (true) {
      if (abortSignal && abortSignal.aborted) return;
      this._refill();
      if (this.tokens > 0) {
        this.tokens--;
        return;
      }
      // 无令牌 → 等待 intervalMs 再重试
      // 【Sprint 5 R5 P2 修复】原 { once: true } 只在 abort 触发时移除,
      //   setTimeout 正常 resolve 时 onAbort 永不 fire 也永不移除 →
      //   100 万收件人 = 100 万 stale listener 挂在 AbortSignal 强引用链
      //   修复:setTimeout 回调里主动 removeEventListener,双路径都保证 cleanup
      await new Promise((resolve) => {
        let onAbort = null;
        const t = setTimeout(() => {
          if (abortSignal && onAbort) abortSignal.removeEventListener('abort', onAbort);
          resolve();
        }, this.intervalMs);
        if (abortSignal) {
          if (abortSignal.aborted) { clearTimeout(t); return resolve(); }
          onAbort = () => { clearTimeout(t); resolve(); };
          abortSignal.addEventListener('abort', onAbort, { once: true });
        }
      });
    }
  }
}

/**
 * 创建速率限制器；ratePerSecond ≤ 0 返回 null（表示不限速，对齐 Go 语义）
 * @param {number} ratePerSecond
 * @returns {RateLimiter|null}
 */
function create(ratePerSecond) {
  if (!ratePerSecond || ratePerSecond <= 0) return null;
  return new RateLimiter(ratePerSecond);
}

module.exports = { RateLimiter, create };
