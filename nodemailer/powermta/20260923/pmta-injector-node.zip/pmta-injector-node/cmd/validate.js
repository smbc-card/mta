'use strict';
// cmd/validate - 验证配置和模板（对应 Go pmta-injector-clean/cmd/validate.go）
//
// 用法：
//   pmta-injector validate --config config.yaml
//   pmta-injector validate --template template.html
//   pmta-injector validate --template template.html --sample-data '{"Email":"..."}'
//
// Sprint 1 覆盖：
//   ✓ 配置文件加载 + 摘要打印
//   ✓ 模板文件存在性 + 可读性检查
//   ✓ Pickup 目录存在性 + 可写检查
//   ⏳ 模板 Handlebars 解析（Sprint 3 交付）
//   ⏳ 示例数据渲染测试（Sprint 3 交付）

const fs = require('fs');
const path = require('path');
const config = require('../config/config');

function register(program, globalOpts) {
  program
    .command('validate')
    .description('验证配置和模板')
    .option('-t, --template <path>', '模板文件路径')
    .option('--sample-data <json>', '示例数据（JSON 格式）')
    .action(async (opts) => {
      const cfgFile = globalOpts.configFile;
      const templateFile = opts.template || '';
      const sampleData = opts.sampleData || '';

      const bar = '═══════════════════════════════════════════════════════════════';
      process.stdout.write(bar + '\n');
      process.stdout.write('                    配置和模板验证\n');
      process.stdout.write(bar + '\n');

      let cfg = null;
      let hasFailure = false;

      // ── 配置文件验证 ──
      if (cfgFile) {
        process.stdout.write('\n[配置文件验证]\n');
        process.stdout.write(`  文件: ${cfgFile}\n`);
        try {
          cfg = config.loadFromFile(cfgFile);
          process.stdout.write('  状态: ✅ 通过\n');
          process.stdout.write('\n  [配置摘要]\n');
          process.stdout.write(`    MTA 类型:      ${cfg.mta_type}\n`);
          process.stdout.write(`    发件人:        ${cfg.sender.from_name} <${cfg.sender.from_address}>\n`);
          process.stdout.write(`    信封发件人:    ${cfg.sender.envelope_from}\n`);
          process.stdout.write(`    虚拟MTA:       ${cfg.pmta.virtual_mta}\n`);
          process.stdout.write(`    Pickup目录:    ${cfg.pmta.pickup_dir}\n`);
          process.stdout.write(`    SMTP:          ${cfg.smtp.host}:${cfg.smtp.port} ` +
                              `(auth=${cfg.smtp.use_auth ? 'yes' : 'no'}, tls=${cfg.smtp.use_tls ? 'yes' : 'no'})\n`);
          process.stdout.write(`    并发数:        ${cfg.performance.workers}\n`);
          process.stdout.write(`    速率限制:      ${cfg.performance.rate_limit || '无限制'}\n`);
          process.stdout.write(`    邮件头:        enabled=${cfg.headers.enabled} ` +
                              `random=${cfg.headers.random_enabled} (min=${cfg.headers.random_min}, max=${cfg.headers.random_max})\n`);
          process.stdout.write(`    ESP Received:  yahoo=${cfg.headers.received_yahoo} ` +
                              `au=${cfg.headers.received_au} softbank=${cfg.headers.received_softbank} ` +
                              `docomo=${cfg.headers.received_docomo} mitsui=${cfg.headers.received_mitsui}\n`);
          process.stdout.write(`    List-Unsub:    mode=${cfg.headers.list_unsub_mode}\n`);
          process.stdout.write(`    收件人文件:    ${cfg.recipients.file_path || '（未指定）'}\n`);
          process.stdout.write(`    CC / BCC:      cc=${cfg.cc.enabled} bcc=${cfg.bcc.enabled}\n`);
        } catch (e) {
          process.stdout.write('  状态: ❌ 失败\n');
          process.stdout.write(`  错误: ${e.message}\n`);
          hasFailure = true;
        }
      }

      // ── 模板文件验证 ──
      if (templateFile) {
        process.stdout.write('\n[模板文件验证]\n');
        process.stdout.write(`  文件: ${templateFile}\n`);

        if (!fs.existsSync(templateFile)) {
          process.stdout.write('  状态: ❌ 文件不存在\n');
          hasFailure = true;
        } else {
          try {
            const content = fs.readFileSync(templateFile, 'utf8');
            const bytes = Buffer.byteLength(content, 'utf8');
            process.stdout.write(`  状态: ✅ 文件可读（${bytes} 字节）\n`);
            process.stdout.write('  说明: Sprint 1 仅做存在性检查，模板语法解析在 Sprint 3 实现\n');
          } catch (e) {
            process.stdout.write('  状态: ❌ 读取失败\n');
            process.stdout.write(`  错误: ${e.message}\n`);
            hasFailure = true;
          }

          if (sampleData) {
            process.stdout.write('\n[模板渲染测试]\n');
            process.stdout.write('  状态: ⏳ Sprint 3 实现\n');
            try {
              const parsed = JSON.parse(sampleData);
              const keys = Object.keys(parsed).join(', ') || '（空对象）';
              process.stdout.write(`  示例数据 keys: ${keys}\n`);
            } catch (e) {
              process.stdout.write(`  警告: 示例数据不是合法 JSON: ${e.message}\n`);
            }
          }
        }
      }

      // ── Pickup 目录验证 ──
      if (cfg) {
        process.stdout.write('\n[Pickup目录验证]\n');
        process.stdout.write(`  路径: ${cfg.pmta.pickup_dir}\n`);
        try {
          const st = fs.statSync(cfg.pmta.pickup_dir);
          if (!st.isDirectory()) {
            process.stdout.write('  状态: ❌ 路径不是目录\n');
          } else {
            const testFile = path.join(cfg.pmta.pickup_dir, '.write_test');
            try {
              fs.writeFileSync(testFile, '');
              fs.unlinkSync(testFile);
              process.stdout.write('  状态: ✅ 目录可写\n');
            } catch (e) {
              process.stdout.write('  状态: ⚠️ 目录存在但无写入权限\n');
              process.stdout.write(`  错误: ${e.message}\n`);
            }
          }
        } catch (e) {
          process.stdout.write('  状态: ❌ 目录不存在或无法访问\n');
          process.stdout.write(`  错误: ${e.message}\n`);
        }
      }

      // ── 无任何输入 ──
      if (!cfgFile && !templateFile) {
        process.stdout.write('\n⚠️ 未指定 --config 或 --template，无内容可验证\n');
        process.stdout.write('   示例: pmta-injector validate --config /etc/pmta/config.yaml\n');
      }

      process.stdout.write('\n' + bar + '\n');
      process.stdout.write('                      验证完成\n');
      process.stdout.write(bar + '\n');

      if (hasFailure) {
        process.exit(1);
      }
    });
}

module.exports = { register };
