'use strict';
// cmd/debug_dump - 生成 N 封 raw MIME .eml 到目录（Sprint 6 完整实现）
//
// 用途：
//   1. Sprint 6 结构对比：Node 端产出 N 封 .eml，与 Go pickup 基线做对比
//   2. 开发调试：单封邮件生成后可直接查看 raw MIME
//
// 用法：
//   pmta-injector debug-dump --config <cfg.yaml> --output <dir> \
//     [--cases <cases.json>] [--limit N] [--worker-id N]
//
// 【与 dispatcher 的区别】
//   不走 dispatcher/injector/reporter 链路 —— 直接 Builder.build() + 写文件。
//   目的：简单确定的行为，去掉并发/速率限制/CC-BCC 等干扰，方便逐封验证。
//
// 输入优先级：--cases > cfg.recipients.file_path（CSV）> 合成收件人（无 cases 无 CSV）
// 输出：<output>/case_001.eml 、case_002.eml 、...
// 【契约】Sprint 6 verify_node_structure.py / compare_structural.py 读取此输出目录

const fs = require('fs');
const path = require('path');
const config = require('../config/config');
const templateMod = require('../email/template');
const builderMod = require('../email/builder');
const readerMod = require('../reader/reader');

function register(program, globalOpts) {
  program
    .command('debug-dump')
    .description('生成 N 封 raw MIME 到目录（Sprint 6 结构对比 / 开发调试用）')
    .option('--cases <path>', '测试用例 JSON 数组（可选，默认用 config recipients CSV）')
    .option('--output <dir>', '输出目录（.eml 落此处）')
    .option('--limit <n>', '最多生成邮件数（默认 100）', (v) => parseInt(v, 10), 100)
    .option('--worker-id <n>', 'Builder workerId（默认 0）', (v) => parseInt(v, 10), 0)
    .action(async (opts) => {
      const cfgFile = globalOpts.configFile;
      if (!cfgFile) {
        process.stderr.write('[debug-dump] --config 参数必填\n');
        process.exit(2);
      }
      if (!opts.output) {
        process.stderr.write('[debug-dump] --output 参数必填\n');
        process.exit(2);
      }

      const outDir = opts.output;
      const limit = (opts.limit > 0 ? opts.limit : 100);
      const workerId = opts.workerId | 0;

      // 1. 加载配置
      let cfg;
      try { cfg = config.loadFromFile(cfgFile); }
      catch (e) {
        process.stderr.write(`[debug-dump] 加载配置失败: ${e.message}\n`);
        process.exit(1);
      }

      // 2. 确保输出目录
      try { fs.mkdirSync(outDir, { recursive: true }); }
      catch (e) {
        process.stderr.write(`[debug-dump] 创建输出目录失败: ${e.message}\n`);
        process.exit(1);
      }

      // 3. 收件人来源
      let recipients = [];
      if (opts.cases) {
        // 从 cases.json 读
        try {
          const raw = fs.readFileSync(opts.cases, 'utf8');
          recipients = JSON.parse(raw);
          if (!Array.isArray(recipients)) throw new Error('cases 必须是 JSON 数组');
        } catch (e) {
          process.stderr.write(`[debug-dump] 加载 cases 失败: ${e.message}\n`);
          process.exit(1);
        }
      } else if (cfg.recipients && cfg.recipients.file_path && fs.existsSync(cfg.recipients.file_path)) {
        // 从 config.recipients.file_path CSV 读
        try {
          const stream = readerMod.createStream(cfg.recipients.file_path, cfg);
          for await (const rec of stream) {
            recipients.push(rec);
            if (recipients.length >= limit) break;
          }
        } catch (e) {
          process.stderr.write(`[debug-dump] 读取 CSV 失败: ${e.message}\n`);
          process.exit(1);
        }
      } else {
        // 都没有 → 合成默认收件人（方便快速测试）
        process.stdout.write('[debug-dump] 未指定 cases/CSV，使用合成收件人\n');
        for (let i = 0; i < limit; i++) {
          recipients.push({
            email: `test${i + 1}@example.com`,
            name: `Test User ${i + 1}`,
            firstName: 'Test',
            lastName: `User${i + 1}`,
            customFields: {},
          });
        }
      }

      // 4. 初始化 Builder
      const templatePath = cfg.email.template_path;
      if (!templatePath || !fs.existsSync(templatePath)) {
        process.stderr.write(`[debug-dump] 模板文件不存在: ${templatePath}\n`);
        process.exit(1);
      }
      let tmplEng, builder;
      try {
        tmplEng = templateMod.create(templatePath);
        tmplEng.setGlobalVariables(cfg.template.global_variables || {});
        builder = builderMod.create(cfg, tmplEng, workerId);
      } catch (e) {
        process.stderr.write(`[debug-dump] Builder 初始化失败: ${e.message}\n`);
        process.exit(1);
      }

      // 5. 生成邮件
      const actualCount = Math.min(recipients.length, limit);
      const bar = '═══════════════════════════════════════════════════════════════';
      process.stdout.write(bar + '\n');
      process.stdout.write(`[debug-dump] 生成 ${actualCount} 封 .eml → ${outDir}\n`);
      process.stdout.write(`[debug-dump] worker_id=${workerId} / limit=${limit}\n`);
      process.stdout.write(bar + '\n');

      let success = 0;
      let failed = 0;
      for (let i = 0; i < actualCount; i++) {
        const rec = recipients[i];
        try {
          const data = templateMod.newTemplateData();
          data.Email = rec.email || rec.Email || '';
          data.Name = rec.name || rec.Name || '';
          data.FirstName = rec.firstName || rec.FirstName || '';
          data.LastName = rec.lastName || rec.LastName || '';
          data.Data = rec.customFields || rec.CustomFields || {};
          data.System.Index = i + 1;
          data.System.JobID = (cfg.job && cfg.job.id) || 'debug-dump';

          if (!data.Email) {
            failed++;
            process.stderr.write(`  [${i + 1}] 跳过（email 为空）\n`);
            continue;
          }

          const email = await builder.build(data);

          // 输出文件名：优先 rec.name（若文件系统安全），否则 case_NNN
          const safeName = (rec.name && /^[A-Za-z0-9_.-]+$/.test(rec.name))
            ? rec.name
            : `case_${String(i + 1).padStart(3, '0')}`;
          const emlPath = path.join(outDir, `${safeName}.eml`);
          fs.writeFileSync(emlPath, email.raw);

          success++;
          if ((i + 1) % 10 === 0 || i === actualCount - 1) {
            process.stdout.write(`  已生成 ${i + 1}/${actualCount}\n`);
          }
        } catch (e) {
          failed++;
          process.stderr.write(`  [${i + 1}] 失败 (${(rec && rec.email) || 'no-email'}): ${e.message}\n`);
        }
      }

      process.stdout.write(bar + '\n');
      process.stdout.write(`[debug-dump] 完成：成功 ${success} / 失败 ${failed}\n`);
      process.stdout.write(`[debug-dump] 输出目录：${outDir}\n`);

      if (failed > 0 && success === 0) process.exit(1);
    });
}

module.exports = { register };
