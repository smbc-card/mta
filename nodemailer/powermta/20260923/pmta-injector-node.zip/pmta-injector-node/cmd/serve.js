'use strict';
// cmd/serve - HTTP 退订服务器命令（Sprint 4 完整实现，对应 Go pmta-injector-clean/cmd/serve.go）
//
// 用法：
//   pmta-injector serve --config /etc/pmta/unsub.yaml
//
// 由 systemd 单元 pmta-injector-unsub.service 管理：
//   - User=root（绑 80/443 需要 root，或用 setcap 给二进制 CAP_NET_BIND_SERVICE）
//   - Restart=on-failure
//   - 部署脚本 deploy-injector-node.sh 在选了"使用真实退订风格"时安装 + enable + start
//
// 退出：SIGINT / SIGTERM 触发优雅关闭（server.shutdown → 5s timeout）

const config = require('../config/config');
const serverMod = require('../unsubserver/server');

function register(program, globalOpts) {
  program
    .command('serve')
    .description('启动 HTTP 退订服务器（List-Unsubscribe real 模式配套）')
    .action(async () => {
      const cfgFile = globalOpts.configFile;
      if (!cfgFile) {
        process.stderr.write('[serve] --config 参数必填\n');
        process.exit(1);
      }

      let cfg;
      try {
        cfg = config.loadFromFile(cfgFile);
      } catch (e) {
        process.stderr.write(`[serve] 加载配置失败: ${e.message}\n`);
        process.exit(1);
      }

      if (!cfg.unsubscribe_server || !cfg.unsubscribe_server.enabled) {
        process.stdout.write('[serve] unsubscribe_server.enabled = false in config, exiting cleanly.\n');
        return;
      }

      let srv;
      try {
        srv = serverMod.newServer(cfg.unsubscribe_server);
      } catch (e) {
        process.stderr.write(`[serve] 初始化退订服务器失败: ${e.message}\n`);
        process.exit(1);
      }

      // 挂载 SIGINT / SIGTERM
      const abortController = new AbortController();
      const onSignal = (sig) => {
        process.stderr.write(`[serve] received ${sig}, shutting down...\n`);
        try { abortController.abort(); } catch (_) { /* ignore */ }
      };
      process.on('SIGINT', () => onSignal('SIGINT'));
      process.on('SIGTERM', () => onSignal('SIGTERM'));

      try {
        await srv.run(abortController.signal);
        process.stdout.write('[serve] shutdown complete.\n');
      } catch (e) {
        process.stderr.write(`[serve] 退订服务器运行出错: ${e.message}\n`);
        process.exit(1);
      }
    });
}

module.exports = { register };
