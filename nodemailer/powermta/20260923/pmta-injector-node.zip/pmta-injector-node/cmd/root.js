'use strict';
// cmd/root - 根命令与子命令注册（对应 Go pmta-injector-clean/cmd/root.go）
//
// 全局标志（对齐 Go cobra 版）：
//   --config, -c <path>   配置文件路径
//   --verbose, -v         详细输出
//   --quiet, -q           静默模式
//
// 子命令：send / serve / validate / debug-dump / version

const { Command } = require('commander');

// 全局共享（其他 cmd 模块访问）
// 由 preAction hook 在每次子命令执行前填充
const globalOpts = {
  configFile: '',
  verbose: false,
  quiet: false,
  version: '',
  buildTime: '',
  gitCommit: '',
};

const sendModule = require('./send');
const serveModule = require('./serve');
const validateModule = require('./validate');
const debugDumpModule = require('./debug_dump');

async function execute(version, buildTime, gitCommit) {
  globalOpts.version = version;
  globalOpts.buildTime = buildTime;
  globalOpts.gitCommit = gitCommit;

  const program = new Command();

  program
    .name('pmta-injector')
    .description('PowerMTA high-throughput email injector (Node port)')
    .version(
      `pmta-injector version ${version}\nBuild time: ${buildTime}\nGit commit: ${gitCommit}`,
      '--version',
      '显示版本信息'
    )
    .option('-c, --config <path>', '配置文件路径')
    .option('-v, --verbose', '详细输出模式', false)
    .option('-q, --quiet', '静默模式', false)
    .hook('preAction', (thisCommand /*, actionCommand */) => {
      const opts = thisCommand.opts();
      globalOpts.configFile = opts.config || '';
      globalOpts.verbose = !!opts.verbose;
      globalOpts.quiet = !!opts.quiet;
    });

  // version 子命令（与 --version 并存，风格上对齐 Go cobra 的 `pmta-injector version`）
  program
    .command('version')
    .description('显示版本信息')
    .action(() => {
      process.stdout.write(`pmta-injector version ${version}\n`);
      process.stdout.write(`Build time: ${buildTime}\n`);
      process.stdout.write(`Git commit: ${gitCommit}\n`);
      process.stdout.write(`Node version: ${process.version}\n`);
      process.stdout.write(`OS/Arch: ${process.platform}/${process.arch}\n`);
    });

  // 注册各子命令模块
  sendModule.register(program, globalOpts);
  serveModule.register(program, globalOpts);
  validateModule.register(program, globalOpts);
  debugDumpModule.register(program, globalOpts);

  // parseAsync 支持子命令 action 返回 Promise
  await program.parseAsync(process.argv);
}

module.exports = { execute, globalOpts };
