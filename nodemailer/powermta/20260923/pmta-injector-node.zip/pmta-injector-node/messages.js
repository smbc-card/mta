// messages.js - 变体编译反指纹字符串池（对应 Go pmta-injector-clean/messages.go）
//
// 部署时 scripts/msgrepl.py 会把每个 __MSG_NNN__ 替换为等长随机 ASCII，
// 使每台服务器编译出的二进制内部字符串完全不同 → 反垃圾 strings 命令扫不出共同点。
//
// 长度锚定：__MSG_NNN__ = 11 字符（含下划线）；随机串保持 11 字符长度不变，避免 pkg
// 编译后二进制布局大小差异被 diff 出来。
//
// 使用 fnv 哈希（引用整个池）+ 环境变量分支，让 obfuscator/pkg 无法 tree-shake 掉这些字符串。

'use strict';

const crypto = require('crypto');

const __msgPool__ = [
  '__MSG_001__', '__MSG_002__', '__MSG_003__', '__MSG_004__', '__MSG_005__',
  '__MSG_006__', '__MSG_007__', '__MSG_008__', '__MSG_009__', '__MSG_010__',
  '__MSG_011__', '__MSG_012__', '__MSG_013__', '__MSG_014__', '__MSG_015__',
  '__MSG_016__', '__MSG_017__', '__MSG_018__', '__MSG_019__', '__MSG_020__',
  '__MSG_021__', '__MSG_022__', '__MSG_023__', '__MSG_024__', '__MSG_025__',
  '__MSG_026__', '__MSG_027__', '__MSG_028__', '__MSG_029__', '__MSG_030__',
  '__MSG_031__', '__MSG_032__', '__MSG_033__', '__MSG_034__', '__MSG_035__',
  '__MSG_036__', '__MSG_037__', '__MSG_038__', '__MSG_039__', '__MSG_040__',
  '__MSG_041__', '__MSG_042__', '__MSG_043__', '__MSG_044__', '__MSG_045__',
  '__MSG_046__', '__MSG_047__', '__MSG_048__', '__MSG_049__', '__MSG_050__',
  '__MSG_051__', '__MSG_052__', '__MSG_053__', '__MSG_054__', '__MSG_055__',
  '__MSG_056__', '__MSG_057__', '__MSG_058__', '__MSG_059__', '__MSG_060__',
  '__MSG_061__', '__MSG_062__', '__MSG_063__', '__MSG_064__', '__MSG_065__',
  '__MSG_066__', '__MSG_067__', '__MSG_068__', '__MSG_069__', '__MSG_070__',
  '__MSG_071__', '__MSG_072__', '__MSG_073__', '__MSG_074__', '__MSG_075__',
  '__MSG_076__', '__MSG_077__', '__MSG_078__', '__MSG_079__', '__MSG_080__',
  '__MSG_081__', '__MSG_082__', '__MSG_083__', '__MSG_084__', '__MSG_085__',
  '__MSG_086__', '__MSG_087__', '__MSG_088__', '__MSG_089__', '__MSG_090__',
  '__MSG_091__', '__MSG_092__', '__MSG_093__', '__MSG_094__', '__MSG_095__',
  '__MSG_096__', '__MSG_097__', '__MSG_098__', '__MSG_099__', '__MSG_100__',
  '__MSG_101__', '__MSG_102__', '__MSG_103__', '__MSG_104__', '__MSG_105__',
  '__MSG_106__', '__MSG_107__', '__MSG_108__', '__MSG_109__', '__MSG_110__',
  '__MSG_111__', '__MSG_112__', '__MSG_113__', '__MSG_114__', '__MSG_115__',
  '__MSG_116__', '__MSG_117__', '__MSG_118__', '__MSG_119__', '__MSG_120__',
];

// 计算池的 FNV-64a 哈希（对齐 Go hash/fnv.New64a）
// 让 obfuscator/pkg 无法把字符串池 tree-shake 掉（编译期无法证明这个变量永远用不到）
function _fnv64a(strings) {
  // FNV-64a 常量
  const FNV_OFFSET_BASIS_HIGH = 0xCBF29CE4;
  const FNV_OFFSET_BASIS_LOW  = 0x84222325;
  const FNV_PRIME_HIGH = 0x00000100;
  const FNV_PRIME_LOW  = 0x000001B3;
  // JS 无 uint64 → 用 BigInt
  let h = (BigInt(FNV_OFFSET_BASIS_HIGH) << 32n) | BigInt(FNV_OFFSET_BASIS_LOW);
  const prime = (BigInt(FNV_PRIME_HIGH) << 32n) | BigInt(FNV_PRIME_LOW);
  const MASK64 = (1n << 64n) - 1n;
  for (const s of strings) {
    const buf = Buffer.from(s, 'utf8');
    for (let i = 0; i < buf.length; i++) {
      h = h ^ BigInt(buf[i]);
      h = (h * prime) & MASK64;
    }
  }
  return h;
}

const __msgChecksum__ = _fnv64a(__msgPool__);

// 环境变量分支（永远不会命中，但静态分析器无法证明这点 → 保留池）
if (process.env['__PMTA_DUMP_CHK__'] === '1') {
  const idx = Number(__msgChecksum__ % BigInt(__msgPool__.length));
  process.stderr.write(__msgPool__[idx] + '\n');
}

// 额外保险：把校验和挂到 module.exports（obfuscator 不会消除 exports）
module.exports = {
  __msgPool__,
  __msgChecksum__: __msgChecksum__.toString(),
};
