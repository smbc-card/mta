// fatcode.js - 变体编译反指纹注入点（对应 Go pmta-injector-clean/fatcode.go）
//
// 本文件是"代码生成锚"：部署时脚本 deploy-injector-node.sh 会：
//   1. sed 替换 __FATCODE_MARKER_PLACEHOLDER__ 为 32 字节随机 ASCII
//   2. 通过 scripts/fatcode_gen.py 在文件末尾追加 200-400 行随机 dead code
//
// 目的：让每次编译出的二进制 SHA256 都不同，破坏反垃圾按二进制指纹批量匹配的能力。
//
// 【重要】此文件手动不要修改；如需调整锚点，需同步更新 deploy-injector-node.sh 的 sed 规则。

'use strict';

// __FATCODE_INJECTION_POINT_BEGIN__
// 部署时下方的占位标记 + 追加 dead code 将使每份编译产物唯一

const __fatcodeMarker__ = '__FATCODE_MARKER_PLACEHOLDER__';

function __fatcodeInit__() {
  return __fatcodeMarker__;
}

// __FATCODE_INJECTION_POINT_END__

// 立即执行（确保 __fatcodeMarker__ 被引用，obfuscator 和 pkg 不会消除它）
const __fatcodeResult__ = __fatcodeInit__();

// 导出为 CommonJS（避免被打包器 tree-shake 掉；实际不被任何模块 require，
// 但 pkg 打包时会把所有 pkg.scripts 列表里的 .js 都打入 —— fatcode.js 在 package.json pkg.scripts）
module.exports = { __fatcodeMarker__, __fatcodeInit__, __fatcodeResult__ };
