'use strict';
// reader - 收件人流式读取器（对应 Go pmta-injector-clean/reader/reader.go）
//
// 支持格式：
//   - CSV  自动列识别 email/name/firstname/lastname，其余进 customFields
//   - JSON 数组 [{email:..., name:...}, ...] 或对象流
//   - TXT  每行一个 email
//
// 关键：所有 reader 返回 AsyncIterable<Recipient>，dispatcher 用 `for await` 消费。
// 关键：readEmailList 是同步版本（CC/BCC 池启动时一次性加载，与 Go 端一致）。

const fs = require('fs');
const path = require('path');
const readline = require('readline');

// ═════════════════════════════════════════════════════════════
// Recipient 对象结构（camelCase 内部，序列化时按需转换）
//   { email, name, firstName, lastName, customFields, lineNumber }
// ═════════════════════════════════════════════════════════════

// CSV 已知列名到 Recipient 字段的映射
const CSV_KNOWN_COLUMNS = {
  email: 'email', 'e-mail': 'email', mail: 'email',
  emailaddress: 'email', email_address: 'email',
  name: 'name', fullname: 'name', full_name: 'name',
  firstname: 'firstName', first_name: 'firstName', first: 'firstName', fname: 'firstName',
  lastname: 'lastName', last_name: 'lastName', last: 'lastName', lname: 'lastName',
};

// ═════════════════════════════════════════════════════════════
// createStream - 根据文件扩展名或 cfg.recipients.format 选择 reader
// 返回 AsyncIterable<Recipient>
// ═════════════════════════════════════════════════════════════
function createStream(filePath, cfg) {
  const ext = path.extname(filePath).toLowerCase();
  let format = (cfg.recipients && cfg.recipients.format) || '';
  if (!format || format === 'auto') {
    switch (ext) {
      case '.csv':  format = 'csv';  break;
      case '.json': format = 'json'; break;
      case '.txt':  format = 'txt';  break;
      default:      format = 'csv';  break;
    }
  }
  switch (format) {
    case 'csv':  return createCSVStream(filePath, cfg);
    case 'json': return createJSONStream(filePath, cfg);
    case 'txt':  return createTXTStream(filePath);
    default:
      throw new Error(`不支持的文件格式: ${format}`);
  }
}

// ═════════════════════════════════════════════════════════════
// CSV 流式读取（手写解析器，避免引入 csv-parser 包，减少 pkg 依赖）
// 支持双引号包裹、双引号转义 ""、分隔符可配置、可选 header 行
// ═════════════════════════════════════════════════════════════
async function* createCSVStream(filePath, cfg) {
  const delimiter = (cfg.recipients && cfg.recipients.csv && cfg.recipients.csv.delimiter) || ',';
  const hasHeader = !cfg.recipients || !cfg.recipients.csv || cfg.recipients.csv.has_header !== false;
  const fieldMapping = (cfg.recipients && cfg.recipients.csv && cfg.recipients.csv.field_mapping) || {};

  const rl = readline.createInterface({
    input: fs.createReadStream(filePath, { encoding: 'utf8' }),
    crlfDelay: Infinity,
  });

  let headers = null;      // 原始列名数组
  let lineNumber = 0;       // 数据行号（不含 header）
  let physicalLine = 0;     // 物理行号（含 header）
  let isFirstLine = true;

  for await (let rawLine of rl) {
    physicalLine++;
    // 首行 BOM 剥除
    if (isFirstLine && rawLine.charCodeAt(0) === 0xFEFF) {
      rawLine = rawLine.slice(1);
    }
    isFirstLine = false;

    // 空行跳过（不计 lineNumber）
    if (rawLine.trim() === '') continue;

    const fields = parseCSVLine(rawLine, delimiter);

    if (hasHeader && headers === null) {
      headers = fields.map((h) => h.trim());
      continue;
    }

    lineNumber++;
    const recipient = {
      email: '', name: '', firstName: '', lastName: '',
      customFields: {},
      lineNumber,
    };

    if (headers && headers.length > 0) {
      for (let i = 0; i < fields.length && i < headers.length; i++) {
        const rawHeader = headers[i];
        const value = (fields[i] || '').trim();
        let fname = rawHeader.toLowerCase().trim();
        // 自定义映射优先
        if (fieldMapping[fname]) fname = String(fieldMapping[fname]).toLowerCase();
        const known = CSV_KNOWN_COLUMNS[fname];
        if (known) {
          recipient[known] = value;
        } else {
          recipient.customFields[rawHeader] = value;
        }
      }
    } else {
      // 无 header：约定 0=email, 1=name, 2=first, 3=last, 4+=field0/field1/...
      if (fields[0]) recipient.email = fields[0].trim();
      if (fields[1]) recipient.name = fields[1].trim();
      if (fields[2]) recipient.firstName = fields[2].trim();
      if (fields[3]) recipient.lastName = fields[3].trim();
      for (let i = 4; i < fields.length; i++) {
        recipient.customFields[`field${i - 4}`] = (fields[i] || '').trim();
      }
    }

    // 合成 name
    if (!recipient.name && (recipient.firstName || recipient.lastName)) {
      recipient.name = `${recipient.firstName} ${recipient.lastName}`.trim();
    }

    yield recipient;
  }
}

// parseCSVLine - 解析一行 CSV，支持 "" 转义
function parseCSVLine(line, delimiter) {
  const out = [];
  let cur = '';
  let inQuote = false;
  const delimChar = delimiter.charAt(0);
  for (let i = 0; i < line.length; i++) {
    const ch = line.charAt(i);
    if (inQuote) {
      if (ch === '"') {
        if (i + 1 < line.length && line.charAt(i + 1) === '"') {
          cur += '"';
          i++;
        } else {
          inQuote = false;
        }
      } else {
        cur += ch;
      }
    } else {
      if (ch === '"') {
        inQuote = true;
      } else if (ch === delimChar) {
        out.push(cur);
        cur = '';
      } else {
        cur += ch;
      }
    }
  }
  out.push(cur);
  return out;
}

// ═════════════════════════════════════════════════════════════
// JSON 流式读取（数组 [{...}, {...}]）
// 简化实现：一次读入内存 + JSON.parse。真正流式解析 (JSONStream) 需要额外依赖。
// 收件人 JSON 通常 ≤ 100 万条，单文件 ≤ 200MB 内存可承受。
// ═════════════════════════════════════════════════════════════
async function* createJSONStream(filePath, cfg) {
  const raw = fs.readFileSync(filePath, 'utf8');
  let arr;
  try {
    arr = JSON.parse(raw);
  } catch (e) {
    throw new Error(`解析 JSON 失败: ${e.message}`);
  }
  if (!Array.isArray(arr)) {
    throw new Error('JSON 格式错误: 期望数组');
  }
  let lineNumber = 0;
  for (const item of arr) {
    if (!item || typeof item !== 'object') continue;
    lineNumber++;
    const recipient = {
      email: '', name: '', firstName: '', lastName: '',
      customFields: {},
      lineNumber,
    };
    for (const key of Object.keys(item)) {
      const lowerKey = key.toLowerCase();
      const val = item[key] == null ? '' : String(item[key]);
      switch (lowerKey) {
        case 'email': case 'e-mail': case 'mail':
          recipient.email = val; break;
        case 'name': case 'fullname':
          recipient.name = val; break;
        case 'firstname': case 'first_name':
          recipient.firstName = val; break;
        case 'lastname': case 'last_name':
          recipient.lastName = val; break;
        default:
          recipient.customFields[key] = val;
      }
    }
    if (!recipient.name && (recipient.firstName || recipient.lastName)) {
      recipient.name = `${recipient.firstName} ${recipient.lastName}`.trim();
    }
    yield recipient;
  }
}

// ═════════════════════════════════════════════════════════════
// TXT 流式读取（每行一个 email）
// ═════════════════════════════════════════════════════════════
async function* createTXTStream(filePath) {
  const rl = readline.createInterface({
    input: fs.createReadStream(filePath, { encoding: 'utf8' }),
    crlfDelay: Infinity,
  });
  let lineNumber = 0;
  let isFirstLine = true;
  for await (let line of rl) {
    if (isFirstLine && line.charCodeAt(0) === 0xFEFF) line = line.slice(1);
    isFirstLine = false;
    const email = line.trim();
    if (email === '') continue;
    lineNumber++;
    yield {
      email,
      name: '', firstName: '', lastName: '',
      customFields: {},
      lineNumber,
    };
  }
}

// ═════════════════════════════════════════════════════════════
// countLines - 快速统计收件人总数（仅用于 progress 百分比显示）
// CSV: 扫全文行 - header 行
// JSON: 返回 -1（无法预知）
// TXT: 扫全文非空行
// ═════════════════════════════════════════════════════════════
async function countLines(filePath, cfg) {
  const ext = path.extname(filePath).toLowerCase();
  let format = (cfg && cfg.recipients && cfg.recipients.format) || '';
  if (!format || format === 'auto') {
    switch (ext) {
      case '.csv':  format = 'csv';  break;
      case '.json': format = 'json'; break;
      case '.txt':  format = 'txt';  break;
      default:      format = 'csv';  break;
    }
  }
  if (format === 'json') return -1;

  const rl = readline.createInterface({
    input: fs.createReadStream(filePath, { encoding: 'utf8' }),
    crlfDelay: Infinity,
  });
  let count = 0;
  for await (const line of rl) {
    if (line.trim() !== '') count++;
  }
  if (format === 'csv') {
    const hasHeader = !cfg || !cfg.recipients || !cfg.recipients.csv || cfg.recipients.csv.has_header !== false;
    if (hasHeader && count > 0) count--;
  }
  return count;
}

// ═════════════════════════════════════════════════════════════
// 【2026-05-26 CC/BCC】readEmailList - 同步读取每行一个 email 的文件
//
// 对应 Go reader.ReadEmailList（含 v8.1.3 #22 CR/LF 过滤 + #24 BOM 过滤）
// 用于 dispatcher 启动时一次性加载 CC/BCC 池
//
// 语义：
//   - 保留原始顺序，不去重
//   - 跳过空白行
//   - 行内 CR/LF 替换为空格（防头部注入纵深防御）
//   - 首行 UTF-8 BOM 剥除
// ═════════════════════════════════════════════════════════════
function readEmailList(filePath) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, 'utf8');
  } catch (e) {
    throw new Error(`打开邮箱列表失败: ${e.message}`);
  }
  // 首行 BOM
  if (raw.length > 0 && raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
  // 按 \n 切
  const lines = raw.split('\n');
  const emails = [];
  for (let line of lines) {
    line = line.trim();
    if (line === '') continue;
    // CR/LF 过滤（v8.1.3 #22 防头部注入）
    if (line.indexOf('\r') !== -1 || line.indexOf('\n') !== -1) {
      line = line.replace(/[\r\n]/g, ' ').trim();
      if (line === '') continue;
    }
    emails.push(line);
  }
  return emails;
}

module.exports = { createStream, countLines, readEmailList };
