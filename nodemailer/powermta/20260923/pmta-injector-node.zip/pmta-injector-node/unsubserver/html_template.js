'use strict';
// unsubserver/html_template - 退订页 HTML 实例签名与模板生成
//   （对应 Go pmta-injector-clean/unsubserver/server.go 的 generateInstanceSignature + buildHTML）
//
// 【反指纹 C3 决策】
//   HTML 实例签名：启动时一次性随机生成，进程生命周期内稳定
//   （爬虫多次 GET 内容一致，不触发"动态"警报；不同服务器不同，破坏批量指纹）

const crypto = require('crypto');

// ═════════════════════════════════════════════════════════════
// 候选池（3 组各 3 个真实退订页面常见日语写法）
// ═════════════════════════════════════════════════════════════
const HEADING_CANDIDATES = [
  'メール配信停止手続き完了',
  '配信停止が完了しました',
  'メール配信停止が完了しました',
];

const BODY_CANDIDATES = [
  'ご登録いただいたメールアドレスへの配信を停止しました。今後、当社からのメールは届きません。',
  'メールマガジンの配信停止を承りました。今後はメールが届きません。',
  '配信停止のお手続きが完了しました。今後このメールアドレスへ配信されることはございません。',
];

// 颜色池
const HEADING_COLORS = ['0055bb', '0066cc', '1d4ed8', '2563eb', '1e40af', '1565c0', '0d47a1'];
const BODY_COLORS = ['333333', '444444', '555555', '2f2f2f', '3a3a3a'];

/**
 * generateInstanceSignature - 生成本进程实例签名（启动时调用一次）
 * @returns {Object} { headingColor, bodyColor, htmlComment, useFullStop, paddingLen, headingText, bodyText }
 */
function generateInstanceSignature() {
  const buf = crypto.randomBytes(16);
  const hIdx = buf[0] % HEADING_COLORS.length;
  const bIdx = buf[1] % BODY_COLORS.length;
  const hCandIdx = buf[2] % HEADING_CANDIDATES.length;
  const bCandIdx = buf[3] % BODY_CANDIDATES.length;
  const useFullStop = (buf[4] & 1) === 1;
  const padLen = buf[5] % 33;

  return {
    headingColor: HEADING_COLORS[hIdx],
    bodyColor: BODY_COLORS[bIdx],
    htmlComment: buf.slice(6, 14).toString('hex'), // 8 字节 hex
    useFullStop,
    paddingLen: padLen,
    headingText: HEADING_CANDIDATES[hCandIdx],
    bodyText: BODY_CANDIDATES[bCandIdx],
  };
}

/**
 * buildHTML - 根据实例签名生成退订页 HTML（Buffer）
 * @param {Object} sig 由 generateInstanceSignature 生成
 * @returns {Buffer}
 */
function buildHTML(sig) {
  let bodyText = sig.bodyText;
  if (!sig.useFullStop) {
    // 去掉末尾全角句号
    bodyText = bodyText.replace(/。+$/, '');
  }
  const padding = ' '.repeat(sig.paddingLen);

  const html =
`<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>${sig.headingText}</title>
<style>
body { font-family: 'Hiragino Sans', 'Yu Gothic', sans-serif; text-align: center; padding: 60px 20px; color: #${sig.bodyColor}; max-width: 600px; margin: 0 auto; }
h1 { font-size: 22px; color: #${sig.headingColor}; margin-bottom: 16px; }
p { font-size: 14px; line-height: 1.7; margin: 0.8em 0; }
.thanks { margin-top: 24px; color: #888; font-size: 13px; }
</style>
</head>
<body>
<h1>${sig.headingText}</h1>
<p>${bodyText}</p>
<p class="thanks">ご利用ありがとうございました</p>
<!-- ref:${sig.htmlComment} -->${padding}
</body>
</html>
`;

  return Buffer.from(html, 'utf8');
}

module.exports = {
  generateInstanceSignature,
  buildHTML,
  HEADING_CANDIDATES,
  BODY_CANDIDATES,
  HEADING_COLORS,
  BODY_COLORS,
};
