'use strict';
// unsubserver/server - HTTP 退订服务器（对应 Go pmta-injector-clean/unsubserver/server.go）
//
// 用途：ListUnsubMode=real 时启动；为 List-Unsubscribe URL 提供真实退订页
// （Gmail/Yahoo 反垃圾爬虫会 HEAD/GET/POST 验证 URL 可访问）。
//
// 架构（C1 决策）：
//   - 独立 systemd service（pmta-injector-unsub.service）长期运行
//   - 监听 0.0.0.0:80 (301 → HTTPS) + 0.0.0.0:443 (TLS)
//   - 通配符路由：所有路径返回同一个 2KB 日文静态退订页
//
// 反指纹（C3 决策）：
//   - HTML 实例签名启动时一次抽样，进程生命周期稳定
//   - X-Robots-Tag: noindex, nofollow
//
// 证书续期（C2 决策）：
//   - SNICallback 每次握手重读证书文件
//   - acme.sh 续期后自动生效，零 reload
//
// 【D2 加固】Host header 校验：Host 不匹配配置 Domain 时返回 404
//   避免直接 IP 扫描时暴露"这是发件器"身份

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const tls = require('tls');
const htmlMod = require('./html_template');

class Server {
  /**
   * @param {Object} cfg config.unsubscribe_server 子对象
   */
  constructor(cfg) {
    if (!cfg || !cfg.enabled) {
      throw new Error('unsubscribe server is disabled in config');
    }
    if (!cfg.cert_file || !cfg.key_file) {
      throw new Error('cert_file and key_file are required');
    }
    this.cfg = {
      enabled: cfg.enabled,
      listen_http: cfg.listen_http || ':80',
      listen_https: cfg.listen_https || ':443',
      cert_file: cfg.cert_file,
      key_file: cfg.key_file,
      domain: cfg.domain || '',
    };

    // 一次性生成实例签名 + 缓存 HTML
    this.instanceSig = htmlMod.generateInstanceSignature();
    this.cachedHTML = htmlMod.buildHTML(this.instanceSig);

    this.httpSrv = null;
    this.httpsSrv = null;

    // access log
    this.logDir = '/var/log/pmta-injector-unsub';
    this.logFilePath = path.join(this.logDir, 'access.log');
    this.logStream = null;
    try {
      fs.mkdirSync(this.logDir, { recursive: true });
      this.logStream = fs.createWriteStream(this.logFilePath, { flags: 'a' });
    } catch (_) { /* 权限不足等 → 静默忽略 */ }

    // 简单日滚动：记录当前日期
    this._logDate = _dateStr(new Date());
  }

  /**
   * Run - 启动 HTTP + HTTPS 服务器（阻塞直到 abortSignal 触发）
   * @param {AbortSignal} [abortSignal]
   * @returns {Promise<void>}
   */
  async run(abortSignal) {
    // ── HTTPS 服务器 ──
    // SNICallback 每次握手重读证书文件（对齐 Go GetCertificate 回调）
    const tlsOptions = {
      minVersion: 'TLSv1.2',
      SNICallback: (servername, cb) => {
        try {
          const key = fs.readFileSync(this.cfg.key_file);
          const cert = fs.readFileSync(this.cfg.cert_file);
          const ctx = tls.createSecureContext({ key, cert });
          cb(null, ctx);
        } catch (e) {
          cb(new Error(`load cert/key failed: ${e.message}`), null);
        }
      },
      // fallback cert/key（TLS 初次握手时用；SNICallback 后覆盖）
      key: fs.readFileSync(this.cfg.key_file),
      cert: fs.readFileSync(this.cfg.cert_file),
    };

    this.httpsSrv = https.createServer(tlsOptions, (req, res) => this._handleUnsubscribe(req, res));
    this.httpsSrv.headersTimeout = 10000;
    this.httpsSrv.requestTimeout = 20000;
    this.httpsSrv.keepAliveTimeout = 60000;

    const httpsAddr = _parseListenAddr(this.cfg.listen_https, 443);
    await _listenAsync(this.httpsSrv, httpsAddr.port, httpsAddr.host);
    _log(`[unsubserver] HTTPS listening on ${this.cfg.listen_https} (cert=${this.cfg.cert_file})`);

    // ── HTTP 服务器（80 端口 301 → HTTPS）──
    this.httpSrv = http.createServer((req, res) => this._handleHTTPRedirect(req, res));
    this.httpSrv.headersTimeout = 10000;
    this.httpSrv.requestTimeout = 20000;
    this.httpSrv.keepAliveTimeout = 60000;

    const httpAddr = _parseListenAddr(this.cfg.listen_http, 80);
    await _listenAsync(this.httpSrv, httpAddr.port, httpAddr.host);
    _log(`[unsubserver] HTTP listening on ${this.cfg.listen_http} (301 → HTTPS)`);

    // 等待中止信号
    if (abortSignal) {
      await new Promise((resolve) => {
        if (abortSignal.aborted) return resolve();
        abortSignal.addEventListener('abort', () => resolve(), { once: true });
      });
      _log('[unsubserver] received shutdown signal, gracefully shutting down...');
      await this.shutdown();
    } else {
      // 无中止信号 → 永久阻塞（外部通过 process.exit 强制退出）
      await new Promise(() => {});
    }
  }

  async shutdown() {
    const shutdownPromises = [];
    if (this.httpsSrv) shutdownPromises.push(_closeServer(this.httpsSrv, 5000));
    if (this.httpSrv) shutdownPromises.push(_closeServer(this.httpSrv, 5000));
    await Promise.all(shutdownPromises);
    if (this.logStream) {
      try { this.logStream.end(); } catch (_) { /* ignore */ }
      this.logStream = null;
    }
  }

  // ═════════════════════════════════════════════════════════════
  // Host 校验（D2 加固）
  // ═════════════════════════════════════════════════════════════
  _hostMatchesConfigured(req) {
    const configured = String(this.cfg.domain || '').trim();
    if (!configured) return true; // 配置缺失 → 退化不校验

    let host = req.headers.host;
    if (!host) return false;

    // 剥端口号
    if (host.startsWith('[')) {
      // IPv6 字面量 [::1]:80
      const end = host.lastIndexOf(']');
      if (end > 0) host = host.slice(1, end);
    } else {
      const idx = host.lastIndexOf(':');
      if (idx >= 0) host = host.slice(0, idx);
    }
    return host.trim().toLowerCase() === configured.toLowerCase();
  }

  // ═════════════════════════════════════════════════════════════
  // 退订页处理器（所有路径 + 所有方法都返回同一页）
  // ═════════════════════════════════════════════════════════════
  _handleUnsubscribe(req, res) {
    if (!this._hostMatchesConfigured(req)) {
      res.setHeader('X-Robots-Tag', 'noindex, nofollow');
      res.statusCode = 404;
      res.end('404 Not Found');
      this._logAccess(req, 404, 0);
      return;
    }

    // 反指纹响应头
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Length', this.cachedHTML.length);

    if (req.method === 'HEAD') {
      res.statusCode = 200;
      res.end();
      this._logAccess(req, 200, 0);
      return;
    }

    // GET / POST / PUT / 其他 → 200 + HTML（Gmail One-Click 用 POST）
    res.statusCode = 200;
    res.end(this.cachedHTML);
    this._logAccess(req, 200, this.cachedHTML.length);
  }

  // ═════════════════════════════════════════════════════════════
  // HTTP 80 → 301 HTTPS
  // ═════════════════════════════════════════════════════════════
  _handleHTTPRedirect(req, res) {
    if (!this._hostMatchesConfigured(req)) {
      res.setHeader('X-Robots-Tag', 'noindex, nofollow');
      res.statusCode = 404;
      res.end('404 Not Found');
      this._logAccess(req, 404, 0);
      return;
    }

    let host = req.headers.host || '';
    const colonIdx = host.indexOf(':');
    if (colonIdx >= 0) host = host.slice(0, colonIdx);
    if (!host) host = this.cfg.domain;

    const target = `https://${host}${req.url || '/'}`;
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    res.setHeader('Location', target);
    res.statusCode = 301;
    res.end();
    this._logAccess(req, 301, 0);
  }

  // ═════════════════════════════════════════════════════════════
  // access log（日滚动 + 7 天清理）
  // ═════════════════════════════════════════════════════════════
  _logAccess(req, status, bytes) {
    if (!this.logStream) return;
    this._rotateIfNeeded();
    const now = _timestampLog();
    const ua = (req.headers['user-agent'] || '-').replace(/"/g, '\\"');
    const remoteAddr = req.socket.remoteAddress || '-';
    const method = req.method || '-';
    const host = req.headers.host || '-';
    const uri = req.url || '-';
    const line = `${now} ${remoteAddr} ${method} ${host} ${uri} ${status} ${bytes} "${ua}"\n`;
    try { this.logStream.write(line); } catch (_) { /* ignore */ }
  }

  _rotateIfNeeded() {
    const today = _dateStr(new Date());
    if (today === this._logDate) return;

    // rotate
    try {
      this.logStream.end();
      const archived = `${this.logFilePath}.${this._logDate}`;
      fs.renameSync(this.logFilePath, archived);
      this.logStream = fs.createWriteStream(this.logFilePath, { flags: 'a' });
      this._logDate = today;
      // 异步清理 > 7 天旧文件
      setImmediate(() => this._cleanOldLogs());
    } catch (_) {
      this._logDate = today; // 避免重复尝试
    }
  }

  _cleanOldLogs() {
    try {
      const dir = path.dirname(this.logFilePath);
      const prefix = path.basename(this.logFilePath) + '.';
      const cutoff = Date.now() - 7 * 24 * 3600 * 1000;
      const entries = fs.readdirSync(dir);
      for (const name of entries) {
        if (!name.startsWith(prefix)) continue;
        try {
          const st = fs.statSync(path.join(dir, name));
          if (st.mtimeMs < cutoff) {
            fs.unlinkSync(path.join(dir, name));
          }
        } catch (_) { /* ignore */ }
      }
    } catch (_) { /* ignore */ }
  }
}

// ═════════════════════════════════════════════════════════════
// 工具函数
// ═════════════════════════════════════════════════════════════

/**
 * _parseListenAddr - 解析 ":80" / "0.0.0.0:443" / "[::1]:80" 形式
 * @returns {{host: string, port: number}}
 */
function _parseListenAddr(addr, defaultPort) {
  const s = String(addr || '').trim();
  if (!s) return { host: '0.0.0.0', port: defaultPort };
  // IPv6 字面量
  if (s.startsWith('[')) {
    const end = s.indexOf(']');
    if (end > 0) {
      const host = s.slice(1, end);
      const portPart = s.slice(end + 1);
      const port = portPart.startsWith(':') ? parseInt(portPart.slice(1), 10) : defaultPort;
      return { host, port: port || defaultPort };
    }
  }
  // ":80" 形式（仅端口）
  if (s.startsWith(':')) {
    const port = parseInt(s.slice(1), 10);
    return { host: '0.0.0.0', port: port || defaultPort };
  }
  // "host:port"
  const idx = s.lastIndexOf(':');
  if (idx > 0) {
    const host = s.slice(0, idx);
    const port = parseInt(s.slice(idx + 1), 10);
    return { host, port: port || defaultPort };
  }
  return { host: s, port: defaultPort };
}

function _listenAsync(server, port, host) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => {
      server.removeListener('error', reject);
      resolve();
    });
  });
}

function _closeServer(server, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const finalize = () => {
      if (done) return;
      done = true;
      resolve();
    };
    try { server.close(finalize); }
    catch (_) { finalize(); return; }
    // 超时兜底
    setTimeout(finalize, timeoutMs);
  });
}

function _dateStr(d) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}

function _timestampLog() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const tzOff = -d.getTimezoneOffset();
  const sign = tzOff >= 0 ? '+' : '-';
  const abs = Math.abs(tzOff);
  const oh = pad(Math.floor(abs / 60));
  const om = pad(abs % 60);
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T` +
         `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}${sign}${oh}${om}`;
}

function _log(msg) {
  process.stdout.write(msg + '\n');
}

function newServer(cfg) {
  return new Server(cfg);
}

module.exports = { Server, newServer };
