'use strict';
// email/bidi - 字节反转隐藏 (RLO + LRI/PDI 隔离)（对应 Go pmta-injector-clean/email/bidi.go）
//
// 【2026-06-17 从 Haraka 移植 / 2026-07-09 升级】
//   输出格式：[LRI(U+2066)][RLO(U+202E)][code point 反序内容][PDF(U+202C)][PDI(U+2069)]
//
// 关键点：
//   - LRI/PDI（Unicode 6.3+）把整段视为独立方向段，外围文本不受内部 RLO 影响
//   - RLO/PDF 在隔离段内部把反序内容视觉再反一次 → 字母/数字/CJK 显示正常
//   - 扫描器看到的原始字节是反序的 → 朴素子串关键词匹配失效
//
// 显示局限（RLO 固有）：
//   ① 成对镜像字符（() [] <> {}）在 RTL 覆盖下会被镜像翻转
//   ② rune 反转会拆散 emoji 的 ZWJ 组合序列 → 组合序列可能错乱
//   纯文字（CJK/拉丁/数字/常见标点）无影响
//
// 应用时机（builder.js）：文本 → 变量/模板替换 → 零宽字符插入（如启用）→ 本函数（最后一道）
//   顺序含义：零宽字符跟原文一起被反转，视觉上仍落在合理位置；RLO 段内零宽字符（BN 类）
//             不打断 bidi 计算 → 视觉正确 + 反指纹叠加
//
// 限制：LRI/RLO/PDF/PDI 是 UTF-8 专属；Shift_JIS/ISO-2022-JP/EUC-JP/GBK 无法表示
//       调用方必须先用 bidiCharsetSupported 判定 charset，非 UTF-8 时跳过

// 4 个控制符（源码里用 \u 转义而非字面控制符，避免真实 RLO 出现在源码里造成显示错乱）
const BIDI_LRI = '⁦'; // Left-to-Right Isolate（开启方向隔离段）
const BIDI_RLO = '‮'; // Right-to-Left Override（强制反转）
const BIDI_PDF = '‬'; // Pop Directional Formatting（关 RLO 覆盖）
const BIDI_PDI = '⁩'; // Pop Directional Isolate（关 LRI 隔离段）

/**
 * bidiReverseHide - rune 反序 + LRI/PDI 隔离包裹
 * @param {string} text
 * @returns {string} 空串原样返回；4 个控制符 × 3 字节 UTF-8 = 12 字节额外开销
 *
 * 关键：Array.from(str) 按 Unicode code point 迭代（而不是 UTF-16 code unit），
 *      正确处理代理对（surrogate pair，如 emoji）。
 */
function bidiReverseHide(text) {
  if (!text) return text;
  const cp = Array.from(text); // code point 数组
  let reversed = '';
  for (let i = cp.length - 1; i >= 0; i--) {
    reversed += cp[i];
  }
  return BIDI_LRI + BIDI_RLO + reversed + BIDI_PDF + BIDI_PDI;
}

/**
 * bidiCharsetSupported - 仅 UTF-8（含空串默认）支持 bidi 控制符
 * @param {string} charset
 * @returns {boolean}
 */
function bidiCharsetSupported(charset) {
  const c = String(charset || '').toUpperCase().trim();
  return c === '' || c === 'UTF-8' || c === 'UTF8';
}

module.exports = {
  bidiReverseHide,
  bidiCharsetSupported,
  BIDI_LRI,
  BIDI_RLO,
  BIDI_PDF,
  BIDI_PDI,
};
