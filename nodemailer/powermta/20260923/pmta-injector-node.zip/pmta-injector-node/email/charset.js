'use strict';
// email/charset - UTF-8 → 目标编码转换（对应 Go pmta-injector-clean/email/charset.go）
//
// 支持编码：
//   Shift_JIS / Windows-31j / CP932  → encoding-japanese SJIS
//   ISO-2022-JP                       → encoding-japanese JIS  ★ 有状态编码，特别注意
//   EUC-JP                            → encoding-japanese EUCJP
//   GB2312 / GBK / GB18030 / CP936    → iconv-lite gbk
//   HZ-GB-2312                        → iconv-lite hz
//   其他 (UTF-8 / US-ASCII / 未知)    → 不转换，UTF-8 字节直返
//
// 【Haraka25 修复】转换失败时逐字符替换为 '?'（**不整段回退**）
//   Go 版本用 transform.Bytes 全串失败后逐字符检测，把不支持的字符换成 '?'
//   Node 版本：encoding-japanese 和 iconv-lite 默认就是"不支持字符替换为 '?'"，
//              效果等价（不需要显式逐字符）
//   ISO-2022-JP 状态机的转义序列在整段转换时保持连续正确

const iconv = require('iconv-lite');
const Encoding = require('encoding-japanese');

/**
 * isUTF8Charset - 判断 charset 是否为 UTF-8（不需要转换）
 * @param {string} charset
 * @returns {boolean}
 */
function isUTF8Charset(charset) {
  const lower = String(charset || '').toLowerCase().trim();
  return lower === '' || lower === 'utf-8' || lower === 'utf8' ||
         lower === 'us-ascii' || lower === 'ascii';
}

/**
 * _normalizeToEncoderKey - 把 charset 名映射到内部编码器 key
 * @param {string} charset
 * @returns {string} 'sjis' | 'iso2022jp' | 'eucjp' | 'gbk' | 'hz' | ''
 */
function _normalizeToEncoderKey(charset) {
  const c = String(charset || '').toLowerCase().trim();
  switch (c) {
    case 'shift_jis': case 'shift-jis': case 'sjis':
    case 'windows-31j': case 'cp932':
      return 'sjis';
    case 'iso-2022-jp': case 'iso2022jp':
      return 'iso2022jp';
    case 'euc-jp': case 'eucjp':
      return 'eucjp';
    case 'gb2312': case 'gbk': case 'gb18030':
    case 'cp936': case 'windows-936':
      return 'gbk';
    case 'hz-gb-2312': case 'hz-gb2312':
      return 'hz';
    default:
      return '';
  }
}

/**
 * convertFromUTF8 - 将 UTF-8 字符串或字节转换为目标编码的 Buffer
 * 如果 charset 是 UTF-8 或不支持的编码，直接返回 UTF-8 字节（不做转换）
 *
 * 关键：与 Go 版行为对齐 —— 不支持字符被替换为 '?'（encoding-japanese 和 iconv-lite 的默认行为）
 *
 * @param {string|Buffer} input UTF-8 字符串或 Buffer
 * @param {string} charset 目标 charset
 * @returns {Buffer} 目标编码的字节
 */
function convertFromUTF8(input, charset) {
  // 统一入参为 string
  let str;
  if (Buffer.isBuffer(input)) str = input.toString('utf8');
  else str = String(input || '');

  if (isUTF8Charset(charset)) return Buffer.from(str, 'utf8');

  const key = _normalizeToEncoderKey(charset);
  if (!key) return Buffer.from(str, 'utf8'); // 未知编码 → 不转换

  try {
    switch (key) {
      case 'sjis':
        return _jpConvert(str, 'SJIS');
      case 'iso2022jp':
        return _jpConvert(str, 'JIS');
      case 'eucjp':
        return _jpConvert(str, 'EUCJP');
      case 'gbk':
        return iconv.encode(str, 'gbk');
      case 'hz':
        // iconv-lite 有 hz 支持
        return iconv.encode(str, 'hz');
      default:
        return Buffer.from(str, 'utf8');
    }
  } catch (e) {
    // 极端情况：转换器本身崩溃 → 逐字符兜底
    return _perCharFallback(str, key);
  }
}

/**
 * convertStringFromUTF8 - 兼容 Go ConvertStringFromUTF8 接口
 * @param {string} s
 * @param {string} charset
 * @returns {Buffer}
 */
function convertStringFromUTF8(s, charset) {
  return convertFromUTF8(s, charset);
}

// ─── 内部：日文编码转换 ───
function _jpConvert(str, targetName) {
  // encoding-japanese 接受 UNICODE (Node string 内部是 UTF-16 code unit，
  // 但要按 code point 传给 encoding-japanese 才能正确处理代理对)
  const codePoints = [];
  for (const ch of str) {
    codePoints.push(ch.codePointAt(0));
  }
  const outArr = Encoding.convert(codePoints, {
    from: 'UNICODE',
    to: targetName,
    type: 'array',
  });
  return Buffer.from(outArr);
}

// ─── 内部：逐字符兜底（极端情况下用）───
function _perCharFallback(str, key) {
  let safe = '';
  for (const ch of str) {
    try {
      let bytes;
      if (key === 'sjis') bytes = _jpConvert(ch, 'SJIS');
      else if (key === 'iso2022jp') bytes = _jpConvert(ch, 'JIS');
      else if (key === 'eucjp') bytes = _jpConvert(ch, 'EUCJP');
      else if (key === 'gbk') bytes = iconv.encode(ch, 'gbk');
      else if (key === 'hz') bytes = iconv.encode(ch, 'hz');
      else bytes = Buffer.from(ch, 'utf8');
      if (bytes && bytes.length > 0) safe += ch;
      else safe += '?';
    } catch (_) {
      safe += '?';
    }
  }
  // 再整段转一次
  try {
    if (key === 'sjis') return _jpConvert(safe, 'SJIS');
    if (key === 'iso2022jp') return _jpConvert(safe, 'JIS');
    if (key === 'eucjp') return _jpConvert(safe, 'EUCJP');
    if (key === 'gbk') return iconv.encode(safe, 'gbk');
    if (key === 'hz') return iconv.encode(safe, 'hz');
  } catch (_) { /* fall through */ }
  return Buffer.from(safe, 'utf8');
}

/**
 * getEncoderKey - 暴露给 headers.js 用于判断是否需要 encoded-word 编码
 * @param {string} charset
 * @returns {string} 归一化的 key（sjis/iso2022jp/eucjp/gbk/hz/'' 表示 UTF-8 或未知）
 */
function getEncoderKey(charset) {
  return _normalizeToEncoderKey(charset);
}

module.exports = {
  isUTF8Charset,
  convertFromUTF8,
  convertStringFromUTF8,
  getEncoderKey,
};
