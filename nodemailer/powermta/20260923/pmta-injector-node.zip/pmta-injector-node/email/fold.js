'use strict';
// email/fold - RFC 5322 §2.2.3 智能邮件头折叠器（对应 Go pmta-injector-clean/email/fold.go）
//
// 规则：
//   - 单行 ≤ 78 字符（软推荐）；单行 ≤ 998 字符（硬上限，超出违反 RFC）
//   - 折叠续行前缀：CRLF + 1 个 WSP（我们用 "\r\n\t"）
//   - 优先在语义边界断行："; " → " for " → " by " → " with " → " (EHLO " → ") " → 空格
//
// 用于 Received（随机）模板池 + List-Unsubscribe 长值折叠。
// 与 Go 版函数签名 + 边界优先级 + 输出格式**逐字节对齐**。

const TARGET_LEN = 78;
const HARD_LIMIT = 998;

/**
 * foldHeaderValue - 把单行头部值折叠成符合 RFC 5322 §2.2.3 的多行形式
 * @param {string} value 头部值（不含 Name 和冒号，不含末尾 CRLF）
 * @param {number} prefixLen "Header-Name: " 的字符数（首行预留宽度）
 * @returns {string} 不含 "Header-Name:" 前缀，但含必要的 CRLF + tab 续行
 */
function foldHeaderValue(value, prefixLen) {
  // 清理可能的 \r \n（防御性）
  let v = String(value)
    .replace(/\r\n/g, ' ')
    .replace(/\r/g, ' ')
    .replace(/\n/g, ' ');

  if (prefixLen + v.length <= TARGET_LEN) return v;

  let out = '';
  let currentLineLen = prefixLen;
  let remaining = v;
  let firstChunk = true;

  while (remaining.length > 0) {
    let budget = TARGET_LEN - currentLineLen;
    if (budget < 20) {
      out += '\r\n\t';
      currentLineLen = 1; // tab 算 1 字符
      budget = TARGET_LEN - 1;
      firstChunk = false;
    }

    if (remaining.length <= budget) {
      out += remaining;
      return out;
    }

    let breakAt = findBestBreak(remaining, budget, HARD_LIMIT - currentLineLen);
    if (breakAt < 0) {
      breakAt = budget;
      if (breakAt > remaining.length) breakAt = remaining.length;
    }

    out += remaining.slice(0, breakAt);
    out += '\r\n\t';
    currentLineLen = 1;

    // 跳过断点后的前导空白（避免续行首字符是空格）
    remaining = remaining.slice(breakAt).replace(/^[ \t]+/, '');
    firstChunk = false;
  }

  return out;
}

/**
 * findBestBreak - 在 value 的 [1, softBudget] 之间找最佳断行位置
 * @param {string} value
 * @param {number} softBudget
 * @param {number} hardBudget
 * @returns {number} 断点索引；找不到返回 -1
 *
 * 优先级（高到低）：
 *   1. "; "     → 在 ";" 后切（含 "; " 在前段）
 *   2. " for "  → 在 for 前的空格之后
 *   3. " by "   → 同上
 *   4. " with " → 同上
 *   5. " (EHLO "→ 在 ( 前的空格之后
 *   6. ") "     → 含 ") " 在前段
 *   7. " "      → 任意空格（最后兜底）
 */
function findBestBreak(value, softBudget, hardBudget) {
  if (hardBudget < softBudget) softBudget = hardBudget;
  if (softBudget <= 1) return -1;
  if (softBudget > value.length) softBudget = value.length;

  const search = value.slice(0, softBudget);

  // 1. "; "
  {
    const idx = search.lastIndexOf('; ');
    if (idx > 0) return idx + 2;
  }
  // 2. " for "
  {
    const idx = search.lastIndexOf(' for ');
    if (idx > 0) return idx + 1;
  }
  // 3. " by "
  {
    const idx = search.lastIndexOf(' by ');
    if (idx > 0) return idx + 1;
  }
  // 4. " with "
  {
    const idx = search.lastIndexOf(' with ');
    if (idx > 0) return idx + 1;
  }
  // 5. " (EHLO "
  {
    const idx = search.lastIndexOf(' (EHLO ');
    if (idx > 0) return idx + 1;
  }
  // 6. ") "
  {
    const idx = search.lastIndexOf(') ');
    if (idx > 0) return idx + 2;
  }
  // 7. 任意空格
  {
    const idx = search.lastIndexOf(' ');
    if (idx > 0) return idx + 1;
  }

  // soft budget 内没找到 → 尝试 hard budget 范围
  if (hardBudget > softBudget && hardBudget <= value.length) {
    const extSearch = value.slice(0, hardBudget);
    const idx = extSearch.lastIndexOf(' ');
    if (idx > softBudget) return idx + 1;
  }

  return -1;
}

/**
 * foldFullHeader - 完整折叠一个 "Name: value\r\n" 形式的邮件头
 * @param {string} name  例如 "Received"
 * @param {string} value 头部值（不含 Name 和冒号，不含末尾 CRLF）
 * @returns {string} 完整 "Name: folded-value\r\n"
 */
function foldFullHeader(name, value) {
  const prefixLen = name.length + 2; // "Name: "
  const folded = foldHeaderValue(value, prefixLen);
  return `${name}: ${folded}\r\n`;
}

module.exports = { foldHeaderValue, findBestBreak, foldFullHeader };
