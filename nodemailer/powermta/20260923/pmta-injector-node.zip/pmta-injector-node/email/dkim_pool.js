'use strict';
// email/dkim_pool - 伪 DKIM-Signature 外部域池（对应 Go pmta-injector-clean/email/headers.go 顶部数据）
//
// 【方案 B 移植自 Haraka 2026-05-15】
// 伪签名故意将 d= 设为外部大厂域（而非发件方真实域），让接收方反垃圾把 "DKIM 校验失败"
// 归因于 "邮件经过外部中转链路时签名损坏"（邮件常态、反垃圾宽容），而非 "发件方自家签名
// 都对不上"（被视为伪造、严重扣分）。
//
// 【2026-05-18】字段多样化：
//   - c= 按 dkimCanonicalizations 加权抽样
//   - h= 按发件方风格池抽样（gmail/outlook/yahoo/ses/japan/generic）
//   - b= 长度对应 selector 的 RSA 位数（1024/2048/4096 → 172/344/684 base64 字符）

const randSafe = require('./rand_safe');

// 环形缓冲区容量
const DKIM_RECENT_RING_SIZE = 8;

// Amazon SES 风格 selector 的字符集（base32 小写 + 数字 2-7）
const DKIM_SES_CHARSET = 'abcdefghijklmnopqrstuvwxyz234567';

// ═════════════════════════════════════════════════════════════
// 外部大厂域签名池（72 条，按真实邮件流量加权）
// 【契约】顺序与 Go dkimExternalSources 逐条一致，新增只能往末尾加
// ═════════════════════════════════════════════════════════════
const dkimExternalSources = [
  // Google 系
  { domain: 'gmail.com', selectors: ['20230601', '20221208', '20210112', '20161025'], weight: 20, isSESLike: false, rsaBits: 2048 },
  { domain: 'googlemail.com', selectors: ['20230601', '20221208'], weight: 4, isSESLike: false, rsaBits: 2048 },
  { domain: 'google.com', selectors: ['20221208', '20230601'], weight: 4, isSESLike: false, rsaBits: 2048 },
  // Microsoft 系
  { domain: 'outlook.com', selectors: ['selector1', 'selector2'], weight: 12, isSESLike: false, rsaBits: 2048 },
  { domain: 'hotmail.com', selectors: ['selector1', 'selector2'], weight: 7, isSESLike: false, rsaBits: 2048 },
  { domain: 'live.com', selectors: ['selector1', 'selector2'], weight: 4, isSESLike: false, rsaBits: 2048 },
  { domain: 'microsoft.com', selectors: ['selector1', 'selector2'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'office365.com', selectors: ['selector1'], weight: 2, isSESLike: false, rsaBits: 2048 },
  // Yahoo 系
  { domain: 'yahoo.com', selectors: ['s2048', 's1024', 's1'], weight: 6, isSESLike: false, rsaBits: 2048 },
  { domain: 'yahoo.co.jp', selectors: ['s2048', 's1024'], weight: 6, isSESLike: false, rsaBits: 2048 },
  { domain: 'ymail.com', selectors: ['s2048'], weight: 2, isSESLike: false, rsaBits: 2048 },
  // Apple 系
  { domain: 'icloud.com', selectors: ['1a1hai', 'sig1'], weight: 5, isSESLike: false, rsaBits: 2048 },
  { domain: 'me.com', selectors: ['1a1hai'], weight: 2, isSESLike: false, rsaBits: 2048 },
  // Amazon SES（selector 每次动态生成 32 字符）
  { domain: 'amazonses.com', selectors: null, weight: 10, isSESLike: true, rsaBits: 2048 },
  // ESP
  { domain: 'sendgrid.net', selectors: ['s1', 'smtpapi', 'm1'], weight: 5, isSESLike: false, rsaBits: 2048 },
  { domain: 'sendgrid.me', selectors: ['s1'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'mailgun.org', selectors: ['k1', 'mg', 'pic'], weight: 4, isSESLike: false, rsaBits: 2048 },
  { domain: 'mandrillapp.com', selectors: ['mandrill', 'mte1'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'mcsv.net', selectors: ['k2'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'mtasv.net', selectors: ['20150623'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'sparkpostmail.com', selectors: ['scph1220'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'hubspotemail.net', selectors: ['hs1'], weight: 2, isSESLike: false, rsaBits: 2048 },
  // 日本运营商
  { domain: 'docomo.ne.jp', selectors: ['docomo', 'mail'], weight: 5, isSESLike: false, rsaBits: 2048 },
  { domain: 'softbank.ne.jp', selectors: ['sb', 'softbank'], weight: 4, isSESLike: false, rsaBits: 2048 },
  { domain: 'au.com', selectors: ['au', 'default'], weight: 4, isSESLike: false, rsaBits: 2048 },
  { domain: 'ezweb.ne.jp', selectors: ['ezweb'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'kddi.com', selectors: ['kddi'], weight: 2, isSESLike: false, rsaBits: 2048 },
  // 日本本地邮件商
  { domain: 'nifty.com', selectors: ['default'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'biglobe.ne.jp', selectors: ['default'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'so-net.ne.jp', selectors: ['s1024'], weight: 2, isSESLike: false, rsaBits: 1024 },
  { domain: 'ocn.ad.jp', selectors: ['default'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'plala.or.jp', selectors: ['default'], weight: 1, isSESLike: false, rsaBits: 2048 },
  // 韩国
  { domain: 'naver.com', selectors: ['s2048', 'naver'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'daum.net', selectors: ['daum'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'kakao.com', selectors: ['kakao'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'hanmail.net', selectors: ['hanmail'], weight: 1, isSESLike: false, rsaBits: 1024 },
  // 欧洲
  { domain: 'gmx.de', selectors: ['s1', 'k1'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'web.de', selectors: ['webde', 'default'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'mail.ru', selectors: ['mailru', 'selector'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'yandex.ru', selectors: ['mail', 'yandex'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'tutanota.com', selectors: ['tutanota'], weight: 1, isSESLike: false, rsaBits: 4096 },
  // 国内主流
  { domain: '163.com', selectors: ['s2048', 's1024'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'qq.com', selectors: ['s201512', 's202004'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: '126.com', selectors: ['s2048'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'sina.com', selectors: ['s1024'], weight: 1, isSESLike: false, rsaBits: 1024 },
  { domain: 'sohu.com', selectors: ['sohu'], weight: 1, isSESLike: false, rsaBits: 1024 },
  { domain: 'aliyun.com', selectors: ['aliyun'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'foxmail.com', selectors: ['foxmail'], weight: 1, isSESLike: false, rsaBits: 1024 },
  // 企业 SaaS
  { domain: 'salesforce.com', selectors: ['200608'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'pardot.com', selectors: ['pardotdkim'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'linkedin.com', selectors: ['proddkim1024'], weight: 1, isSESLike: false, rsaBits: 1024 },
  { domain: 'paypal.com', selectors: ['pp-dkim1'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'adobe.com', selectors: ['s2048'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'zoho.com', selectors: ['zmail'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'zendesk.com', selectors: ['mail'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'intercom-mail.com', selectors: ['intercom'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'protonmail.com', selectors: ['protonmail'], weight: 1, isSESLike: false, rsaBits: 4096 },
  { domain: 'fastmail.com', selectors: ['fm1'], weight: 1, isSESLike: false, rsaBits: 2048 },
  // 长尾欧美
  { domain: 'fastmail.fm', selectors: ['fm1'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'gmx.com', selectors: ['k1'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'mailbox.org', selectors: ['mbo1'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'runbox.com', selectors: ['runbox'], weight: 1, isSESLike: false, rsaBits: 2048 },
  // 日本运营商 / MVNO / ISP 扩展（2026-05-18 第二批）
  { domain: 'i.softbank.jp', selectors: ['sb-iphone', 'softbank'], weight: 5, isSESLike: false, rsaBits: 2048 },
  { domain: 'ymobile.ne.jp', selectors: ['ymobile'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'uqmobile.jp', selectors: ['uqmobile'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'rakuten-mobile.jp', selectors: ['rakuten-mobile'], weight: 3, isSESLike: false, rsaBits: 2048 },
  { domain: 'mineo.jp', selectors: ['mineo'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'iijmio.jp', selectors: ['iijmio'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'ocn.ne.jp', selectors: ['ocn', 'default'], weight: 2, isSESLike: false, rsaBits: 2048 },
  { domain: 'dion.ne.jp', selectors: ['dion'], weight: 1, isSESLike: false, rsaBits: 2048 },
  { domain: 'odn.ne.jp', selectors: ['odn'], weight: 1, isSESLike: false, rsaBits: 1024 },
  { domain: 'zaq.ne.jp', selectors: ['zaq'], weight: 1, isSESLike: false, rsaBits: 1024 },
];

// ═════════════════════════════════════════════════════════════
// c= 规范化算法加权池
// ═════════════════════════════════════════════════════════════
const dkimCanonicalizations = [
  { value: 'relaxed/relaxed', weight: 70 },
  { value: 'relaxed/simple', weight: 15 },
  { value: 'simple/simple', weight: 10 },
  { value: 'simple/relaxed', weight: 5 },
];

// ═════════════════════════════════════════════════════════════
// h= 字段按发件方风格池
// ═════════════════════════════════════════════════════════════
const dkimHFieldsByStyle = {
  gmail: [
    'from:to:subject:date:message-id:mime-version:content-type',
    'from:to:subject:date:message-id:mime-version:reply-to',
    'to:cc:from:subject:message-id:date:mime-version',
  ],
  outlook: [
    'From:To:Subject:Date:Message-ID:Content-Type:Content-Transfer-Encoding:MIME-Version',
    'MIME-Version:Date:From:To:Subject:Message-ID:Content-Type:Content-Transfer-Encoding',
  ],
  yahoo: [
    'Received:From:Reply-To:Subject:Date:To:Message-ID:Content-Type:Content-Transfer-Encoding:MIME-Version',
    'Date:From:Reply-To:Subject:To:MIME-Version:Content-Type:Message-ID',
  ],
  ses: [
    'Date:From:Reply-To:To:Message-ID:Subject:MIME-Version:Content-Type:Content-Transfer-Encoding',
    'From:To:Subject:Date:Message-ID:MIME-Version:Content-Type',
  ],
  japan: [
    'Received:From:Reply-To:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding',
    'From:Sender:Reply-To:To:Subject:Date:Message-ID:Content-Type:MIME-Version',
    'from:to:subject:date:message-id:mime-version:content-type:content-transfer-encoding',
  ],
  generic: [
    'From:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding',
    'from:to:subject:date:message-id:mime-version:content-type',
    'From:Reply-To:To:Subject:Date:Message-ID:Content-Type',
  ],
};

// ═════════════════════════════════════════════════════════════
// 域 → 风格映射
// ═════════════════════════════════════════════════════════════
const JAPAN_DKIM_DOMAINS = new Set([
  'docomo.ne.jp', 'softbank.ne.jp', 'au.com', 'ezweb.ne.jp', 'kddi.com',
  'nifty.com', 'biglobe.ne.jp', 'so-net.ne.jp', 'ocn.ad.jp', 'plala.or.jp',
  'i.softbank.jp', 'ymobile.ne.jp', 'uqmobile.jp', 'rakuten-mobile.jp',
  'mineo.jp', 'iijmio.jp', 'ocn.ne.jp', 'dion.ne.jp', 'odn.ne.jp', 'zaq.ne.jp',
]);

function _styleForDomain(srcDomain) {
  switch (srcDomain) {
    case 'gmail.com': case 'googlemail.com': case 'google.com':
      return 'gmail';
    case 'outlook.com': case 'hotmail.com': case 'live.com': case 'microsoft.com': case 'office365.com':
      return 'outlook';
    case 'yahoo.com': case 'yahoo.co.jp': case 'ymail.com':
      return 'yahoo';
    case 'amazonses.com':
      return 'ses';
    default:
      return JAPAN_DKIM_DOMAINS.has(srcDomain) ? 'japan' : 'generic';
  }
}

// ═════════════════════════════════════════════════════════════
// 加权抽样 c= 值
// ═════════════════════════════════════════════════════════════
function pickDkimCanonicalization(rng) {
  let total = 0;
  for (const c of dkimCanonicalizations) total += c.weight;
  if (total <= 0) return 'relaxed/relaxed';
  let r = randSafe.safeIntn(rng, total);
  for (const c of dkimCanonicalizations) {
    r -= c.weight;
    if (r < 0) return c.value;
  }
  return dkimCanonicalizations[dkimCanonicalizations.length - 1].value;
}

// ═════════════════════════════════════════════════════════════
// 按发件方风格选 h= 字段
// @param customEnabled 若为 true 且 customList 非空 → 走 buildCustomDkimHFields
// ═════════════════════════════════════════════════════════════
function pickDkimHFields(rng, srcDomain, customEnabled, customList) {
  if (customEnabled && Array.isArray(customList) && customList.length > 0) {
    return buildCustomDkimHFields(customList);
  }
  const style = _styleForDomain(srcDomain);
  const pool = dkimHFieldsByStyle[style];
  if (!pool || pool.length === 0) {
    return 'From:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding';
  }
  return pool[randSafe.safeIntn(rng, pool.length)];
}

// ═════════════════════════════════════════════════════════════
// 【2026-07-23 P2-8】用用户自定义字段列表生成 h= 值
//   - 按传入顺序保留 + 去重（大小写不敏感）+ 规范化 + 强制包含 From
// ═════════════════════════════════════════════════════════════
function buildCustomDkimHFields(list) {
  const seen = new Set();
  const out = [];
  for (const raw of list) {
    const name = normalizeDkimHeaderName(raw);
    if (!name) continue;
    const lower = name.toLowerCase();
    if (seen.has(lower)) continue;
    seen.add(lower);
    out.push(name);
  }
  if (!seen.has('from')) out.unshift('From');
  if (out.length === 0) return 'From:To:Subject:Date:Message-ID:MIME-Version:Content-Type';
  return out.join(':');
}

// ═════════════════════════════════════════════════════════════
// 规范化头名（RFC 5322 惯例：段首大写-连字符-小写；ID/MIME/DKIM 等缩写全大写）
// ═════════════════════════════════════════════════════════════
function normalizeDkimHeaderName(raw) {
  const s = String(raw || '').trim();
  if (!s) return '';
  const segs = s.split('-');
  for (let i = 0; i < segs.length; i++) {
    let seg = segs[i].trim();
    if (!seg) continue;
    const lower = seg.toLowerCase();
    switch (lower) {
      case 'id':    segs[i] = 'ID'; break;
      case 'ip':    segs[i] = 'IP'; break;
      case 'mime':  segs[i] = 'MIME'; break;
      case 'dkim':  segs[i] = 'DKIM'; break;
      case 'spf':   segs[i] = 'SPF'; break;
      case 'dmarc': segs[i] = 'DMARC'; break;
      case 'csa':   segs[i] = 'CSA'; break;
      case 'url':   segs[i] = 'URL'; break;
      case 'http':
      case 'https': segs[i] = lower.toUpperCase(); break;
      default:
        segs[i] = lower.charAt(0).toUpperCase() + lower.slice(1);
    }
  }
  return segs.join('-');
}

// ═════════════════════════════════════════════════════════════
// b= 字段字节数（RSA 位数 / 8）
// ═════════════════════════════════════════════════════════════
function dkimSignatureByteCount(rsaBits) {
  switch (rsaBits) {
    case 1024: return 128;
    case 4096: return 512;
    case 2048: return 256;
    default:   return 256;
  }
}

// ═════════════════════════════════════════════════════════════
// 加权抽样 dkimExternalSources，尽量避开最近用过的源
// @param rng - PRNG
// @param recent - 环形缓冲区数组（长度 8，元素为最近索引；-1 表示空槽）
// @param recentPosRef - {pos: number} 环形缓冲写入位置的可变引用
// @returns {source, index}
// ═════════════════════════════════════════════════════════════
function pickDkimExternalSource(rng, recent, recentPosRef) {
  if (dkimExternalSources.length === 0) {
    return { source: { domain: 'gmail.com', selectors: ['20230601'], weight: 1, isSESLike: false, rsaBits: 2048 }, index: 0 };
  }

  let totalWeight = 0;
  for (const s of dkimExternalSources) totalWeight += s.weight;
  if (totalWeight <= 0) return { source: dkimExternalSources[0], index: 0 };

  const maxRetry = DKIM_RECENT_RING_SIZE + 2;
  let lastIdx = 0;
  for (let retry = 0; retry < maxRetry; retry++) {
    let r = randSafe.safeIntn(rng, totalWeight);
    let idx = 0;
    for (let i = 0; i < dkimExternalSources.length; i++) {
      r -= dkimExternalSources[i].weight;
      if (r < 0) { idx = i; break; }
    }
    lastIdx = idx;
    if (recent.indexOf(idx) === -1) {
      recent[recentPosRef.pos] = idx;
      recentPosRef.pos = (recentPosRef.pos + 1) % DKIM_RECENT_RING_SIZE;
      return { source: dkimExternalSources[idx], index: idx };
    }
  }

  // 重试用完 → 接受重复
  recent[recentPosRef.pos] = lastIdx;
  recentPosRef.pos = (recentPosRef.pos + 1) % DKIM_RECENT_RING_SIZE;
  return { source: dkimExternalSources[lastIdx], index: lastIdx };
}

// ═════════════════════════════════════════════════════════════
// 生成 SES 风格 selector（32 字符 base32）
// ═════════════════════════════════════════════════════════════
function generateSESLikeSelector(rng) {
  let out = '';
  for (let i = 0; i < 32; i++) {
    out += DKIM_SES_CHARSET.charAt(randSafe.safeIntn(rng, DKIM_SES_CHARSET.length));
  }
  return out;
}

// ═════════════════════════════════════════════════════════════
// 创建空环形缓冲区（全 -1，避免 0 索引被误判为 "最近用过"）
// ═════════════════════════════════════════════════════════════
function newRecentBuffer() {
  const buf = new Array(DKIM_RECENT_RING_SIZE);
  for (let i = 0; i < DKIM_RECENT_RING_SIZE; i++) buf[i] = -1;
  return buf;
}

module.exports = {
  DKIM_RECENT_RING_SIZE,
  DKIM_SES_CHARSET,
  dkimExternalSources,
  dkimCanonicalizations,
  dkimHFieldsByStyle,
  pickDkimCanonicalization,
  pickDkimHFields,
  buildCustomDkimHFields,
  normalizeDkimHeaderName,
  dkimSignatureByteCount,
  pickDkimExternalSource,
  generateSESLikeSelector,
  newRecentBuffer,
};
