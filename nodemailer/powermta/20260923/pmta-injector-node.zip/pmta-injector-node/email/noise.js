'use strict';
// email/noise - 图片像素噪点 + 尾部随机字节（对应 Go pmta-injector-clean/email/noise.go）
//
// 【Haraka26】对 JPG/PNG 图片添加随机噪点 + 尾部追加随机字节，
// 使每封邮件的图片 MD5/SHA256 都不同，破坏反垃圾感知哈希（pHash）匹配。
//
// ★ Node 特有的 async 语义 ★
// Sharp 是异步的（libvips 后端）—— Node 端 addImageNoise 是 async 函数
// Go 版是同步的 image.Decode + Set + Encode。语义等价但接口不同。
// Builder 在 build() 阶段 await 一次性应用完噪点，writeAttachments 消费已噪化的 buffer。
//
// 【Sprint 4 实现】
//   - JPEG / PNG → 用 sharp 解码 → 修改 1-5 像素（±1-3 RGB） → 重编码（JPEG 随机质量 90-95）+ 尾部噪点
//   - 其他格式 → 仅追加尾部 4-16 字节随机
//   - sharp 加载失败或解码失败 → fallback 到"仅尾部噪点"（不阻断构建）

const crypto = require('crypto');

// sharp 是可选依赖：pkg 打包时通过 assets 打入；如加载失败退化到"仅尾部噪点"
let sharp = null;
try {
  sharp = require('sharp');
} catch (e) {
  // pkg 打包环境或 sharp 缺失 → 降级模式，不影响主流程
  sharp = null;
}

/**
 * addImageNoise - 主入口
 * @param {Buffer} imgBuf 图片二进制
 * @param {string} filename 用于判断 JPG/PNG 格式（按扩展名）
 * @returns {Promise<Buffer>} 加噪后的图片
 */
async function addImageNoise(imgBuf, filename) {
  const buf = Buffer.isBuffer(imgBuf) ? imgBuf : Buffer.from(String(imgBuf || ''), 'binary');
  const lower = String(filename || '').toLowerCase();

  const isJPEG = lower.endsWith('.jpg') || lower.endsWith('.jpeg');
  const isPNG = lower.endsWith('.png');

  // 不支持的格式：只追加尾部噪点
  if (!isJPEG && !isPNG) return appendTrailingNoise(buf);

  // sharp 不可用：降级为尾部噪点
  if (!sharp) return appendTrailingNoise(buf);

  try {
    // 1. 用 sharp 读取原图并转为 RGBA raw 像素数据
    const { data, info } = await sharp(buf)
      .ensureAlpha() // 保证 4 通道（对齐 Go RGBA）
      .raw()
      .toBuffer({ resolveWithObject: true });

    const width = info.width;
    const height = info.height;
    const channels = info.channels || 4;
    if (width < 1 || height < 1) return appendTrailingNoise(buf);

    // 2. 修改 1-5 个随机像素，每个通道 ±1-3
    const pixelCount = 1 + _rand256() % 5;
    for (let i = 0; i < pixelCount; i++) {
      const x = _rand256() % width; // 用小随机数取模，虽然分布不完美，但 1-5 像素扰动无需高精度
      const y = _randUint(0x7FFFFFFF) % height;
      const offset = (y * width + x) * channels;
      // R / G / B 三通道各微调，Alpha 保留
      data[offset]     = _clampU8(data[offset]     + (_rand256() % 7) - 3);
      data[offset + 1] = _clampU8(data[offset + 1] + (_rand256() % 7) - 3);
      data[offset + 2] = _clampU8(data[offset + 2] + (_rand256() % 7) - 3);
      // channels === 4 时的 alpha 不动
    }

    // 3. 重编码
    const rebuilder = sharp(data, {
      raw: { width, height, channels },
    });
    let outBuf;
    if (isJPEG) {
      const quality = 90 + (_rand256() % 6); // 90-95
      outBuf = await rebuilder.jpeg({ quality }).toBuffer();
    } else {
      outBuf = await rebuilder.png().toBuffer();
    }

    // 4. 追加尾部随机噪点
    return appendTrailingNoise(outBuf);
  } catch (e) {
    // 任何一步失败 → 降级为尾部噪点
    return appendTrailingNoise(buf);
  }
}

/**
 * appendTrailingNoise - 尾部追加 4-16 字节随机数据
 * JPEG / PNG 解码器会忽略尾部多余数据，但文件哈希完全不同
 */
function appendTrailingNoise(buf) {
  const noiseLen = 4 + (_rand256() % 13); // 4-16
  const noise = crypto.randomBytes(noiseLen);
  return Buffer.concat([buf, noise]);
}

// ═════════════════════════════════════════════════════════════
// 内部：随机工具（用 crypto/rand，对齐 Go 的 math/rand 全局源）
// ═════════════════════════════════════════════════════════════

function _rand256() {
  return crypto.randomBytes(1)[0];
}

function _randUint(max) {
  const b = crypto.randomBytes(4);
  const u = (b.readUInt32BE(0) & 0x7FFFFFFF);
  return u;
}

function _clampU8(v) {
  if (v < 0) return 0;
  if (v > 255) return 255;
  return v | 0;
}

module.exports = { addImageNoise, appendTrailingNoise };
