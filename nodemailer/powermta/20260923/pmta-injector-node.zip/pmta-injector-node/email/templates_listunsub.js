'use strict';
// email/templates_listunsub - 50 个 List-Unsubscribe 模板（对应 Go pmta-injector-clean/email/templates_listunsub.go）
//
// 【契约】50 条顺序、内容与 Go 版**字节级一致**。
// 双工程（PowerMTA / Haraka）共用此清单，任何修改必须两端同步。
//
// 类别分布：
//   SendGrid 5 + Mailchimp 4 + Salesforce MC 3 + Constant Contact 3 +
//   HubSpot 3 + Mailgun 3 + Amazon SES 3 + Marketo 3 + Klaviyo 3 +
//   IBM Watson/Pardot 3 + vpass 3 + biccamera 2 +
//   通用复合 5 + HTTPS-only 4 + mailto-only 3 = 50
//
// 约定：
//   - 每模板以 "<" 开头、">" 结尾（RFC 2369 / RFC 8058）
//   - 单行，渲染后由 foldHeaderValue 折叠
//   - 不含 "List-Unsubscribe: " 前缀（调用方拼）
//   - 变量占位符必须能被 variables.js + variables_ext.js 解析
//
// 运行时并不直接读此池（实际读 cfg.list_unsub_*_templates），保留此池的作用：
//   1. 反指纹二进制变体差异（D4 决策）
//   2. 未来 API 备份池或"自动生成"基础数据

const listUnsubTemplatePool = [
  // ── SendGrid 风格 (5) ──
  '<https://u{ID_QUEUE:7}.ct.sendgrid.net/wf/unsubscribe?upn={JWT_TOKEN}>',
  '<https://u{ID_QUEUE:7}.ct.sendgrid.net/wf/unsubscribe?upn={JWT_TOKEN}>, <mailto:unsubscribe-{ID_HEX:16}@{FROM_DOMAIN}>',
  '<https://email.{FROM_DOMAIN}/wf/unsubscribe?upn={JWT_TOKEN}>',
  '<mailto:unsubscribe@{FROM_DOMAIN}?subject=unsubscribe-{ID_HEX:16}>, <https://email.{FROM_DOMAIN}/wf/unsubscribe?upn={JWT_TOKEN}>',
  '<https://sendgrid.{FROM_DOMAIN}/asm/unsubscribe?u={ID_HEX:32}>',

  // ── Mailchimp 风格 (4) ──
  '<http://{FROM_DOMAIN}/unsubscribe?u={ID_HEX:32}&id={ID_HEX:10}>',
  '<http://{FROM_DOMAIN}/unsubscribe?u={ID_HEX:32}&id={ID_HEX:10}>, <mailto:unsubscribe-{ID_HEX:16}@{FROM_DOMAIN}>',
  '<https://{FROM_DOMAIN}/mc/unsubscribe?u={ID_HEX:32}&id={ID_HEX:10}&e={ID_HEX:16}>',
  '<mailto:unsubscribe-mc.list-{ID_HEX:16}.{ID_HEX:16}@{FROM_DOMAIN}>',

  // ── Salesforce MC / ExactTarget (3) ──
  '<https://cl.{FROM_DOMAIN}/subscription_center.aspx?qs={ID_HEX:64}>',
  '<https://cl.{FROM_DOMAIN}/subscription_center.aspx?qs={ID_HEX:64}>, <mailto:leave-{ID_BOUNCE_TOKEN}@{FROM_DOMAIN}>',
  '<https://email.{FROM_DOMAIN}/subscription_center?jwt={JWT_TOKEN}>',

  // ── Constant Contact (3) ──
  '<https://visitor.r20.{FROM_DOMAIN}/manage/optout?v={JWT_TOKEN}>',
  '<https://visitor.r20.{FROM_DOMAIN}/manage/optout?v={JWT_TOKEN}>, <mailto:optout-{ID_HEX:16}@{FROM_DOMAIN}>',
  '<https://r20.{FROM_DOMAIN}/d.jsp?llr={ID_HEX:16}&p=oo&m={ID_HEX:32}>',

  // ── HubSpot (3) ──
  '<https://app.{FROM_DOMAIN}/email-unsubscribe?d={ID_HEX:64}>',
  '<https://app.{FROM_DOMAIN}/email-unsubscribe?d={ID_HEX:64}>, <mailto:unsubscribe-{ID_HEX:16}@reply.{FROM_DOMAIN}>',
  '<https://t.hsms{ID_QUEUE:2}.{FROM_DOMAIN}/c/unsubscribe?h={JWT_TOKEN}>',

  // ── Mailgun (3) ──
  '<https://email.{FROM_DOMAIN}/u/eh/{ID_HEX:64}>',
  '<https://email.{FROM_DOMAIN}/u/eh/{ID_HEX:64}>, <mailto:unsubscribe-{ID_HEX:32}@{FROM_DOMAIN}>',
  '<mailto:unsubscribe+{ID_HEX:32}@mg.{FROM_DOMAIN}>, <https://email.{FROM_DOMAIN}/u/{ID_HEX:64}>',

  // ── Amazon SES (3) ──
  '<https://{FROM_DOMAIN}/r/?id={JWT_TOKEN}&utype=u>',
  '<mailto:{ID_HEX:32}@unsubscribe.{FROM_DOMAIN}>',
  '<mailto:{ID_HEX:32}@unsubscribe.{FROM_DOMAIN}>, <https://{FROM_DOMAIN}/r/?id={JWT_TOKEN}&utype=u>',

  // ── Marketo (3) ──
  '<https://email.{FROM_DOMAIN}/un.aspx?id={ID_HEX:16}&u={JWT_TOKEN}>',
  '<https://email.{FROM_DOMAIN}/un.aspx?id={ID_HEX:16}&u={JWT_TOKEN}>, <mailto:reply-{ID_HEX:16}@{FROM_DOMAIN}>',
  '<https://go.{FROM_DOMAIN}/un.aspx?bid={ID_HEX:24}&cid={ID_HEX:16}>',

  // ── Klaviyo (3) ──
  '<https://manage.kmail-lists.com/subscriptions/{ID_HEX:24}/list/{ID_HEX:10}>',
  '<https://manage.kmail-lists.com/subscriptions/{ID_HEX:24}/list/{ID_HEX:10}>, <mailto:unsubscribe-{ID_HEX:16}@{FROM_DOMAIN}>',
  '<https://email.{FROM_DOMAIN}/email/unsubscribe?h={JWT_TOKEN}&p={ID_HEX:16}>',

  // ── IBM Watson Campaign / Pardot (3) ──
  '<https://maillist.{FROM_DOMAIN}/u/{ID_HEX:32}-{ID_HEX:16}-{ID_HEX:16}-{ID_HEX:8}>',
  '<https://go.pardot.{FROM_DOMAIN}/e/{ID_HEX:32}/{ID_HEX:16}/{ID_HEX:24}>',
  '<https://email.{FROM_DOMAIN}/op.aspx?u={JWT_TOKEN}&token={ID_HEX:48}>',

  // ── vpass / smbc 风格 (3) ──
  '<https://{FROM_DOMAIN}/contact/mail-stop?id={ID_HEX:32}>, <mailto:leave-{ID_BOUNCE_TOKEN}@bounce.{FROM_DOMAIN}>',
  '<https://www.{FROM_DOMAIN}/cgi-bin/mail_stop?u={ID_HEX:24}&t={ID_HEX:16}>',
  '<mailto:unsubscribe-{ID_HEX:16}@bounce.contact.{FROM_DOMAIN}>',

  // ── biccamera / ml 风格 (2) ──
  '<https://www.{FROM_DOMAIN}/bin/mail_unsubscribe?bid={ID_HEX:16}&cid={ID_HEX:8}>',
  '<mailto:leave-{ID_BOUNCE_TOKEN}@bounce.ml.{FROM_DOMAIN}>, <https://ml.{FROM_DOMAIN}/u/{ID_HEX:32}>',

  // ── 通用 mailto + HTTPS 复合 (5) ──
  '<mailto:unsubscribe-{ID_HEX:16}@{FROM_DOMAIN}>, <https://{FROM_DOMAIN}/unsubscribe/{ID_HEX:48}>',
  '<mailto:unsubscribe-{ID_HEX:16}@{FROM_DOMAIN}>, <https://{FROM_DOMAIN}/mail-unsubscribe/{ID_HEX:64}>',
  '<https://{FROM_DOMAIN}/u/{ID_HEX:32}>, <mailto:unsubscribe-{ID_HEX:16}@{FROM_DOMAIN}>',
  '<https://{FROM_DOMAIN}/subscription_center?jwt={JWT_TOKEN}>, <mailto:leave-{ID_BOUNCE_TOKEN}@{FROM_DOMAIN}>',
  '<mailto:unsub-{ID_HEX:32}@{FROM_DOMAIN}>, <https://{FROM_DOMAIN}/opt-out?token={JWT_TOKEN}>',

  // ── 通用 HTTPS only (4) ──
  '<https://{FROM_DOMAIN}/mail-unsubscribe/{ID_HEX:64}>',
  '<https://{FROM_DOMAIN}/unsubscribe?u={ID_HEX:32}&h={ID_HEX:16}>',
  '<https://{FROM_DOMAIN}/list/unsubscribe?id={ID_HEX:24}>',
  '<https://{FROM_DOMAIN}/opt-out/{ID_HEX:32}>',

  // ── 通用 mailto only (3) ──
  '<mailto:unsubscribe-{ID_HEX:16}@{FROM_DOMAIN}>',
  '<mailto:remove-{ID_HEX:24}@{FROM_DOMAIN}>',
  '<mailto:list-unsubscribe-{ID_HEX:32}@{FROM_DOMAIN}>',
];

// 启动时一次性计算池大小
const listUnsubTemplatePoolSize = listUnsubTemplatePool.length;

module.exports = { listUnsubTemplatePool, listUnsubTemplatePoolSize };
