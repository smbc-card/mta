'use strict';
// email/variables_ext - 53 扩展变量（对应 Go pmta-injector-clean/email/variables_ext.go）
//
// A. RFC 2822 时间变量 13 个
// B. ID 类变量 8 个
// C. IP 池变量 10 个
// D. 域名池变量 15 个
// E. SMTP/TLS 协议变量 6 个
// F. JWT 变量 1 个
//
// 设计原则：
//   - 所有随机源走 vp.random（每 worker 独立）
//   - 参数化变量先处理（正则），无参变量后处理（replaceLiteral）
//   - 全部支持大小写双形式
//   - LoadLocation 失败 → 静默回退 UTC
//   - 不嵌套其他变量
//
// ★ IP 池的 randomYahooIP / randomSoftbank172IP / randomPublicIP ★
//   Go 版这 3 个函数定义在 headers.go 里。Sprint 3B 暂时用**简化实现**（IP 段合理但非完整 CIDR 池）。
//   Sprint 3C 写 headers.js 时会**替换**为完整 122 条 Yahoo CIDR 池 + 9 段非公网排除的实现。
//   注入方式：Sprint 3C 会通过 setIPHelpers(...) 覆盖本文件里的默认实现。

const randSafe = require('./rand_safe');

// ═════════════════════════════════════════════════════════════
// 预编译正则
// ═════════════════════════════════════════════════════════════

const RE_RFC2822_TZ        = /\{RFC2822_DATE_TZ:([A-Za-z][A-Za-z0-9_/+\-]+)\}/gi;
const RE_RFC2822_OFFSET    = /\{RFC2822_DATE_OFFSET:([+\-]\d{4})\}/gi;
const RE_RFC2822_PAST_SEC  = /\{RFC2822_DATE_PAST_SEC:(\d+)\}/gi;
const RE_RFC2822_PAST_RAND = /\{RFC2822_DATE_PAST_RAND:(\d+)-(\d+)\}/gi;

const RE_ID_QUEUE = /\{ID_QUEUE:(\d+)\}/gi;
const RE_ID_HEX   = /\{ID_HEX:(\d+)\}/gi;

// ═════════════════════════════════════════════════════════════
// 时区常量（偏移分钟数）
// ═════════════════════════════════════════════════════════════

const TZ_JST = 9 * 60;    // +540
const TZ_GMT = 0;
const TZ_PST = -8 * 60;   // -480
const TZ_PDT = -7 * 60;   // -420
const TZ_EST = -5 * 60;   // -300
const TZ_CET = 1 * 60;    // +60

// ═════════════════════════════════════════════════════════════
// 字符集
// ═════════════════════════════════════════════════════════════

const CS_UPPER_NUM   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const CS_LOWER_NUM   = 'abcdefghijklmnopqrstuvwxyz0123456789';
const CS_HEX         = '0123456789abcdef';
const CS_BASE62      = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
const CS_DIGITS      = '0123456789';

// ═════════════════════════════════════════════════════════════
// 3 个 IP 池辅助函数（Sprint 3B 简化实现；Sprint 3C 会用 setIPHelpers 覆盖）
// ═════════════════════════════════════════════════════════════

// Sprint 3B 简化版：Yahoo Japan 常见的几段（不完整，Sprint 3C 会用完整 122 条 CIDR）
let _randomYahooIP = function (rng) {
  const yahooSegments = [
    [43, 223],   // 43.223.x.x
    [183, 79],   // 183.79.x.x
    [124, 83],   // 124.83.x.x
    [211, 14],   // 211.14.x.x
    [124, 172],  // 124.172.x.x
    [124, 175],  // 124.175.x.x
  ];
  const seg = yahooSegments[randSafe.safeIntn(rng, yahooSegments.length)];
  const c = randSafe.safeIntn(rng, 256);
  const d = 1 + randSafe.safeIntn(rng, 254);
  return `${seg[0]}.${seg[1]}.${c}.${d}`;
};

// SoftBank 172.16.0.0/12 私网段（172.16-31.x.x）
let _randomSoftbank172IP = function (rng) {
  const b = 16 + randSafe.safeIntn(rng, 16); // 16-31
  const c = randSafe.safeIntn(rng, 256);
  const d = 1 + randSafe.safeIntn(rng, 254);
  return `172.${b}.${c}.${d}`;
};

// 全球随机公网 IPv4（简化：排除 10/172.16/192.168/127/169.254/100.64/0/224+/240+ 段）
let _randomPublicIP = function (rng) {
  // 简化：反复抽直到落到公网段（99%+ 情况下 1 次成功）
  for (let attempt = 0; attempt < 8; attempt++) {
    const a = 1 + randSafe.safeIntn(rng, 222); // [1, 222]
    // 排除私网/保留段
    if (a === 10) continue;
    if (a === 127) continue;
    const b = randSafe.safeIntn(rng, 256);
    if (a === 172 && b >= 16 && b <= 31) continue;
    if (a === 192 && b === 168) continue;
    if (a === 169 && b === 254) continue;
    if (a === 100 && b >= 64 && b <= 127) continue;
    const c = randSafe.safeIntn(rng, 256);
    const d = 1 + randSafe.safeIntn(rng, 254);
    return `${a}.${b}.${c}.${d}`;
  }
  // 兜底：直接返回一个已知公网 IP 段
  return `8.8.${randSafe.safeIntn(rng, 256)}.${1 + randSafe.safeIntn(rng, 254)}`;
};

/**
 * setIPHelpers - Sprint 3C 会调用此函数注入完整 CIDR 池的实现
 * @param {Object} impls {randomYahooIP, randomSoftbank172IP, randomPublicIP}
 */
function setIPHelpers(impls) {
  if (impls.randomYahooIP)       _randomYahooIP = impls.randomYahooIP;
  if (impls.randomSoftbank172IP) _randomSoftbank172IP = impls.randomSoftbank172IP;
  if (impls.randomPublicIP)      _randomPublicIP = impls.randomPublicIP;
}

// ═════════════════════════════════════════════════════════════
// 域名池
// ═════════════════════════════════════════════════════════════

// yahoo MX 7 种范式
const YAHOO_MX_PATTERNS = [
  { tpl: 'mta%04d.mail.otm.ynwp.yahoo.co.jp', start: 1, end: 9999, pad: 4 },
  { tpl: 'mta%04d.mail.snz.ynwp.yahoo.co.jp', start: 1, end: 9999, pad: 4 },
  { tpl: 'mtaat%04d.mail.otm.ynwp.yahoo.co.jp', start: 1, end: 9999, pad: 4 },
  { tpl: 'mtaat%04d.mail.snz.ynwp.yahoo.co.jp', start: 1, end: 9999, pad: 4 },
  { tpl: 'mta%03d.kks.gm.yahoo.co.jp', start: 1, end: 600, pad: 3 },
  { tpl: 'mta%03d.ssk.gm.yahoo.co.jp', start: 1, end: 600, pad: 3 },
  { tpl: 'mta%03d.kth.gm.yahoo.co.jp', start: 1, end: 600, pad: 3 },
];

const YAHOO_EHLO_SUBS = ['kks', 'kth', 'ssk'];

const GMAIL_OUT_DOMAIN_POOL = [
  'smtp.gmail.com',
  'mail-yw1-f%d.google.com',
  'mail-ed1-f%d.google.com',
  'mail-pl1-f%d.google.com',
  'mail-lf1-f%d.google.com',
  'mail-pf1-f%d.google.com',
  'mail-pj1-f%d.google.com',
  'mail-ot1-f%d.google.com',
  'mail-qk1-f%d.google.com',
  'mail-vk1-f%d.google.com',
];

const MITSUI_DOMAIN_POOL = [
  'mail.vpass.ne.jp',
  'mail.smbc.co.jp',
  'mta.contact.vpass.ne.jp',
  'smtp.smbc.co.jp',
  'mta1.contact.vpass.ne.jp',
  'mta2.contact.vpass.ne.jp',
];

const AMAZON_SES_PREFIX_POOL = [
  'a8-', 'a10-', 'a12-', 'a15-', 'a23-', 'a28-', 'a30-', 'a45-', 'a48-', 'a52-',
  'e23-', 'e45-',
];

// Gmail 出口段
const GMAIL_GW_IP_RANGES = [
  [209, 85], [74, 125], [173, 194], [64, 233], [72, 14], [216, 58],
];

// AWS SES 出口段
const AWS_SES_IP_RANGES = [
  [23, 249], [54, 240], [199, 255], [207, 171], [52, 95], [76, 223],
];

// ═════════════════════════════════════════════════════════════
// 协议 / TLS 池
// ═════════════════════════════════════════════════════════════

const TLS_VERSION_POOL = ['TLS1_3', 'TLS1_2'];

const TLS_CIPHER_POOL = [
  'TLS_AES_256_GCM_SHA384',
  'TLS_AES_128_GCM_SHA256',
  'TLS_CHACHA20_POLY1305_SHA256',
  'ECDHE-RSA-AES256-GCM-SHA384',
  'ECDHE-RSA-AES128-GCM-SHA256',
  'ECDHE-RSA-CHACHA20-POLY1305',
  'ECDHE-ECDSA-AES256-GCM-SHA384',
  'ECDHE-ECDSA-CHACHA20-POLY1305',
];

const TLS_BITS_POOL = ['256/256', '128/128', '256/128'];

const SMTP_PROTOCOL_POOL = ['ESMTP', 'ESMTPS', 'ESMTPSA', 'SMTP'];

const MTA_TYPE_POOL = ['Postfix', 'sendmail', 'Exim'];

const MTA_VERSION_BANNERS = [
  '(Postfix)',
  '(sendmail)',
  '(Exim)',
  '(2.20.1.0.0)',
  '(DOCOMO Mail Server Ver2.0)',
  '(Postfix-2.11.7)',
  '(Microsoft SMTP Server)',
];

// ═════════════════════════════════════════════════════════════
// JWT header 池（对齐 Go 5 种预编码 header）
// ═════════════════════════════════════════════════════════════

const JWT_HEADER_POOL = [
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9', // HS256
  'eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9', // HS384
  'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9', // HS512
  'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9', // RS256
  'eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9', // ES256
];

// ═════════════════════════════════════════════════════════════
// 时区处理（Node 用 Intl.DateTimeFormat 获取任意 IANA tz 偏移）
// ═════════════════════════════════════════════════════════════

// tz 偏移缓存（避免频繁 Intl.DateTimeFormat 构造）
const _tzOffsetCache = new Map();

/**
 * getTzOffsetMinutes - 获取指定 IANA tz name 在 date 时刻的偏移分钟数
 * @param {string} tzName 例如 'Asia/Tokyo'
 * @param {Date} date
 * @returns {number} 偏移分钟数；失败返回 0（UTC）
 */
function getTzOffsetMinutes(tzName, date) {
  const cacheKey = `${tzName}_${Math.floor(date.getTime() / 3600000)}`; // 按小时缓存
  if (_tzOffsetCache.has(cacheKey)) return _tzOffsetCache.get(cacheKey);
  let offset = 0;
  try {
    const fmt = new Intl.DateTimeFormat('en-US', {
      timeZone: tzName,
      timeZoneName: 'shortOffset',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hour12: false,
    });
    const parts = fmt.formatToParts(date);
    const tzPart = parts.find((p) => p.type === 'timeZoneName');
    if (tzPart) {
      const m = tzPart.value.match(/GMT([+\-])(\d{1,2})(?::(\d{2}))?/);
      if (m) {
        const sign = m[1] === '-' ? -1 : 1;
        const hh = parseInt(m[2], 10);
        const mm = m[3] ? parseInt(m[3], 10) : 0;
        offset = sign * (hh * 60 + mm);
      } else if (tzPart.value === 'GMT' || tzPart.value === 'UTC') {
        offset = 0;
      }
    }
  } catch (_) { /* fall back to 0 */ }
  _tzOffsetCache.set(cacheKey, offset);
  return offset;
}

/**
 * formatRFC2822 - RFC 2822 date string ("Mon, 02 Jan 2006 15:04:05 -0700")
 * @param {Date} date
 * @param {number} tzOffMin 目标时区偏移（分钟）
 */
function formatRFC2822(date, tzOffMin) {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const pad2 = (n) => String(n).padStart(2, '0');
  // 用 date + offset 得到"目标时区的当地时间"（用 UTC 方法读取）
  const adj = new Date(date.getTime() + tzOffMin * 60000);
  const day = days[adj.getUTCDay()];
  const dd = pad2(adj.getUTCDate());
  const mon = months[adj.getUTCMonth()];
  const yyyy = adj.getUTCFullYear();
  const HH = pad2(adj.getUTCHours());
  const MM = pad2(adj.getUTCMinutes());
  const SS = pad2(adj.getUTCSeconds());
  const sign = tzOffMin >= 0 ? '+' : '-';
  const abs = Math.abs(tzOffMin);
  const oh = pad2(Math.floor(abs / 60));
  const om = pad2(abs % 60);
  return `${day}, ${dd} ${mon} ${yyyy} ${HH}:${MM}:${SS} ${sign}${oh}${om}`;
}

// ═════════════════════════════════════════════════════════════
// replaceLiteral - 每次替换都调用 gen()（对齐 Go replaceLiteral）
// 大写 + 小写双形式
// ═════════════════════════════════════════════════════════════

function replaceLiteral(content, token, gen) {
  const tokens = [token, token.toLowerCase()];
  for (const t of tokens) {
    if (!t || t.length === 0) continue;
    while (true) {
      const idx = content.indexOf(t);
      if (idx < 0) break;
      content = content.slice(0, idx) + gen() + content.slice(idx + t.length);
    }
  }
  return content;
}

// ═════════════════════════════════════════════════════════════
// 总入口
// ═════════════════════════════════════════════════════════════

/**
 * processExtendedVariables - 由 variables.js::process() 步骤 10 调用
 * @param {Object} vp VariableProcessor 实例（含 .random）
 * @param {string} content
 * @returns {string}
 */
function processExtendedVariables(vp, content) {
  if (!content) return content;
  content = processRFC2822Variables(vp, content);
  content = processIDVariables(vp, content);
  content = processExtIPVariables(vp, content);
  content = processExtDomainVariables(vp, content);
  content = processProtocolVariables(vp, content);
  content = processJWTVariables(vp, content);
  return content;
}

// ═════════════════════════════════════════════════════════════
// A. RFC 2822 时间变量 13 个
// ═════════════════════════════════════════════════════════════

function processRFC2822Variables(vp, content) {
  const now = new Date();

  // 参数化先处理
  RE_RFC2822_TZ.lastIndex = 0;
  content = content.replace(RE_RFC2822_TZ, (match, tzName) => {
    const off = getTzOffsetMinutes(tzName, now);
    return formatRFC2822(now, off);
  });

  RE_RFC2822_OFFSET.lastIndex = 0;
  content = content.replace(RE_RFC2822_OFFSET, (match, offsetStr) => {
    const sign = offsetStr[0] === '-' ? -1 : 1;
    const hh = parseInt(offsetStr.slice(1, 3), 10) || 0;
    const mm = parseInt(offsetStr.slice(3, 5), 10) || 0;
    const off = sign * (hh * 60 + mm);
    return formatRFC2822(now, off);
  });

  RE_RFC2822_PAST_SEC.lastIndex = 0;
  content = content.replace(RE_RFC2822_PAST_SEC, (match, secStr) => {
    const secs = parseInt(secStr, 10) || 0;
    const t = new Date(now.getTime() - secs * 1000);
    return formatRFC2822(t, TZ_JST);
  });

  RE_RFC2822_PAST_RAND.lastIndex = 0;
  content = content.replace(RE_RFC2822_PAST_RAND, (match, minStr, maxStr) => {
    const minS = parseInt(minStr, 10) || 0;
    let maxS = parseInt(maxStr, 10) || 0;
    if (maxS < minS) maxS = minS;
    const gap = maxS - minS + 1;
    const offSec = minS + randSafe.safeIntn(vp.random, gap);
    const t = new Date(now.getTime() - offSec * 1000);
    return formatRFC2822(t, TZ_JST);
  });

  // 字面变量 9 个
  const literalReplacements = {
    '{RFC2822_DATE}':          formatRFC2822(now, TZ_JST),
    '{RFC2822_DATE_JST}':      formatRFC2822(now, TZ_JST),
    '{RFC2822_DATE_UTC}':      formatRFC2822(now, 0),
    '{RFC2822_DATE_GMT}':      formatRFC2822(now, TZ_GMT) + ' (GMT)',
    '{RFC2822_DATE_PST}':      formatRFC2822(now, TZ_PST),
    '{RFC2822_DATE_PDT}':      formatRFC2822(now, TZ_PDT) + ' (PDT)',
    '{RFC2822_DATE_EST}':      formatRFC2822(now, TZ_EST),
    '{RFC2822_DATE_CET}':      formatRFC2822(now, TZ_CET),
    '{RFC2822_DATE_WITH_JST}': formatRFC2822(now, TZ_JST) + ' (JST)',
  };
  for (const k of Object.keys(literalReplacements)) {
    content = content.split(k).join(literalReplacements[k]);
    content = content.split(k.toLowerCase()).join(literalReplacements[k]);
  }
  return content;
}

// ═════════════════════════════════════════════════════════════
// B. ID 变量 8 个
// ═════════════════════════════════════════════════════════════

function processIDVariables(vp, content) {
  // 参数化先
  RE_ID_QUEUE.lastIndex = 0;
  content = content.replace(RE_ID_QUEUE, (match, nStr) => {
    let n = parseInt(nStr, 10) || 11;
    if (n < 1) n = 11;
    if (n > 64) n = 64;
    return randSafe.randStringFrom(vp.random, n, CS_UPPER_NUM);
  });

  RE_ID_HEX.lastIndex = 0;
  content = content.replace(RE_ID_HEX, (match, nStr) => {
    let n = parseInt(nStr, 10) || 16;
    if (n < 1) n = 16;
    if (n > 256) n = 256;
    return randSafe.randStringFrom(vp.random, n, CS_HEX);
  });

  // 字面 6 个（每次生成不同）
  content = replaceLiteral(content, '{ID_POSTFIX_LONG}',
    () => randSafe.randStringFrom(vp.random, 22, CS_BASE62));

  content = replaceLiteral(content, '{ID_GMAIL}', () => {
    const nDigit = 11 + randSafe.safeIntn(vp.random, 3); // 11-13
    const nTail = 1 + randSafe.safeIntn(vp.random, 2);   // 1-2
    return `${randSafe.randStringFrom(vp.random, 12, CS_HEX)}-` +
           `${randSafe.randStringFrom(vp.random, 11, CS_HEX)}sm` +
           `${randSafe.randStringFrom(vp.random, nDigit, CS_DIGITS)}.` +
           `${randSafe.randStringFrom(vp.random, nTail, CS_DIGITS)}`;
  });

  content = replaceLiteral(content, '{ID_BOUNCE_TOKEN}',
    () => randSafe.randStringFrom(vp.random, 26, CS_UPPER_NUM) + '.' +
          randSafe.randStringFrom(vp.random, 5, CS_DIGITS));

  content = replaceLiteral(content, '{ID_AMAZON_SES}', () =>
    `${randSafe.randStringFrom(vp.random, 16, CS_HEX)}-` +
    `${randSafe.randStringFrom(vp.random, 8, CS_HEX)}-` +
    `${randSafe.randStringFrom(vp.random, 4, CS_HEX)}-` +
    `${randSafe.randStringFrom(vp.random, 4, CS_HEX)}-` +
    `${randSafe.randStringFrom(vp.random, 4, CS_HEX)}-` +
    `${randSafe.randStringFrom(vp.random, 12, CS_HEX)}-` +
    `${randSafe.randStringFrom(vp.random, 6, CS_DIGITS)}`);

  content = replaceLiteral(content, '{ID_BICCAMERA}',
    () => randSafe.randStringFrom(vp.random, 12, CS_LOWER_NUM));

  content = replaceLiteral(content, '{ID_EXIM_QUEUE}', () => {
    const mid = 6 + randSafe.safeIntn(vp.random, 2); // 6-7
    return `1${randSafe.randStringFrom(vp.random, mid, CS_BASE62)}-` +
           `${randSafe.randStringFrom(vp.random, 6, CS_BASE62)}-` +
           `${randSafe.randStringFrom(vp.random, 2, CS_BASE62)}`;
  });

  return content;
}

// ═════════════════════════════════════════════════════════════
// C. IP 池变量 10 个
// ═════════════════════════════════════════════════════════════

function processExtIPVariables(vp, content) {
  content = replaceLiteral(content, '{IP_YAHOO_JP}', () => _randomYahooIP(vp.random));

  content = replaceLiteral(content, '{IP_SOFTBANK_172}', () => _randomSoftbank172IP(vp.random));

  content = replaceLiteral(content, '{IP_DOCOMO_INTERNAL}', () =>
    `10.200.${randSafe.safeIntn(vp.random, 256)}.${1 + randSafe.safeIntn(vp.random, 254)}`);

  content = replaceLiteral(content, '{IP_GMAIL_GW}', () => {
    const r = GMAIL_GW_IP_RANGES[randSafe.safeIntn(vp.random, GMAIL_GW_IP_RANGES.length)];
    return `${r[0]}.${r[1]}.${randSafe.safeIntn(vp.random, 256)}.${1 + randSafe.safeIntn(vp.random, 254)}`;
  });

  content = replaceLiteral(content, '{IP_PRIVATE_10}', () =>
    `10.${randSafe.safeIntn(vp.random, 256)}.${randSafe.safeIntn(vp.random, 256)}.${1 + randSafe.safeIntn(vp.random, 254)}`);

  content = replaceLiteral(content, '{IP_PRIVATE_172}', () =>
    `172.${16 + randSafe.safeIntn(vp.random, 16)}.${randSafe.safeIntn(vp.random, 256)}.${1 + randSafe.safeIntn(vp.random, 254)}`);

  content = replaceLiteral(content, '{IP_PRIVATE_192}', () =>
    `192.168.${randSafe.safeIntn(vp.random, 256)}.${1 + randSafe.safeIntn(vp.random, 254)}`);

  content = replaceLiteral(content, '{IP_LOOPBACK}', () => '127.0.0.1');

  content = replaceLiteral(content, '{IP_PUBLIC_GLOBAL}', () => _randomPublicIP(vp.random));

  content = replaceLiteral(content, '{IP_AWS_SES}', () => {
    const r = AWS_SES_IP_RANGES[randSafe.safeIntn(vp.random, AWS_SES_IP_RANGES.length)];
    return `${r[0]}.${r[1]}.${randSafe.safeIntn(vp.random, 256)}.${1 + randSafe.safeIntn(vp.random, 254)}`;
  });

  return content;
}

// ═════════════════════════════════════════════════════════════
// D. 域名池变量 15 个
// ═════════════════════════════════════════════════════════════

function processExtDomainVariables(vp, content) {
  // Sprintf-like 填充：只支持 %d / %03d / %04d / %02d
  const formatNum = (tpl, num) => tpl.replace(/%(0?)(\d*)d/, (m, zero, width) => {
    const w = width ? parseInt(width, 10) : 0;
    const s = String(num);
    return zero && s.length < w ? s.padStart(w, '0') : s;
  });

  content = replaceLiteral(content, '{DOMAIN_YAHOO_MX}', () => {
    const p = YAHOO_MX_PATTERNS[randSafe.safeIntn(vp.random, YAHOO_MX_PATTERNS.length)];
    const num = p.start + randSafe.safeIntn(vp.random, p.end - p.start + 1);
    return formatNum(p.tpl, num);
  });

  content = replaceLiteral(content, '{DOMAIN_YAHOO_EHLO}', () => {
    const sub = YAHOO_EHLO_SUBS[randSafe.safeIntn(vp.random, YAHOO_EHLO_SUBS.length)];
    const num = 1 + randSafe.safeIntn(vp.random, 600);
    return `mta${String(num).padStart(3, '0')}.${sub}.gm.yahoo.co.jp`;
  });

  content = replaceLiteral(content, '{DOMAIN_YAHOO_GW}', () => {
    const f = randSafe.safeIntn(vp.random, 100);   // 0-99
    const h = randSafe.safeIntn(vp.random, 1000);  // 0-999
    const c = randSafe.safeIntn(vp.random, 100);   // 0-99
    return `smtp-gw-f${String(f).padStart(2, '0')}h${String(h).padStart(3, '0')}c${String(c).padStart(2, '0')}.prod.goats.kks.ynwl.yahoo.co.jp`;
  });

  content = replaceLiteral(content, '{DOMAIN_GMAIL_OUT}', () => {
    const tpl = GMAIL_OUT_DOMAIN_POOL[randSafe.safeIntn(vp.random, GMAIL_OUT_DOMAIN_POOL.length)];
    if (tpl.indexOf('%d') !== -1) return formatNum(tpl, 1 + randSafe.safeIntn(vp.random, 200));
    return tpl;
  });

  content = replaceLiteral(content, '{DOMAIN_GMAIL_HOST}', () => {
    return `server-${1 + randSafe.safeIntn(vp.random, 222)}-${randSafe.safeIntn(vp.random, 256)}-${randSafe.safeIntn(vp.random, 256)}-${1 + randSafe.safeIntn(vp.random, 254)}.da.direct`;
  });

  content = replaceLiteral(content, '{DOMAIN_DOCOMO_BILL}', () =>
    `mail${1 + randSafe.safeIntn(vp.random, 10)}.docomo-bill.ne.jp`);

  content = replaceLiteral(content, '{DOMAIN_DOCOMO_LOCAL}', () => 'localhost.docomo.ne.jp');

  content = replaceLiteral(content, '{DOMAIN_DOCOMO_MFSMAX}', () => 'mfsmax.docomo.ne.jp');

  content = replaceLiteral(content, '{DOMAIN_SOFTBANK_EBMKY}', () =>
    `ebmky${101 + randSafe.safeIntn(vp.random, 50)}sc.softbank.ad.jp`);

  content = replaceLiteral(content, '{DOMAIN_AU}', () =>
    `mta-snd-e${String(1 + randSafe.safeIntn(vp.random, 99)).padStart(2, '0')}.au.com`);

  content = replaceLiteral(content, '{DOMAIN_MITSUI}', () =>
    MITSUI_DOMAIN_POOL[randSafe.safeIntn(vp.random, MITSUI_DOMAIN_POOL.length)]);

  content = replaceLiteral(content, '{DOMAIN_BICCAMERA}', () =>
    `mta${1 + randSafe.safeIntn(vp.random, 15)}.ml.biccamera.com`);

  content = replaceLiteral(content, '{DOMAIN_YODOBASHI}', () =>
    `yctcue${String(1 + randSafe.safeIntn(vp.random, 99)).padStart(2, '0')}.yodobashi.co.jp`);

  content = replaceLiteral(content, '{DOMAIN_LTIKE}', () =>
    `md${1 + randSafe.safeIntn(vp.random, 10)}.l-tike.com`);

  content = replaceLiteral(content, '{DOMAIN_AMAZONSES_OUT}', () => {
    const pref = AMAZON_SES_PREFIX_POOL[randSafe.safeIntn(vp.random, AMAZON_SES_PREFIX_POOL.length)];
    const tail = randSafe.randStringFrom(vp.random, 4 + randSafe.safeIntn(vp.random, 5), CS_LOWER_NUM);
    return `${pref}${tail}.smtp-out.amazonses.com`;
  });

  return content;
}

// ═════════════════════════════════════════════════════════════
// E. SMTP / TLS 协议变量 6 个
// ═════════════════════════════════════════════════════════════

function processProtocolVariables(vp, content) {
  content = replaceLiteral(content, '{TLS_VERSION}',
    () => TLS_VERSION_POOL[randSafe.safeIntn(vp.random, TLS_VERSION_POOL.length)]);
  content = replaceLiteral(content, '{TLS_CIPHER}',
    () => TLS_CIPHER_POOL[randSafe.safeIntn(vp.random, TLS_CIPHER_POOL.length)]);
  content = replaceLiteral(content, '{TLS_BITS}',
    () => TLS_BITS_POOL[randSafe.safeIntn(vp.random, TLS_BITS_POOL.length)]);
  content = replaceLiteral(content, '{SMTP_PROTOCOL}',
    () => SMTP_PROTOCOL_POOL[randSafe.safeIntn(vp.random, SMTP_PROTOCOL_POOL.length)]);
  content = replaceLiteral(content, '{MTA_TYPE}',
    () => MTA_TYPE_POOL[randSafe.safeIntn(vp.random, MTA_TYPE_POOL.length)]);
  content = replaceLiteral(content, '{MTA_VERSION_BANNER}',
    () => MTA_VERSION_BANNERS[randSafe.safeIntn(vp.random, MTA_VERSION_BANNERS.length)]);
  return content;
}

// ═════════════════════════════════════════════════════════════
// F. JWT 变量 1 个
// ═════════════════════════════════════════════════════════════

// base64url no-padding encode
function base64URLNoPad(buf) {
  return buf.toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function processJWTVariables(vp, content) {
  content = replaceLiteral(content, '{JWT_TOKEN}', () => {
    const header = JWT_HEADER_POOL[randSafe.safeIntn(vp.random, JWT_HEADER_POOL.length)];

    // payload: 80-160 字节随机
    const payloadLen = 80 + randSafe.safeIntn(vp.random, 81);
    const payloadBytes = Buffer.alloc(payloadLen);
    for (let i = 0; i < payloadLen; i++) {
      payloadBytes[i] = randSafe.safeIntn(vp.random, 256);
    }
    const payload = base64URLNoPad(payloadBytes);

    // signature 长度：HS512 用 64；HS256/RS256/其他用 32；RS256 用 64 视觉合理
    let sigLen = 32;
    if (header.indexOf('IUzUxMiI') !== -1) sigLen = 64;      // HS512
    else if (header.indexOf('JSUzI1NiI') !== -1 || header.indexOf('RS256') !== -1) sigLen = 64; // RS256
    const sigBytes = Buffer.alloc(sigLen);
    for (let i = 0; i < sigLen; i++) sigBytes[i] = randSafe.safeIntn(vp.random, 256);
    const signature = base64URLNoPad(sigBytes);

    return `${header}.${payload}.${signature}`;
  });
  return content;
}

module.exports = {
  processExtendedVariables,
  // 单独导出便于测试
  processRFC2822Variables,
  processIDVariables,
  processExtIPVariables,
  processExtDomainVariables,
  processProtocolVariables,
  processJWTVariables,
  replaceLiteral,
  formatRFC2822,
  getTzOffsetMinutes,
  setIPHelpers,
  // 也导出池给 Sprint 3C headers.js 可以复用
  YAHOO_EHLO_SUBS,
  MITSUI_DOMAIN_POOL,
};
