'use strict';
// email/zerowidth - 零宽字符插入（对应 Go pmta-injector-clean/email/zerowidth.go）
//
// 【Haraka26】在邮件主题、显示名、模板内容中随机插入零宽字符，
// 使每封邮件的文本指纹不同，防止反垃圾系统通过内容哈希批量拦截。
//
// 5 种零宽字符混用（增加指纹多样性）：
//   U+200B  零宽空格
//   U+200C  零宽非连接符
//   U+200D  零宽连接符
//   U+FEFF  零宽不换行空格
//   U+2060  单词连接符
//
// 安全区规则：
//   - {xxx} 变量块 → 排除
//   - <xxx> HTML 标签 → 排除
//   - &xxx; HTML 实体 → HTML 模式下排除
//   - http:// / https:// 开头到空白/</"/'/> 结束 → 整段排除
//   - excludeChars 里的 ASCII 标点 / 数字 / 空白 → 排除
//   - ASCII 控制字符 < 32 → 排除
//   - 只有汉字/假名/字母等"可见文字" → 安全（可插）
//
// 每行随机取 1-5 个安全位置插入，字符从 5 种池随机

const randSafe = require('./rand_safe');

// 5 种零宽字符
const ZERO_WIDTH_CHARS = [
  '​', // 零宽空格
  '‌', // 零宽非连接符
  '‍', // 零宽连接符
  '﻿', // 零宽不换行空格
  '⁠', // 单词连接符
];

// 排除字符集合（对齐 Go excludeChars map）
const EXCLUDE_SET = new Set([
  '0','1','2','3','4','5','6','7','8','9',
  '-','，','。',',','.',
  '：',':','/','\\','*',
  '?','？','!','@','#',
  '$','%','^','&','(',
  ')','=','[',']','{',
  '}','【','】','；',';',
  "'",'"','‘','“','《',
  '》','<','>','+','「',
  '」','『','』','、','・',
  '\r','\n','\t',' ','_',
]);

// 判定 code point 是否是"可见文字"（Letter / Han / Hiragana / Katakana）
// Node 用 Unicode 属性正则（ES2018+）
const LETTER_RE = /\p{L}/u;
const CJK_RE = /[一-鿿㐀-䶿\u{20000}-\u{2A6DF}\u{2A700}-\u{2B73F}\u{2B740}-\u{2B81F}]/u; // Han
const HIRA_RE = /[぀-ゟ]/u;
const KATA_RE = /[゠-ヿㇰ-ㇿ]/u;

function isLetterLike(ch) {
  return LETTER_RE.test(ch) || CJK_RE.test(ch) || HIRA_RE.test(ch) || KATA_RE.test(ch);
}

/**
 * insertZeroWidth - 在文本中随机插入零宽字符
 * @param {string} text
 * @param {boolean} isHTML 是否为 HTML 格式（仅影响 &xxx; 实体排除）
 * @param {Function} rng RNG 函数（若不传则使用 Math.random 兜底 - **不推荐生产环境**）
 * @returns {string}
 */
function insertZeroWidth(text, isHTML, rng) {
  if (!text) return text;
  if (!rng) rng = Math.random; // 兼容旧调用，但生产必须传 worker rng
  const lines = text.split('\n');
  const result = [];
  for (let i = 0; i < lines.length; i++) {
    result.push(_insertInLine(lines[i], !!isHTML, rng));
  }
  return result.join('\n');
}

/**
 * _insertInLine - 对单行文本插入零宽字符
 */
function _insertInLine(line, isHTML, rng) {
  if (!line) return line;

  // 用 Array.from 按 code point 遍历（避免代理对被拆）
  const runes = Array.from(line);
  const n = runes.length;
  const safe = new Array(n).fill(false);

  let inTag = false;
  let inVariable = false;
  let inEntity = false;
  let inURL = false;

  for (let i = 0; i < n; i++) {
    const r = runes[i];

    // URL 检测：http:// 或 https:// 开头
    if (!inURL && !inTag && !inVariable) {
      if (r === 'h' && i + 7 < n) {
        const rest = runes.slice(i, i + 8).join('');
        if (rest.startsWith('http://') || rest.startsWith('https://')) {
          inURL = true;
        }
      }
    }

    // URL 结束检测
    if (inURL) {
      if (r === ' ' || r === '\t' || r === '<' || r === '"' || r === "'" || r === '>' || r === '\r' || r === '\n') {
        inURL = false;
      } else {
        safe[i] = false;
        continue;
      }
    }

    // 更新禁区状态
    if (r === '{') {
      inVariable = true;
    } else if (r === '}') {
      inVariable = false;
      safe[i] = false;
      continue;
    } else if (r === '<') {
      inTag = true;
    } else if (r === '>') {
      inTag = false;
      safe[i] = false;
      continue;
    } else if (r === '&' && isHTML) {
      inEntity = true;
    } else if (r === ';' && inEntity) {
      inEntity = false;
      safe[i] = false;
      continue;
    }

    if (inTag || inVariable || inEntity) {
      safe[i] = false;
      continue;
    }

    if (EXCLUDE_SET.has(r)) {
      safe[i] = false;
      continue;
    }

    // ASCII 控制字符
    if (r.length === 1 && r.charCodeAt(0) < 32) {
      safe[i] = false;
      continue;
    }

    if (isLetterLike(r)) {
      safe[i] = true;
    }
  }

  // 收集所有安全位置
  const safePositions = [];
  for (let i = 0; i < n; i++) {
    if (safe[i]) safePositions.push(i);
  }
  if (safePositions.length === 0) return line;

  // 随机 1-5 个位置插入
  let count = 1 + randSafe.safeIntn(rng, 5); // Go: 1 + rand.Intn(5) = 1..5
  if (count > safePositions.length) count = safePositions.length;

  // 洗牌 safePositions 取前 count 个
  const shuffled = safePositions.slice();
  randSafe.shuffleInPlace(rng, shuffled);
  const insertSet = new Set();
  for (let i = 0; i < count; i++) insertSet.add(shuffled[i]);

  // 构建结果
  let result = '';
  for (let i = 0; i < n; i++) {
    result += runes[i];
    if (insertSet.has(i)) {
      const zw = ZERO_WIDTH_CHARS[randSafe.safeIntn(rng, ZERO_WIDTH_CHARS.length)];
      result += zw;
    }
  }
  return result;
}

module.exports = { insertZeroWidth, ZERO_WIDTH_CHARS };
