'use strict';
// email/headers_postprocess - 邮件头后处理（对应 Go pmta-injector-clean/email/headers_postprocess.go）
//
// 2 项后处理：
//   1. 字段名随机大小写（Sprint 3C）
//   2. 锚定式温和乱序（Fisher-Yates + 锚定表）
//   3. 【2026-07-25 方案 D】DKIM 排序（reorderByDkimList）—— 覆盖 shuffleOrder
//
// 入口 PostprocessMainHeaders 在 builder.js::buildRawEmail 主头组装完成后调用一次
//
// 锚定规则（温和模式）：
//   prio 0 : x-virtual-mta / x-job          (PMTA 控制头)
//   prio 1 : 所有 Received-*                (RFC 5321 时序)
//   prio 2 : DKIM-Signature                 (紧随 Received)
//   prio 4 : From
//   prio 5 : To
//   prio 6 : Cc
//   prio 7 : Subject
//   prio 8 : Date
//   prio 9 : Message-ID
//   prio 10: MIME-Version                   (锚定在 Message-ID 之后，与 append 顺序一致)
//   其它头  : Fisher-Yates 洗牌
//   特殊配对: List-Unsubscribe-Post 紧跟 List-Unsubscribe
//
// 大小写跳过名单（联合集，两工程共用）：
//   dkim-signature / x-virtual-mta / x-job / x-internal-ccbcc-skip-tg

const randSafe = require('./rand_safe');

// ═════════════════════════════════════════════════════════════
// 常量表
// ═════════════════════════════════════════════════════════════

// 大小写跳过名单（全小写比对）
const caseSkipNames = new Set([
  'dkim-signature',
  'x-virtual-mta',
  'x-job',
  'x-internal-ccbcc-skip-tg',
]);

// 锚定优先级（不在表里的进可乱池）
// 注：'received' 是前缀匹配（Received: / Received-*），其它为精确匹配
const anchorPriority = new Map([
  ['x-virtual-mta', 0],
  ['x-job',         0],
  ['received',      1], // 前缀
  ['dkim-signature', 2],
  ['from',          4],
  ['to',            5],
  ['cc',            6],
  ['subject',       7],
  ['date',          8],
  ['message-id',    9],
  ['mime-version', 10], // 【2026-06-01】改为 10（锚定在 Message-ID 之后）
]);

// ═════════════════════════════════════════════════════════════
// splitHeaderBlock - 把多头字符串块按 RFC 5322 §2.2.3 折叠规则切成单条
//   续行（SP/TAB 开头）归属上一个头
// ═════════════════════════════════════════════════════════════
function splitHeaderBlock(block) {
  if (!block) return [];
  // SplitAfter 保留分隔符 —— JS 用 match 全部切出行含换行的形式
  const lines = block.match(/[^\n]*\n?/g) || [];
  const result = [];
  let current = '';
  for (let raw of lines) {
    if (raw === '') continue;
    // 空白行（trimRight 后为空）不参与也不分隔
    const trimmed = raw.replace(/[\r\n]+$/, '');
    if (trimmed === '') continue;
    if (current === '') { current = raw; continue; }
    const first = raw.charAt(0);
    if (first === ' ' || first === '\t') {
      current += raw;
    } else {
      result.push(current);
      current = raw;
    }
  }
  if (current !== '') result.push(current);
  return result;
}

// ═════════════════════════════════════════════════════════════
// extractFieldName - 从 header 条目提取字段名（小写、去空白）
//   续行（SP/TAB 开头）返回空串
//   无冒号返回空串
// ═════════════════════════════════════════════════════════════
function extractFieldName(line) {
  if (!line) return '';
  const first = line.charAt(0);
  if (first === ' ' || first === '\t') return '';
  const colon = line.indexOf(':');
  if (colon <= 0) return '';
  return line.slice(0, colon).trim().toLowerCase();
}

// ═════════════════════════════════════════════════════════════
// randomizeFieldName - 字段名逐字符 50/50 随机大小写；值部分不动
//   跳过 caseSkipNames；续行原样返回
// ═════════════════════════════════════════════════════════════
function randomizeFieldName(line, rng) {
  if (!line) return line;
  const first = line.charAt(0);
  if (first === ' ' || first === '\t') return line;
  const colon = line.indexOf(':');
  if (colon <= 0) return line;
  const name = line.slice(0, colon);
  if (caseSkipNames.has(name.trim().toLowerCase())) return line;
  let out = '';
  for (let i = 0; i < name.length; i++) {
    const ch = name.charCodeAt(i);
    const isLower = ch >= 97 && ch <= 122;
    const isUpper = ch >= 65 && ch <= 90;
    if (!isLower && !isUpper) {
      out += name.charAt(i);
      continue;
    }
    // 50/50 翻转
    if (randSafe.safeIntn(rng, 2) === 0) {
      // 取大写
      out += isLower ? String.fromCharCode(ch - 32) : name.charAt(i);
    } else {
      // 取小写
      out += isUpper ? String.fromCharCode(ch + 32) : name.charAt(i);
    }
  }
  return out + line.slice(colon);
}

// ═════════════════════════════════════════════════════════════
// applyCaseRandomization - 对整个 headers 数组做字段名大小写随机化
//   就地修改 + 返回同一数组
//   caseMode: 预留 D2 决策切换点（当前仅 'random' 分支）
// ═════════════════════════════════════════════════════════════
function applyCaseRandomization(headers, rng, caseMode) {
  void caseMode; // 预留
  if (!headers || headers.length === 0) return headers;
  for (let i = 0; i < headers.length; i++) {
    headers[i] = randomizeFieldName(headers[i], rng);
  }
  return headers;
}

// ═════════════════════════════════════════════════════════════
// shuffleHeadersWithAnchors - 锚定式乱序
//   1. 分离锚定头（anchorPriority 命中）+ list-unsubscribe-post 特殊配对
//   2. 剩余进可乱池，Fisher-Yates 洗牌
//   3. 把 Post 插回 List-Unsubscribe 之后
//   4. 锚定头按 priority 升序排（同 priority 按原 index 保稳定）
//   5. 输出 = 锚定序列 + 洗牌池
// ═════════════════════════════════════════════════════════════
function shuffleHeadersWithAnchors(headers, rng) {
  if (!headers || headers.length <= 1) return headers;

  const anchors = [];       // {line, priority, origIndex}
  const pool = [];
  let listUnsubPost = '';

  for (let i = 0; i < headers.length; i++) {
    const h = headers[i];
    const name = extractFieldName(h);
    if (!name) { pool.push(h); continue; }

    // Received-* 系列前缀匹配
    if (name.startsWith('received')) {
      anchors.push({ line: h, priority: anchorPriority.get('received'), origIndex: i });
      continue;
    }
    if (anchorPriority.has(name)) {
      anchors.push({ line: h, priority: anchorPriority.get(name), origIndex: i });
      continue;
    }
    if (name === 'list-unsubscribe-post') {
      listUnsubPost = h; // 兼容多个 Post：保留最后一个
      continue;
    }
    pool.push(h);
  }

  // Fisher-Yates 洗牌
  for (let i = pool.length - 1; i > 0; i--) {
    const j = randSafe.safeIntn(rng, i + 1);
    const tmp = pool[i]; pool[i] = pool[j]; pool[j] = tmp;
  }

  // 把 list-unsubscribe-post 插回 list-unsubscribe 之后
  if (listUnsubPost) {
    let insertIdx = -1;
    for (let i = 0; i < pool.length; i++) {
      if (extractFieldName(pool[i]) === 'list-unsubscribe') {
        insertIdx = i + 1;
        break;
      }
    }
    if (insertIdx >= 0) {
      pool.splice(insertIdx, 0, listUnsubPost);
    } else {
      pool.push(listUnsubPost);
    }
  }

  // 锚定头按 priority 升序（同 priority 按原 index 保稳定）
  anchors.sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    return a.origIndex - b.origIndex;
  });

  const result = new Array(headers.length);
  let k = 0;
  for (const a of anchors) result[k++] = a.line;
  for (const p of pool) result[k++] = p;
  return result;
}

// ═════════════════════════════════════════════════════════════
// 【2026-07-25 方案 D】reorderByDkimList - 按 dkimList 顺序重排 headers
//   目的：控制 header 出现顺序 = 控制 PMTA 生成的 h= 顺序
//
//   算法：
//     1. 分离顶部锚定头（x-virtual-mta / x-job / Received-* / DKIM-Signature）
//     2. 按 dkimList 顺序，把邮件里能匹配的字段放进 dkimSlots
//        - 大小写不敏感匹配
//        - dkimList 里有但邮件没的 slot 保持空（输出跳过）
//        - 邮件里有但 dkimList 没的 → others 池
//     3. 输出 = 顶部锚定 + dkimSlots (跳空) + others
//
//   不变量：len(output) == len(input)；每个输入头出现且仅出现一次
// ═════════════════════════════════════════════════════════════
const TOP_ANCHOR_NAMES = new Set(['x-virtual-mta', 'x-job', 'dkim-signature']);

function reorderByDkimList(headers, dkimList) {
  if (!headers || headers.length === 0 || !dkimList || dkimList.length === 0) return headers;

  // 建 dkim 字段名 → list 位置 的映射（大小写不敏感 + 去空白）
  // 重复的后者覆盖前者
  const dkimIndex = new Map();
  for (let i = 0; i < dkimList.length; i++) {
    const key = String(dkimList[i] || '').trim().toLowerCase();
    if (!key) continue;
    dkimIndex.set(key, i);
  }
  if (dkimIndex.size === 0) return headers; // 全空/空白 → 不动

  const topAnchors = [];
  const dkimSlots = new Array(dkimList.length); // 稀疏，undefined 表示未填
  const others = [];

  for (const h of headers) {
    const name = extractFieldName(h);
    if (!name) { others.push(h); continue; }
    if (TOP_ANCHOR_NAMES.has(name)) { topAnchors.push(h); continue; }
    if (name.startsWith('received')) { topAnchors.push(h); continue; }
    if (dkimIndex.has(name)) {
      const idx = dkimIndex.get(name);
      dkimSlots[idx] = h;
      continue;
    }
    others.push(h);
  }

  // 组装输出：topAnchors（保原序）+ dkimSlots（跳空）+ others（保原序）
  const result = [];
  for (const h of topAnchors) result.push(h);
  for (const h of dkimSlots) if (h !== undefined) result.push(h);
  for (const h of others) result.push(h);
  return result;
}

// ═════════════════════════════════════════════════════════════
// PostprocessMainHeaders - 总入口（builder.js 调用）
//
// 顺序：先乱序 / DKIM 排序，后大小写随机化
//   理由：乱序时用 lowercase 比对字段名（大小写不敏感），即使先大小写化也不失效
//         但先乱序保持字段名原大小写形式（不易出 bug）
//
// 【2026-07-25 方案 D】优先级：
//   dkimList 非空 → reorderByDkimList（跳过 shuffleOrder）
//   dkimList 空 且 shuffleOrder → shuffleHeadersWithAnchors
//   randomCase 独立生效（大小写与顺序正交）
// ═════════════════════════════════════════════════════════════
function PostprocessMainHeaders(headers, rng, shuffleOrder, randomCase, caseMode, dkimList) {
  if (!headers || headers.length === 0) return headers;

  // 方案 D：DKIM 排序优先，跳过 shuffle
  if (Array.isArray(dkimList) && dkimList.length > 0) {
    headers = reorderByDkimList(headers, dkimList);
  } else if (shuffleOrder) {
    headers = shuffleHeadersWithAnchors(headers, rng);
  }

  if (randomCase) {
    headers = applyCaseRandomization(headers, rng, caseMode);
  }
  return headers;
}

module.exports = {
  caseSkipNames,
  anchorPriority,
  splitHeaderBlock,
  extractFieldName,
  randomizeFieldName,
  applyCaseRandomization,
  shuffleHeadersWithAnchors,
  reorderByDkimList,
  PostprocessMainHeaders,
};
