'use strict';
// email/rand_safe - 安全随机数工具（对应 Go pmta-injector-clean/email/rand_safe.go）
//
// ═══════════════════════════════════════════════════════════════
// 核心 bug 修复历史（不能回退）
// ═══════════════════════════════════════════════════════════════
//   v62 修复：100 worker 在纳秒级循环内创建时 seed 重复，导致 math/rand 内部状态退化，
//            Intn(n) 返回越界值 n 的致命 bug。
//   v63 修复：safeIntn 用 Int63() + 取模，编译器不可能优化掉模运算，数学层面保证安全。
//   v62 修复：每个 worker 独立 Builder + VariableProcessor + HeaderGenerator。
//
// Node 端实现说明：
//   - Go 用 crypto/rand 生成 8 字节种子 + workerID 偏移 → math/rand.NewSource
//   - Node 用 crypto.randomBytes(16) → seedrandom(seedStr) 返回 PRNG 函数
//   - 每次调 rng() 返回 [0, 1) 的 double
//   - safeIntn(rng, n) 返回 [0, n) 的整数（n <= 0 时返回 0，与 Go 语义一致）
//   - randIntRange / randStringFrom 与 Go 版函数签名和行为一一对应
//
// 惯用调用：
//   const rand = require('./rand_safe');
//   const rng = rand.cryptoSeed(workerId);
//   const n = rand.safeIntn(rng, 100);        // [0, 99]
//   const r = rand.randIntRange(rng, 1, 5, 1, 10);  // 夹紧 [1,5]→[1,10]
//   const s = rand.randStringFrom(rng, 8, 'abcdef0123456789');
// ═══════════════════════════════════════════════════════════════

const crypto = require('crypto');
const seedrandom = require('seedrandom');

/**
 * cryptoSeed - 用 crypto.randomBytes 生成真随机 seed，加 workerId 保证 worker 间独立
 * @param {number} workerId
 * @returns {Function} rng() 返回 [0, 1) 的 double；额外挂 .quick(), .int32() 等 seedrandom 方法
 */
function cryptoSeed(workerId) {
  // 16 字节 hex + workerId 拼字符串作为 seed（seedrandom 接受任意字符串）
  const seedHex = crypto.randomBytes(16).toString('hex');
  const seedStr = `${seedHex}_w${workerId | 0}`;
  return seedrandom(seedStr);
}

/**
 * safeIntn - 安全的随机整数生成，保证返回值在 [0, n) 范围内
 * @param {Function} rng 由 cryptoSeed 返回的 PRNG 函数
 * @param {number} n 上限（不含）
 * @returns {number} [0, n-1] 或 n <= 0 时返回 0
 *
 * 对齐 Go safeIntn(r *rand.Rand, n int) int：
 *   Go 用 r.Int63() % int64(n) 数学保证安全
 *   Node 用 Math.floor(rng() * n)；rng() ∈ [0, 1)，乘 n 后 floor ∈ [0, n-1]
 *   注意：Number 精度 53 bit，n < 2^53 时无误差；n < 2^32 时无实际使用差异
 */
function safeIntn(rng, n) {
  if (!Number.isFinite(n) || n <= 0) return 0;
  const v = Math.floor(rng() * n);
  // 极端情况防御：rng() 若返回 1.0（理论不可能，seedrandom 明确 [0,1)），加 clamp
  if (v >= n) return n - 1;
  return v;
}

/**
 * randIntRange - 返回 [min, max] 内随机整数，先把 min/max 夹紧到 [lo, hi] 并处理 min > max
 * 永不 panic、永不越界
 * @param {Function} rng
 * @param {number} min
 * @param {number} max
 * @param {number} lo  夹紧下限
 * @param {number} hi  夹紧上限
 * @returns {number}
 */
function randIntRange(rng, min, max, lo, hi) {
  if (lo < 0) lo = 0;
  if (min < lo) min = lo;
  if (max > hi) max = hi;
  if (max < min) max = min;
  return min + safeIntn(rng, max - min + 1);
}

/**
 * randStringFrom - 从 alphabet 随机取 n 个字符组成串
 * @param {Function} rng
 * @param {number} n 长度（n <= 0 或空 alphabet → ''）
 * @param {string} alphabet 字母表
 * @returns {string}
 */
function randStringFrom(rng, n, alphabet) {
  if (!Number.isFinite(n) || n <= 0 || !alphabet || alphabet.length === 0) return '';
  let out = '';
  const alen = alphabet.length;
  for (let i = 0; i < n; i++) {
    out += alphabet.charAt(safeIntn(rng, alen));
  }
  return out;
}

/**
 * shuffleInPlace - Fisher-Yates 洗牌，对齐 Go rand.Shuffle
 * @param {Function} rng
 * @param {Array} arr
 */
function shuffleInPlace(rng, arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = safeIntn(rng, i + 1);
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
}

module.exports = {
  cryptoSeed,
  safeIntn,
  randIntRange,
  randStringFrom,
  shuffleInPlace,
};
