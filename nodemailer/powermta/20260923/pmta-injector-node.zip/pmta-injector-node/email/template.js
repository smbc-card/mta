'use strict';
// email/template - 模板引擎（Sprint 2 简版；Sprint 3 会引入 Handlebars 完整替换）
//
// Sprint 2 目标：能读模板文件 + 支持 Go 模板语法 {{.Field}} / {{.Nested.Field}} 基础替换。
//   支持字段：Email / Name / FirstName / LastName / Data.xxx / Global.xxx /
//             System.Date / System.DateTime / System.Year / System.UUID / System.JobID /
//             System.MessageID / System.Index / Computed.EmailHash /
//             Computed.UnsubscribeURL / Computed.Greeting
//
// Sprint 3+ 计划：
//   - 引入 Handlebars（helper 30+）替换本简版
//   - 或保留简版 + 加 IF/RANGE 支持（视性能）
//
// 与 Go 版接口对齐：
//   - new TemplateEngine(templatePath) → 读文件 + 缓存 rawContent
//   - .setGlobalVariables(vars) → 存 global
//   - .render(data) → 渲染主模板
//   - .renderString(text, data) → 渲染任意字符串（用于 subject）

const fs = require('fs');

class TemplateEngine {
  constructor(templatePath) {
    if (!templatePath) {
      throw new Error('模板路径不能为空');
    }
    let content;
    try {
      content = fs.readFileSync(templatePath, 'utf8');
    } catch (e) {
      throw new Error(`读取模板文件失败: ${e.message}`);
    }
    this.templatePath = templatePath;
    this.rawContent = content;
    this.globalVariables = {};
    // 字符串缓存（renderString 高频调用 subject 等短串）
    this._stringCache = new Map();
  }

  setGlobalVariables(vars) {
    this.globalVariables = vars || {};
  }

  /**
   * 渲染主模板
   * @param {Object} data TemplateData 对象
   * @returns {string}
   */
  render(data) {
    return _renderText(this.rawContent, this._mergeData(data));
  }

  /**
   * 渲染任意字符串（Sprint 2 简版无 Parse 缓存，Sprint 3 完整版会引入 Handlebars 编译缓存）
   * @param {string} text
   * @param {Object} data
   * @returns {string}
   */
  renderString(text, data) {
    return _renderText(String(text || ''), this._mergeData(data));
  }

  _mergeData(data) {
    // Global 合并（浅合并到 data.Global）
    if (!data.Global) data.Global = {};
    for (const k of Object.keys(this.globalVariables || {})) {
      if (data.Global[k] === undefined) data.Global[k] = this.globalVariables[k];
    }
    return data;
  }
}

// ═════════════════════════════════════════════════════════════
// _renderText - 极简 Go 模板语法替换（Sprint 2 版）
//   匹配 {{ .Path.To.Field }}（允许空白），大小写敏感
//   Sprint 3+ 换 Handlebars 时保留同样入口签名
// ═════════════════════════════════════════════════════════════
const PLACEHOLDER_RE = /\{\{\s*\.([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*\}\}/g;

function _renderText(text, data) {
  return text.replace(PLACEHOLDER_RE, (match, path) => {
    const val = _lookupPath(data, path);
    if (val === undefined || val === null) return match; // 未匹配保持原样，便于调试
    return String(val);
  });
}

function _lookupPath(obj, dotPath) {
  const segs = dotPath.split('.');
  let cur = obj;
  for (const s of segs) {
    if (cur === null || cur === undefined) return undefined;
    cur = cur[s];
  }
  return cur;
}

// ═════════════════════════════════════════════════════════════
// TemplateData 构造器（对应 Go NewTemplateData）
//
// 字段结构与 Go TemplateData 一致（首字母大写以便 {{.Email}} 语法直接命中）：
//   Email / Name / FirstName / LastName
//   Data (map)     — 自定义字段
//   Global (map)   — 全局变量
//   System { Date, DateTime, Timestamp, Year, UUID, JobID, MessageID, Index }
//   Computed { UnsubscribeURL, TrackingPixel, Greeting, EmailHash }
// ═════════════════════════════════════════════════════════════
function newTemplateData() {
  const now = new Date();
  const pad2 = (n) => String(n).padStart(2, '0');
  const dateStr = `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`;
  const dtStr = `${dateStr} ${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())}`;
  return {
    Email: '',
    Name: '',
    FirstName: '',
    LastName: '',
    Data: {},
    Global: {},
    System: {
      Date: dateStr,
      DateTime: dtStr,
      Timestamp: Math.floor(now.getTime() / 1000),
      Year: now.getFullYear(),
      UUID: '',            // dispatcher 会填充
      JobID: '',           // dispatcher 会填充
      MessageID: '',       // builder 会填充
      Index: 0,            // dispatcher 会填充
    },
    Computed: {
      UnsubscribeURL: '',
      TrackingPixel: '',
      Greeting: '',
      EmailHash: '',
    },
  };
}

/**
 * @param {string} templatePath
 * @returns {TemplateEngine}
 */
function create(templatePath) {
  return new TemplateEngine(templatePath);
}

module.exports = { TemplateEngine, create, newTemplateData };
