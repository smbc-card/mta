'use strict';
// email/templates_received - 19987 条 Received 模板池
//   （对应 Go pmta-injector-clean/email/templates_received.go）
//
// 【契约】数据文件 email/templates_received_pool.txt 与 Go 版**字节级一致**
// （C# Resources/builtin-received-templates.txt 也是同一份，两工程 3 处 MD5 相同）
//
// 加载流程：
//   1. 启动时 fs.readFileSync 读嵌入的 .txt 文件（3.5MB, ~19987 行）
//   2. 按 \n split → 每行 trim → 过滤空行 + "//" 注释行
//   3. 结果数组固定在内存，不再变化
//
// 【重要】运行时 generateReceivedRandom 从 cfg.received_random_templates 读取
// （用户在 C# UI 编辑 + config.yaml 写入），不直接读此池。
// 此池的两个作用：
//   1. 反指纹"二进制变体差异"（D4 决策）— 嵌入 3.5MB 数据让每台服务器二进制不同
//   2. 未来扩展 API 备份池 — 万一 config 空池时可回落到内置池
//
// pkg 打包路径处理：
//   - 开发时（node main.js）：__dirname 是绝对路径，能直接读
//   - pkg 编译后：__dirname 指向虚拟文件系统，txt 已在 pkg.assets 里
//   - path.join(__dirname, 'templates_received_pool.txt') 两种模式都工作
//
// 防御：文件读取失败 → 返回空数组（不 throw，保持服务可用）
//       实际不会到这（pkg 编译时数据已包）

const fs = require('fs');
const path = require('path');

/**
 * loadReceivedTemplatePool - 解析嵌入 txt 文件
 * 与 Go loadReceivedTemplatePool 语义 100% 对齐：
 *   - 按 \n split（\r\n 中 \r 会被 trimRight 去掉）
 *   - trim 每行前后空白
 *   - 跳过空行
 *   - 跳过 "//" 开头的注释行
 * @returns {string[]}
 */
function loadReceivedTemplatePool() {
  let raw;
  try {
    raw = fs.readFileSync(path.join(__dirname, 'templates_received_pool.txt'), 'utf8');
  } catch (e) {
    // 数据文件缺失（不应发生 —— pkg 编译时打入 assets；开发环境 Sprint 3D 手动拷贝）
    process.stderr.write(`[templates_received] 加载嵌入池失败：${e.message}\n`);
    return [];
  }
  if (!raw) return [];

  // 剥首行 BOM（防御性；Go 版没做，我们更保守）
  if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);

  const result = [];
  const lines = raw.split('\n');
  for (const rawLine of lines) {
    // Go: strings.TrimRight(raw, "\r") + strings.TrimSpace
    // JS: 手动 trimRight \r 再 trim 空白 —— 与 Go 一致
    let line = rawLine.endsWith('\r') ? rawLine.slice(0, -1) : rawLine;
    line = line.trim();
    if (line === '') continue;
    if (line.startsWith('//')) continue;
    result.push(line);
  }
  return result;
}

// 启动时一次性加载，运行时不再变化
const receivedTemplatePool = loadReceivedTemplatePool();
const receivedTemplatePoolSize = receivedTemplatePool.length;

module.exports = {
  receivedTemplatePool,
  receivedTemplatePoolSize,
  loadReceivedTemplatePool, // 暴露以便测试或需要重新加载时用
};
