'use strict';
// email/builder - MIME 组装（Sprint 3E 完整反指纹版；对应 Go pmta-injector-clean/email/builder.go）
//
// 【本 sprint 覆盖】
//   ✅ VariableProcessor 接入（Sprint 3B 30+ 基础 + 53 扩展变量）
//   ✅ HeaderGenerator 接入（Sprint 3C: Received/DKIM/25 Message-ID/26 扩展头/联动组/v2 独立头/5 ESP）
//   ✅ 零宽字符（Subject/DisplayName/TemplateContent）
//   ✅ RLO/PDF bidi 反转（Subject + DisplayName，UTF-8 守卫）
//   ✅ 字符集转换 UTF-8 → JIS/GBK 逐字符 '?' 兜底
//   ✅ RFC 2047 encoded-word（B/Q）+ 非 UTF-8 不分段（保 ISO-2022-JP 状态机连续）
//   ✅ mainHeaders 数组累积 → PostprocessMainHeaders（大小写 + 乱序 + 方案 D DKIM 顺序）
//   ✅ CC 头 RFC 5322 §2.2.3 折叠 + CR/LF 注入防御
//   ✅ multipart/mixed + multipart/alternative + multipart/related 组合
//   ✅ 附件（上传 + 自定义随机附件 13 字段）
//   ✅ CID 内嵌图片
//   ✅ 6 种 MIME boundary 客户端风格
//   ✅ Custom From 邮箱轮换（Haraka26）
//   ✅ CustomHeadersText 多行头 + 变量渲染
//   ✅ Message-ID 主域策略（P0-2 OrgDomain）
//   ✅ v8.1.3 #22/#23 CR/LF 注入防御 + Cc 折叠
//   ✅ TextToHTML txt→html 转换（v66 charset 支持）
//   ⏳ Sprint 4: 图片像素噪点（Sharp）—— 本 sprint 用 no-op 占位

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const randSafe = require('./rand_safe');
const varsMod = require('./variables');
const headersMod = require('./headers');
const postproc = require('./headers_postprocess');
const bidiMod = require('./bidi');
const zwMod = require('./zerowidth');
const charsetMod = require('./charset');
const foldMod = require('./fold');
const templateMod = require('./template');
const noiseMod = require('./noise');
const utils = require('../utils/utils');

// ═════════════════════════════════════════════════════════════
// 6 种 boundary 客户端风格
// ═════════════════════════════════════════════════════════════
const BOUNDARY_STYLES = [
  // Outlook: ----=_NextPart_000_{4-hex}_01D{5-hex}.{8-hex} 全大写
  () => `----=_NextPart_000_${headersMod.randomHexString(4).toUpperCase()}_01D${headersMod.randomHexString(5).toUpperCase()}.${headersMod.randomHexString(8).toUpperCase()}`,
  // Apple Mail: Apple-Mail=_{UUID 大写}
  () => `Apple-Mail=_${utils.generateUUID().toUpperCase()}`,
  // Gmail: 30 位 hex（前 14 位 0，后 16 位随机）
  () => `00000000000000${headersMod.randomHexString(16)}`,
  // Postfix: {8-hex}.{8-hex}
  () => `${headersMod.randomHexString(8)}.${headersMod.randomHexString(8)}`,
  // Thunderbird: ------------{24-hex 小写}
  () => `------------${headersMod.randomHexString(24)}`,
  // PHPMailer: b1_{32-hex}
  () => `b1_${headersMod.randomHexString(32)}`,
];

function generateBoundary(_prefix) {
  return BOUNDARY_STYLES[Math.floor(Math.random() * BOUNDARY_STYLES.length)]();
}

// ═════════════════════════════════════════════════════════════
// 附件文件名 / 后缀 / 内容 字符集
// ═════════════════════════════════════════════════════════════
const ATTACH_ALNUM = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
const ATTACH_SUFFIX_ALPHA = 'abcdefghijklmnopqrstuvwxyz';

// ═════════════════════════════════════════════════════════════
// HTML 检测 + HTML→纯文本（用于 multipart/alternative 生成 text/plain 备份）
// ═════════════════════════════════════════════════════════════
function isHTMLContent(content) {
  const s = String(content || '').trim().toLowerCase();
  return s.startsWith('<!doctype') || s.startsWith('<html') || s.indexOf('<body') !== -1;
}

function htmlToPlainText(html) {
  let text = String(html || '');
  text = text.replace(/<br\s*\/?>/gi, '\n');
  text = text.replace(/<\/p>/gi, '\n\n');
  text = text.replace(/<\/div>/gi, '\n');
  text = text.replace(/<\/tr>/gi, '\n');
  text = text.replace(/<li[^>]*>/gi, '- ');
  text = text.replace(/<hr\s*\/?>/gi, '\n━━━━━━━━━━━━\n');
  // 链接：<a href="URL">text</a> → text (URL)
  text = text.replace(/<a[^>]+href=["']([^"']*)["'][^>]*>(.*?)<\/a>/gi, '$2 ($1)');
  // 图片：<img alt="alt">
  text = text.replace(/<img[^>]+alt=["']([^"']*)["'][^>]*\/?>/gi, '[画像: $1]');
  // 去 style/script（含内容）
  text = text.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
  text = text.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  // 去所有剩余标签
  text = text.replace(/<[^>]+>/g, '');
  // HTML 实体
  text = text.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<')
             .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
             .replace(/&#x27;/g, "'").replace(/&yen;/g, '¥').replace(/&copy;/g, '©')
             .replace(/&reg;/g, '®');
  // 清理多余空行
  text = text.replace(/\n{3,}/g, '\n\n');
  // 清理行首尾空格
  text = text.split('\n').map((l) => l.trim()).join('\n');
  return text.trim();
}

// ═════════════════════════════════════════════════════════════
// RFC 2047 encoded-word 编码
// ═════════════════════════════════════════════════════════════

function needsEncoding(s) {
  const str = String(s || '');
  for (let i = 0; i < str.length; i++) {
    if (str.charCodeAt(i) > 127) return true;
  }
  return false;
}

function needsQuoting(s) {
  const special = '()<>[]:;@\\,."';
  const str = String(s || '');
  for (let i = 0; i < str.length; i++) {
    const ch = str.charAt(i);
    if (special.indexOf(ch) !== -1 || ch === ' ' || ch === '\t') return true;
  }
  return false;
}

// UTF-8 rune start: byte 高位不是 10xxxxxx（不是续字节）
function _isUTF8RuneStart(byte) {
  return (byte & 0xC0) !== 0x80;
}

/**
 * encodeRFC2047B - Base64 encoded-word
 * 关键：非 UTF-8 编码（ISO-2022-JP 等）不分段，避免破坏有状态编码的转义序列连续性
 */
function encodeRFC2047B(s, charset) {
  const dataBuf = charsetMod.convertFromUTF8(s, charset);
  const encoded = dataBuf.toString('base64');

  // 短串或非 UTF-8：一段输出
  if (encoded.length <= 65 || !charsetMod.isUTF8Charset(charset)) {
    return `=?${charset}?B?${encoded}?=`;
  }

  // UTF-8 长串：按 rune 边界分段（每段 ~45 字节）
  const chunkSize = 45;
  const parts = [];
  let i = 0;
  while (i < dataBuf.length) {
    let end = Math.min(i + chunkSize, dataBuf.length);
    // 边界对齐：不在多字节字符中间截断
    while (end > i && !_isUTF8RuneStart(dataBuf[end])) end--;
    if (end <= i) end = Math.min(i + chunkSize, dataBuf.length); // 兜底
    const chunk = dataBuf.slice(i, end);
    const enc = chunk.toString('base64');
    parts.push(`=?${charset}?B?${enc}?=`);
    i = end;
  }
  return parts.join(' ');
}

/**
 * encodeRFC2047Q - Quoted-Printable encoded-word
 */
function encodeRFC2047Q(s, charset) {
  const dataBuf = charsetMod.convertFromUTF8(s, charset);
  let out = `=?${charset}?Q?`;
  for (let i = 0; i < dataBuf.length; i++) {
    const b = dataBuf[i];
    if (b >= 0x21 && b <= 0x7e && b !== 0x3D && b !== 0x3F && b !== 0x5F) {
      // '=' 0x3D / '?' 0x3F / '_' 0x5F 需转义
      out += String.fromCharCode(b);
    } else if (b === 0x20) {
      out += '_';
    } else {
      out += '=' + b.toString(16).toUpperCase().padStart(2, '0');
    }
  }
  out += '?=';
  return out;
}

function encodeRFC2047WithCharset(s, charset, encoding) {
  if (!needsEncoding(s)) return String(s);
  if (String(encoding || '').toLowerCase() === 'quoted-printable') {
    return encodeRFC2047Q(s, charset);
  }
  return encodeRFC2047B(s, charset);
}

/**
 * encodeEmailAddressWithCharset - 编码 "显示名 <地址>"
 * 【v8.1.3 #22】过滤 CR/LF 防头部注入（纵深防御第 3 层）
 */
function encodeEmailAddressWithCharset(displayName, email, charset, encoding) {
  // CR/LF 注入过滤
  let dn = String(displayName || '');
  let em = String(email || '');
  if (em.indexOf('\r') !== -1 || em.indexOf('\n') !== -1) {
    em = em.replace(/\r/g, ' ').replace(/\n/g, ' ');
  }
  if (dn.indexOf('\r') !== -1 || dn.indexOf('\n') !== -1) {
    dn = dn.replace(/\r/g, ' ').replace(/\n/g, ' ');
  }
  if (dn === '') return em;
  if (needsEncoding(dn)) {
    const encoded = encodeRFC2047WithCharset(dn, charset, encoding);
    return `${encoded} <${em}>`;
  }
  if (needsQuoting(dn)) {
    let escaped = dn.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    return `"${escaped}" <${em}>`;
  }
  return `${dn} <${em}>`;
}

// ═════════════════════════════════════════════════════════════
// MIME 类型表（Sprint 4 完整扩充，~260 条，对齐 Go getMimeType）
// 契约：与 C# TaskConfiguration.AttachmentInfo.SupportedExtensions 一致
// 冲突点（有意保持）：
//   .ts → video/mp2t（IANA 标准，非 TypeScript）
//   .key → application/vnd.apple.keynote（Apple Keynote，非 SSL 私钥）
//   .cab → application/vnd.ms-cab-compressed（归压缩类）
// 未在表中 → 兜底 application/octet-stream
// ═════════════════════════════════════════════════════════════
const MIME_TYPES = {
  // ─ 文档 ─
  '.txt': 'text/plain', '.csv': 'text/csv', '.tsv': 'text/tab-separated-values',
  '.html': 'text/html', '.htm': 'text/html', '.xhtml': 'application/xhtml+xml',
  '.xml': 'application/xml', '.json': 'application/json', '.pdf': 'application/pdf',
  '.doc': 'application/msword',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.dot': 'application/msword',
  '.dotx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
  '.xls': 'application/vnd.ms-excel',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.xlsm': 'application/vnd.ms-excel.sheet.macroEnabled.12',
  '.xlsb': 'application/vnd.ms-excel.sheet.binary.macroEnabled.12',
  '.xlt': 'application/vnd.ms-excel',
  '.xltx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.template',
  '.ppt': 'application/vnd.ms-powerpoint',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.pptm': 'application/vnd.ms-powerpoint.presentation.macroEnabled.12',
  '.pps': 'application/vnd.ms-powerpoint',
  '.ppsx': 'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
  '.pot': 'application/vnd.ms-powerpoint',
  '.potx': 'application/vnd.openxmlformats-officedocument.presentationml.template',
  '.rtf': 'application/rtf',
  '.odt': 'application/vnd.oasis.opendocument.text',
  '.ods': 'application/vnd.oasis.opendocument.spreadsheet',
  '.odp': 'application/vnd.oasis.opendocument.presentation',
  '.pages': 'application/vnd.apple.pages',
  '.numbers': 'application/vnd.apple.numbers',
  '.key': 'application/vnd.apple.keynote',
  '.tex': 'application/x-tex', '.wps': 'application/vnd.ms-works',
  '.xps': 'application/vnd.ms-xpsdocument',
  '.md': 'text/markdown', '.markdown': 'text/markdown',
  '.bib': 'application/x-bibtex', '.org': 'text/x-org', '.rst': 'text/x-rst',
  '.adoc': 'text/asciidoc',
  '.epub': 'application/epub+zip', '.mobi': 'application/x-mobipocket-ebook',
  '.azw': 'application/vnd.amazon.ebook', '.azw3': 'application/vnd.amazon.ebook',
  '.fb2': 'application/x-fictionbook+xml', '.djvu': 'image/vnd.djvu',

  // ─ 图片 ─
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.gif': 'image/gif',
  '.bmp': 'image/bmp', '.ico': 'image/x-icon', '.webp': 'image/webp', '.svg': 'image/svg+xml',
  '.tiff': 'image/tiff', '.tif': 'image/tiff', '.heic': 'image/heic', '.heif': 'image/heif',
  '.raw': 'image/x-raw', '.cr2': 'image/x-canon-cr2', '.nef': 'image/x-nikon-nef',
  '.arw': 'image/x-sony-arw', '.dng': 'image/x-adobe-dng',
  '.psd': 'image/vnd.adobe.photoshop',
  '.ai': 'application/postscript', '.eps': 'application/postscript',

  // ─ 音频 ─
  '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.flac': 'audio/flac',
  '.aac': 'audio/aac', '.wma': 'audio/x-ms-wma', '.m4a': 'audio/mp4', '.aiff': 'audio/aiff',
  '.opus': 'audio/opus', '.amr': 'audio/amr',

  // ─ 视频 ─
  '.mp4': 'video/mp4', '.avi': 'video/x-msvideo', '.mkv': 'video/x-matroska',
  '.mov': 'video/quicktime', '.wmv': 'video/x-ms-wmv', '.flv': 'video/x-flv',
  '.webm': 'video/webm', '.m4v': 'video/x-m4v', '.3gp': 'video/3gpp',
  '.mpg': 'video/mpeg', '.mpeg': 'video/mpeg', '.ts': 'video/mp2t',
  '.asx': 'video/x-ms-asf',

  // ─ 压缩包 ─
  '.zip': 'application/zip', '.rar': 'application/vnd.rar', '.7z': 'application/x-7z-compressed',
  '.tar': 'application/x-tar', '.gz': 'application/gzip', '.gzip': 'application/gzip',
  '.bz2': 'application/x-bzip2', '.xz': 'application/x-xz',
  '.tgz': 'application/x-compressed-tar', '.tbz2': 'application/x-bzip-compressed-tar',
  '.zst': 'application/zstd', '.lz': 'application/x-lzip', '.lzma': 'application/x-lzma',
  '.cab': 'application/vnd.ms-cab-compressed',

  // ─ 设计 / CAD / BIM ─
  '.dwg': 'image/vnd.dwg', '.dxf': 'image/vnd.dxf',
  '.skp': 'application/vnd.sketchup.skp', '.stl': 'model/stl', '.obj': 'model/obj',
  '.fbx': 'application/octet-stream',
  '.step': 'application/step', '.stp': 'application/step', '.igs': 'model/iges',
  '.sldprt': 'application/sldworks', '.sldasm': 'application/sldworks',
  '.fig': 'application/x-figma', '.sketch': 'application/x-sketch',
  '.xd': 'application/x-adobe-xd', '.indd': 'application/x-indesign',
  '.rvt': 'application/octet-stream',
  '.ifc': 'application/x-step',

  // ─ 字体 ─
  '.ttf': 'font/ttf', '.otf': 'font/otf', '.woff': 'font/woff', '.woff2': 'font/woff2',
  '.eot': 'application/vnd.ms-fontobject',
  '.fon': 'application/x-font', '.fnt': 'application/x-font', '.pfb': 'application/x-font',

  // ─ 代码 / 脚本 ─
  '.js': 'application/javascript', '.mjs': 'application/javascript',
  '.css': 'text/css', '.php': 'application/x-httpd-php',
  '.py': 'text/x-python', '.pyw': 'text/x-python',
  '.pyc': 'application/x-python-code', '.pyo': 'application/x-python-code',
  '.pyz': 'application/x-python-code', '.pyzw': 'application/x-python-code',
  '.java': 'text/x-java-source', '.cs': 'text/x-csharp',
  '.cpp': 'text/x-c++src', '.c': 'text/x-csrc',
  '.h': 'text/x-chdr', '.hpp': 'text/x-c++hdr',
  '.go': 'text/x-go', '.rs': 'text/x-rust', '.rb': 'text/x-ruby',
  '.swift': 'text/x-swift', '.kt': 'text/x-kotlin',
  '.r': 'text/x-r-source', '.m': 'text/x-matlab',
  '.pl': 'text/x-perl',
  '.sh': 'application/x-sh', '.csh': 'application/x-csh', '.ksh': 'application/x-sh',
  '.bat': 'application/x-bat', '.cmd': 'application/x-bat',
  '.ps1': 'application/x-powershell', '.psm1': 'application/x-powershell',
  '.psd1': 'application/x-powershell', '.ps1xml': 'application/xml',
  '.ps2': 'application/x-powershell', '.ps2xml': 'application/xml',
  '.psc1': 'application/x-powershell', '.psc2': 'application/x-powershell',
  '.pssc': 'application/x-powershell',
  '.sql': 'application/sql',
  '.vbs': 'application/x-vbscript', '.vbe': 'application/x-vbscript',
  '.vb': 'application/x-vbscript',
  '.vbp': 'application/x-vbscript', '.vbg': 'application/x-vbscript',
  '.bas': 'text/plain',
  '.jse': 'application/x-javascript',
  '.wsf': 'application/x-ms-wsf', '.wsc': 'text/scriptlet',
  '.wsh': 'text/scriptlet', '.ws': 'text/scriptlet', '.sct': 'text/scriptlet',
  '.htc': 'text/x-component', '.asp': 'text/asp', '.aspx': 'application/xml',

  // ─ 配置文件 ─
  '.ini': 'text/plain', '.cfg': 'text/plain', '.conf': 'text/plain',
  '.yaml': 'text/yaml', '.yml': 'text/yaml', '.toml': 'application/toml',
  '.properties': 'text/plain', '.env': 'text/plain', '.lock': 'text/plain',
  '.plist': 'application/x-plist', '.mobileconfig': 'application/x-apple-aspen-config',
  '.theme': 'text/plain', '.udl': 'text/plain',

  // ─ 数据 / 数据库 ─
  '.db': 'application/x-sqlite3', '.sqlite': 'application/x-sqlite3', '.sqlite3': 'application/x-sqlite3',
  '.accdb': 'application/x-msaccess', '.mdb': 'application/x-msaccess',
  '.dbf': 'application/x-dbf',
  '.parquet': 'application/vnd.apache.parquet',
  '.feather': 'application/x-feather', '.arrow': 'application/vnd.apache.arrow.file',
  '.bak': 'application/octet-stream',
  '.ipynb': 'application/x-ipynb+json', '.rmd': 'text/x-rmarkdown',

  // ─ AI 模型 ─
  '.onnx': 'application/onnx', '.pb': 'application/x-protobuf',
  '.h5': 'application/x-hdf5', '.pkl': 'application/x-pickle',
  '.pt': 'application/octet-stream',
  '.safetensors': 'application/octet-stream',
  '.gguf': 'application/octet-stream',

  // ─ 字幕 ─
  '.srt': 'application/x-subrip', '.ass': 'text/x-ssa',
  '.vtt': 'text/vtt', '.ssa': 'text/x-ssa', '.sub': 'text/plain',

  // ─ 财务 / 会计 ─
  '.qif': 'application/x-quicken', '.qfx': 'application/vnd.intu.qfx',
  '.ofx': 'application/x-ofx', '.iif': 'application/x-quickbooks',

  // ─ 邮件 / 通讯录 / 日历 ─
  '.eml': 'message/rfc822', '.msg': 'application/vnd.ms-outlook',
  '.mbox': 'application/mbox', '.vcf': 'text/vcard', '.ics': 'text/calendar',
  '.pst': 'application/vnd.ms-outlook',
  '.mht': 'multipart/related', '.mhtml': 'multipart/related',

  // ─ 证书 / 签名 ─
  '.pem': 'application/x-x509-ca-cert', '.crt': 'application/x-x509-ca-cert',
  '.cer': 'application/x-x509-ca-cert', '.der': 'application/x-x509-ca-cert',
  '.p12': 'application/x-pkcs12', '.pfx': 'application/x-pkcs12',
  '.sig': 'application/pgp-signature', '.asc': 'application/pgp-signature',
  '.gpg': 'application/pgp-encrypted',
  '.sha256': 'text/plain', '.md5': 'text/plain', '.sfv': 'text/plain',

  // ─ 可执行 / 安装包 / Windows 系统 ─
  '.exe': 'application/x-msdownload', '.msi': 'application/x-msi',
  '.dmg': 'application/x-apple-diskimage',
  '.apk': 'application/vnd.android.package-archive',
  '.aab': 'application/x-authorware-bin',
  '.xapk': 'application/octet-stream',
  '.deb': 'application/x-deb', '.rpm': 'application/x-rpm',
  '.appx': 'application/vnd.ms-appx', '.appxbundle': 'application/vnd.ms-appx',
  '.msix': 'application/vnd.ms-appx', '.msixbundle': 'application/vnd.ms-appx',
  '.msu': 'application/octet-stream',
  '.msp': 'application/octet-stream',
  '.mst': 'application/octet-stream',
  '.ade': 'application/octet-stream', '.adp': 'application/octet-stream',
  '.com': 'application/x-msdownload', '.scr': 'application/x-msdownload',
  '.pif': 'application/x-msdownload', '.lnk': 'application/x-ms-shortcut',
  '.dll': 'application/x-msdownload',
  '.sys': 'application/octet-stream',
  '.cpl': 'application/x-msdownload', '.ocx': 'application/x-msdownload',
  '.gadget': 'application/x-windows-gadget',
  '.jar': 'application/java-archive', '.jnlp': 'application/x-java-jnlp-file',
  '.reg': 'application/x-msdos-registry',
  '.url': 'application/internet-shortcut', '.website': 'application/internet-shortcut',
  '.chm': 'application/vnd.ms-htmlhelp',
  '.hlp': 'application/x-winhelp',
  '.hpj': 'text/plain',
  '.hta': 'application/hta',
  '.inf': 'application/inf',
  '.ins': 'application/x-internet-signup', '.isp': 'application/x-internet-signup',
  '.its': 'application/octet-stream',
  '.application': 'application/x-ms-application',
  '.appref-ms': 'application/xml',
  '.xbap': 'application/x-ms-xbap', '.xll': 'application/x-msexcel',
  '.ex': 'application/octet-stream', '.ex_': 'application/octet-stream',
  '.app': 'application/octet-stream', '.lib': 'application/octet-stream',
  '.fxp': 'application/octet-stream', '.vxd': 'application/octet-stream',
  '.scf': 'application/octet-stream', '.shb': 'application/octet-stream',
  '.shs': 'application/octet-stream', '.prg': 'application/octet-stream',
  '.plg': 'application/octet-stream', '.pcd': 'application/octet-stream',
  '.cnt': 'application/octet-stream',
  '.cdxml': 'application/xml',
  '.msc': 'application/x-msc', '.msh': 'application/x-msh',
  '.msh1': 'application/x-msh', '.msh2': 'application/x-msh',
  '.msh1xml': 'application/xml', '.msh2xml': 'application/xml', '.mshxml': 'application/xml',
  '.prf': 'application/pics-rules',
  '.ops': 'application/octet-stream', '.osd': 'application/octet-stream',
  '.nsh': 'text/plain',
  '.grp': 'application/octet-stream', '.bgi': 'application/octet-stream',
  '.vsmacros': 'application/octet-stream', '.vsw': 'application/octet-stream',
  '.printerexport': 'application/octet-stream',
  '.diagcab': 'application/vnd.ms-cab-compressed',
  '.diagcfg': 'application/xml',
  '.diagpkg': 'application/octet-stream',
  '.library-ms': 'application/xml',
  '.search-ms': 'application/xml',
  '.settingcontent-ms': 'application/xml',
  '.appcontent-ms': 'application/xml',
  '.webpnp': 'application/xml',
  '.wsb': 'application/xml',
  '.xnk': 'application/octet-stream',

  // ─ Office Access 变种 ─
  '.mad': 'application/x-msaccess', '.maf': 'application/x-msaccess',
  '.mag': 'application/x-msaccess', '.mam': 'application/x-msaccess',
  '.maq': 'application/x-msaccess', '.mar': 'application/x-msaccess',
  '.mas': 'application/x-msaccess', '.mat': 'application/x-msaccess',
  '.mau': 'application/x-msaccess', '.mav': 'application/x-msaccess',
  '.maw': 'application/x-msaccess',
  '.mcf': 'application/octet-stream',
  '.mda': 'application/x-msaccess',
  '.mde': 'application/x-msaccess', '.mdt': 'application/x-msaccess',
  '.mdw': 'application/x-msaccess', '.mdz': 'application/x-msaccess',
  '.tmp': 'application/octet-stream',

  // ─ 镜像 / 虚拟磁盘 ─
  '.iso': 'application/x-iso9660-image',
  '.img': 'application/octet-stream',
  '.vhd': 'application/octet-stream', '.vhdx': 'application/octet-stream',
  '.vdi': 'application/octet-stream', '.vmdk': 'application/octet-stream',
  '.qcow2': 'application/octet-stream', '.wim': 'application/octet-stream',

  // ─ 二进制兜底 / 其他 ─
  '.bin': 'application/octet-stream', '.dat': 'application/octet-stream',
  '.dump': 'application/octet-stream',
  '.log': 'text/plain',
};

function getMimeType(fileName) {
  const s = String(fileName || '').toLowerCase();
  const idx = s.lastIndexOf('.');
  if (idx < 0) return 'application/octet-stream';
  const ext = s.slice(idx);
  return MIME_TYPES[ext] || 'application/octet-stream';
}

// ═════════════════════════════════════════════════════════════
// Builder
// ═════════════════════════════════════════════════════════════
class Builder {
  /**
   * @param {Object} cfg     完整 config 对象
   * @param {Object} tmplEng TemplateEngine 实例（Sprint 2 简版）
   * @param {number} workerId
   */
  constructor(cfg, tmplEng, workerId) {
    this.cfg = cfg;
    this.tmplEng = tmplEng;
    this.workerId = workerId | 0;

    // 【Sprint 3E】接入 3B/3C 反指纹系统
    this.varProc = new varsMod.VariableProcessor(cfg, workerId);
    this.headerGen = new headersMod.HeaderGenerator(cfg.headers, workerId);

    // 附件内容缓存（每个文件只从硬盘读取一次）
    this.attachmentCache = new Map();

    // 多模板 TemplateEngine 缓存（每个 templatePath 只 fs.readFileSync 一次）
    // 【P0-C 修复】避免 template_paths 场景下每封邮件都重新读文件
    this._templateCache = new Map();
    if (cfg.email && cfg.email.template_path) {
      this._templateCache.set(cfg.email.template_path, tmplEng);
    }

    // Custom From 邮箱轮换索引
    this.customFromIndex = 0;
  }

  /**
   * 获取指定路径的 TemplateEngine（Worker 级缓存,每路径只读一次）
   * 【P0-C 修复】builder 内多模板切换时避免重复 fs.readFileSync + new TemplateEngine
   * @param {string} templatePath
   * @returns {Object} TemplateEngine
   */
  _getTemplateEngine(templatePath) {
    let eng = this._templateCache.get(templatePath);
    if (eng) return eng;
    eng = templateMod.create(templatePath);
    eng.setGlobalVariables(this.tmplEng.globalVariables);
    this._templateCache.set(templatePath, eng);
    return eng;
  }

  // 【v66】统一 charset 获取（Build 和 buildRawEmail 共用）
  _getCharset() {
    let charset = this.cfg.encoding.charset;
    if (!charset) charset = this.cfg.email.charset;
    if (charsetMod.isUTF8Charset(charset) && !charsetMod.isUTF8Charset(this.cfg.email.charset)) {
      charset = this.cfg.email.charset;
    }
    if (!charset) charset = 'UTF-8';
    return charset;
  }

  /**
   * build - 完整构建单封邮件
   * @param {Object} data TemplateData（含 Email/Name/FirstName/LastName/Data/System/...）
   * @param {Object} [opts] { ccHeaderList: string[] }
   * @returns {Promise<Object>} email 对象 { envelopeFrom, envelopeTo, raw, from, to, subject, messageId, ccHeader }
   */
  async build(data, opts) {
    opts = opts || {};
    const cfg = this.cfg;

    // ── 1. Message-ID / 系统时间字段 ──
    const now = new Date();
    const fromAddressBase = cfg.sender.from_address || 'noreply@example.com';
    const messageID = utils.generateMessageID(fromAddressBase);
    data.System.MessageID = messageID;

    const pad2 = (n) => String(n).padStart(2, '0');
    data.System.Date = `${now.getFullYear()}-${pad2(now.getMonth()+1)}-${pad2(now.getDate())}`;
    data.System.DateTime = `${data.System.Date} ${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())}`;
    data.System.Timestamp = Math.floor(now.getTime() / 1000);
    data.System.Year = now.getFullYear();
    if (!data.System.UUID) data.System.UUID = utils.generateUUID();

    // ── 2. Computed.EmailHash / UnsubscribeURL ──
    data.Computed.EmailHash = utils.md5Hash(data.Email || '');
    const unsubBase = data.Global && data.Global.UnsubscribeBase;
    if (unsubBase) {
      data.Computed.UnsubscribeURL =
        `${unsubBase}?email=${utils.urlEncode(data.Email || '')}&hash=${data.Computed.EmailHash}`;
    }

    // 创建 recipient 对象供 varProc 使用
    const recipient = {
      email: data.Email,
      name: data.Name || '',
      firstName: data.FirstName || '',
      lastName: data.LastName || '',
      customFields: data.Data || {},
      lineNumber: data.System.Index || 0,
    };

    const charset = this._getCharset();
    const headerEncoding = cfg.encoding.header_encoding || 'base64';
    const supportsBidi = bidiMod.bidiCharsetSupported(charset);

    // ── 3. Subject（多主题 → varProc → tmplEng → 零宽 → RLO） ──
    let subject = this.varProc.getNextSubject();
    subject = this.varProc.process(subject, recipient);
    try {
      subject = this.tmplEng.renderString(subject, data);
    } catch (_) { /* 保留原 subject */ }
    if (cfg.zero_width && cfg.zero_width.enabled && cfg.zero_width.subject) {
      subject = zwMod.insertZeroWidth(subject, false, this.varProc.random);
    }
    if (cfg.email.subject_bidi_reverse && supportsBidi) {
      subject = bidiMod.bidiReverseHide(subject);
    }

    // ── 4. Display Name（多显示名 → varProc → \r\n → 零宽 → RLO） ──
    let displayName = this.varProc.getNextDisplayName();
    displayName = this.varProc.process(displayName, recipient);
    if (cfg.headers.display_name_newline) {
      displayName = displayName.replace(/\\r\\n/g, '\r\n');
    }
    if (cfg.zero_width && cfg.zero_width.enabled && cfg.zero_width.display_name) {
      displayName = zwMod.insertZeroWidth(displayName, false, this.varProc.random);
    }
    if (cfg.sender.display_name_bidi_reverse && supportsBidi) {
      displayName = bidiMod.bidiReverseHide(displayName);
    }

    // ── 5. 模板路径（多模板）+ 渲染 + 变量处理 + 零宽 ──
    const templatePath = this.varProc.getNextTemplate();
    let htmlBody;
    try {
      if (templatePath && templatePath !== cfg.email.template_path) {
        // 多模板：走 per-Builder 缓存,避免每封邮件重复 fs.readFileSync
        htmlBody = this._getTemplateEngine(templatePath).render(data);
      } else {
        htmlBody = this.tmplEng.render(data);
      }
    } catch (e) {
      throw new Error(`渲染模板失败: ${e.message}`);
    }
    htmlBody = this.varProc.process(htmlBody, recipient);
    if (cfg.zero_width && cfg.zero_width.enabled && cfg.zero_width.template_content) {
      htmlBody = zwMod.insertZeroWidth(htmlBody, isHTMLContent(htmlBody), this.varProc.random);
    }
    // TXT→HTML 转换（若 body 不是 HTML 且开关启用）
    if (cfg.email.convert_txt_to_html && !isHTMLContent(htmlBody)) {
      htmlBody = varsMod.textToHTML(htmlBody, charset);
    } else if (!isHTMLContent(htmlBody)) {
      htmlBody = varsMod.normalizeLineEndings(htmlBody);
    }

    // ── 6. Custom From 邮箱（Haraka26） ──
    let fromEmail = fromAddressBase;
    if (cfg.headers.custom_from_enabled &&
        Array.isArray(cfg.headers.custom_from_emails) &&
        cfg.headers.custom_from_emails.length > 0) {
      const emails = cfg.headers.custom_from_emails;
      if (String(cfg.headers.custom_from_mode || '').toLowerCase() === 'random') {
        fromEmail = emails[randSafe.safeIntn(this.varProc.random, emails.length)];
      } else {
        fromEmail = emails[this.customFromIndex % emails.length];
        this.customFromIndex++;
      }
    }

    const fromDisplay = encodeEmailAddressWithCharset(displayName, fromEmail, charset, headerEncoding);
    const toDisplay = encodeEmailAddressWithCharset(data.Name || '', data.Email, charset, headerEncoding);

    // ── 7. Email 对象 ──
    const email = {
      envelopeFrom: cfg.sender.envelope_from || fromAddressBase,
      envelopeTo: data.Email,
      virtualMta: (cfg.pmta && cfg.pmta.virtual_mta) || '',
      jobId: (cfg.job && cfg.job.id) || '',
      from: fromDisplay,
      to: toDisplay,
      subject,
      date: now,
      messageId: messageID,
      htmlBody,
      attachments: this._getAttachments(),
      embeddedImages: this._getEmbeddedImages(),
      ccHeader: '',
    };

    // ── 7.5. 【Sprint 4】图片噪点预应用（async）──
    // 关键：sharp 是异步的，无法在同步的 writeAttachments 闭包里 await。
    // 因此在 build() 里预先 await 处理完，writeAttachments 消费已噪化的 buffer。
    if (cfg.image_noise && cfg.image_noise.enabled) {
      for (const att of email.attachments) {
        try { att.content = await noiseMod.addImageNoise(att.content, att.fileName); }
        catch (_) { /* 单张失败不阻断整封邮件 */ }
      }
      for (const img of email.embeddedImages) {
        try { img.content = await noiseMod.addImageNoise(img.content, img.fileName); }
        catch (_) { /* ignore */ }
      }
    }

    // ── 8. CC 头填充（含 CR/LF 防御 + RFC 5322 §2.2.3 折叠） ──
    if (Array.isArray(opts.ccHeaderList) && opts.ccHeaderList.length > 0) {
      const ccParts = [];
      for (const rawCc of opts.ccHeaderList) {
        let trimmed = String(rawCc || '').trim();
        if (!trimmed) continue;
        if (trimmed.indexOf('\r') !== -1 || trimmed.indexOf('\n') !== -1) {
          trimmed = trimmed.replace(/\r/g, ' ').replace(/\n/g, ' ').trim();
          if (!trimmed) continue;
        }
        if (needsEncoding(trimmed)) {
          ccParts.push(encodeRFC2047WithCharset(trimmed, charset, headerEncoding));
        } else {
          ccParts.push(trimmed);
        }
      }
      if (ccParts.length > 0) {
        const rawCc = ccParts.join(', ');
        email.ccHeader = foldMod.foldHeaderValue(rawCc, 'Cc: '.length);
      }
    }

    // ── 9. 生成 raw ──
    email.raw = this._buildRawEmail(email, data, recipient, charset, headerEncoding);
    return email;
  }

  // ═════════════════════════════════════════════════════════════
  // _buildRawEmail - MIME 组装（含 mainHeaders 后处理管道）
  // ═════════════════════════════════════════════════════════════
  _buildRawEmail(email, data, recipient, charset, headerEncoding) {
    const cfg = this.cfg;
    const headersCfg = cfg.headers || {};

    // 随机传输编码（v66-fix#12：只在 base64/QP 间随机，不改字符集）
    let bodyEncoding = cfg.encoding.body_encoding || 'base64';
    if (cfg.encoding.random_encoding) {
      const encodings = ['base64', 'quoted-printable'];
      bodyEncoding = encodings[randSafe.safeIntn(this.varProc.random, encodings.length)];
    }

    // mainHeaders 累积（供 PostprocessMainHeaders 后处理）
    const mainHeaders = [];

    // ── PMTA 控制头（仅 PMTA 模式） ──
    if (!cfg.mta_type || cfg.mta_type === 'pmta') {
      if (email.virtualMta) mainHeaders.push(`x-virtual-mta: ${email.virtualMta}\r\n`);
      if (email.jobId)      mainHeaders.push(`x-job: ${email.jobId}\r\n`);
    }

    // ── 提取发件方域 ──
    let fromDomain = email.envelopeFrom || '';
    const at = fromDomain.indexOf('@');
    if (at !== -1) fromDomain = fromDomain.slice(at + 1);

    // ── Received 系列（5 ESP + 随机 + 原）──
    if (headersCfg.enabled) {
      const rcvdBlock = this.headerGen.generateAllReceived(
        email.envelopeFrom, email.envelopeTo, fromDomain, this.varProc, recipient);
      if (rcvdBlock) {
        // 切成单条（含续行）
        for (const one of postproc.splitHeaderBlock(rcvdBlock)) {
          mainHeaders.push(one);
        }
      }
    }

    // ── DKIM-Signature 伪签名 ──
    if (headersCfg.enabled && headersCfg.dkim_signature) {
      mainHeaders.push(this.headerGen.generateDkimSignature(email.envelopeFrom, fromDomain));
    }

    // ── 标准 RFC 5322 头 ──
    mainHeaders.push(`From: ${email.from}\r\n`);
    mainHeaders.push(`To: ${email.to}\r\n`);
    if (email.ccHeader) mainHeaders.push(`Cc: ${email.ccHeader}\r\n`);
    mainHeaders.push(`Subject: ${encodeRFC2047WithCharset(email.subject, charset, headerEncoding)}\r\n`);
    mainHeaders.push(`Date: ${_formatRFC5322Date(email.date)}\r\n`);

    // ── Message-ID（支持 25 自定义风格 + P0-2 主域策略） ──
    if (headersCfg.enabled && headersCfg.message_id) {
      let msgIdDomainInput = email.envelopeFrom;
      if (headersCfg.message_id_use_org_domain && cfg.sender.org_domain) {
        msgIdDomainInput = cfg.sender.org_domain;
      }
      const customMsgID = this.headerGen.generateCustomMessageID(msgIdDomainInput);
      mainHeaders.push(`Message-ID: <${customMsgID}>\r\n`);
    } else {
      mainHeaders.push(`Message-ID: <${email.messageId}>\r\n`);
    }

    mainHeaders.push('MIME-Version: 1.0\r\n');

    // ── Reply-To（走 headerGen 或 cfg.sender.reply_to） ──
    if (headersCfg.enabled && headersCfg.reply_to) {
      // 由下面 generateHeaders 处理
    } else if (cfg.sender.reply_to) {
      mainHeaders.push(`Reply-To: ${cfg.sender.reply_to}\r\n`);
    }

    // ── 扩展头（Reply-To/Return-Path/X-Mailer/X-Priority + P0 + P1/P2/P3 抽样） ──
    if (headersCfg.enabled) {
      const customBlock = this.headerGen.generateHeaders(
        email.envelopeFrom, email.envelopeTo, fromDomain, this.varProc, recipient);
      if (customBlock) {
        for (const one of postproc.splitHeaderBlock(customBlock)) {
          mainHeaders.push(one);
        }
      }
    }

    // ── cfg.email.custom_headers（map 格式） ──
    if (cfg.email.custom_headers && typeof cfg.email.custom_headers === 'object') {
      for (const key of Object.keys(cfg.email.custom_headers)) {
        let val = cfg.email.custom_headers[key];
        val = this.varProc.process(String(val), recipient);
        try { val = this.tmplEng.renderString(val, data); } catch (_) { /* ignore */ }
        mainHeaders.push(`${key}: ${encodeRFC2047WithCharset(val, charset, headerEncoding)}\r\n`);
      }
    }

    // ── 多行自定义头（headers.custom_headers_text） ──
    if (headersCfg.enabled && headersCfg.custom_headers_text) {
      // 【R1 P0-B 修复】SMTP header 注入防护:先归一化 CRLF → LF 再 split,
      //   然后逐行内清 CR/LF/NUL 为空格。
      //   攻击场景:custom_headers_text = "X-A: val\rX-Injected: bad@evil.com"
      //   原 split('\n') 只把 \n 视为行分隔,单 \r 保留在 line 内 → SMTP DATA 阶段
      //   收到 header 中的 \r → 视为新 header 边界 → 隐藏 Bcc/Cc 注入成功。
      //   现在:①raw \r\n?/g → \n 归一;②每行再 [\r\n\x00] → 空格,双层防御。
      const normalized = String(headersCfg.custom_headers_text).replace(/\r\n?/g, '\n');
      const lines = normalized.split('\n');
      for (let line of lines) {
        // 再兜底清行内残留控制字符(NUL 也拒,防 SMTP command 截断)
        line = line.replace(/[\r\n\x00]/g, ' ').trim();
        if (!line || line.startsWith('#')) continue;
        const colonIdx = line.indexOf(':');
        if (colonIdx <= 0) continue;
        const headerName = line.slice(0, colonIdx).trim();
        let headerValue = line.slice(colonIdx + 1).trim();
        if (!headerName) continue;
        // 头名也过一层白名单(RFC 5322 header name = printable ASCII 除冒号)
        // 攻击者若构造 headerName 含空格/特殊字符 → 用同样清洗兜底
        const safeHeaderName = headerName.replace(/[^!-9;-~]/g, '');
        if (!safeHeaderName) continue;
        headerValue = this.varProc.process(headerValue, recipient);
        try { headerValue = this.tmplEng.renderString(headerValue, data); } catch (_) { /* ignore */ }
        // headerValue 最后再清一次(变量替换后可能引入 \r\n)
        headerValue = String(headerValue).replace(/[\r\n\x00]/g, ' ');
        mainHeaders.push(`${safeHeaderName}: ${encodeRFC2047WithCharset(headerValue, charset, headerEncoding)}\r\n`);
      }
    }

    // ── PostprocessMainHeaders（大小写随机 + 锚定式乱序 + 方案 D DKIM 顺序） ──
    // 【方案 β】触发条件用 DkimHFieldsMasterEnabled 而非 CustomEnabled
    let dkimList = null;
    if (headersCfg.dkim_h_fields_master_enabled &&
        Array.isArray(headersCfg.dkim_h_fields_list) &&
        headersCfg.dkim_h_fields_list.length > 0) {
      dkimList = headersCfg.dkim_h_fields_list;
    }
    const processed = postproc.PostprocessMainHeaders(
      mainHeaders, this.varProc.random,
      !!headersCfg.shuffle_order, !!headersCfg.random_case, headersCfg.case_mode || '',
      dkimList
    );

    // ── 序列化主头 + MIME body ──
    const chunks = []; // 累积字符串片段
    for (const h of processed) chunks.push(h);

    // ── MIME body 构造 ──
    const mimeMode = String(cfg.email.mime_mode || 'standard').toLowerCase();
    const useAlternative = mimeMode === 'alternative' || mimeMode === 'full';
    const plainText = useAlternative ? htmlToPlainText(email.htmlBody) : '';
    const hasAttachments = email.attachments && email.attachments.length > 0;
    const hasEmbedded = email.embeddedImages && email.embeddedImages.length > 0;

    const self = this;

    // ── writeAttachments ──
    // 【Sprint 4】image_noise 已在 build() 阶段 async 应用；此处消费已噪化的 buffer
    const writeAttachments = (out, boundary) => {
      for (const att of email.attachments) {
        out.push(`--${boundary}\r\n`);
        out.push(`Content-Type: ${att.contentType}; name="${encodeRFC2047WithCharset(att.fileName, charset, headerEncoding)}"\r\n`);
        out.push('Content-Transfer-Encoding: base64\r\n');
        out.push(`Content-Disposition: attachment; filename="${encodeRFC2047WithCharset(att.fileName, charset, headerEncoding)}"\r\n\r\n`);
        const content = att.content;
        const b64 = Buffer.isBuffer(content) ? content.toString('base64') : Buffer.from(String(content), 'utf8').toString('base64');
        for (let i = 0; i < b64.length; i += 76) {
          out.push(b64.slice(i, Math.min(i + 76, b64.length)));
          out.push('\r\n');
        }
      }
    };

    // ── writeAlternative ──
    const writeAlternative = (out) => {
      const altBoundary = generateBoundary('Alt');
      out.push(`Content-Type: multipart/alternative; boundary="${altBoundary}"\r\n\r\n`);
      out.push(`--${altBoundary}\r\n`);
      out.push(`Content-Type: text/plain; charset="${charset}"\r\n`);
      out.push(`Content-Transfer-Encoding: ${bodyEncoding}\r\n\r\n`);
      out.push(self._encodeBodyString(plainText, bodyEncoding, charset));
      out.push('\r\n');
      out.push(`--${altBoundary}\r\n`);
      out.push(`Content-Type: text/html; charset="${charset}"\r\n`);
      out.push(`Content-Transfer-Encoding: ${bodyEncoding}\r\n\r\n`);
      out.push(self._encodeBodyString(email.htmlBody, bodyEncoding, charset));
      out.push('\r\n');
      out.push(`--${altBoundary}--\r\n`);
      return altBoundary;
    };

    // ── writeSingleBody ──
    const writeSingleBody = (out) => {
      const contentType = isHTMLContent(email.htmlBody) ? 'text/html' : 'text/plain';
      out.push(`Content-Type: ${contentType}; charset="${charset}"\r\n`);
      out.push(`Content-Transfer-Encoding: ${bodyEncoding}\r\n\r\n`);
      out.push(self._encodeBodyString(email.htmlBody, bodyEncoding, charset));
      out.push('\r\n');
    };

    // ── writeEmbeddedImages ──
    // 【Sprint 4】image_noise 已在 build() 阶段 async 应用
    const writeEmbeddedImages = (out, boundary) => {
      for (const img of email.embeddedImages) {
        out.push(`--${boundary}\r\n`);
        out.push(`Content-Type: ${img.contentType}; name="${img.fileName}"\r\n`);
        out.push(`Content-ID: <${img.cid}>\r\n`);
        out.push('Content-Transfer-Encoding: base64\r\n');
        out.push(`Content-Disposition: inline; filename="${img.fileName}"\r\n\r\n`);
        const content = img.content;
        const b64 = Buffer.isBuffer(content) ? content.toString('base64') : Buffer.from(String(content), 'utf8').toString('base64');
        for (let i = 0; i < b64.length; i += 76) {
          out.push(b64.slice(i, Math.min(i + 76, b64.length)));
          out.push('\r\n');
        }
      }
    };

    // ── writeContentBlock（自动判断是否需要 multipart/related 包裹） ──
    const writeContentBlock = (out) => {
      if (hasEmbedded) {
        const relBoundary = generateBoundary('Rel');
        out.push(`Content-Type: multipart/related; boundary="${relBoundary}"\r\n\r\n`);
        out.push(`--${relBoundary}\r\n`);
        if (useAlternative) writeAlternative(out);
        else writeSingleBody(out);
        writeEmbeddedImages(out, relBoundary);
        out.push(`--${relBoundary}--\r\n`);
      } else {
        if (useAlternative) writeAlternative(out);
        else writeSingleBody(out);
      }
    };

    // ── 主分支：full/附件 → multipart/mixed；内嵌图片 → related；否则单体 ──
    if (mimeMode === 'full' || hasAttachments) {
      const mixedBoundary = generateBoundary('Mixed');
      chunks.push(`Content-Type: multipart/mixed; boundary="${mixedBoundary}"\r\n\r\n`);
      chunks.push(`--${mixedBoundary}\r\n`);
      writeContentBlock(chunks);
      if (hasAttachments) writeAttachments(chunks, mixedBoundary);
      chunks.push(`--${mixedBoundary}--\r\n`);
    } else if (hasEmbedded) {
      writeContentBlock(chunks);
    } else {
      if (useAlternative) {
        writeAlternative(chunks);
      } else {
        const contentType = isHTMLContent(email.htmlBody)
          ? 'text/html'
          : (cfg.email.content_type || 'text/plain');
        chunks.push(`Content-Type: ${contentType}; charset="${charset}"\r\n`);
        chunks.push(`Content-Transfer-Encoding: ${bodyEncoding}\r\n\r\n`);
        chunks.push(this._encodeBodyString(email.htmlBody, bodyEncoding, charset));
      }
    }

    // 拼装最终 Buffer
    return Buffer.from(chunks.join(''), 'binary'); // 用 binary 避免二次 UTF-8 编码破坏已 encode 的 base64
    // 注：mainHeaders 里所有值都是 ASCII 或已 encoded-word 编码；MIME body 由 _encodeBodyString 处理编码
  }

  // ═════════════════════════════════════════════════════════════
  // _encodeBodyString - body 编码（对齐 Go writeEncodedBody，返回字符串片段）
  // 【v66】先做字符集转换 UTF-8 → 目标编码，再做传输编码（base64/QP）
  // ═════════════════════════════════════════════════════════════
  _encodeBodyString(body, encoding, charset) {
    const bodyBuf = charsetMod.convertFromUTF8(String(body || ''), charset);
    const enc = String(encoding || 'base64').toLowerCase();

    switch (enc) {
      case 'base64': {
        const encoded = bodyBuf.toString('base64');
        const lines = [];
        for (let i = 0; i < encoded.length; i += 76) {
          lines.push(encoded.slice(i, Math.min(i + 76, encoded.length)));
        }
        return lines.join('\r\n');
      }
      case 'quoted-printable': {
        return _qpEncode(bodyBuf);
      }
      case '7bit':
      case '8bit': {
        let str = bodyBuf.toString('binary');
        str = str.replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/\n/g, '\r\n');
        if (!str.endsWith('\r\n')) str += '\r\n';
        return str;
      }
      default: {
        // 未知 → 兜底 base64
        const encoded = bodyBuf.toString('base64');
        const lines = [];
        for (let i = 0; i < encoded.length; i += 76) {
          lines.push(encoded.slice(i, Math.min(i + 76, encoded.length)));
        }
        return lines.join('\r\n');
      }
    }
  }

  // ═════════════════════════════════════════════════════════════
  // getAttachments（上传附件 + 自定义随机附件叠加）
  // ═════════════════════════════════════════════════════════════
  _getAttachments() {
    const ac = this.cfg.attachments;
    if (!ac || !ac.enabled) return [];
    const out = [];

    // 上传附件
    if (Array.isArray(ac.files) && ac.files.length > 0) {
      let filePath;
      if (String(ac.mode || '').toLowerCase() === 'random') {
        filePath = ac.files[randSafe.safeIntn(this.varProc.random, ac.files.length)];
      } else {
        filePath = ac.files[this.varProc.getNextAttachmentIndex(ac.files.length)];
      }
      const att = this._getCachedAttachment(filePath);
      if (att) out.push(att);
    }

    // 自定义随机附件（Haraka26 移植）
    if (ac.custom && ac.custom.enabled) {
      out.push(this._generateCustomAttachment(ac.custom));
    }

    return out;
  }

  _getCachedAttachment(filePath) {
    if (this.attachmentCache.has(filePath)) return this.attachmentCache.get(filePath);
    let content;
    try { content = fs.readFileSync(filePath); }
    catch (_) { return null; }
    const fileName = path.basename(filePath);
    const contentType = getMimeType(fileName);
    const att = { fileName, filePath, contentType, content };
    this.attachmentCache.set(filePath, att);
    return att;
  }

  _generateCustomAttachment(c) {
    const filename = this._genAttachName(c) + '.' + this._genAttachSuffix(c);
    return {
      fileName: filename,
      filePath: '',
      contentType: 'text/plain; charset=us-ascii',
      content: this._genAttachContent(c),
    };
  }

  _genAttachName(c) {
    if (String(c.name_mode || '').toLowerCase() === 'fixed') {
      const s = _sanitizeAttachPart(c.fixed_name);
      if (s) return s;
    }
    const n = randSafe.randIntRange(this.varProc.random, c.name_min, c.name_max, 1, 64);
    return randSafe.randStringFrom(this.varProc.random, n, ATTACH_ALNUM);
  }

  _genAttachSuffix(c) {
    if (String(c.suffix_mode || '').toLowerCase() === 'fixed') {
      let s = _sanitizeAttachPart(c.fixed_suffix);
      s = s.replace(/^\.+|\.+$/g, ''); // 去首尾点
      if (s) return s;
    }
    const n = randSafe.randIntRange(this.varProc.random, c.suffix_min, c.suffix_max, 1, 16);
    return randSafe.randStringFrom(this.varProc.random, n, ATTACH_SUFFIX_ALPHA);
  }

  _genAttachContent(c) {
    const lines = randSafe.randIntRange(this.varProc.random, c.content_lines_min, c.content_lines_max, 1, 10000);
    const parts = [];
    for (let i = 0; i < lines; i++) {
      if (i > 0) parts.push('\r\n');
      const chars = randSafe.randIntRange(this.varProc.random, c.content_chars_min, c.content_chars_max, 1, 100000);
      parts.push(randSafe.randStringFrom(this.varProc.random, chars, ATTACH_ALNUM));
    }
    return Buffer.from(parts.join(''), 'utf8');
  }

  // ═════════════════════════════════════════════════════════════
  // getEmbeddedImages（CID 内嵌图片）
  // ═════════════════════════════════════════════════════════════
  _getEmbeddedImages() {
    const list = this.cfg.email.embedded_images;
    if (!Array.isArray(list) || list.length === 0) return [];
    const out = [];
    for (const imgCfg of list) {
      const att = this._getCachedAttachment(imgCfg.path);
      if (!att) continue;
      let cid = imgCfg.cid || '';
      if (!cid) {
        const name = path.basename(imgCfg.path);
        const idx = name.lastIndexOf('.');
        cid = idx > 0 ? name.slice(0, idx) : name;
      }
      let contentType = imgCfg.content_type || att.contentType;
      out.push({
        cid, contentType,
        fileName: path.basename(imgCfg.path),
        content: att.content,
      });
    }
    return out;
  }
}

// ═════════════════════════════════════════════════════════════
// 内部辅助
// ═════════════════════════════════════════════════════════════

function _formatRFC5322Date(d) {
  const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const pad = (n) => String(n).padStart(2, '0');
  const tzOff = -d.getTimezoneOffset();
  const sign = tzOff >= 0 ? '+' : '-';
  const abs = Math.abs(tzOff);
  const oh = pad(Math.floor(abs / 60));
  const om = pad(abs % 60);
  return `${DAYS[d.getDay()]}, ${pad(d.getDate())} ${MONTHS[d.getMonth()]} ${d.getFullYear()} ` +
         `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} ${sign}${oh}${om}`;
}

// Sanitize 附件名/后缀：剥控制字符 + 文件系统危险字符
function _sanitizeAttachPart(s) {
  if (!s) return '';
  let out = '';
  const dangerous = '/\\:*?"<>|';
  for (let i = 0; i < s.length; i++) {
    const cc = s.charCodeAt(i);
    if (cc < 0x20 || cc === 0x7F) continue; // 控制字符
    const ch = s.charAt(i);
    if (dangerous.indexOf(ch) !== -1) continue;
    out += ch;
  }
  return out.trim();
}

// Quoted-Printable body 编码（对齐 Go quotedprintable.NewWriter）
// 规则：可打印 ASCII (33-126, 除 =) 直接输出；
//       空格/tab 行尾编码；
//       其它字节 =XX；
//       软换行 = 每 76 字符（含 =）加 =\r\n
function _qpEncode(buf) {
  const bytes = buf;
  let out = '';
  let lineLen = 0;
  const MAX_LINE = 76;
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i];
    let repr;
    if (b === 0x0D) { // \r
      // 忽略单独 \r（\r\n 一起处理）
      if (i + 1 < bytes.length && bytes[i+1] === 0x0A) {
        out += '\r\n';
        lineLen = 0;
        i++;
        continue;
      }
      repr = `=${b.toString(16).toUpperCase().padStart(2,'0')}`;
    } else if (b === 0x0A) { // \n
      out += '\r\n';
      lineLen = 0;
      continue;
    } else if (b === 0x09 || b === 0x20) { // tab or space
      // 若在行尾（下一个是 \n 或到结尾），需转义
      const isEnd = (i + 1 >= bytes.length) || (bytes[i+1] === 0x0A) || (bytes[i+1] === 0x0D);
      if (isEnd) repr = `=${b.toString(16).toUpperCase().padStart(2,'0')}`;
      else repr = String.fromCharCode(b);
    } else if (b === 0x3D) { // '='
      repr = '=3D';
    } else if (b >= 0x21 && b <= 0x7E) {
      repr = String.fromCharCode(b);
    } else {
      repr = `=${b.toString(16).toUpperCase().padStart(2,'0')}`;
    }
    // 软换行
    if (lineLen + repr.length > MAX_LINE - 1) {
      out += '=\r\n';
      lineLen = 0;
    }
    out += repr;
    lineLen += repr.length;
  }
  return out;
}

// ═════════════════════════════════════════════════════════════
// 工厂 + exports
// ═════════════════════════════════════════════════════════════

function create(cfg, tmplEng, workerId) {
  return new Builder(cfg, tmplEng, workerId);
}

module.exports = {
  Builder,
  create,
  // 暴露内部工具（测试 + 其他模块可能复用）
  isHTMLContent,
  htmlToPlainText,
  needsEncoding,
  needsQuoting,
  encodeRFC2047B,
  encodeRFC2047Q,
  encodeRFC2047WithCharset,
  encodeEmailAddressWithCharset,
  getMimeType,
  generateBoundary,
  BOUNDARY_STYLES,
};
