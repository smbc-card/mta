#!/usr/bin/env python3
# scripts/fatcode_gen.py - 在 fatcode.js 末尾追加 N 行随机 dead code（JS 语法）
#
# 用法：
#   python3 scripts/fatcode_gen.py <seed> <line_count>
#
# 【与 Go 版对齐】部署脚本传入 seed+7919 作为 Python random 的种子；
# 生成的函数格式：
#   function _fn_xxxxxxxxxx() { let _v_yyyyyyyy = <int>; _v_yyyyyyyy = _v_yyyyyyyy <op> <int>; ...; return _v_yyyyyyyy; }
#
# JavaScript 不支持 Go 的 `^` 位异或和 `|`, `&` 用法完全相同（都是位运算符），
# 只有 `^` 在 JS 是 XOR 而不是 Go 里的按位异或 —— 语义等价。

import random
import sys
import string
import os

if len(sys.argv) < 3:
    sys.stderr.write("Usage: fatcode_gen.py <seed> <line_count>\n")
    sys.exit(1)

try:
    seed = int(sys.argv[1]) + 7919
    line_count = int(sys.argv[2])
except ValueError:
    sys.stderr.write("Error: seed and line_count must be integers\n")
    sys.exit(1)

if line_count <= 0:
    sys.stderr.write("Error: line_count must be > 0\n")
    sys.exit(1)

random.seed(seed)

target = 'fatcode.js'
if not os.path.isfile(target):
    sys.stderr.write(f"Error: {target} not found (must run from Node source root)\n")
    sys.exit(1)

lines = ['', '// auto-generated dead code (JS)', '']

# JS 位运算符（子集与 Go 一致：+ - * ^ | &）
OPS = ['+', '-', '*', '^', '|', '&']

for i in range(line_count):
    fn_suffix = ''.join(random.choices('abcdefghijklmnop', k=10))
    v_suffix = ''.join(random.choices('abcdefghij', k=8))
    fn_name = f'_fn_{fn_suffix}'
    v_name = f'_v_{v_suffix}'

    lines.append(f'function {fn_name}() {{')
    lines.append(f'  let {v_name} = {random.randint(1, 9999)};')
    step_count = random.randint(3, 12)
    for _ in range(step_count):
        op = random.choice(OPS)
        rhs = random.randint(1, 500)
        lines.append(f'  {v_name} = ({v_name} {op} {rhs}) | 0;')
    lines.append(f'  return {v_name};')
    lines.append('}')

# 追加到 fatcode.js 末尾
with open(target, 'a', encoding='utf-8') as f:
    f.write('\n'.join(lines))

sys.stdout.write(f"[fatcode_gen] appended {line_count} dead functions to {target}\n")
