#!/usr/bin/env python3
# verify_node_structure.py - 验证 .eml 目录里的邮件结构合规性
#
# Sprint 6 目标：检查 Node 端 debug-dump 输出（或 Go pickup 输出）的**结构级合规性**
# —— 不做字节 diff（Go/Node RNG 算法不同，本来就不可能一致），而是查：
#   - 头字段齐全性（Received / DKIM / From / To / Subject / Date / Message-ID / MIME-Version）
#   - Message-ID 匹配 25 种风格之一（regex）
#   - DKIM d= 域名落在 72 池
#   - MIME 结构可解析（Python email.parser）
#   - Received 至少一个（多 hop 加 5 ESP + 随机模板池，通常 ≥ 2）
#   - 5 ESP Received 续行空白正确（softbank 10 / docomo 1 / mitsui 3 / yahoo/au 2）
#
# 用法：
#   python3 verify_node_structure.py --input-dir <dir> [--dkim-pool <path>] [--json-output <path>]
#
# 输入：
#   --input-dir  含 .eml 文件的目录（debug_dump 或 pickup 生成）
#   --dkim-pool  可选，Node dkim_pool.js 路径（自动提取 72 域）默认相对本脚本推断
#   --json-output 可选，输出机器可读 JSON 报告
#
# 退出码：
#   0 = 全部合规
#   1 = 有不合规文件（详情打印到 stderr + 可选 JSON）
#   2 = 参数错误 / 输入目录为空

import argparse
import email
import email.parser
import email.policy
import glob
import json
import os
import re
import sys


# ═════════════════════════════════════════════════════════════
# Message-ID 25 风格识别（对齐 Node headers.js::messageIDStyleKeys）
# ═════════════════════════════════════════════════════════════
MSGID_STYLE_PATTERNS = {
    # uuid_v4_lower
    'uuid_v4_lower': re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}@'),
    # uuid_v4_upper
    'uuid_v4_upper': re.compile(r'^[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}@'),
    # uuid_v1 (小写)
    'uuid_v1':       re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-1[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}@'),
    # hex32
    'hex32':         re.compile(r'^[0-9a-f]{32}@'),
    # hex40
    'hex40':         re.compile(r'^[0-9a-f]{40}@'),
    # hex64
    'hex64':         re.compile(r'^[0-9a-f]{64}@'),
    # hex16
    'hex16':         re.compile(r'^[0-9a-f]{16}@'),
    # hex_underscore: 13hex_13hex
    'hex_underscore': re.compile(r'^[0-9a-f]{13}_[0-9a-f]{13}@'),
    # javamail: N.N.N (纯数字)
    'javamail':      re.compile(r'^\d{10}\.\d+\.\d{13}@'),
    # ts_uuid_counter: 20250923t153045-{uuid}-000001
    'ts_uuid_counter': re.compile(r'^\d{8}t\d{6}-[0-9a-f-]+-\d{6}@'),
    # readable_ts: 20250923153045123.abcd
    'readable_ts':   re.compile(r'^\d{17}\.[0-9a-f]{4}@'),
    # uuid_seq: uuid.N
    'uuid_seq':      re.compile(r'^[0-9a-f-]+\.\d+@'),
    # ms_ts_hex: 1727100000000.abc123
    'ms_ts_hex':     re.compile(r'^\d{13,}\.[0-9a-f]{12}@'),
    # biz_prefix: mkt_ + 32hex
    'biz_prefix':    re.compile(r'^(mkt|promo|news|notify|sys|mail|camp|info|noreply|alert)_[0-9a-f]{32}@'),
    # enterprise_multiseg: ms.ymd.label.N.6d.6d
    'enterprise_multiseg': re.compile(r'^\d+\.\d{8}\.\w+\.\d+\.\d{6}\.\d{6}@'),
    # epoch_counter: unixsec.8digits
    'epoch_counter': re.compile(r'^\d{10}\.\d{8}@'),
    # bigint_hex: bigint.8hex
    'bigint_hex':    re.compile(r'^\d{15,}\.[0-9a-f]{8}@'),
    # mixed_alnum: 32-40 mixed alnum
    'mixed_alnum':   re.compile(r'^[A-Za-z0-9]{32,40}@'),
    # compact_date_ns: 20250923NNNNNNNNNNNN + 6hex
    'compact_date_ns': re.compile(r'^\d{8}\d{12}[0-9a-f]{6}@'),
    # tag_uuid: notify-{uuid}
    'tag_uuid':      re.compile(r'^(notify|alert|txn|sys|msg|info|mail|auto|noreply)-[0-9a-f-]{36}@'),
    # ns_hex: 大整数.12hex
    'ns_hex':        re.compile(r'^\d{16,}\.[0-9a-f]{12}@'),
    # exim: E1XXXXXXX-XXXXXX-XX
    'exim':          re.compile(r'^E1[0-9A-F]{7}-[0-9A-F]{6}-[A-Z]{2}@'),
    # sendmail: YYYYMMDDHHMMSS.6hex
    'sendmail':      re.compile(r'^\d{14}\.[0-9a-f]{6}@'),
    # becky: 4 段 2 位大写 hex 分隔
    'becky':         re.compile(r'^[0-9A-F]{2}\.[0-9A-F]{2}\.[0-9A-F]{2}\.[0-9A-F]{2}@'),
    # base64url: 22 字符 base64url (16 字节)
    'base64url':     re.compile(r'^[A-Za-z0-9_-]{20,24}@'),
}


# ═════════════════════════════════════════════════════════════
# 6 boundary 风格识别
# ═════════════════════════════════════════════════════════════
BOUNDARY_STYLE_PATTERNS = {
    'outlook':     re.compile(r'^----=_NextPart_000_[0-9A-F]{4}_01D[0-9A-F]{5}\.[0-9A-F]{8}$'),
    'apple_mail':  re.compile(r'^Apple-Mail=_[0-9A-F-]+$'),
    'gmail':       re.compile(r'^0{14}[0-9a-f]{16}$'),
    'postfix':     re.compile(r'^[0-9a-f]{8}\.[0-9a-f]{8}$'),
    'thunderbird': re.compile(r'^-{12}[0-9a-f]{24}$'),
    'phpmailer':   re.compile(r'^b1_[0-9a-f]{32}$'),
}


def load_dkim_domains(dkim_pool_path):
    """从 Node dkim_pool.js 里 grep 出 72 域名"""
    if not os.path.isfile(dkim_pool_path):
        return set()
    with open(dkim_pool_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # regex 匹配 { domain: 'xxx.com', selectors: ...
    domains = re.findall(r"\{\s*domain:\s*'([^']+)'", content)
    return set(domains)


def classify_msgid(msgid_value):
    """给定 Message-ID 值（不含 <>），返回匹配的风格 key（或 'unknown'）"""
    if not msgid_value:
        return 'empty'
    # 剥去 <>
    v = msgid_value.strip()
    if v.startswith('<') and v.endswith('>'):
        v = v[1:-1]
    for style, pattern in MSGID_STYLE_PATTERNS.items():
        if pattern.match(v):
            return style
    return 'unknown'


def classify_boundary(boundary_value):
    """给定 boundary 值，返回匹配的客户端风格（或 'unknown'）"""
    if not boundary_value:
        return 'empty'
    for style, pattern in BOUNDARY_STYLE_PATTERNS.items():
        if pattern.match(boundary_value):
            return style
    return 'unknown'


def parse_dkim_header(value):
    """解析 DKIM-Signature 头，返回 {v, a, c, d, s, t, h, bh, b} 字典"""
    d = {}
    # DKIM-Signature 是 tag=value; tag=value; ... 结构，续行以空白开头
    normalized = ' '.join(line.strip() for line in value.split('\n') if line.strip())
    for part in normalized.split(';'):
        part = part.strip()
        if '=' not in part:
            continue
        k, _, v = part.partition('=')
        d[k.strip()] = v.strip()
    return d


def check_esp_received_indent(received_headers):
    """检查 5 ESP Received 的续行空白特征
    softbank: 10 空格 / au+yahoo: 2 空格 / docomo: 1 空格 / mitsui: 3 空格
    仅做统计，不判失败（因为不是每封都有 5 种 ESP）
    """
    stats = {'softbank_like': 0, 'docomo_like': 0, 'mitsui_like': 0, 'au_yahoo_like': 0}
    for r in received_headers:
        if not isinstance(r, str):
            continue
        lines = r.split('\n')
        if len(lines) < 2:
            continue
        # 检查续行缩进模式
        second = lines[1]
        if second.startswith(' ' * 10):
            stats['softbank_like'] += 1
        elif second.startswith('   ') and not second.startswith('    '):
            stats['mitsui_like'] += 1
        elif second.startswith('  ') and not second.startswith('   '):
            stats['au_yahoo_like'] += 1
        elif second.startswith(' ') and not second.startswith('  '):
            stats['docomo_like'] += 1
    return stats


def verify_one_eml(path, dkim_pool):
    """检查单个 .eml 文件，返回 {path, ok, issues, metrics}"""
    result = {
        'path': path,
        'ok': True,
        'issues': [],
        'metrics': {
            'received_count': 0,
            'has_dkim_signature': False,
            'has_from': False,
            'has_to': False,
            'has_subject': False,
            'has_date': False,
            'has_message_id': False,
            'has_mime_version': False,
            'msgid_style': 'unknown',
            'boundary_style': 'unknown',
            'dkim_d_in_pool': None,
            'dkim_d_value': None,
            'has_list_unsubscribe': False,
            'has_list_unsubscribe_post': False,
            'has_x_mailer': False,
            'mime_mode': 'unknown',
        },
    }

    try:
        with open(path, 'rb') as f:
            raw = f.read()
    except Exception as e:
        result['ok'] = False
        result['issues'].append(f'read failed: {e}')
        return result

    # 用 email 模块解析
    try:
        parser = email.parser.BytesParser(policy=email.policy.default)
        msg = parser.parsebytes(raw)
    except Exception as e:
        result['ok'] = False
        result['issues'].append(f'MIME parse failed: {e}')
        return result

    # 头字段齐全性
    required = ['From', 'To', 'Subject', 'Date', 'Message-ID', 'MIME-Version']
    for h in required:
        val = msg.get(h)
        if val is None:
            result['issues'].append(f'missing header: {h}')
            result['ok'] = False
        else:
            key = 'has_' + h.lower().replace('-', '_')
            result['metrics'][key] = True

    # Received（至少 1 个，多 hop 加 5 ESP 通常 ≥ 2）
    received_list = msg.get_all('Received') or []
    result['metrics']['received_count'] = len(received_list)
    if len(received_list) < 1:
        result['issues'].append('no Received header')
        result['ok'] = False

    # DKIM-Signature 存在性 + 落池
    dkim_value = msg.get('DKIM-Signature')
    if dkim_value:
        result['metrics']['has_dkim_signature'] = True
        parsed_dkim = parse_dkim_header(dkim_value)
        d_value = parsed_dkim.get('d', '').strip()
        result['metrics']['dkim_d_value'] = d_value
        if dkim_pool:
            in_pool = d_value in dkim_pool
            result['metrics']['dkim_d_in_pool'] = in_pool
            if not in_pool:
                result['issues'].append(f'DKIM d={d_value} not in 72-pool')
                # 不算致命，仅告警

        # 检查 c=/h= 存在
        if 'c' not in parsed_dkim:
            result['issues'].append('DKIM missing c= field')
        if 'h' not in parsed_dkim:
            result['issues'].append('DKIM missing h= field')

    # Message-ID 风格识别
    msgid = msg.get('Message-ID')
    if msgid:
        result['metrics']['msgid_style'] = classify_msgid(msgid)

    # Content-Type / boundary
    ct = msg.get_content_type() or ''
    ct_full = str(msg.get('Content-Type', ''))
    if 'multipart' in ct:
        # 取 boundary
        boundary = msg.get_boundary()
        if boundary:
            result['metrics']['boundary_style'] = classify_boundary(boundary)
        if 'multipart/mixed' in ct:
            result['metrics']['mime_mode'] = 'mixed'
        elif 'multipart/alternative' in ct:
            result['metrics']['mime_mode'] = 'alternative'
        elif 'multipart/related' in ct:
            result['metrics']['mime_mode'] = 'related'
        else:
            result['metrics']['mime_mode'] = 'multipart'
    else:
        result['metrics']['mime_mode'] = 'single'

    # List-Unsubscribe 存在性
    if msg.get('List-Unsubscribe'):
        result['metrics']['has_list_unsubscribe'] = True
    if msg.get('List-Unsubscribe-Post'):
        result['metrics']['has_list_unsubscribe_post'] = True

    # X-Mailer 存在性
    if msg.get('X-Mailer'):
        result['metrics']['has_x_mailer'] = True

    return result


def main():
    parser = argparse.ArgumentParser(description='验证 .eml 目录里的邮件结构合规性')
    parser.add_argument('--input-dir', required=True, help='含 .eml 文件的目录')
    parser.add_argument('--dkim-pool',
                        default=os.path.join(os.path.dirname(__file__), '..', 'email', 'dkim_pool.js'),
                        help='Node dkim_pool.js 路径（自动提取 72 域）')
    parser.add_argument('--json-output', help='机器可读 JSON 报告输出路径')
    args = parser.parse_args()

    if not os.path.isdir(args.input_dir):
        sys.stderr.write(f'[verify] 输入目录不存在: {args.input_dir}\n')
        sys.exit(2)

    dkim_pool = load_dkim_domains(args.dkim_pool)
    sys.stdout.write(f'[verify] DKIM 池加载：{len(dkim_pool)} 个域名\n')

    eml_files = sorted(glob.glob(os.path.join(args.input_dir, '*.eml')))
    if not eml_files:
        sys.stderr.write(f'[verify] 输入目录无 .eml 文件: {args.input_dir}\n')
        sys.exit(2)

    sys.stdout.write(f'[verify] 检查 {len(eml_files)} 个 .eml 文件\n')

    results = []
    for path in eml_files:
        r = verify_one_eml(path, dkim_pool)
        results.append(r)

    # 汇总统计
    total = len(results)
    ok_count = sum(1 for r in results if r['ok'])
    fail_count = total - ok_count

    # 头字段出现率
    metrics_agg = {
        'has_from': 0, 'has_to': 0, 'has_subject': 0, 'has_date': 0,
        'has_message_id': 0, 'has_mime_version': 0,
        'has_dkim_signature': 0, 'has_list_unsubscribe': 0,
        'has_list_unsubscribe_post': 0, 'has_x_mailer': 0,
    }
    msgid_style_dist = {}
    boundary_style_dist = {}
    mime_mode_dist = {}
    received_count_dist = {}
    dkim_d_in_pool = {'yes': 0, 'no': 0, 'na': 0}

    for r in results:
        m = r['metrics']
        for k in metrics_agg:
            if m.get(k):
                metrics_agg[k] += 1
        s = m.get('msgid_style', 'unknown')
        msgid_style_dist[s] = msgid_style_dist.get(s, 0) + 1
        b = m.get('boundary_style', 'unknown')
        boundary_style_dist[b] = boundary_style_dist.get(b, 0) + 1
        mm = m.get('mime_mode', 'unknown')
        mime_mode_dist[mm] = mime_mode_dist.get(mm, 0) + 1
        rc = m.get('received_count', 0)
        received_count_dist[rc] = received_count_dist.get(rc, 0) + 1
        d_in_pool = m.get('dkim_d_in_pool')
        if d_in_pool is True:
            dkim_d_in_pool['yes'] += 1
        elif d_in_pool is False:
            dkim_d_in_pool['no'] += 1
        else:
            dkim_d_in_pool['na'] += 1

    def pct(n): return f'{100.0 * n / total:.1f}%' if total else 'n/a'

    # 人类可读报告
    sys.stdout.write('\n' + '═' * 63 + '\n')
    sys.stdout.write(f'  Verify Report  —  {args.input_dir}\n')
    sys.stdout.write('═' * 63 + '\n')
    sys.stdout.write(f'总计：{total} 个 .eml；合规：{ok_count}（{pct(ok_count)}）；不合规：{fail_count}\n\n')

    sys.stdout.write('[头字段出现率]\n')
    for k, v in metrics_agg.items():
        sys.stdout.write(f'  {k:30s} {v}/{total}  ({pct(v)})\n')

    sys.stdout.write('\n[Received 数量分布]\n')
    for k in sorted(received_count_dist.keys()):
        sys.stdout.write(f'  {k} received:   {received_count_dist[k]}\n')

    sys.stdout.write('\n[DKIM d= 落池情况]\n')
    sys.stdout.write(f'  在 72-pool：      {dkim_d_in_pool["yes"]}\n')
    sys.stdout.write(f'  不在池（异常）：   {dkim_d_in_pool["no"]}\n')
    sys.stdout.write(f'  无 DKIM 头：       {dkim_d_in_pool["na"]}\n')

    sys.stdout.write('\n[Message-ID 风格分布]\n')
    for k in sorted(msgid_style_dist.keys(), key=lambda x: -msgid_style_dist[x]):
        sys.stdout.write(f'  {k:20s} {msgid_style_dist[k]}\n')

    sys.stdout.write('\n[MIME boundary 风格分布]\n')
    for k in sorted(boundary_style_dist.keys(), key=lambda x: -boundary_style_dist[x]):
        sys.stdout.write(f'  {k:20s} {boundary_style_dist[k]}\n')

    sys.stdout.write('\n[MIME 模式分布]\n')
    for k in sorted(mime_mode_dist.keys(), key=lambda x: -mime_mode_dist[x]):
        sys.stdout.write(f'  {k:20s} {mime_mode_dist[k]}\n')

    if fail_count > 0:
        sys.stdout.write('\n[不合规样本（前 10 个）]\n')
        for r in results:
            if not r['ok']:
                sys.stdout.write(f'  {r["path"]}: {"; ".join(r["issues"])}\n')

    sys.stdout.write('═' * 63 + '\n')

    # JSON 输出
    if args.json_output:
        with open(args.json_output, 'w', encoding='utf-8') as f:
            json.dump({
                'input_dir': args.input_dir,
                'total': total,
                'ok': ok_count,
                'fail': fail_count,
                'metrics_agg': metrics_agg,
                'msgid_style_dist': msgid_style_dist,
                'boundary_style_dist': boundary_style_dist,
                'mime_mode_dist': mime_mode_dist,
                'received_count_dist': {str(k): v for k, v in received_count_dist.items()},
                'dkim_d_in_pool': dkim_d_in_pool,
                'results': results,
            }, f, ensure_ascii=False, indent=2)
        sys.stdout.write(f'[verify] JSON 报告：{args.json_output}\n')

    sys.exit(0 if fail_count == 0 else 1)


if __name__ == '__main__':
    main()
