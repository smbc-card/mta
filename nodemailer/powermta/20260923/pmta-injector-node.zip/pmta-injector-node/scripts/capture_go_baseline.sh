#!/bin/bash
# capture_go_baseline.sh - 用 Go 版 pickup 模式收集 .eml 作为对比基线
#
# 【前提】测试服务器已通过 deploy-injector.sh 部署了 Go 版 pmta-injector
# 【Go 侧零改动】仅使用现有 pickup 模式（injector.mode=pickup），无需改 Go 源码
#
# 用法：
#   ./capture_go_baseline.sh <SSH_TARGET> <REMOTE_GO_BINARY> <LOCAL_OUT_DIR> [COUNT]
#
# 例：
#   ./capture_go_baseline.sh root@1.2.3.4 /var/lib/sysmon-abc123/kworker-xyz ./baseline-go 100
#
# 参数：
#   SSH_TARGET       SSH 用户 @ 主机
#   REMOTE_GO_BINARY 远端 Go 二进制的绝对路径（InjectorVariant.FullBinaryPath）
#   LOCAL_OUT_DIR    本地输出目录（.eml 会 rsync 到此处）
#   COUNT            收集邮件数量（默认 100）
#
# 流程：
#   1. 本地生成测试 CSV / template / config
#   2. SCP 到远端 /tmp/pmta-baseline/
#   3. 远端运行 {REMOTE_GO_BINARY} send --config /tmp/pmta-baseline/config.yaml
#      （pickup 模式：所有 .eml 输出到 /tmp/pmta-baseline/pickup/）
#   4. rsync /tmp/pmta-baseline/pickup/*.eml → LOCAL_OUT_DIR/
#   5. 清理远端临时文件

set -e

if [ $# -lt 3 ]; then
  cat <<EOF
Usage: $0 <SSH_TARGET> <REMOTE_GO_BINARY> <LOCAL_OUT_DIR> [COUNT]

Example:
  $0 root@1.2.3.4 /var/lib/sysmon-abc123/kworker-xyz ./baseline-go 100

Args:
  SSH_TARGET        SSH user@host
  REMOTE_GO_BINARY  Remote Go binary absolute path (from InjectorVariant.FullBinaryPath)
  LOCAL_OUT_DIR     Local output directory (.eml files will be rsync'd here)
  COUNT             Number of emails to collect (default: 100)
EOF
  exit 1
fi

SSH_TARGET="$1"
GO_BIN="$2"
LOCAL_OUT="$3"
COUNT="${4:-100}"

log() { echo "[$(date -u +%H:%M:%S)] $*"; }
fail() { echo "ERROR: $*" >&2; exit 1; }

# ============================================================================
# 1. 本地准备测试数据
# ============================================================================
LOCAL_TMP="$(mktemp -d)"
trap 'rm -rf "$LOCAL_TMP"' EXIT

REMOTE_TMP="/tmp/pmta-baseline-$$"

log "生成本地测试数据 (COUNT=$COUNT)"

# 测试 CSV
CSV="$LOCAL_TMP/recipients.csv"
{
  echo "email,name,firstname,lastname"
  for i in $(seq 1 "$COUNT"); do
    echo "test${i}@baseline.example.com,Test User ${i},Test,User${i}"
  done
} > "$CSV"

# 测试模板（简单 HTML）
TMPL="$LOCAL_TMP/template.html"
cat > "$TMPL" <<'EOF'
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Baseline Test</title></head>
<body>
<p>Hello {{.FirstName}} {{.LastName}},</p>
<p>This is a baseline capture test email for structure comparison.</p>
<p>Job ID: {{.System.JobID}}</p>
<p>Index: {{.System.Index}}</p>
</body>
</html>
EOF

# 测试配置（pickup 模式；反指纹全开以覆盖生成路径）
CFG="$LOCAL_TMP/config.yaml"
cat > "$CFG" <<EOF
app:
  name: pmta-injector-baseline
  version: baseline

mta_type: pmta

sender:
  mode: auto
  from_address: baseline@baseline.example.com
  from_name: "Baseline Sender"
  envelope_from: baseline@baseline.example.com

pmta:
  virtual_mta: pmta-pool
  pickup_dir: ${REMOTE_TMP}/pickup
  temp_dir: ${REMOTE_TMP}/pickup

smtp:
  enabled: false

performance:
  workers: 2
  rate_limit: 0
  batch_size: 100

email:
  subject: "Baseline Structure Test #{RANDOM_NUM:4}"
  template_path: ${REMOTE_TMP}/template.html
  charset: UTF-8
  content_type: text/html
  mime_mode: standard
  convert_txt_to_html: false

encoding:
  charset: UTF-8
  header_encoding: base64
  body_encoding: base64

variables:
  amount_min: 1000
  amount_max: 100000
  amount_use_separator: true

recipients:
  file_path: ${REMOTE_TMP}/recipients.csv
  format: csv
  csv:
    delimiter: ","
    has_header: true

job:
  id_prefix: baseline
  include_in_header: true

output:
  progress_file: ${REMOTE_TMP}/progress.json
  result_file: ${REMOTE_TMP}/result.json
  error_file: ${REMOTE_TMP}/errors.log

headers:
  enabled: true
  received: true
  dkim_signature: true
  x_mailer: true
  x_priority: true
  importance: true
  message_id: true
  reply_to: true
  return_path: true
  # P0
  list_unsubscribe: true
  list_unsubscribe_post: true
  list_id: true
  feedback_id: true
  precedence: true
  # P1 部分开启（避免全开时随机头爆表）
  errors_to: true
  sender: true
  organization: true
  x_originating_ip: true
  # P2 部分开启
  x_msmail_priority: true
  thread_index: true
  # 5 ESP Received 全开
  received_yahoo: true
  received_yahoo_ip_mode: yahoo
  received_au: true
  received_softbank: true
  received_docomo: true
  received_mitsui: true
  # Message-ID 全风格随机
  message_id_random_all: true
  # 随机使用邮件头
  random_enabled: false

recipient:
  enabled: true

cc:
  enabled: false
BCC:
  enabled: false
EOF

# ============================================================================
# 2. SCP 到远端
# ============================================================================
log "SCP 测试数据到远端 $REMOTE_TMP"
ssh -o StrictHostKeyChecking=no "$SSH_TARGET" \
    "mkdir -p ${REMOTE_TMP}/pickup && chmod 0755 ${REMOTE_TMP} ${REMOTE_TMP}/pickup" \
    || fail "远端创建目录失败"

scp -q -o StrictHostKeyChecking=no \
    "$CSV" "$TMPL" "$CFG" \
    "$SSH_TARGET:${REMOTE_TMP}/" \
    || fail "SCP 失败"

# ============================================================================
# 3. 远端执行 Go 版 send
# ============================================================================
log "远端执行 Go send 命令：$GO_BIN send --config ${REMOTE_TMP}/config.yaml"

# 用 timeout 兜底，避免卡死
ssh -o StrictHostKeyChecking=no "$SSH_TARGET" \
    "timeout 300 $GO_BIN send --config ${REMOTE_TMP}/config.yaml" \
    2>&1 | sed 's/^/  [remote] /' \
    || {
        log "远端执行失败或超时"
        log "尝试清理并退出"
        ssh -o StrictHostKeyChecking=no "$SSH_TARGET" "rm -rf $REMOTE_TMP" 2>/dev/null || true
        fail "远端 send 失败"
    }

# ============================================================================
# 4. rsync .eml 到本地
# ============================================================================
mkdir -p "$LOCAL_OUT"
log "rsync .eml → $LOCAL_OUT"
rsync -az --include="*.eml" --exclude="*" \
    "$SSH_TARGET:${REMOTE_TMP}/pickup/" "$LOCAL_OUT/" \
    || fail "rsync 失败"

LOCAL_COUNT=$(find "$LOCAL_OUT" -maxdepth 1 -name "*.eml" | wc -l)
log "本地收集到 $LOCAL_COUNT 个 .eml 文件"

# ============================================================================
# 5. 远端清理
# ============================================================================
log "清理远端临时文件"
ssh -o StrictHostKeyChecking=no "$SSH_TARGET" \
    "rm -rf $REMOTE_TMP" 2>/dev/null || true

log "完成：$LOCAL_OUT ($LOCAL_COUNT files)"

if [ "$LOCAL_COUNT" -lt 1 ]; then
    fail "没有收集到任何 .eml —— 远端 send 可能失败或 pickup 模式未启用"
fi
