#!/usr/bin/env python3
# compare_structural.py - 对比 Go 基线目录 vs Node 输出目录的结构指标
#
# Sprint 6 核心：不做字节 diff（RNG 算法不同），做**结构分布对比**。
# 输出并排指标表 —— Go / Node 两侧各自的：
#   - 头字段出现率
#   - Message-ID 风格分布
#   - Boundary 风格分布
#   - MIME 模式分布
#   - Received 数量分布
#   - DKIM d= 落池率
#
# 【预期】Go/Node 两侧的**分布应相近**（差异 <5%）：
#   - 头字段出现率：应完全一致（都由 cfg.headers 开关控制）
#   - 风格分布：应相似（都从 25 风格 / 6 boundary / 6 dkim 风格池均匀抽样）
#   - Received 数量：应相似（都由 5 ESP 开关 + 1/2/3 hop 加权决定）
#
# 用法：
#   python3 compare_structural.py --go-dir <dir> --node-dir <dir> [--json-output <path>]
#
# 退出码：
#   0 = 分布差异 ≤ 阈值（默认 10%）
#   1 = 分布差异 > 阈值（可能是 Node 端反指纹逻辑漏洞）
#   2 = 参数错误 / 输入目录为空

import argparse
import json
import os
import sys

# 复用 verify_node_structure 的 verify_one_eml
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from verify_node_structure import verify_one_eml, load_dkim_domains
except ImportError as e:
    sys.stderr.write(f'[compare] 无法导入 verify_node_structure: {e}\n')
    sys.exit(2)


import glob


def analyze_dir(input_dir, dkim_pool):
    """遍历目录，返回汇总统计"""
    eml_files = sorted(glob.glob(os.path.join(input_dir, '*.eml')))
    total = len(eml_files)
    if total == 0:
        return None

    metrics_agg = {
        'has_from': 0, 'has_to': 0, 'has_subject': 0, 'has_date': 0,
        'has_message_id': 0, 'has_mime_version': 0,
        'has_dkim_signature': 0, 'has_list_unsubscribe': 0,
        'has_list_unsubscribe_post': 0, 'has_x_mailer': 0,
    }
    msgid_style_dist = {}
    boundary_style_dist = {}
    mime_mode_dist = {}
    received_count_dist = {}
    dkim_d_in_pool = {'yes': 0, 'no': 0, 'na': 0}
    ok_count = 0

    for path in eml_files:
        r = verify_one_eml(path, dkim_pool)
        if r['ok']:
            ok_count += 1
        m = r['metrics']
        for k in metrics_agg:
            if m.get(k):
                metrics_agg[k] += 1
        s = m.get('msgid_style', 'unknown')
        msgid_style_dist[s] = msgid_style_dist.get(s, 0) + 1
        b = m.get('boundary_style', 'unknown')
        boundary_style_dist[b] = boundary_style_dist.get(b, 0) + 1
        mm = m.get('mime_mode', 'unknown')
        mime_mode_dist[mm] = mime_mode_dist.get(mm, 0) + 1
        rc = m.get('received_count', 0)
        received_count_dist[rc] = received_count_dist.get(rc, 0) + 1
        d_in_pool = m.get('dkim_d_in_pool')
        if d_in_pool is True:
            dkim_d_in_pool['yes'] += 1
        elif d_in_pool is False:
            dkim_d_in_pool['no'] += 1
        else:
            dkim_d_in_pool['na'] += 1

    return {
        'total': total,
        'ok': ok_count,
        'metrics_agg': metrics_agg,
        'msgid_style_dist': msgid_style_dist,
        'boundary_style_dist': boundary_style_dist,
        'mime_mode_dist': mime_mode_dist,
        'received_count_dist': received_count_dist,
        'dkim_d_in_pool': dkim_d_in_pool,
    }


def rate(n, total):
    return (100.0 * n / total) if total > 0 else 0.0


def format_dist_line(go_stats, node_stats, key, go_total, node_total, threshold_pct=10.0):
    """返回一行对比 + 是否越阈值"""
    g = go_stats.get(key, 0)
    n = node_stats.get(key, 0)
    g_pct = rate(g, go_total)
    n_pct = rate(n, node_total)
    diff = abs(g_pct - n_pct)
    marker = ''
    exceeds = diff > threshold_pct
    if exceeds and (g_pct > 5 or n_pct > 5):  # 只对非零场景报警
        marker = '  ⚠ diff > {:.1f}%'.format(threshold_pct)
    return f'  {key:30s}  Go={g:5d}({g_pct:5.1f}%)  Node={n:5d}({n_pct:5.1f}%)  Δ={diff:5.1f}%{marker}', exceeds


def compare_dists(go_dist, node_dist, go_total, node_total, name, threshold_pct=10.0):
    """对比两个字典分布，返回 (lines, warnings)"""
    lines = [f'\n[{name} 对比]']
    all_keys = set(go_dist.keys()) | set(node_dist.keys())
    warnings = 0
    # 按 Go 侧数值降序
    def sort_key(k):
        return -go_dist.get(k, 0)
    for key in sorted(all_keys, key=sort_key):
        line, exceeds = format_dist_line(go_dist, node_dist, key, go_total, node_total, threshold_pct)
        lines.append(line)
        if exceeds:
            warnings += 1
    return lines, warnings


def main():
    parser = argparse.ArgumentParser(description='对比 Go 基线 vs Node 输出的结构分布')
    parser.add_argument('--go-dir', required=True, help='Go 版 pickup 输出目录（capture_go_baseline.sh 产物）')
    parser.add_argument('--node-dir', required=True, help='Node 版 debug-dump 输出目录')
    parser.add_argument('--dkim-pool',
                        default=os.path.join(os.path.dirname(__file__), '..', 'email', 'dkim_pool.js'),
                        help='Node dkim_pool.js 路径')
    parser.add_argument('--threshold', type=float, default=10.0,
                        help='分布差异告警阈值（百分比，默认 10）')
    parser.add_argument('--json-output', help='机器可读 JSON 报告输出路径')
    args = parser.parse_args()

    if not os.path.isdir(args.go_dir):
        sys.stderr.write(f'[compare] Go 目录不存在: {args.go_dir}\n')
        sys.exit(2)
    if not os.path.isdir(args.node_dir):
        sys.stderr.write(f'[compare] Node 目录不存在: {args.node_dir}\n')
        sys.exit(2)

    dkim_pool = load_dkim_domains(args.dkim_pool)
    sys.stdout.write(f'[compare] DKIM 池加载：{len(dkim_pool)} 个域名\n')

    sys.stdout.write(f'[compare] 分析 Go 目录：{args.go_dir}\n')
    go_stats = analyze_dir(args.go_dir, dkim_pool)
    sys.stdout.write(f'[compare] 分析 Node 目录：{args.node_dir}\n')
    node_stats = analyze_dir(args.node_dir, dkim_pool)

    if go_stats is None:
        sys.stderr.write(f'[compare] Go 目录无 .eml\n')
        sys.exit(2)
    if node_stats is None:
        sys.stderr.write(f'[compare] Node 目录无 .eml\n')
        sys.exit(2)

    go_total = go_stats['total']
    node_total = node_stats['total']
    total_warnings = 0

    sys.stdout.write('\n' + '═' * 90 + '\n')
    sys.stdout.write(f'  Structural Comparison Report\n')
    sys.stdout.write(f'  Go dir:   {args.go_dir}  ({go_total} .eml)\n')
    sys.stdout.write(f'  Node dir: {args.node_dir}  ({node_total} .eml)\n')
    sys.stdout.write(f'  Threshold: {args.threshold:.1f}%\n')
    sys.stdout.write('═' * 90 + '\n')

    sys.stdout.write(f'\n[合规率]\n')
    sys.stdout.write(f'  Go:   {go_stats["ok"]}/{go_total}  ({rate(go_stats["ok"], go_total):.1f}%)\n')
    sys.stdout.write(f'  Node: {node_stats["ok"]}/{node_total}  ({rate(node_stats["ok"], node_total):.1f}%)\n')

    # 头字段出现率
    lines, warns = compare_dists(
        go_stats['metrics_agg'], node_stats['metrics_agg'],
        go_total, node_total, '头字段出现率', args.threshold)
    for l in lines:
        sys.stdout.write(l + '\n')
    total_warnings += warns

    # Message-ID 风格
    lines, warns = compare_dists(
        go_stats['msgid_style_dist'], node_stats['msgid_style_dist'],
        go_total, node_total, 'Message-ID 风格分布', args.threshold)
    for l in lines:
        sys.stdout.write(l + '\n')
    total_warnings += warns

    # Boundary 风格
    lines, warns = compare_dists(
        go_stats['boundary_style_dist'], node_stats['boundary_style_dist'],
        go_total, node_total, 'MIME boundary 风格分布', args.threshold)
    for l in lines:
        sys.stdout.write(l + '\n')
    total_warnings += warns

    # MIME 模式
    lines, warns = compare_dists(
        go_stats['mime_mode_dist'], node_stats['mime_mode_dist'],
        go_total, node_total, 'MIME 模式分布', args.threshold)
    for l in lines:
        sys.stdout.write(l + '\n')
    total_warnings += warns

    # Received 数量
    lines, warns = compare_dists(
        go_stats['received_count_dist'], node_stats['received_count_dist'],
        go_total, node_total, 'Received 数量分布', args.threshold)
    for l in lines:
        sys.stdout.write(l + '\n')
    total_warnings += warns

    # DKIM d= 落池
    sys.stdout.write('\n[DKIM d= 落池对比]\n')
    for k in ['yes', 'no', 'na']:
        g = go_stats['dkim_d_in_pool'][k]
        n = node_stats['dkim_d_in_pool'][k]
        sys.stdout.write(f'  {k:5s}  Go={g:5d}({rate(g, go_total):5.1f}%)  Node={n:5d}({rate(n, node_total):5.1f}%)\n')

    sys.stdout.write('\n' + '═' * 90 + '\n')
    if total_warnings == 0:
        sys.stdout.write(f'✅ 分布对齐良好，无越阈值指标（阈值 {args.threshold:.1f}%）\n')
    else:
        sys.stdout.write(f'⚠ {total_warnings} 个指标超过 {args.threshold:.1f}% 阈值 — 建议检查\n')
    sys.stdout.write('═' * 90 + '\n')

    # JSON 输出
    if args.json_output:
        with open(args.json_output, 'w', encoding='utf-8') as f:
            json.dump({
                'go_dir': args.go_dir,
                'node_dir': args.node_dir,
                'threshold_pct': args.threshold,
                'go_stats': go_stats,
                'node_stats': node_stats,
                'total_warnings': total_warnings,
            }, f, ensure_ascii=False, indent=2,
               default=lambda x: str(x))
        sys.stdout.write(f'[compare] JSON 报告：{args.json_output}\n')

    sys.exit(0 if total_warnings == 0 else 1)


if __name__ == '__main__':
    main()
