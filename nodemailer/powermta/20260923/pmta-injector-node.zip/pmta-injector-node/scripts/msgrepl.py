#!/usr/bin/env python3
# scripts/msgrepl.py - 替换 messages.js 里的 __MSG_NNN__ 占位符为等长随机 ASCII
#
# 用法：
#   python3 scripts/msgrepl.py <seed>
#
# 【与 Go 版兼容】此脚本沿用 Go 版 deploy-injector.sh 内嵌的 Python 逻辑，
# 仅替换目标文件从 messages.go 改为 messages.js。
#
# 长度保持：__MSG_NNN__ 是 11 字符（含下划线），随机串长度=match.group(0).__len__() 保证严格等长

import re
import random
import string
import sys
import os

if len(sys.argv) < 2:
    sys.stderr.write("Usage: msgrepl.py <seed>\n")
    sys.exit(1)

try:
    seed = int(sys.argv[1])
except ValueError:
    sys.stderr.write("Error: seed must be integer\n")
    sys.exit(1)

random.seed(seed)

# 【重要】相对路径 messages.js —— 部署脚本执行前会 cd 到源码根目录
target = 'messages.js'
if not os.path.isfile(target):
    sys.stderr.write(f"Error: {target} not found (must run from Node source root)\n")
    sys.exit(1)

with open(target, 'r', encoding='utf-8') as f:
    content = f.read()

def replace_placeholder(match):
    # 保持相同字符数（__MSG_NNN__ 长度 11）
    alphabet = string.ascii_letters + string.digits
    return ''.join(random.choices(alphabet, k=len(match.group(0))))

# 匹配 __MSG_ + 3 位数字 + __
content = re.sub(r'__MSG_\d{3}__', replace_placeholder, content)

with open(target, 'w', encoding='utf-8') as f:
    f.write(content)

sys.stdout.write(f"[msgrepl] {target} placeholders replaced with seed {seed}\n")
