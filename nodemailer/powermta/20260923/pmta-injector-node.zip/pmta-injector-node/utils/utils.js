'use strict';
// utils - 通用工具（对应 Go pmta-injector-clean/utils/utils.go）
//
// 涵盖：UUID / 短 ID / Message-ID / MD5 / SHA256 / Base64 / URL 编解码 / 文件操作 /
//       原子写 / JSON 序列化 / 字符串工具。
// 后续 sprint 会按需扩展（如 email 模块的 raw email atomic pickup 写入）。

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ─────────────────────────────────────────────────────────────
// UUID / ID 生成
// ─────────────────────────────────────────────────────────────

// generateUUID 生成 UUID v4（对应 Go GenerateUUID）
function generateUUID() {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  // Node <14.17 兜底
  const b = crypto.randomBytes(16);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const hex = b.toString('hex');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20,32)}`;
}

// generateShortID 生成 12 位 hex 短 ID（对应 Go GenerateShortID: 6 字节 hex）
function generateShortID() {
  return crypto.randomBytes(6).toString('hex');
}

// nowUnixNano 当前时间 Unix 纳秒（BigInt，对应 Go time.Now().UnixNano()）
// 说明：JS Date 精度到毫秒；用 ms*1e6 + 随机低 6 位保证唯一性即可（Message-ID 场景够用）
function nowUnixNano() {
  return BigInt(Date.now()) * 1000000n + BigInt(Math.floor(Math.random() * 1000000));
}

// generateMessageID 生成邮件 Message-ID（对应 Go utils.GenerateMessageID）
// 格式：{unixNano}.{6-byte hex}@{domain}
function generateMessageID(domain) {
  const ts = nowUnixNano();
  const rand = generateShortID();
  let d = domain || 'localhost';
  const at = d.indexOf('@');
  if (at !== -1) d = d.slice(at + 1);
  return `${ts}.${rand}@${d}`;
}

// ─────────────────────────────────────────────────────────────
// 哈希
// ─────────────────────────────────────────────────────────────

function md5Hash(s) {
  return crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
}

function sha256Hash(s) {
  return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex');
}

// ─────────────────────────────────────────────────────────────
// 编解码
// ─────────────────────────────────────────────────────────────

function base64Encode(s) {
  return Buffer.from(String(s), 'utf8').toString('base64');
}

// base64Decode 失败时返回原串（对应 Go 版行为）
function base64Decode(s) {
  try {
    return Buffer.from(String(s), 'base64').toString('utf8');
  } catch (_) {
    return s;
  }
}

// urlEncode 对齐 Go net/url.QueryEscape
// encodeURIComponent 不编码 !'()*，QueryEscape 会编码它们，手动补
function urlEncode(s) {
  return encodeURIComponent(String(s))
    .replace(/!/g, '%21')
    .replace(/'/g, '%27')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29')
    .replace(/\*/g, '%2A');
}

function urlDecode(s) {
  try {
    return decodeURIComponent(String(s));
  } catch (_) {
    return s;
  }
}

// ─────────────────────────────────────────────────────────────
// 数据 / 字符串
// ─────────────────────────────────────────────────────────────

function toJSON(v) {
  try {
    return JSON.stringify(v);
  } catch (_) {
    return '';
  }
}

function truncate(s, length) {
  const str = String(s);
  if (str.length <= length) return str;
  return str.slice(0, length);
}

function safeString(s) {
  if (s === null || s === undefined) return '';
  return String(s);
}

function coalesceString(...values) {
  for (const v of values) {
    if (v !== null && v !== undefined && v !== '') return String(v);
  }
  return '';
}

// ─────────────────────────────────────────────────────────────
// 文件系统
// ─────────────────────────────────────────────────────────────

function readFile(p) {
  return fs.readFileSync(p);
}

function readFileText(p) {
  return fs.readFileSync(p, 'utf8');
}

function getFileName(p) {
  return path.basename(p);
}

function fileExists(p) {
  try {
    fs.accessSync(p);
    return true;
  } catch (_) {
    return false;
  }
}

function isDir(p) {
  try {
    return fs.statSync(p).isDirectory();
  } catch (_) {
    return false;
  }
}

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

// atomicWriteFile 原子写：先写 .tmp 再 rename
// 关键：同一文件系统内 rename 是原子的，读方不会读到半写状态
async function atomicWriteFile(targetPath, data) {
  const tmp = targetPath + '.tmp';
  await fs.promises.writeFile(tmp, data);
  await fs.promises.rename(tmp, targetPath);
}

function atomicWriteFileSync(targetPath, data) {
  const tmp = targetPath + '.tmp';
  fs.writeFileSync(tmp, data);
  fs.renameSync(tmp, targetPath);
}

// ─────────────────────────────────────────────────────────────
// 异步小工具
// ─────────────────────────────────────────────────────────────

function sleepMs(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = {
  generateUUID,
  generateShortID,
  nowUnixNano,
  generateMessageID,
  md5Hash,
  sha256Hash,
  base64Encode,
  base64Decode,
  urlEncode,
  urlDecode,
  toJSON,
  truncate,
  safeString,
  coalesceString,
  readFile,
  readFileText,
  getFileName,
  fileExists,
  isDir,
  ensureDir,
  atomicWriteFile,
  atomicWriteFileSync,
  sleepMs,
};
