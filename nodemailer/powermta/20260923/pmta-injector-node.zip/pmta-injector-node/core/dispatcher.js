'use strict';
// core/dispatcher - 任务调度器（对应 Go pmta-injector-clean/core/dispatcher.go）
//
// ═══════════════════════════════════════════════════════════════
// 结构：
//   ┌── main 事件循环 ──┐
//   │  1. 加载 CC/BCC 池          │
//   │  2. countLines → this.total │
//   │  3. 预分配 N 个 workerContext（每个含 Builder + templateEngine）│
//   │  4. 起 progress reporter 定时器                    │
//   │  5. for await (rec of readerStream)                │
//   │     → limit(() => processOne(rec, ctx))            │
//   │  6. Promise.allSettled(tasks)                      │
//   │  7. buildResult + 清理                             │
//   └────────────────────────────┘
//
// processOne(rec, ctx):
//   - takeCCBatch / takeBCCBatch（原子）
//   - 主邮件 build + inject（per-recipient try/catch，失败不中断）
//   - CC 独立邮件循环 build + inject
//   - BCC 独立邮件循环 build + inject
//   - 每封独立邮件独立计入 processed/success/failed
//
// ═══════════════════════════════════════════════════════════════
// Node 与 Go 的语义差异（关键）：
//   - Go 用 100 goroutine + channel + sync.WaitGroup
//   - Node 用 p-limit(N) + async/await + Promise.allSettled
//   - Go 原子操作用 atomic.AddInt64
//     Node 单线程事件循环里普通 ++ 已经原子（无 CPU 并发插入）
//   - Go per-worker Builder 是长驻实例
//     Node 预分配 N 个 Builder，用 round-robin 分配（本质等价）
//   - Go 用 context.Cancel 传播停机信号
//     Node 用 graceful.stopping flag + abortSignal 传播
//
// ═══════════════════════════════════════════════════════════════

const pLimit = require('p-limit');
const injectorMod = require('../injector/injector');
const readerMod = require('../reader/reader');
const templateMod = require('../email/template');
const builderMod = require('../email/builder');
const rateLimiterMod = require('./ratelimiter');

class Dispatcher {
  constructor(cfg, reporter, graceful) {
    this.cfg = cfg;
    this.reporter = reporter;
    this.graceful = graceful;

    // 统计（Node 单线程，普通数字加减即原子）
    this.total = 0;
    this.processed = 0;
    this.success = 0;
    this.failed = 0;
    this.startTime = null;

    // 错误收集
    this.errors = [];
    this._MAX_ERRORS = 1000;

    // 速率限制
    this.rateLimiter = rateLimiterMod.create(cfg.performance.rate_limit);

    // CC/BCC 池
    this.ccEnabled = false;
    this.ccPool = [];
    this.ccIdx = 0;
    this.ccPerEmail = 0;
    this.bccEnabled = false;
    this.bccPool = [];
    this.bccIdx = 0;
    this.bccPerEmail = 0;

    // 内部资源（run 中初始化，close 中释放）
    this._injector = null;
    this._progressTimer = null;
  }

  // ═════════════════════════════════════════════════════════════
  // run - 主入口
  // ═════════════════════════════════════════════════════════════
  async run() {
    this.startTime = new Date();

    // ── 1. 创建注入器 ──
    try {
      this._injector = injectorMod.create(this.cfg);
    } catch (e) {
      throw new Error(`创建注入器失败: ${e.message}`);
    }
    if (this.graceful) {
      this.graceful.register(() => { try { this._injector.close(); } catch (_) { /* ignore */ } });
    }

    // ── 2. 加载 CC/BCC 池 ──
    await this._loadCCBCCPools();

    // ── 3. 主收件人总数（用于 progress 百分比）──
    let totalMain = 0;
    try {
      const n = await readerMod.countLines(this.cfg.recipients.file_path, this.cfg);
      totalMain = n < 0 ? 0 : n;
    } catch (e) {
      // countLines 失败不阻断，只是失去百分比显示
      _dbg(`[dispatcher] countLines 失败（不阻断）: ${e.message}`);
    }
    this.total = totalMain;

    // 补齐 total = 主邮件 + 实际会触发的 CC/BCC 独立邮件数（消费完即停语义）
    if (this.ccEnabled) {
      const maxCC = Math.min(totalMain * this.ccPerEmail, this.ccPool.length);
      this.total += maxCC;
    }
    if (this.bccEnabled) {
      const maxBCC = Math.min(totalMain * this.bccPerEmail, this.bccPool.length);
      this.total += maxBCC;
    }

    // ── 4. 预分配 worker contexts（每个含独立 Builder + templateEngine）──
    const workerCount = Math.max(1, this.cfg.performance.workers || 10);
    const contexts = [];
    for (let i = 0; i < workerCount; i++) {
      let tmpl, builder;
      try {
        tmpl = templateMod.create(this.cfg.email.template_path);
        tmpl.setGlobalVariables(this.cfg.template.global_variables || {});
        builder = builderMod.create(this.cfg, tmpl, i);
      } catch (e) {
        throw new Error(`worker ${i} 初始化失败: ${e.message}`);
      }
      contexts.push({ workerId: i, tmpl, builder });
    }

    // ── 5. 进度报告定时器 ──
    const intervalSec = Math.max(1, this.cfg.performance.progress_interval || 1);
    this._progressTimer = setInterval(() => this._updateProgress().catch(() => {}), intervalSec * 1000);
    if (this._progressTimer && typeof this._progressTimer.unref === 'function') {
      this._progressTimer.unref();
    }
    if (this.graceful) {
      this.graceful.register(() => {
        if (this._progressTimer) { clearInterval(this._progressTimer); this._progressTimer = null; }
      });
    }

    // ── 6. 分发循环 ──
    // 关键：tasks[] 需要周期性 drain，防止 100M 级收件人时 promise 引用累积撑爆内存
    //       drain 阈值取 workerCount * 50（例如 100 worker → 5000 阈值），
    //       保证 drain 不会太频繁（每次 drain 会短暂阻塞 reader，损失一点吞吐）
    const limit = pLimit(workerCount);
    let tasks = [];
    let ctxRotator = 0;
    let physicalLine = 0;
    const skipLines = this.cfg.recipients.skip_lines || 0;
    const DRAIN_WATERMARK = Math.max(1000, workerCount * 50);

    let readerStream;
    try {
      readerStream = readerMod.createStream(this.cfg.recipients.file_path, this.cfg);
    } catch (e) {
      throw new Error(`创建收件人读取器失败: ${e.message}`);
    }

    try {
      for await (const recipient of readerStream) {
        if (this.graceful && this.graceful.stopping) break;
        physicalLine++;
        if (physicalLine <= skipLines) continue;
        recipient.lineNumber = physicalLine;
        const ctx = contexts[ctxRotator++ % contexts.length];
        // 提交任务到 limit 队列（不 await，让分发继续；tasks 里保存 promise）
        tasks.push(limit(async () => {
          if (this.graceful && this.graceful.stopping) return;
          if (this.rateLimiter) {
            await this.rateLimiter.wait(this.graceful ? this.graceful.abortSignal : undefined);
          }
          if (this.graceful && this.graceful.stopping) return;
          await this._processOne(recipient, ctx);
        }));

        // 【内存防御】达到水位则 drain 一批，让已完成任务的 promise 释放
        if (tasks.length >= DRAIN_WATERMARK) {
          await Promise.allSettled(tasks);
          tasks = [];
        }
      }
    } catch (e) {
      _dbg(`[dispatcher] 读取循环异常: ${e.message}`);
      this._recordError({ email: '', lineNumber: physicalLine }, e, '[reader]');
    }

    // ── 7. 等待最后一批任务完成 ──
    await Promise.allSettled(tasks);
    tasks = [];

    // ── 8. 清理 ──
    if (this._progressTimer) { clearInterval(this._progressTimer); this._progressTimer = null; }
    try { this._injector.close(); } catch (_) { /* ignore */ }

    // ── 9. 最后一次进度刷（100% 结算）──
    try { await this._updateProgress(); } catch (_) { /* ignore */ }

    return this._buildResult();
  }

  // ═════════════════════════════════════════════════════════════
  // _processOne - 单条 CSV 行的完整处理（主邮件 + CC/BCC 独立邮件循环）
  // per-recipient try/catch：单封 panic 不影响后续
  // ═════════════════════════════════════════════════════════════
  async _processOne(recipient, ctx) {
    // takeCCBatch / takeBCCBatch 同步原子（Node 单线程）
    const ccBatch = this._takeCCBatch();
    const bccBatch = this._takeBCCBatch();

    // ── 主邮件 ──
    const skipMain = !this.cfg.recipient.enabled || !recipient.email;
    if (!skipMain) {
      try {
        await this._buildAndInjectOne(recipient, recipient.email, ctx, ccBatch);
        this.processed++;
        this.success++;
      } catch (e) {
        this.processed++;
        this.failed++;
        this._recordError({ email: recipient.email, lineNumber: recipient.lineNumber }, e);
      }
    } else {
      // 主邮件跳过（占位）：计入 processed + success，避免外层进度错乱
      this.processed++;
      this.success++;
    }

    // ── CC 独立邮件循环 ──
    // 【v8.1 关键】主邮件失败 **不** 跳过 CC/BCC —— ccBatch/bccBatch 已 atomic 分配走，
    // 跳过会让配额永久浪费（消费完即停语义下永远发不出去）
    for (const ccAddr of ccBatch) {
      if (this.graceful && this.graceful.stopping) return;
      if (this.rateLimiter) {
        await this.rateLimiter.wait(this.graceful ? this.graceful.abortSignal : undefined);
      }
      if (this.graceful && this.graceful.stopping) return;
      try {
        await this._buildAndInjectOne(recipient, ccAddr, ctx, null);
        this.processed++;
        this.success++;
      } catch (e) {
        this.processed++;
        this.failed++;
        this._recordError(
          { email: ccAddr, lineNumber: recipient.lineNumber },
          e,
          `[CC独立邮件 主收件人=${recipient.email}]`
        );
      }
    }

    // ── BCC 独立邮件循环 ──
    for (const bccAddr of bccBatch) {
      if (this.graceful && this.graceful.stopping) return;
      if (this.rateLimiter) {
        await this.rateLimiter.wait(this.graceful ? this.graceful.abortSignal : undefined);
      }
      if (this.graceful && this.graceful.stopping) return;
      try {
        await this._buildAndInjectOne(recipient, bccAddr, ctx, null);
        this.processed++;
        this.success++;
      } catch (e) {
        this.processed++;
        this.failed++;
        this._recordError(
          { email: bccAddr, lineNumber: recipient.lineNumber },
          e,
          `[BCC独立邮件 主收件人=${recipient.email}]`
        );
      }
    }
  }

  // ═════════════════════════════════════════════════════════════
  // _buildAndInjectOne - 构建单封邮件 + 注入
  //   targetEmail 是这封邮件的收件人（主邮件 = recipient.email，CC/BCC = 各自地址）
  //   变量上下文用 recipient 的字段（保持 CSV 自定义变量语义）
  //   但 tmplData.Email = targetEmail（让 builder 生成对应 To 头 / Message-ID 域名等）
  // ═════════════════════════════════════════════════════════════
  async _buildAndInjectOne(recipient, targetEmail, ctx, ccHeaderList) {
    const data = templateMod.newTemplateData();
    data.Email = targetEmail;
    data.Name = recipient.name || '';
    data.FirstName = recipient.firstName || '';
    data.LastName = recipient.lastName || '';
    data.Data = recipient.customFields || {};
    data.System.Index = recipient.lineNumber || 0;
    data.System.JobID = this.cfg.job.id || '';

    let email;
    try {
      const opts = (Array.isArray(ccHeaderList) && ccHeaderList.length > 0)
        ? { ccHeaderList }
        : undefined;
      email = await ctx.builder.build(data, opts);
    } catch (e) {
      throw new Error(`生成邮件失败: ${e.message}`);
    }

    if (this.cfg.dry_run) return;
    await this._injector.inject(email);
  }

  // ═════════════════════════════════════════════════════════════
  // CC/BCC 原子分配（Node 单线程，同步 slice + 索引推进即原子）
  // ═════════════════════════════════════════════════════════════
  _takeCCBatch() {
    if (!this.ccEnabled || this.ccPool.length === 0 || this.ccPerEmail === 0) return [];
    const start = this.ccIdx;
    if (start >= this.ccPool.length) return [];
    const end = Math.min(start + this.ccPerEmail, this.ccPool.length);
    this.ccIdx = end;
    return this.ccPool.slice(start, end);
  }
  _takeBCCBatch() {
    if (!this.bccEnabled || this.bccPool.length === 0 || this.bccPerEmail === 0) return [];
    const start = this.bccIdx;
    if (start >= this.bccPool.length) return [];
    const end = Math.min(start + this.bccPerEmail, this.bccPool.length);
    this.bccIdx = end;
    return this.bccPool.slice(start, end);
  }

  async _loadCCBCCPools() {
    if (this.cfg.cc.enabled && this.cfg.cc.file_path) {
      try {
        this.ccPool = readerMod.readEmailList(this.cfg.cc.file_path);
      } catch (e) {
        throw new Error(`加载抄送列表失败: ${e.message}`);
      }
      this.ccPerEmail = _clamp(this.cfg.cc.per_email, 1, 100);
      this.ccEnabled = true;
      process.stdout.write(`[CC] 已加载抄送池: ${this.ccPool.length} 条，每封 ${this.ccPerEmail} 个，消费完即停\n`);
    }
    if (this.cfg.bcc.enabled && this.cfg.bcc.file_path) {
      try {
        this.bccPool = readerMod.readEmailList(this.cfg.bcc.file_path);
      } catch (e) {
        throw new Error(`加载密送列表失败: ${e.message}`);
      }
      this.bccPerEmail = _clamp(this.cfg.bcc.per_email, 1, 100);
      this.bccEnabled = true;
      process.stdout.write(`[BCC] 已加载密送池: ${this.bccPool.length} 条，每封 ${this.bccPerEmail} 个，独立邮件\n`);
    }
  }

  // ═════════════════════════════════════════════════════════════
  // 进度更新
  // ═════════════════════════════════════════════════════════════
  async _updateProgress() {
    const now = new Date();
    const elapsedSec = (now - this.startTime) / 1000;
    const rate = elapsedSec > 0 ? (this.processed / elapsedSec) : 0;
    const remaining = this.total - this.processed;
    const eta = (rate > 0 && remaining > 0) ? Math.floor(remaining / rate) : 0;

    if (this.reporter) {
      await this.reporter.updateProgress({
        jobId: this.cfg.job.id || '',
        status: 'running',
        total: this.total,
        processed: this.processed,
        success: this.success,
        failed: this.failed,
        rate,
        etaSeconds: eta,
        startTime: this.startTime,
        updateTime: now,
      });
    }

    if (this.cfg.output.show_progress_bar !== false) {
      const percent = this.total > 0 ? (this.processed / this.total * 100) : 0;
      // \r 覆盖同行输出（对齐 Go 版）
      process.stdout.write(
        `\r[进度] ${this.processed}/${this.total} (${percent.toFixed(1)}%) | ` +
        `成功: ${this.success} | 失败: ${this.failed} | 速率: ${rate.toFixed(0)}/秒 | 剩余: ${eta}s`
      );
    }
  }

  // ═════════════════════════════════════════════════════════════
  // 错误记录
  // ═════════════════════════════════════════════════════════════
  _recordError(rec, err, prefix) {
    if (this.errors.length >= this._MAX_ERRORS) return;
    const msg = (err && err.message) ? err.message : String(err);
    this.errors.push({
      email: rec.email || '',
      error: prefix ? `${prefix} ${msg}` : msg,
      line: rec.lineNumber || 0,
    });
  }

  // ═════════════════════════════════════════════════════════════
  // buildResult - 生成最终 Result 对象
  // ═════════════════════════════════════════════════════════════
  _buildResult() {
    const endTime = new Date();
    const duration = (endTime - this.startTime) / 1000;
    const avgRate = duration > 0 ? (this.processed / duration) : 0;
    const status = (this.graceful && this.graceful.stopping) ? 'cancelled' : 'completed';
    return {
      jobId: this.cfg.job.id || '',
      status,
      total: this.processed,           // 对齐 Go: 用 processed 而不是 this.total
      success: this.success,
      failed: this.failed,
      startTime: this.startTime,
      endTime,
      durationSeconds: duration,
      averageRate: avgRate,
      errors: this.errors,
    };
  }
}

function _clamp(n, min, max) {
  n = Number(n);
  if (!Number.isFinite(n)) return min;
  if (n < min) return min;
  if (n > max) return max;
  return Math.floor(n);
}

function _dbg(msg) {
  process.stderr.write(msg + '\n');
}

/**
 * @param {Object} cfg
 * @param {Object} reporter
 * @param {Object} graceful
 * @returns {Dispatcher}
 */
function create(cfg, reporter, graceful) {
  return new Dispatcher(cfg, reporter, graceful);
}

module.exports = { Dispatcher, create };
