'use strict';
// core/graceful - 优雅停机协调器
//
// 三条停机信号（对齐 Go 版）：
//   1. SIGINT   Ctrl+C
//   2. SIGTERM  systemd stop
//   3. STOP 文件出现在 progress.json 所在目录（每秒轮询）
//
// 触发后：
//   - stopping = true（各处循环检查）
//   - abortController.abort()（触发 abortSignal 传给 fetch/setTimeout 等）
//   - onStop 回调链（顺序执行，用于 transport.close / reporter.flush 等）

const fs = require('fs');
const path = require('path');

class GracefulController {
  constructor() {
    this.stopping = false;
    this.reason = '';
    this._onStopCallbacks = [];
    this._stopFilePath = '';
    this._stopFilePoller = null;
    this._sigHandlers = [];
    // AbortController 传给 rate limiter / http 请求 / 需要打断的 sleep
    this.abortController = new AbortController();
  }

  get abortSignal() {
    return this.abortController.signal;
  }

  /**
   * 初始化并挂载信号 + STOP 文件轮询
   * @param {string} stopFilePath 停止文件的绝对路径
   */
  init(stopFilePath) {
    this._stopFilePath = stopFilePath || '';

    const sigint = () => this._trigger('SIGINT');
    const sigterm = () => this._trigger('SIGTERM');
    process.on('SIGINT', sigint);
    process.on('SIGTERM', sigterm);
    this._sigHandlers.push(
      { sig: 'SIGINT', h: sigint },
      { sig: 'SIGTERM', h: sigterm },
    );

    if (this._stopFilePath) {
      this._stopFilePoller = setInterval(() => {
        try {
          if (fs.existsSync(this._stopFilePath)) {
            // 触发前尝试删除，避免下次启动误触发
            try { fs.unlinkSync(this._stopFilePath); } catch (_) { /* ignore */ }
            this._trigger('STOP-FILE');
          }
        } catch (_) { /* ignore */ }
      }, 1000);
      // 轮询定时器不阻塞进程退出
      if (this._stopFilePoller && typeof this._stopFilePoller.unref === 'function') {
        this._stopFilePoller.unref();
      }
    }
  }

  /**
   * 注册停机回调（顺序执行，串行等待）
   * @param {Function} cb 回调，可返回 Promise
   */
  register(cb) {
    if (typeof cb === 'function') this._onStopCallbacks.push(cb);
  }

  /**
   * 手动触发停机（外部代码遇到不可恢复错误时可调用）
   * @param {string} reason
   */
  triggerManual(reason) {
    this._trigger(reason || 'manual');
  }

  async _trigger(reason) {
    if (this.stopping) return;
    this.stopping = true;
    this.reason = reason;
    process.stderr.write(`\n[graceful] 收到 ${reason}，开始优雅停机...\n`);
    try {
      this.abortController.abort();
    } catch (_) { /* ignore */ }

    // 串行执行 onStop 回调（避免并发关闭副作用）
    for (const cb of this._onStopCallbacks) {
      try {
        await cb(reason);
      } catch (e) {
        process.stderr.write(`[graceful] onStop 回调出错: ${e.message}\n`);
      }
    }

    this._cleanup();
  }

  _cleanup() {
    if (this._stopFilePoller) {
      clearInterval(this._stopFilePoller);
      this._stopFilePoller = null;
    }
    for (const { sig, h } of this._sigHandlers) {
      try { process.removeListener(sig, h); } catch (_) { /* ignore */ }
    }
    this._sigHandlers = [];
  }
}

/**
 * 创建并挂载停机协调器
 * @param {string} stopFilePath
 * @returns {GracefulController}
 */
function init(stopFilePath) {
  const gc = new GracefulController();
  gc.init(stopFilePath);
  return gc;
}

module.exports = { GracefulController, init };
