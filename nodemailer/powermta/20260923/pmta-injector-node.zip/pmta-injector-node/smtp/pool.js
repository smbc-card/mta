'use strict';
// smtp/pool - Nodemailer SMTP transport 封装
//   （对应 Go pmta-injector-clean/smtp/pool.go + client.go 的功能替代）
//
// ★ 关键决策 ★
// 完全用 Nodemailer 的 pool: true 替代 Go 的自实现连接池 + SMTP 事务：
//   - maxConnections   = cfg.smtp.max_conn 或 workers 数（等价 Go PoolSize）
//   - maxMessages      = 100（等价 Go MaxSendPerConn）
//   - socketTimeout    = cfg.smtp.timeout * 1000（毫秒）
//   - connectionTimeout = 10s
//
// 提交邮件时 **只用 sendMail({envelope, raw})**，让 Nodemailer 只做 SMTP 事务，
// 不参与 MIME 组装 —— 反指纹层保留完全控制权（Sprint 3+）。

const nodemailer = require('nodemailer');

class SMTPPool {
  /**
   * @param {Object} smtpCfg config.smtp 子对象
   * @param {number} defaultPoolSize 若 max_conn ≤ 0 时的兜底值
   */
  constructor(smtpCfg, defaultPoolSize) {
    let poolSize = smtpCfg.max_conn > 0 ? smtpCfg.max_conn : (defaultPoolSize || 50);
    // 兜底 clamp（避免异常配置导致资源耗尽）
    if (poolSize < 1) poolSize = 1;
    if (poolSize > 1000) poolSize = 1000;

    const transportOpts = {
      host: smtpCfg.host || '127.0.0.1',
      port: smtpCfg.port || 25,
      // 同机免加密（PMTA <source 127.0.0.1> 段不强制 TLS）
      secure: !!smtpCfg.use_tls && (smtpCfg.port === 465),
      ignoreTLS: !smtpCfg.use_tls,
      requireTLS: !!smtpCfg.use_tls,
      tls: smtpCfg.skip_verify ? { rejectUnauthorized: false } : undefined,
      // 连接池
      pool: true,
      maxConnections: poolSize,
      maxMessages: 100,
      // 超时（毫秒）
      socketTimeout: (smtpCfg.timeout || 30) * 1000,
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      // 关闭 Nodemailer 内建的 X-Mailer/Message-ID 生成 —— 我们 raw 里自带
      disableFileAccess: true,
      disableUrlAccess: true,
    };

    if (smtpCfg.use_auth && smtpCfg.username) {
      transportOpts.auth = {
        user: smtpCfg.username,
        pass: smtpCfg.password || '',
      };
    }
    // 注：Haraka 场景需要 auth（use_auth=true），PMTA 本机 127.0.0.1 场景免 auth

    this.transport = nodemailer.createTransport(transportOpts);
    this.addr = `${transportOpts.host}:${transportOpts.port}`;
    this.stats = { sent: 0, failed: 0 };
  }

  /**
   * 发送单封邮件（用 raw 字节，envelope 单独指定，不让 Nodemailer 组装 MIME）
   * @param {string} envelopeFrom
   * @param {string} envelopeTo
   * @param {Buffer|string} rawMime
   * @returns {Promise<Object>} 返回 Nodemailer 的 info 对象
   */
  async sendRaw(envelopeFrom, envelopeTo, rawMime) {
    try {
      const info = await this.transport.sendMail({
        envelope: { from: envelopeFrom, to: envelopeTo },
        raw: rawMime,
      });
      this.stats.sent++;
      return info;
    } catch (e) {
      this.stats.failed++;
      throw e;
    }
  }

  /**
   * 带重试的发送（对齐 Go SendWithRetry(..., 2 次)）
   * @param {number} maxRetries 重试次数（不含首次尝试）
   */
  async sendRawWithRetry(envelopeFrom, envelopeTo, rawMime, maxRetries) {
    let lastErr = null;
    const total = 1 + (maxRetries || 0);
    for (let i = 0; i < total; i++) {
      try {
        return await this.sendRaw(envelopeFrom, envelopeTo, rawMime);
      } catch (e) {
        lastErr = e;
        // 简单退避：50ms → 200ms → 500ms
        if (i < total - 1) {
          await new Promise((r) => setTimeout(r, 50 * Math.pow(4, i)));
        }
      }
    }
    throw lastErr;
  }

  /**
   * 关闭连接池
   */
  close() {
    if (this.transport && typeof this.transport.close === 'function') {
      try { this.transport.close(); } catch (_) { /* ignore */ }
    }
  }

  getStats() {
    return { addr: this.addr, sent: this.stats.sent, failed: this.stats.failed };
  }
}

/**
 * @param {Object} smtpCfg
 * @param {number} [defaultPoolSize=50]
 * @returns {SMTPPool}
 */
function create(smtpCfg, defaultPoolSize) {
  return new SMTPPool(smtpCfg, defaultPoolSize);
}

module.exports = { SMTPPool, create };
