'use strict';
// reporter - 原子写 progress.json / result.json / errors.log
//   （对应 Go pmta-injector-clean/reporter/reporter.go）
//
// 契约层（C# 端 InjectionManager.GetTaskStatusAsync 会 cat 这些文件解析）：
//   - progress.json: {job_id, status, total, processed, success, failed, rate, eta_seconds, start_time, update_time}
//   - result.json:   {job_id, status, total, success, failed, start_time, end_time, duration_seconds, average_rate, errors[]}
//   - errors.log:    每行 "Line N: email - error_message"
//
// 原子写：先写 .tmp，再 rename。同一文件系统内 rename 原子。

const fs = require('fs');
const path = require('path');

class Reporter {
  /**
   * @param {Object} cfg 完整 config 对象
   */
  constructor(cfg) {
    this.cfg = cfg;
    this.progressFile = cfg.output.progress_file || '';
    this.resultFile = cfg.output.result_file || '';
    this.errorFile = cfg.output.error_file || '';
    // 提前创建目录
    for (const f of [this.progressFile, this.resultFile, this.errorFile]) {
      if (f) {
        try { fs.mkdirSync(path.dirname(f), { recursive: true }); }
        catch (_) { /* ignore */ }
      }
    }
    // 简单串行锁（用 Promise 链避免同一文件的并发写）
    this._writeChain = Promise.resolve();
  }

  /**
   * 更新进度（原子写 progress.json）
   * @param {Object} progress camelCase 字段的 Progress 对象
   */
  async updateProgress(progress) {
    if (!this.progressFile) return;
    const payload = _progressToJSON(progress);
    await this._chain(() => _atomicWriteJSON(this.progressFile, payload));
  }

  /**
   * 保存最终结果（原子写 result.json + 错误详情写 errors.log）
   * @param {Object} result camelCase 字段的 Result 对象
   */
  async saveResult(result) {
    if (this.resultFile) {
      const payload = _resultToJSON(result);
      await this._chain(() => _atomicWriteJSON(this.resultFile, payload));
    }
    if (this.errorFile && result.errors && result.errors.length > 0) {
      await this._chain(() => _writeErrorsLog(this.errorFile, result.errors));
    }
  }

  /** 串行执行（避免同 Reporter 实例的并发写导致 rename 冲突） */
  _chain(fn) {
    this._writeChain = this._writeChain.then(fn, fn);
    return this._writeChain;
  }
}

function _progressToJSON(p) {
  const toISO = (d) => (d instanceof Date) ? d.toISOString() : (d || null);
  return {
    job_id: p.jobId || '',
    status: p.status || '',
    total: p.total || 0,
    processed: p.processed || 0,
    success: p.success || 0,
    failed: p.failed || 0,
    rate: p.rate || 0,
    eta_seconds: p.etaSeconds || 0,
    start_time: toISO(p.startTime),
    update_time: toISO(p.updateTime),
  };
}

function _resultToJSON(r) {
  const toISO = (d) => (d instanceof Date) ? d.toISOString() : (d || null);
  const out = {
    job_id: r.jobId || '',
    status: r.status || '',
    total: r.total || 0,
    success: r.success || 0,
    failed: r.failed || 0,
    start_time: toISO(r.startTime),
    end_time: toISO(r.endTime),
    duration_seconds: r.durationSeconds || 0,
    average_rate: r.averageRate || 0,
  };
  if (r.errors && r.errors.length > 0) {
    out.errors = r.errors.map((e) => ({ email: e.email, error: e.error, line: e.line }));
  }
  return out;
}

async function _atomicWriteJSON(targetPath, obj) {
  const tmp = targetPath + '.tmp';
  const data = JSON.stringify(obj, null, 2);
  await fs.promises.writeFile(tmp, data, { encoding: 'utf8' });
  await fs.promises.rename(tmp, targetPath);
}

async function _writeErrorsLog(errorFile, errors) {
  // 全量覆盖写（对齐 Go 版行为：os.Create）
  const lines = errors.map((e) =>
    `Line ${e.line || 0}: ${e.email || ''} - ${e.error || ''}\n`
  );
  await fs.promises.writeFile(errorFile, lines.join(''), { encoding: 'utf8' });
}

/**
 * @param {Object} cfg
 * @returns {Reporter}
 */
function create(cfg) {
  return new Reporter(cfg);
}

module.exports = { Reporter, create };
