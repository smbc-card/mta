'use strict';
// injector - 双模式邮件注入器（对应 Go pmta-injector-clean/injector/injector.go）
//
// SMTP 模式（默认，cfg.smtp.enabled=true）：
//   通过 Nodemailer transport 提交到 127.0.0.1:25（PMTA）
//
// Pickup 模式（cfg.smtp.enabled=false 且 cfg.pmta.pickup_dir 非空）：
//   写 .eml 文件到 pickup 目录，PMTA 自动扫描取走
//   流程：写 temp 目录 → 原子 rename 到 pickup 目录（同一文件系统内 rename 原子）

const fs = require('fs');
const path = require('path');
const smtpPool = require('../smtp/pool');
const utils = require('../utils/utils');

const MODE_SMTP = 'smtp';
const MODE_PICKUP = 'pickup';

class Injector {
  constructor(cfg) {
    this.cfg = cfg;
    this.mode = '';
    this.enabled = false;
    this.pool = null;              // SMTPPool 实例（SMTP 模式）
    this.pickupDir = '';           // Pickup 模式
    this.tempDir = '';
    this.fileMode = 0o644;
    this.fileSeq = 0;              // 原子递增（Node 单线程，普通 ++ 即原子）
    this.counter = 0;              // 成功注入计数

    if (cfg.smtp.enabled) {
      this._initSMTP();
    } else if (cfg.pmta.pickup_dir) {
      this._initPickup();
    }
    // 都不满足时保持 enabled=false，Inject 会返回错误
  }

  _initSMTP() {
    const wanted = this.cfg.smtp.max_conn > 0
      ? this.cfg.smtp.max_conn
      : Math.max(10, Math.min(100, this.cfg.performance.workers || 50));
    this.pool = smtpPool.create(this.cfg.smtp, wanted);
    this.mode = MODE_SMTP;
    this.enabled = true;
  }

  _initPickup() {
    this.pickupDir = this.cfg.pmta.pickup_dir;
    this.tempDir = this.cfg.pmta.temp_dir || this.pickupDir;
    this.fileMode = this.cfg.pmta.file_mode || 0o644;

    _ensureDirWritable(this.pickupDir);
    if (this.tempDir !== this.pickupDir) {
      _ensureDirWritable(this.tempDir);
    }

    this.mode = MODE_PICKUP;
    this.enabled = true;
  }

  /**
   * 注入单封邮件（根据模式自动分发）
   * @param {Object} email {envelopeFrom, envelopeTo, raw (Buffer|string)}
   */
  async inject(email) {
    if (!this.enabled) {
      throw new Error('注入器未启用（smtp.enabled=false 且 pmta.pickup_dir 未配置）');
    }
    if (this.mode === MODE_SMTP) {
      await this._injectSMTP(email);
    } else if (this.mode === MODE_PICKUP) {
      await this._injectPickup(email);
    } else {
      throw new Error(`未知的注入模式: ${this.mode}`);
    }
    this.counter++;
  }

  async _injectSMTP(email) {
    if (!this.pool) throw new Error('SMTP 连接池未初始化');
    // 重试 2 次（对齐 Go SendWithRetry(..., 2)）
    await this.pool.sendRawWithRetry(email.envelopeFrom, email.envelopeTo, email.raw, 2);
  }

  async _injectPickup(email) {
    this.fileSeq++;
    // 文件名：msg_{unixNano}_{seq}.eml（对齐 Go time.Now().UnixNano()）
    // 关键：用 utils.nowUnixNano()（BigInt = ms*1e6 + 低 6 位随机）而不是 process.hrtime.bigint()
    // 后者是进程启动后经过的纳秒（不是 unix 纪元），会让 pickup 扫描器按文件名排序时乱序
    const ns = utils.nowUnixNano().toString();
    const seqStr = String(this.fileSeq).padStart(8, '0');
    const filename = `msg_${ns}_${seqStr}.eml`;
    const tempPath = path.join(this.tempDir, filename);
    const finalPath = path.join(this.pickupDir, filename);

    // 写 temp
    const rawBuf = Buffer.isBuffer(email.raw) ? email.raw : Buffer.from(String(email.raw), 'utf8');
    await fs.promises.writeFile(tempPath, rawBuf, { mode: this.fileMode });

    // 原子 rename 到 pickup
    try {
      await fs.promises.rename(tempPath, finalPath);
    } catch (e) {
      try { await fs.promises.unlink(tempPath); } catch (_) { /* ignore */ }
      throw new Error(`移动到 pickup 目录失败 [${tempPath} → ${finalPath}]: ${e.message}`);
    }
  }

  /**
   * 关闭注入器（释放 SMTP 连接池等资源）
   */
  close() {
    if (this.pool) {
      this.pool.close();
      this.pool = null;
    }
  }

  getMode() { return this.mode; }
  getCounter() { return this.counter; }
  isEnabled() { return this.enabled; }
  getStats() {
    if (this.pool) {
      return this.pool.getStats();
    }
    return { addr: '', sent: 0, failed: 0 };
  }
}

function _ensureDirWritable(dir) {
  let st;
  try {
    st = fs.statSync(dir);
  } catch (e) {
    throw new Error(`目录不存在 [${dir}]: ${e.message}`);
  }
  if (!st.isDirectory()) {
    throw new Error(`路径不是目录: ${dir}`);
  }
  const testFile = path.join(dir, '.write_test');
  try {
    fs.writeFileSync(testFile, '');
    fs.unlinkSync(testFile);
  } catch (e) {
    throw new Error(`目录不可写 [${dir}]: ${e.message}`);
  }
}

/**
 * @param {Object} cfg
 * @returns {Injector}
 */
function create(cfg) {
  return new Injector(cfg);
}

module.exports = { Injector, create, MODE_SMTP, MODE_PICKUP };
