#!/usr/bin/env node
// pmta-injector - PowerMTA high-throughput email injector (Node port)
//
// 变体编译占位符（deploy-injector-node.sh 会按 InjectorVariant 值 sed 替换）：
//   __VERSION_PLACEHOLDER__     版本号（如 4.12.37）
//   __BUILDTIME_PLACEHOLDER__   构建时间戳（ISO8601）
//   __GITCOMMIT_PLACEHOLDER__   40 字节 hex git commit（伪造）
//
// __MODULE_PLACEHOLDER__ 仅出现在 package.json 的 name 字段（Node 端 require 走相对路径，
// 不像 Go 那样在业务代码里被广泛引用）。
'use strict';

const VERSION    = '__VERSION_PLACEHOLDER__';
const BUILD_TIME = '__BUILDTIME_PLACEHOLDER__';
const GIT_COMMIT = '__GITCOMMIT_PLACEHOLDER__';

const { execute } = require('./cmd/root');

execute(VERSION, BUILD_TIME, GIT_COMMIT).catch((err) => {
  const msg = err && err.message ? err.message : String(err);
  process.stderr.write(`Error: ${msg}\n`);
  process.exit(1);
});
