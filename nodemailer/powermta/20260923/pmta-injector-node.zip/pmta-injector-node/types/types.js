'use strict';
// types - 数据类型定义（对应 Go pmta-injector-clean/types/types.go）
//
// Node 无静态类型，用 JSDoc typedef 提供 IDE 补全 + 文档。
// 内部字段用 camelCase；序列化到 JSON 时经 *ToJSON 函数转 snake_case 以与 Go 版
// JSON tag 保持一致（progress.json / result.json 是 C# 端要解析的契约）。

/**
 * @typedef {Object} Recipient
 * @property {string} email
 * @property {string} name
 * @property {string} firstName
 * @property {string} lastName
 * @property {Object<string,string>} [customFields]
 */

/**
 * @typedef {Object} ErrorInfo
 * @property {string} email
 * @property {string} error
 * @property {number} line
 */

/**
 * @typedef {Object} Result
 * @property {string} jobId
 * @property {string} status
 * @property {number} total
 * @property {number} success
 * @property {number} failed
 * @property {Date|null} startTime
 * @property {Date|null} endTime
 * @property {number} durationSeconds
 * @property {number} averageRate
 * @property {ErrorInfo[]} [errors]
 */

/**
 * @typedef {Object} Progress
 * @property {string} jobId
 * @property {string} status
 * @property {number} total
 * @property {number} processed
 * @property {number} success
 * @property {number} failed
 * @property {number} rate
 * @property {number} etaSeconds
 * @property {Date|null} startTime
 * @property {Date|null} updateTime
 */

// ─────────────────────────────────────────────────────────────
// 构造函数（返回默认对象，其他模块创建新实例用）
// ─────────────────────────────────────────────────────────────

function newRecipient() {
  return { email: '', name: '', firstName: '', lastName: '', customFields: {} };
}

function newResult(jobId) {
  return {
    jobId: jobId || '',
    status: 'pending',
    total: 0,
    success: 0,
    failed: 0,
    startTime: null,
    endTime: null,
    durationSeconds: 0,
    averageRate: 0,
    errors: [],
  };
}

function newProgress(jobId) {
  return {
    jobId: jobId || '',
    status: 'pending',
    total: 0,
    processed: 0,
    success: 0,
    failed: 0,
    rate: 0,
    etaSeconds: 0,
    startTime: null,
    updateTime: null,
  };
}

// ─────────────────────────────────────────────────────────────
// 序列化到 snake_case JSON（progress.json / result.json 契约）
// ─────────────────────────────────────────────────────────────

function errorInfoToJSON(e) {
  return { email: e.email, error: e.error, line: e.line };
}

function resultToJSON(r) {
  const out = {
    job_id: r.jobId,
    status: r.status,
    total: r.total,
    success: r.success,
    failed: r.failed,
    start_time: r.startTime,
    end_time: r.endTime,
    duration_seconds: r.durationSeconds,
    average_rate: r.averageRate,
  };
  if (r.errors && r.errors.length > 0) {
    out.errors = r.errors.map(errorInfoToJSON);
  }
  return out;
}

function progressToJSON(p) {
  return {
    job_id: p.jobId,
    status: p.status,
    total: p.total,
    processed: p.processed,
    success: p.success,
    failed: p.failed,
    rate: p.rate,
    eta_seconds: p.etaSeconds,
    start_time: p.startTime,
    update_time: p.updateTime,
  };
}

module.exports = {
  newRecipient,
  newResult,
  newProgress,
  resultToJSON,
  errorInfoToJSON,
  progressToJSON,
};