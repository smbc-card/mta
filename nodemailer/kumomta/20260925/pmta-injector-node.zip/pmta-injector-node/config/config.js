'use strict';
// config - YAML 配置加载与默认值（对应 Go pmta-injector-clean/config/config.go）
//
// ★ 契约层 ★
// YAML key 名与 Go 端 yaml tag 保持字节级一致（C# InjectionManager.GenerateConfigYaml
// 生成的 YAML 无需改动，Node 端只是被动消费）。
//
// 内部字段全用 snake_case（不做 camelCase 转换），减少心智负担，方便与 Go 源码对照。

const fs = require('fs');
const os = require('os');
const yaml = require('js-yaml');

// ═════════════════════════════════════════════════════════════
// defaults - 返回默认配置，逐字段对应 Go config.Default()
// ═════════════════════════════════════════════════════════════
function defaults() {
  return {
    // ── app ──
    app: {
      name: 'pmta-injector',
      version: '2.0.0',
      log_level: 'info',
      log_file: '/var/log/pmta-injector/app.log',
    },

    // ── MTA 类型（PMTA 端本项目固定 'pmta'，容忍字段存在为兼容 Haraka 端）──
    mta_type: 'pmta',

    // ── sender ──
    sender: {
      mode: 'auto',
      from_address: 'noreply@example.com',
      from_name: 'Example Company',
      envelope_from: '',
      reply_to: '',
      display_names: [],
      display_name_mode: 'random',
      display_name_bidi_reverse: false,   // 2026-06-17 RLO 反转（显示名）
      org_domain: '',                      // 2026-07-23 P0-2 组织域
    },

    // ── PMTA 输出 ──
    pmta: {
      virtual_mta: 'pmta-vmta1',
      pickup_dir: '/var/spool/pmta/pickup',
      temp_dir: '/var/spool/pmta/tmp',
      file_mode: 0o644,
      dir_mode: 0o755,
    },

    // ── SMTP 提交 ──
    smtp: {
      enabled: true,
      host: '127.0.0.1',
      port: 25,
      use_auth: false,
      username: '',
      password: '',
      use_tls: false,
      skip_verify: true,
      timeout: 30,
      max_conn: 50,
    },

    // ── 性能 ──
    performance: {
      workers: os.cpus().length * 10,
      rate_limit: 0,
      batch_size: 1000,
      channel_buffer: 10000,
      memory_warning_mb: 500,
      progress_interval: 1,
      min_interval: 0,
      max_interval: 100,
      batch_pause: 5,
      retry_count: 3,
      retry_interval: 1000,
    },

    // ── email 主体 ──
    email: {
      subject: 'Welcome',
      subjects: [],
      subject_mode: 'random',
      subject_bidi_reverse: false,         // 2026-06-17 RLO 反转（主题）
      template_path: '',
      template_paths: [],
      template_mode: 'random',
      convert_txt_to_html: true,
      charset: 'UTF-8',
      content_type: 'text/html',
      include_text_part: false,
      mime_mode: 'standard',               // standard | alternative | full
      custom_headers: {},
      embedded_images: [],                 // Haraka24 CID 内嵌图片
    },

    // ── 附件（含 2026-06-17 自定义随机附件 13 字段）──
    attachments: {
      enabled: false,
      mode: 'sequential',
      files: [],
      custom: {
        enabled: false,
        name_mode: 'random',              // random | fixed
        name_min: 0,
        name_max: 0,
        fixed_name: '',
        suffix_mode: 'random',            // random | fixed
        suffix_min: 0,
        suffix_max: 0,
        fixed_suffix: '',
        content_lines_min: 0,
        content_lines_max: 0,
        content_chars_min: 0,
        content_chars_max: 0,
      },
    },

    // ── 收件人 ──
    recipients: {
      file_path: '',
      format: 'auto',
      skip_lines: 0,
      csv: {
        delimiter: ',',
        has_header: true,
        field_mapping: {},
      },
      remove_duplicates: true,
      filter_invalid: true,
    },

    // ── job ──
    job: {
      id: '',
      id_prefix: 'job',
      include_in_header: true,
    },

    // ── output ──
    output: {
      progress_interval: 1,
      show_progress_bar: true,
      progress_file: '/tmp/progress.json',
      result_file: '/tmp/result.json',
      error_file: '/tmp/errors.log',
      save_log: true,
      save_failed_emails: true,
      log_directory: '/var/log/pmta-injector',
    },

    // ── template ──
    template: {
      global_variables: {},
    },

    // ── encoding ──
    encoding: {
      charset: 'UTF-8',
      header_encoding: 'base64',
      body_encoding: 'base64',
      random_encoding: false,
    },

    // ── variables（金额生成 + 自定义变量文件）──
    variables: {
      amount_min: 10000,
      amount_max: 100000,
      amount_decimals: 0,
      amount_use_separator: true,
      custom_variable_files: {},
    },

    // ═════════════════════════════════════════════════════════
    // headers - 邮件头总控（~70 字段，最大的一段）
    // ═════════════════════════════════════════════════════════
    headers: {
      // ── 基础 15 项 ──
      enabled: false,
      received: false,
      dkim_signature: false,
      x_mailer: false,
      x_priority: false,
      x_priority_value: 'random',
      importance: false,
      importance_value: 'random',
      message_id: false,
      reply_to: false,
      reply_to_mode: 'from_address',
      return_path: false,
      return_path_mode: 'from_address',
      accept_language: false,
      accept_language_value: 'random',
      content_language: false,
      content_language_value: 'random',
      custom_headers_text: '',

      // ── Haraka26 自定义 From ──
      custom_from_enabled: false,
      custom_from_mode: 'sequential',
      custom_from_emails: [],

      // ── Haraka26 显示名 \r\n ──
      display_name_newline: false,

      // ── P0 送达率刚需 (4 项) ──
      list_unsubscribe: false,
      list_unsubscribe_post: false,
      feedback_id: false,
      precedence: false,

      // ── P1 反指纹 (9 项) ──
      errors_to: false,
      sender: false,
      organization: false,
      x_originating_ip: false,
      auto_submitted: false,
      comments: false,
      keywords: false,
      x_report_abuse: false,
      x_csa_complaints: false,

      // ── P2 Outlook (4 项) ──
      x_msmail_priority: false,
      thread_index: false,
      thread_topic: false,
      x_auto_response_suppress: false,

      // ── P2 行为标识 (3 项) ──
      return_receipt_to: false,
      disposition_notification_to: false,
      x_entity_ref_id: false,

      // ── P3 营销 (3 项) ──
      x_campaign_id: false,
      x_mailer_lid: false,
      campaign_id: false,

      // ── P3 联动组 (2 项) ──
      x_tm_as_group: false,      // Trend Micro 6 头联动
      x_sfmc_group: false,       // Salesforce MC 2 头联动

      // ── 4 企业网关联动 (2026-05-18 新增) ──
      x_barracuda_group: false,
      x_proofpoint_group: false,
      x_mimecast_group: false,
      x_symantec_group: false,

      // ── v2 5 个新独立头 (2026-05-15) ──
      list_id: false,
      x_originating_email: false,
      x_mime_ole: false,
      x_mailer_version: false,
      x_original_arrival_time: false,

      // ── 5 ESP Received (2026-05-20) 特殊独立开关，不进随机池 ──
      received_yahoo: false,
      received_yahoo_ip_mode: 'yahoo',   // 'yahoo' | 'random'
      received_au: false,
      received_softbank: false,
      received_docomo: false,
      received_mitsui: false,

      // ── 随机使用邮件头（Worker 级 50-200 封寿命） ──
      random_enabled: false,
      random_min: 1,   // [1, 10]
      random_max: 10,  // [1, 10]

      // ── Message-ID 25 风格 (2026-06-17) ──
      message_id_random_all: false,
      message_id_styles: [],

      // ── Message-ID 主域策略 (2026-07-23 P0-2) ──
      message_id_use_org_domain: false,

      // ── DKIM h= 自定义 (2026-07-23 P2-8 + 2026-07-25 方案 β) ──
      dkim_h_fields_custom_enabled: false,   // 方案 B 是否启用（受 Scope 影响）
      dkim_h_fields_list: [],                // 字段名列表（大小写不敏感）
      dkim_h_fields_master_enabled: false,   // 方案 β UI 主开关（独立于 Scope）

      // ── Return-Path 简洁化标志 (2026-07-23 P1-7) ──
      // Go 端不消费此字段（真正生效在 PMTA config verp-default no），仅记录状态
      simple_return_path: false,

      // ── Received (随机) 模板池 (2026-05-24 批次 2) ──
      received_random_enabled: false,
      received_random_mode: 'random',   // sequential | random
      received_random_templates: [],

      // ── List-Unsubscribe 4 模式 (2026-05-24) ──
      list_unsub_mode: 'default',       // default | real | custom | random
      list_unsub_real_templates: [],
      list_unsub_real_mode: 'random',
      list_unsub_custom_templates: [],
      list_unsub_custom_mode: 'random',
      list_unsub_random_templates: [],
      list_unsub_random_mode: 'random',

      // ── 字段名随机大小写 + 锚定式乱序 (2026-05-31) ──
      random_case: false,
      shuffle_order: false,
      case_mode: '',                    // 空 = 'random'（默认）；预留 'stylepool' 切换点
    },

    // ── Haraka26 零宽字符 ──
    zero_width: {
      enabled: false,
      subject: false,
      display_name: false,
      template_content: false,
    },

    // ── Haraka26 图片噪点 ──
    image_noise: {
      enabled: false,
    },

    // ── 退订 HTTP 服务器配置 (serve 子命令消费) ──
    unsubscribe_server: {
      enabled: false,
      listen_http: ':80',
      listen_https: ':443',
      cert_file: '',
      key_file: '',
      domain: '',
    },

    // ── CC/BCC 三组对称 (2026-05-26) ──
    // recipient.enabled=false 时跳过 Email 为空的合成主收件人，
    // 但仍触发 CC/BCC 独立邮件循环（由 CC/BCC 池本身驱动）
    recipient: {
      enabled: true,
    },
    cc: {
      enabled: false,
      file_path: '',   // 远端 cc.txt 绝对路径
      per_email: 1,    // 每封主邮件对应的 CC 数（消费完即停）
    },
    bcc: {
      enabled: false,
      file_path: '',
      per_email: 1,
    },

    // ── 运行标志（不来自 YAML，命令行 --dry-run 设置）──
    dry_run: false,
  };
}

// ═════════════════════════════════════════════════════════════
// deepMerge - 递归合并 source 到 target
//   - source 里的 undefined 保留 target 原值
//   - source 里的 null 会覆盖 target 为 null（对齐 yaml.load 空值语义）
//   - 数组不合并（source 数组整体覆盖 target）
//   - 对象递归合并
// ═════════════════════════════════════════════════════════════
function deepMerge(target, source) {
  if (source === null || source === undefined) return target;
  if (typeof source !== 'object' || Array.isArray(source)) return source;

  for (const key of Object.keys(source)) {
    const sv = source[key];
    const tv = target[key];

    if (sv === undefined) continue;
    if (sv === null) { target[key] = null; continue; }

    if (typeof sv === 'object' && !Array.isArray(sv) &&
        typeof tv === 'object' && tv !== null && !Array.isArray(tv)) {
      deepMerge(tv, sv);
    } else {
      target[key] = sv;
    }
  }
  return target;
}

// ═════════════════════════════════════════════════════════════
// loadFromFile - 从 YAML 文件加载配置
// ═════════════════════════════════════════════════════════════
function loadFromFile(filePath) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, 'utf8');
  } catch (e) {
    throw new Error(`读取配置文件失败: ${e.message}`);
  }

  // 【R1 P0-A 修复】YAML billion laughs 攻击防护
  //   js-yaml v4 无 alias 数量/深度限制,恶意 YAML(如 &a [1,1..] *a *a *a...)
  //   展开为 10^10 元素 → OOM crash → 拒绝服务
  //   前置检测: 数 raw 里 alias 数量(*name pattern),超阈值直接拒
  //   正常 config.yaml 几乎无 alias(应≤5), 50 是极宽松阈值
  //   信任模型: config.yaml 由 C# SSH 上传,SSH 中间人/本地误改是唯一攻击面
  const aliasMatches = raw.match(/[*&][A-Za-z0-9_-]+/g) || [];
  if (aliasMatches.length > 50) {
    throw new Error(`配置文件 YAML alias 数量 ${aliasMatches.length} > 50,拒绝加载(疑似 billion laughs 攻击)`);
  }

  let parsed;
  try {
    parsed = yaml.load(raw) || {};
  } catch (e) {
    throw new Error(`解析配置文件失败: ${e.message}`);
  }

  // 【R1 P0-A 修复】后置大小校验兜底: 展开后 > 5MB 拒(正常 config.yaml < 100KB)
  //   若 alias 逃过前置检测但展开异常大,仍能拦住
  //   注意: stringify 本身可能对巨型对象 OOM, 但 V8 heap 默认 1.5GB, parsed 若真是 GB 级
  //   yaml.load 阶段已 OOM, 到不了这里 → 双层防御
  try {
    const expandedSize = JSON.stringify(parsed).length;
    if (expandedSize > 5 * 1024 * 1024) {
      throw new Error(`配置文件展开后 ${expandedSize} 字节 > 5MB 上限,拒绝加载`);
    }
  } catch (e) {
    if (e.message && e.message.startsWith('配置文件展开')) throw e;
    // stringify 失败(循环引用等)直接拒
    throw new Error(`配置文件结构异常,无法序列化校验: ${e.message}`);
  }

  const cfg = defaults();
  deepMerge(cfg, parsed);

  // 与 Go LoadFromFile 一致的补齐逻辑
  if (!cfg.sender.envelope_from) {
    cfg.sender.envelope_from = cfg.sender.from_address;
  }
  if (!cfg.performance.workers || cfg.performance.workers <= 0) {
    cfg.performance.workers = os.cpus().length * 10;
  }

  return cfg;
}

// ═════════════════════════════════════════════════════════════
// MTA 类型便捷判定
// ═════════════════════════════════════════════════════════════
function isPMTA(cfg) {
  // 【Sprint 5 2026-09-25 KumoMTA 兼容】C# 端 InjectionManager.GenerateConfigYaml 输出 mta_type="kumo"
  //   (KumoMTA 2026-06-02 决策保留语义清晰的 "kumo" 值)。KumoMTA 走 SMTP 127.0.0.1:25 免认证与 PMTA 同源,
  //   故 Node 端 isPMTA 兼容 "kumo" —— 让未来 Node 端若加消费此判定时行为对齐 Go 端 IsPMTA()。
  //   当前 Node 端无代码消费 isPMTA/isHaraka(0 grep hit),改一行零风险 + 语义防御性对齐。
  return !cfg.mta_type || cfg.mta_type === 'pmta' || cfg.mta_type === 'kumo';
}

function isHaraka(cfg) {
  return cfg.mta_type === 'haraka';
}

module.exports = {
  defaults,
  loadFromFile,
  deepMerge,
  isPMTA,
  isHaraka,
};
