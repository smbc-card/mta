// pmta-injector v2 - PowerMTA 反指纹邮件注入程序(重写版)
//
// 【Week 2 Day 10 收官】main.go 恢复标准入口:
//   1. 设置版本信息(占位符由 C# 部署脚本或 -ldflags 注入)
//   2. 调用 cmd.Execute() 走 cobra 命令分发
//
// 【契约 §3.2】3 个版本占位符必须保持:__VERSION_PLACEHOLDER__ / __BUILDTIME_PLACEHOLDER__ / __GITCOMMIT_PLACEHOLDER__
// 【契约 §3.1】__MODULE_PLACEHOLDER__ 是合法 Go 模块名,C# 部署时可选替换
package main

import (
	"fmt"
	"os"

	"__MODULE_PLACEHOLDER__/cmd"
)

// 版本信息(编译时由 C# 部署脚本或 -ldflags 注入)—— 契约 §3.2
var (
	Version   = "__VERSION_PLACEHOLDER__"
	BuildTime = "__BUILDTIME_PLACEHOLDER__"
	GitCommit = "__GITCOMMIT_PLACEHOLDER__"
)

func main() {
	// 注入版本信息到 cmd 包(供 version 子命令读取)
	cmd.SetVersionInfo(Version, BuildTime, GitCommit)

	// 执行 cobra 根命令 —— 契约 §2.6 退出码语义
	if err := cmd.Execute(); err != nil {
		// cobra 内部已经打印过 error(RunE 返回值),这里只负责退出码
		fmt.Fprintln(os.Stderr, "错误:", err)
		os.Exit(1)
	}
}
