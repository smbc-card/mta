package cmd

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/spf13/cobra"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
	"__MODULE_PLACEHOLDER__/internal/variables/basic"
)

// validate 命令的 2 个 flag(契约 §2.3)
var (
	validateTemplate  string
	validateSampleData string
)

var validateCmd = &cobra.Command{
	Use:   "validate",
	Short: "验证配置和模板",
	Long: `验证配置文件和邮件模板是否正确(契约 §2.3)。

三段独立校验(每段互不阻断):
  1. 配置文件(仅当传 --config 时执行)
  2. 模板文件(仅当传 --template 时执行)
  3. Pickup 目录(仅当传 --config 时执行,警告级)

示例:
  pmta-injector validate --config config.yaml
  pmta-injector validate --template template.html --sample-data '{"Email":"test@x.com","Name":"John"}'`,
	RunE: runValidate,
}

func init() {
	validateCmd.Flags().StringVarP(&validateTemplate, "template", "t", "", "模板文件路径")
	validateCmd.Flags().StringVar(&validateSampleData, "sample-data", "", "示例数据(JSON格式)")

	rootCmd.AddCommand(validateCmd)
}

func runValidate(cmd *cobra.Command, args []string) error {
	fmt.Println("═══════════════════════════════════════════════════════════════")
	fmt.Println("                    配置和模板验证")
	fmt.Println("═══════════════════════════════════════════════════════════════")

	// 【A9 修 2026-08-13】三段校验补齐:config + template(含渲染)+ pickup 目录(警告级)
	var cfg *config.Config
	if cfgFile != "" {
		var err error
		cfg, err = validateConfigSection()
		if err != nil {
			return err
		}
	}
	if validateTemplate != "" {
		if err := validateTemplateSection(); err != nil {
			return err
		}
	}
	// pickup 目录校验(cfg 加载成功 && PickupDir 非空)—— 警告级,不 return err
	if cfg != nil && cfg.PMTA.PickupDir != "" {
		validatePickupDirSection(cfg.PMTA.PickupDir)
	}
	if cfgFile == "" && validateTemplate == "" {
		mustPrintlnErr("请至少传入 --config 或 --template 之一")
	}

	fmt.Println("\n═══════════════════════════════════════════════════════════════")
	fmt.Println("                      验证完成")
	fmt.Println("═══════════════════════════════════════════════════════════════")
	return nil
}

func validateConfigSection() (*config.Config, error) {
	fmt.Printf("\n[配置文件验证]\n")
	fmt.Printf("  文件: %s\n", cfgFile)
	cfg, err := config.LoadFromFile(cfgFile)
	if err != nil {
		fmt.Printf("  状态: ❌ 失败\n")
		fmt.Printf("  错误: %v\n", err)
		return nil, err
	}
	fmt.Printf("  状态: ✅ 通过\n")

	fmt.Printf("\n  [配置摘要]\n")
	fmt.Printf("    发件人: %s <%s>\n", cfg.Sender.FromName, cfg.Sender.FromAddress)
	fmt.Printf("    虚拟MTA: %s\n", cfg.PMTA.VirtualMTA)
	fmt.Printf("    投递路径: %s\n", inferInjectionPath(cfg))
	fmt.Printf("    并发数: %d\n", cfg.Performance.Workers)
	return cfg, nil
}

// validatePickupDirSection 契约 §2.3 point 4 + cli H1 修 2026-08-13:
// PickupDir 存在性 + 写权限探测;失败仅打印警告,不 return err(warning-level)
func validatePickupDirSection(pickupDir string) {
	fmt.Printf("\n[Pickup 目录验证](警告级)\n")
	fmt.Printf("  路径: %s\n", pickupDir)

	info, err := os.Stat(pickupDir)
	if os.IsNotExist(err) {
		fmt.Printf("  状态: ⚠️  目录不存在(send 时会 MkdirAll,若父目录无写权限会失败)\n")
		return
	}
	if err != nil {
		fmt.Printf("  状态: ⚠️  Stat 失败: %v\n", err)
		return
	}
	if !info.IsDir() {
		fmt.Printf("  状态: ⚠️  路径存在但不是目录\n")
		return
	}

	// 写权限探测:创建临时文件后删除
	testFile := filepath.Join(pickupDir, ".pmta_validate_write_test")
	f, err := os.Create(testFile)
	if err != nil {
		fmt.Printf("  状态: ⚠️  目录存在但无写入权限: %v\n", err)
		return
	}
	_ = f.Close()
	_ = os.Remove(testFile)
	fmt.Printf("  状态: ✅ 目录存在且可写\n")
}

// inferInjectionPath 从 config 推断实际投递路径(契约 §1.5 优先级)
func inferInjectionPath(cfg *config.Config) string {
	if cfg.SMTP.Enabled {
		return fmt.Sprintf("SMTP → %s:%d", cfg.SMTP.Host, cfg.SMTP.Port)
	}
	if cfg.PMTA.PickupDir != "" {
		return fmt.Sprintf("Pickup → %s (⚠️ DEPRECATED)", cfg.PMTA.PickupDir)
	}
	return "disabled"
}

func validateTemplateSection() error {
	fmt.Printf("\n[模板文件验证]\n")
	fmt.Printf("  文件: %s\n", validateTemplate)

	// 【A9 修 2026-08-13】v2 无 Go html/template 引擎(v2 用 {VAR} 花括号处理器),
	// 所以"语法解析"退化为"文件可读 + 有内容";如传 --sample-data,走 basic.Processor 试渲染
	info, err := os.Stat(validateTemplate)
	if os.IsNotExist(err) {
		fmt.Printf("  状态: ❌ 文件不存在\n")
		return fmt.Errorf("template %q not found", validateTemplate)
	}
	if err != nil {
		fmt.Printf("  状态: ❌ Stat 失败: %v\n", err)
		return err
	}
	if info.IsDir() {
		fmt.Printf("  状态: ❌ 是目录而非文件\n")
		return fmt.Errorf("template %q is a directory", validateTemplate)
	}
	if info.Size() == 0 {
		fmt.Printf("  状态: ⚠️  文件为空\n")
	} else {
		fmt.Printf("  状态: ✅ 文件存在(%d 字节)\n", info.Size())
	}

	// --sample-data 分支:试渲染
	if validateSampleData != "" {
		tmplData, err := os.ReadFile(validateTemplate)
		if err != nil {
			fmt.Printf("  ❌ 模板读取失败: %v\n", err)
			return err
		}

		var raw map[string]any
		if err := json.Unmarshal([]byte(validateSampleData), &raw); err != nil {
			fmt.Printf("  ❌ 示例数据 JSON 解析失败: %v\n", err)
			return fmt.Errorf("sample-data JSON: %w", err)
		}

		// JSON → basic.Recipient(标准字段映射;其他键入 CustomFields)
		rcpt := &basic.Recipient{CustomFields: make(map[string]string)}
		for k, v := range raw {
			sv, _ := v.(string)
			if sv == "" {
				if v != nil {
					sv = fmt.Sprintf("%v", v)
				}
			}
			switch k {
			case "email", "Email":
				rcpt.Email = sv
			case "name", "Name":
				rcpt.Name = sv
			case "firstname", "FirstName", "first_name":
				rcpt.FirstName = sv
			case "lastname", "LastName", "last_name":
				rcpt.LastName = sv
			default:
				rcpt.CustomFields[k] = sv
			}
		}

		// 用 basic.Processor 试渲染(不含 extended/混淆/编码,只做变量替换预览)
		proc := basic.New(random.NewFixedSource(42), clock.NewSystemClock(), &basic.Config{
			Custom: map[string][]string{},
		})
		rendered := proc.Process(string(tmplData), rcpt)

		fmt.Printf("\n  [渲染预览(前 500 字符)]\n")
		preview := rendered
		if len(preview) > 500 {
			preview = preview[:500] + "..."
		}
		fmt.Printf("  %s\n", preview)
	}
	return nil
}
