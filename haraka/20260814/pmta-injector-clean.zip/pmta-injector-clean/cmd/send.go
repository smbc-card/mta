package cmd

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"time"

	"github.com/spf13/cobra"

	"__MODULE_PLACEHOLDER__/internal/app/bootstrap"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/telemetry"
)

// send 命令的 17 个 flag(契约 §2.2)—— 全部定义,--resume 标 DEPRECATED
var (
	recipientsFile string
	templateFile   string
	subject        string
	fromAddress    string
	fromName       string
	envelopeFrom   string
	vmta           string
	jobID          string
	workers        int
	rateLimit      int
	pickupDir      string
	tempDir        string
	progressFile   string
	resultFile     string
	dryRun         bool
	resume         bool // DEPRECATED —— v1 定义未消费,v2 保留字段防破坏 C# 脚本(契约 §2.2)
	skipLines      int
)

var sendCmd = &cobra.Command{
	Use:   "send",
	Short: "发送邮件",
	Long: `发送邮件到 PowerMTA(Pickup 或 SMTP)/Haraka(SMTP)。

【投递路径优先级】(契约 §1.5):
  - SMTP.Enabled=true → 走 SMTP(生产 PMTA 也走这条,发到 127.0.0.1:25)
  - SMTP.Enabled=false + PMTA.PickupDir != "" → 走 pickup(DEPRECATED,PMTA 5.0r8 不接受)

【示例】:
  pmta-injector send --config /etc/pmta-injector/config.yaml
  pmta-injector send --config config.yaml --dry-run
  pmta-injector send --config config.yaml --workers 200 --rate-limit 50000`,
	RunE: runSend,
}

func init() {
	// 17 个 flag(契约 §2.2 —— 一个都不能少)
	sendCmd.Flags().StringVarP(&recipientsFile, "recipients", "r", "", "收件人文件路径 (CSV/JSON)")
	sendCmd.Flags().StringVarP(&templateFile, "template", "t", "", "邮件模板文件路径")
	sendCmd.Flags().StringVarP(&subject, "subject", "s", "", "邮件主题")
	sendCmd.Flags().StringVarP(&fromAddress, "from", "f", "", "发件人地址")
	sendCmd.Flags().StringVar(&fromName, "from-name", "", "发件人显示名")
	sendCmd.Flags().StringVar(&envelopeFrom, "envelope-from", "", "信封发件人(用于退信)")
	sendCmd.Flags().StringVar(&vmta, "vmta", "", "虚拟MTA名称")
	sendCmd.Flags().StringVar(&jobID, "job-id", "", "任务ID(留空自动生成)")
	sendCmd.Flags().IntVarP(&workers, "workers", "w", 0, "并发工作协程数")
	sendCmd.Flags().IntVar(&rateLimit, "rate-limit", 0, "每秒最大发送数(0=不限制)")
	sendCmd.Flags().StringVar(&pickupDir, "pickup-dir", "", "Pickup目录路径(DEPRECATED,PMTA 5.0r8 不接受 pickup)")
	sendCmd.Flags().StringVar(&tempDir, "temp-dir", "", "临时目录路径(DEPRECATED,同上)")
	sendCmd.Flags().StringVar(&progressFile, "progress-file", "", "进度文件路径")
	sendCmd.Flags().StringVar(&resultFile, "result-file", "", "结果文件路径")
	sendCmd.Flags().BoolVar(&dryRun, "dry-run", false, "模拟运行(不实际写入,不 inject)")
	sendCmd.Flags().BoolVar(&resume, "resume", false, "【DEPRECATED】v1 未消费,v2 保留字段防破坏 C# 脚本")
	sendCmd.Flags().IntVar(&skipLines, "skip-lines", 0, "跳过前N行(用于断点续发)")

	rootCmd.AddCommand(sendCmd)
}

// runSend send 命令主流程
//
// 【Week 2 Day 10 骨架实现】接线 config + telemetry,不实际 build/inject。
// 【Week 3+ 补】replaces this stub with real dispatcher + inject 逻辑。
func runSend(cmd *cobra.Command, args []string) error {
	// 1. 加载 config(fallback:cfg == "" 时用 Default,不报错)
	cfg, err := loadConfig()
	if err != nil {
		return fmt.Errorf("加载配置失败: %w", err)
	}

	// 2. 应用 CLI flag override(契约 §2.2 命令行只加不减)
	applyCommandLineOverrides(cfg)

	// 3. 校验 config(契约 §2.2)
	if err := validateSendConfig(cfg); err != nil {
		return fmt.Errorf("配置验证失败: %w", err)
	}

	// 4. 生成 job.id(空时按 v1 fallback 格式;C# UI 通常通过 --job-id 覆盖,契约 §1.10)
	if cfg.Job.ID == "" {
		cfg.Job.ID = fmt.Sprintf("%s-%s", cfg.Job.IDPrefix, time.Now().Format("20060102-150405"))
	}

	// 5. 初始化 telemetry(接线 internal/telemetry)
	logger, closer, err := initTelemetry(cfg)
	if err != nil {
		return fmt.Errorf("telemetry 初始化失败: %w", err)
	}
	defer closer.Close()

	// 6. slog.Info("send.start", ...)
	startTime := time.Now()
	logger.Info("send.start",
		"job_id", cfg.Job.ID,
		"mta_type", cfg.MtaType,
		"workers", cfg.Performance.Workers,
		"rate_limit", cfg.Performance.RateLimit,
		"config", cfgFile,
		"dry_run", cfg.DryRun,
		"cc_enabled", cfg.CC.Enabled,
		"bcc_enabled", cfg.BCC.Enabled,
	)

	// 7. 【Week 6 Day 32 集成】调 bootstrap.Run —— 完整 wire up 12 子包 + dispatcher 主循环
	// bootstrap 内部自己写 result.json(通过 reporter.FileReporter)
	// send.go 只做 slog + 兜底 result.json(bootstrap 未写时用)
	res, runErr := bootstrap.Run(cfg, bootstrap.RunOptions{
		Quiet:   quiet,
		Verbose: verbose,
		DryRun:  cfg.DryRun,
		JobID:   cfg.Job.ID,
	})

	endTime := time.Now()
	duration := endTime.Sub(startTime)

	var total, success, failed int64
	if res != nil {
		total = res.Total
		success = res.Success
		failed = res.Failed
	}

	// 8. slog.Info("send.done", ...)
	logger.Info("send.done",
		"job_id", cfg.Job.ID,
		"total", total,
		"success", success,
		"failed", failed,
		"duration_seconds", duration.Seconds(),
	)

	// 9. 兜底写 result.json(bootstrap 未写时,或 ResultFile 空时)
	if cfg.Output.ResultFile == "" {
		if err := writeResult(cfg, startTime, endTime, duration, total, success, failed); err != nil {
			logger.Error("send.result_write_failed", "err", err.Error())
		}
	}

	if runErr != nil {
		logger.Error("send.run_failed", "err", runErr.Error())
		return runErr
	}
	return nil
}

// loadConfig 加载配置文件(空 --config 时用 Default)
func loadConfig() (*config.Config, error) {
	if cfgFile != "" {
		return config.LoadFromFile(cfgFile)
	}
	return config.Default(), nil
}

// applyCommandLineOverrides 应用 CLI flag 覆盖 config(契约 §2.2 "命令行只加不减")
//
// 覆盖语义:
//   - 字符串:非空串时覆盖
//   - 数字:> 0 时覆盖(命令行不能把 config 里的正值改回 0)
//   - bool --dry-run:true 时覆盖(命令行不能把 config 里的 true 改回 false)
//   - --resume:DEPRECATED,读入即丢弃
func applyCommandLineOverrides(cfg *config.Config) {
	if recipientsFile != "" {
		cfg.Recipients.FilePath = recipientsFile
	}
	if templateFile != "" {
		cfg.Email.TemplatePath = templateFile
	}
	if subject != "" {
		cfg.Email.Subject = subject
	}
	if fromAddress != "" {
		cfg.Sender.FromAddress = fromAddress
	}
	if fromName != "" {
		cfg.Sender.FromName = fromName
	}
	if envelopeFrom != "" {
		cfg.Sender.EnvelopeFrom = envelopeFrom
	}
	if vmta != "" {
		cfg.PMTA.VirtualMTA = vmta
	}
	if jobID != "" {
		cfg.Job.ID = jobID
	}
	if workers > 0 {
		cfg.Performance.Workers = workers
	}
	if rateLimit > 0 {
		cfg.Performance.RateLimit = rateLimit
	}
	if pickupDir != "" {
		cfg.PMTA.PickupDir = pickupDir
	}
	if tempDir != "" {
		cfg.PMTA.TempDir = tempDir
	}
	if progressFile != "" {
		cfg.Output.ProgressFile = progressFile
	}
	if resultFile != "" {
		cfg.Output.ResultFile = resultFile
	}
	if dryRun {
		cfg.DryRun = true
	}
	// resume DEPRECATED —— 读入即丢弃,不做任何逻辑
	_ = resume
	if skipLines > 0 {
		cfg.Recipients.SkipLines = skipLines
	}
}

// validateSendConfig 与 v1 validateConfig 契约一致(契约 §2.2)
func validateSendConfig(cfg *config.Config) error {
	if cfg.Recipients.FilePath == "" {
		return fmt.Errorf("未指定收件人文件")
	}
	if _, err := os.Stat(cfg.Recipients.FilePath); os.IsNotExist(err) {
		return fmt.Errorf("收件人文件不存在: %s", cfg.Recipients.FilePath)
	}
	if cfg.Email.TemplatePath == "" {
		return fmt.Errorf("未指定模板文件")
	}
	if _, err := os.Stat(cfg.Email.TemplatePath); os.IsNotExist(err) {
		return fmt.Errorf("模板文件不存在: %s", cfg.Email.TemplatePath)
	}
	if cfg.Sender.FromAddress == "" {
		return fmt.Errorf("未指定发件人地址")
	}
	// 主题允许为空(v1 契约 §2.2 明确)

	// SMTP 校验(非 dry-run + smtp 启用时)
	if !cfg.DryRun && cfg.SMTP.Enabled {
		if cfg.SMTP.Host == "" {
			return fmt.Errorf("未指定 SMTP 服务器地址")
		}
		if cfg.SMTP.Port <= 0 {
			return fmt.Errorf("无效的 SMTP 端口: %d", cfg.SMTP.Port)
		}
	}
	return nil
}

// initTelemetry 初始化 slog(接线 internal/telemetry)
//
// level 优先级:CLI --verbose > CLI --quiet > cfg.App.LogLevel
func initTelemetry(cfg *config.Config) (logger *slog.Logger, closer interface{ Close() error }, err error) {
	level := cfg.App.LogLevel
	if verbose {
		level = "debug" // §2.1 Q4 决策
	} else if quiet {
		level = "warn"
	}

	logger, closer, err = telemetry.Init(telemetry.Options{
		Level:        level,
		Format:       "json",
		LogFile:      "", // 骨架期直接输出 stdout
		SetAsDefault: true,
	})
	return
}

// writeResult 写 result.json(契约 §4.3)
//
// 【原子写】tmp + rename;失败不影响 send 退出码,仅返回 error 给调用方 log。
func writeResult(cfg *config.Config, start, end time.Time, duration time.Duration,
	total, success, failed int64) error {

	if cfg.Output.ResultFile == "" {
		return nil // 未配置输出路径,静默跳过
	}

	// 与 v1 reporter/reporter.go 里的匿名 struct 完全一致(契约 §4.3)
	avgRate := 0.0
	if duration.Seconds() > 0 && total > 0 {
		avgRate = float64(total) / duration.Seconds()
	}

	output := struct {
		JobID           string  `json:"job_id"`
		Status          string  `json:"status"`
		Total           int64   `json:"total"`
		Success         int64   `json:"success"`
		Failed          int64   `json:"failed"`
		StartTime       string  `json:"start_time"`
		EndTime         string  `json:"end_time"`
		DurationSeconds float64 `json:"duration_seconds"`
		AverageRate     float64 `json:"average_rate"`
		// Errors 字段 omitempty:骨架期总是 nil,不输出(与 v1 一致)
	}{
		JobID:           cfg.Job.ID,
		Status:          "completed",
		Total:           total,
		Success:         success,
		Failed:          failed,
		StartTime:       start.Format(time.RFC3339), // §4.3 RFC3339 无 Nano
		EndTime:         end.Format(time.RFC3339),
		DurationSeconds: duration.Seconds(),
		AverageRate:     avgRate,
	}

	data, err := json.MarshalIndent(output, "", "  ")
	if err != nil {
		return fmt.Errorf("序列化 result 失败: %w", err)
	}

	// 创建父目录 + tmp + rename 原子写(契约 §4.0)
	dir := filepath.Dir(cfg.Output.ResultFile)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return fmt.Errorf("创建 result 目录失败: %w", err)
	}

	tmp := cfg.Output.ResultFile + ".tmp"
	if err := os.WriteFile(tmp, data, 0644); err != nil {
		return fmt.Errorf("写入 tmp 失败: %w", err)
	}
	if err := os.Rename(tmp, cfg.Output.ResultFile); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("rename 到 result.json 失败: %w", err)
	}
	return nil
}
