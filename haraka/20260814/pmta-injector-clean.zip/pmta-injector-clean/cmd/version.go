package cmd

import (
	"fmt"
	"runtime"

	"github.com/spf13/cobra"
)

// versionCmd 版本命令 —— 契约 §2.5
//
// 【v2 修 v1 的 2 个 bug】(契约 §2.5 建议修正):
//  1. Go version:v1 硬编码 "go1.21+" → v2 用 runtime.Version()(真实运行时版本)
//  2. OS/Arch:v1 用 os.Getenv("GOOS")/GOARCH(错误,env 通常空) → v2 用 runtime.GOOS/GOARCH(编译期常量)
var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "显示版本信息",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Printf("pmta-injector version %s\n", version)
		fmt.Printf("Build time: %s\n", buildTime)
		fmt.Printf("Git commit: %s\n", gitCommit)
		fmt.Printf("Go version: %s\n", runtime.Version()) // ← v2 修 §2.5 bug 1
		fmt.Printf("OS/Arch: %s/%s\n", runtime.GOOS, runtime.GOARCH) // ← v2 修 §2.5 bug 2
	},
}

func init() {
	rootCmd.AddCommand(versionCmd)
}
