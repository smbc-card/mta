package cmd

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"github.com/spf13/cobra"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/unsubserver"
)

// serveCmd 启动 HTTP 退订服务器(契约 §2.4 + §8)
//
// 【契约】UnsubscribeServer.Enabled=false 时必须干净退出 0(防 systemd Restart=on-failure 风暴)
// 【关闭】SIGINT / SIGTERM 触发 graceful shutdown(契约 §8.7)
var serveCmd = &cobra.Command{
	Use:   "serve",
	Short: "启动 HTTP 退订服务器(List-Unsubscribe 真实模式)",
	Long: `serve 子命令仅在 ListUnsubMode = "real" 部署模式下使用(契约 §2.4)。

启动长期运行的 HTTP 服务:
  - 0.0.0.0:80  → 301 → HTTPS
  - 0.0.0.0:443 → 返回退订成功页面(日文静态 HTML,< 2 KB)
  - 所有请求路径都返回同一个页面
  - 反指纹实例签名 + Host 校验 + X-Robots-Tag noindex
  - TLS 证书 5s mtime 缓存(支持 acme.sh 自动续期)
  - Access log 硬编码 /var/log/pmta-injector-unsub/access.log(日滚 7 天)`,
	RunE: runServe,
}

func init() {
	rootCmd.AddCommand(serveCmd)
}

func runServe(cmd *cobra.Command, args []string) error {
	if cfgFile == "" {
		return fmt.Errorf("--config 参数必填(契约 §2.4)")
	}

	cfg, err := config.LoadFromFile(cfgFile)
	if err != nil {
		return fmt.Errorf("加载配置失败: %w", err)
	}

	// 契约 §2.4:UnsubscribeServer.Enabled=false 时必须干净退出 0
	if !cfg.UnsubscribeServer.Enabled {
		fmt.Println("[serve] unsubscribe_server.enabled = false in config, exiting cleanly.")
		return nil
	}

	srv, err := unsubserver.New(cfg)
	if err != nil {
		return fmt.Errorf("创建 unsubserver 失败: %w", err)
	}

	// SIGINT / SIGTERM → ctx cancel → graceful shutdown
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	return srv.Start(ctx)
}
