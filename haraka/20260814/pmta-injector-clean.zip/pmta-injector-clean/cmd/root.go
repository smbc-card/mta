// Package cmd 提供 v2 里所有 cobra 命令 —— send / validate / serve / version
//
// 【契约来源】§2 命令行接口 (契约 §2.0-§2.7)
// 【Week 2 Day 10 骨架】接线 config + telemetry,业务逻辑留给 Week 3+ 补
package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

// 版本信息占位符(编译时由 C# 部署脚本或 -ldflags 注入)
// 由 main.go 通过 SetVersionInfo 设置
var (
	version   = "1.0.0"
	buildTime = "unknown"
	gitCommit = "unknown"
)

// 全局 flag 变量(契约 §2.1)
var (
	cfgFile string
	verbose bool
	quiet   bool
)

// rootCmd 根命令(不带子命令时打印帮助并退出 0,cobra 默认行为)
var rootCmd = &cobra.Command{
	Use:   "pmta-injector",
	Short: "PowerMTA Pickup 模式高性能邮件注入程序",
	Long: `pmta-injector 是一个高性能的邮件注入工具,
通过直接写入 PowerMTA 的 Pickup 目录 或 SMTP 连接实现极高吞吐量的邮件发送。

支持功能:
  - 高并发邮件生成(50,000+ 封/秒)
  - 模板变量替换
  - CSV/JSON 收件人数据
  - 实时进度追踪
  - CC/BCC 独立邮件路径

使用示例:
  pmta-injector send --config config.yaml
  pmta-injector send -r recipients.csv -t template.html -s "Welcome"
  pmta-injector validate --template template.html`,
}

// Execute 执行根命令(main.go 入口)
//
// 【退出码语义】(契约 §2.6):
//   - 命令成功完成 → 0
//   - 子命令 RunE 返回 error → 1(cobra 默认)
//   - cobra 参数解析错误 → 1(cobra 默认)
func Execute() error {
	return rootCmd.Execute()
}

// SetVersionInfo 由 main.go 调用注入版本信息 —— 契约 §3.2 支持 `__VERSION_PLACEHOLDER__` 等
func SetVersionInfo(v, bt, gc string) {
	version = v
	buildTime = bt
	gitCommit = gc
}

func init() {
	// 全局 flag(契约 §2.1)
	rootCmd.PersistentFlags().StringVarP(&cfgFile, "config", "c", "", "配置文件路径")
	rootCmd.PersistentFlags().BoolVarP(&verbose, "verbose", "v", false, "详细输出模式(驱动 slog level → debug)")
	rootCmd.PersistentFlags().BoolVarP(&quiet, "quiet", "q", false, "静默模式(抑制启动/结果段落)")
}

// mustPrintlnErr 输出到 stderr(骨架期简单 wrapper)
func mustPrintlnErr(s string) {
	fmt.Fprintln(os.Stderr, s)
}
