// Package emaillist 邮件列表加载(§7 8 步行处理)
//
// 【契约】v2 与 v1 reader.ReadEmailList 语义等价
//
// 【用途】
//   - CC/BCC 池加载(dispatcher.Run 启动时)
//   - 其他 email 列表加载(unsubserver 黑白名单等)
//
// 【§7 8 步行处理】(契约冻结 —— Day 29 实现):
//   1. TrimRight("\r\n")
//   2. TrimSpace
//   3. skip 空行
//   4. skip "#" / "//" 注释
//   5. TrimSpace 引号
//   6. ToLower(可选,取决于 cfg)
//   7. 简单 email 语法校验(含 @)
//   8. 去重(保留首次出现顺序)
//
// 【返回】[]string —— 每行一个 email
package emaillist
