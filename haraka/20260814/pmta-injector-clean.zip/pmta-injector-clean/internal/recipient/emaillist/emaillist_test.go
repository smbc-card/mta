package emaillist

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func writeFile(t *testing.T, content string) string {
	dir := t.TempDir()
	p := filepath.Join(dir, "list.txt")
	if err := os.WriteFile(p, []byte(content), 0644); err != nil {
		t.Fatalf("write:%v", err)
	}
	return p
}

func TestReadEmailList_Basic(t *testing.T) {
	p := writeFile(t, "a@x.com\nb@y.com\nc@z.com\n")
	emails, err := ReadEmailList(p)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	want := []string{"a@x.com", "b@y.com", "c@z.com"}
	if len(emails) != len(want) {
		t.Fatalf("len:%d, want=%d", len(emails), len(want))
	}
	for i, e := range want {
		if emails[i] != e {
			t.Errorf("[%d]:%q, want=%q", i, emails[i], e)
		}
	}
}

func TestReadEmailList_SkipEmptyLines(t *testing.T) {
	p := writeFile(t, "a@x.com\n\n\nb@y.com\n   \nc@z.com\n")
	emails, _ := ReadEmailList(p)
	if len(emails) != 3 {
		t.Errorf("空行应跳过:%v", emails)
	}
}

func TestReadEmailList_PreservesOrderNoDedup(t *testing.T) {
	// 重复邮箱不去重(v1 契约:保留原始数据)
	p := writeFile(t, "a@x.com\na@x.com\nb@y.com\na@x.com\n")
	emails, _ := ReadEmailList(p)
	if len(emails) != 4 {
		t.Errorf("不应去重,len=%d", len(emails))
	}
}

func TestReadEmailList_StripBOM(t *testing.T) {
	// v1 v8.1.3 #24:首行 UTF-8 BOM 过滤
	p := writeFile(t, "\xEF\xBB\xBFa@x.com\nb@y.com\n")
	emails, _ := ReadEmailList(p)
	if len(emails) < 1 || emails[0] != "a@x.com" {
		t.Errorf("BOM 未过滤:%v", emails)
	}
}

func TestReadEmailList_FilterCRLF(t *testing.T) {
	// v1 v8.1.3 #22:行内 CR/LF 替换为空格防注入
	// 构造包含 \r 的行(scanner 按 \n 分,行内可能残留 \r)
	// 用 \r\r\nb 让 line 内含 \r
	p := writeFile(t, "a@x.com\r\r\nb@y.com\n")
	emails, _ := ReadEmailList(p)
	// 第 1 行内的 \r 应被 trim(不含);第 2 行正常
	// 具体断言:emails 里没有 \r
	for _, e := range emails {
		if strings.ContainsAny(e, "\r\n") {
			t.Errorf("CR/LF 未过滤:%q", e)
		}
	}
}

func TestReadEmailList_EmptyFile(t *testing.T) {
	p := writeFile(t, "")
	emails, err := ReadEmailList(p)
	if err != nil {
		t.Errorf("空文件应 err=nil:%v", err)
	}
	if len(emails) != 0 {
		t.Errorf("空文件应返回 []:%v", emails)
	}
}

func TestReadEmailList_FileNotFound(t *testing.T) {
	_, err := ReadEmailList("/nonexistent/path/xxx.txt")
	if err == nil {
		t.Error("不存在文件应返回 err")
	}
}

func TestReadEmailList_OnlyBOMLine(t *testing.T) {
	// 首行只有 BOM,过滤后为空 → 跳过
	p := writeFile(t, "\xEF\xBB\xBF\nb@y.com\n")
	emails, _ := ReadEmailList(p)
	if len(emails) != 1 || emails[0] != "b@y.com" {
		t.Errorf("只有 BOM 的首行应跳过:%v", emails)
	}
}

func TestReadEmailList_OnlyCRLFAfterReplaceIsEmpty(t *testing.T) {
	// 行内只有 \r,替换为空格 + trim 后应为空 → 跳过
	// 构造:第一行 "\r\r\r"(scanner 按 \n 分,这些 \r 全在行内)
	p := writeFile(t, "\r\r\r\na@x.com\n")
	emails, _ := ReadEmailList(p)
	if len(emails) != 1 || emails[0] != "a@x.com" {
		t.Errorf("纯 CR 行应跳过:%v", emails)
	}
}

func TestReadEmailList_TrimSpaces(t *testing.T) {
	p := writeFile(t, "  a@x.com  \n\tb@y.com\t\n")
	emails, _ := ReadEmailList(p)
	if len(emails) != 2 || emails[0] != "a@x.com" || emails[1] != "b@y.com" {
		t.Errorf("首尾空白应 trim:%v", emails)
	}
}
