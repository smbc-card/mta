package emaillist

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// utf8BOM UTF-8 首字节 BOM("\xEF\xBB\xBF")
const utf8BOM = "\xEF\xBB\xBF"

// ReadEmailList 读取每行一个邮箱的纯文本文件
//
// 【契约】v2 与 v1 reader.ReadEmailList 语义完全一致
//
// 【设计要点】(v1 一致)
//   - 流式读取(bufio.Scanner),100 万行约 1 秒
//   - 保留原始顺序,**不去重**(用户要求保留原始数据)
//   - 跳过完全空白行
//   - **不做**邮箱格式校验(原始数据信任 C# 端)
//   - bufio.Scanner 默认 64KB buffer,扩到 1MB
//
// 【v1 v8.1.3 #22 安全防御】过滤行内 CR/LF 防邮件头注入
// 【v1 v8.1.3 #24】过滤首行 UTF-8 BOM(\xEF\xBB\xBF)
//
// 【失败】
//   - 文件不存在 / 打开失败 → (nil, err)
//   - 读取中出错(过大行等)→ (已读部分, err)
//
// 【空文件】返回 ([], nil)
//
// 【用途】dispatcher.Run 启动时加载 CC/BCC 池
func ReadEmailList(path string) ([]string, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("emaillist: open %q: %w", path, err)
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	// 扩缓冲区到 1MB(默认 64KB 单行超过会 panic)
	buf := make([]byte, 0, 64*1024)
	scanner.Buffer(buf, 1024*1024)

	emails := make([]string, 0, 1024)
	isFirstLine := true

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		// v8.1.3 #22:过滤行内 CR/LF(纯 \r 行尾或混合行尾污染文件)
		if strings.ContainsAny(line, "\r\n") {
			line = strings.ReplaceAll(line, "\r", " ")
			line = strings.ReplaceAll(line, "\n", " ")
			line = strings.TrimSpace(line)
			if line == "" {
				continue
			}
		}

		// v8.1.3 #24:首行 BOM 过滤
		if isFirstLine {
			line = strings.TrimPrefix(line, utf8BOM)
			line = strings.TrimSpace(line)
			isFirstLine = false
			if line == "" {
				continue
			}
		}

		emails = append(emails, line)
	}
	if err := scanner.Err(); err != nil {
		return emails, fmt.Errorf("emaillist: scan %q: %w", path, err)
	}
	return emails, nil
}
