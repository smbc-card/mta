package reader

import (
	"bufio"
	"encoding/csv"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/security"
)

// Recipient 收件人上下文
//
// 【契约】v2 与 v1 reader.Recipient 字段等价
type Recipient struct {
	Email        string
	Name         string
	FirstName    string
	LastName     string
	CustomFields map[string]string
	LineNumber   int
}

// Reader 收件人读取接口
//
// 【契约】v2 与 v1 reader.Reader 语义等价
//
// 【行为】
//   - Read():读下一条;文件结束返回 (nil, nil)(非 io.EOF)
//   - Count():返回总条数(独立文件句柄扫描,不影响当前 Read 位置)
//   - Close():释放文件句柄
type Reader interface {
	Read() (*Recipient, error)
	Count() (int64, error)
	Close() error
}

// Options reader 配置(不 import config —— 由调用方从 cfg.Recipients 挑字段构造)
//
// 【设计】保 recipient/reader 独立可复用,便于测试
type Options struct {
	// Format 指定格式("csv" / "txt");空时按 filePath 扩展名判
	Format string

	// CSV Delimiter 默认 ","(v1 一致)
	CSVDelimiter string

	// CSV 是否有表头(有则首行不返回,列名映射走 headerIndex)
	CSVHasHeader bool

	// CSV 表头字段映射(可选,把 CSV 表头改名为标准字段)
	// 例:{"用户邮箱": "email"} → CSV 里的 "用户邮箱" 列映射到 Recipient.Email
	CSVFieldMapping map[string]string
}

// New 根据 filePath / opts 分派创建 Reader
//
// 【格式判定】
//   - opts.Format 非空 → 用它
//   - 否则按扩展名:.csv → csv;.txt → txt;其他 → csv(v1 一致的默认)
//
// 【v2 精简】JSON 不实现(v1 有 JSONReader 但生产用得少;若需要可 Week 7 补)
func New(filePath string, opts Options) (Reader, error) {
	format := opts.Format
	if format == "" {
		ext := strings.ToLower(filepath.Ext(filePath))
		switch ext {
		case ".csv":
			format = "csv"
		case ".txt":
			format = "txt"
		default:
			format = "csv" // v1 一致的默认
		}
	}

	switch format {
	case "csv":
		return NewCSVReader(filePath, opts)
	case "txt":
		return NewTXTReader(filePath)
	default:
		return nil, fmt.Errorf("reader: unsupported format %q(v2 仅支持 csv/txt)", format)
	}
}

// ============================================================================
// CSVReader
// ============================================================================

// CSVReader CSV 收件人读取器
//
// 【契约】v2 与 v1 reader.CSVReader 语义完全一致
type CSVReader struct {
	file         *os.File
	reader       *csv.Reader
	headers      []string
	headerIndex  map[string]int
	fieldMapping map[string]string
	lineNumber   int
	hasHeader    bool
}

// NewCSVReader 创建 CSVReader
//
// 【行为】
//   - 打开文件(失败返回 err)
//   - 设置 csv.Reader.Comma(默认 ",")
//   - FieldsPerRecord = -1 允许字段数不一致
//   - hasHeader=true 时读取首行为 headers,建 headerIndex(小写 trim)
func NewCSVReader(filePath string, opts Options) (*CSVReader, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("csv: open %q: %w", filePath, err)
	}

	r := csv.NewReader(file)
	if opts.CSVDelimiter != "" {
		r.Comma = rune(opts.CSVDelimiter[0])
	}
	r.FieldsPerRecord = -1

	cr := &CSVReader{
		file:         file,
		reader:       r,
		headerIndex:  make(map[string]int),
		fieldMapping: opts.CSVFieldMapping,
		hasHeader:    opts.CSVHasHeader,
	}

	if opts.CSVHasHeader {
		headers, err := r.Read()
		if err != nil {
			_ = file.Close()
			return nil, fmt.Errorf("csv: read header: %w", err)
		}
		cr.headers = headers
		for i, h := range headers {
			cr.headerIndex[strings.ToLower(strings.TrimSpace(h))] = i
		}
		cr.lineNumber = 1
	}

	return cr, nil
}

// standardFields 判断某字段名是否为"标准字段"(email/name/firstname/lastname 的别名之一)
//
// 【契约】v2 与 v1 CSVReader.Read 里的 switch case 完全一致
var standardFields = map[string]string{
	"email": "email", "e-mail": "email", "mail": "email",
	"emailaddress": "email", "email_address": "email",
	"name": "name", "fullname": "name", "full_name": "name",
	"firstname": "firstname", "first_name": "firstname", "first": "firstname", "fname": "firstname",
	"lastname": "lastname", "last_name": "lastname", "last": "lastname", "lname": "lastname",
}

// Read 读一行 Recipient
//
// 【契约】v2 与 v1 CSVReader.Read 语义完全一致
//
// 【EOF】返回 (nil, nil)
// 【无标题行】按位置映射:[0]email [1]name [2]firstname [3]lastname [4+]custom fieldN
// 【有标题行】按 fieldMapping(可选)+ 标准字段名映射;其他字段进 CustomFields
// 【Name 兜底】Name 空但 FirstName/LastName 非空 → 拼接
func (r *CSVReader) Read() (*Recipient, error) {
	record, err := r.reader.Read()
	if err == io.EOF {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	r.lineNumber++

	rcpt := &Recipient{
		CustomFields: make(map[string]string),
		LineNumber:   r.lineNumber,
	}

	if len(r.headers) > 0 {
		// 有标题行:按字段名映射
		for i, value := range record {
			if i >= len(r.headers) {
				break
			}
			origFieldName := r.headers[i]
			fieldName := strings.ToLower(strings.TrimSpace(origFieldName))
			// 【安全】用户数据必须走 SanitizeLine 剥离内嵌 CRLF,防头/命令注入
			value = security.SanitizeLine(value)

			// 自定义映射(fieldMapping)优先
			if mappedName, ok := r.fieldMapping[fieldName]; ok {
				fieldName = strings.ToLower(mappedName)
			}

			// 标准字段名 → Recipient 对应字段;其他 → CustomFields
			if stdName, ok := standardFields[fieldName]; ok {
				switch stdName {
				case "email":
					rcpt.Email = value
				case "name":
					rcpt.Name = value
				case "firstname":
					rcpt.FirstName = value
				case "lastname":
					rcpt.LastName = value
				}
			} else {
				// 【v1 一致】CustomFields 用原始字段名(不 lower)
				rcpt.CustomFields[origFieldName] = value
			}
		}
	} else {
		// 无标题行:按位置映射
		// 【安全】所有用户数据走 SanitizeLine 剥离内嵌 CRLF,防头/命令注入
		if len(record) > 0 {
			rcpt.Email = security.SanitizeLine(record[0])
		}
		if len(record) > 1 {
			rcpt.Name = security.SanitizeLine(record[1])
		}
		if len(record) > 2 {
			rcpt.FirstName = security.SanitizeLine(record[2])
		}
		if len(record) > 3 {
			rcpt.LastName = security.SanitizeLine(record[3])
		}
		for i := 4; i < len(record); i++ {
			rcpt.CustomFields[fmt.Sprintf("field%d", i-4)] = security.SanitizeLine(record[i])
		}
	}

	// Name 兜底
	if rcpt.Name == "" && (rcpt.FirstName != "" || rcpt.LastName != "") {
		rcpt.Name = strings.TrimSpace(rcpt.FirstName + " " + rcpt.LastName)
	}

	return rcpt, nil
}

// Count 统计总条数(独立文件句柄扫描,不影响当前 Read 位置)
//
// 【契约】v2 与 v1 CSVReader.Count 语义完全一致
//
// 【算法】
//   - bufio.Scanner + 1MB buffer(容超长行)
//   - 只计非空行
//   - 有 header 时减 1
func (r *CSVReader) Count() (int64, error) {
	file, err := os.Open(r.file.Name())
	if err != nil {
		return 0, err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	buf := make([]byte, 0, 64*1024)
	scanner.Buffer(buf, 1024*1024)

	var count int64
	for scanner.Scan() {
		if strings.TrimSpace(scanner.Text()) != "" {
			count++
		}
	}
	if r.hasHeader && count > 0 {
		count--
	}
	return count, scanner.Err()
}

// Close 关闭文件
func (r *CSVReader) Close() error {
	return r.file.Close()
}

// ============================================================================
// TXTReader
// ============================================================================

// TXTReader 纯文本读取器(每行一个邮箱)
//
// 【契约】v2 与 v1 reader.TXTReader 语义完全一致
type TXTReader struct {
	file       *os.File
	scanner    *bufio.Scanner
	lineNumber int
}

// NewTXTReader 创建 TXTReader
func NewTXTReader(filePath string) (*TXTReader, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("txt: open %q: %w", filePath, err)
	}
	return &TXTReader{
		file:    file,
		scanner: bufio.NewScanner(file),
	}, nil
}

// Read 读一行 Recipient
//
// 【契约】v2 与 v1 TXTReader.Read 语义完全一致
//
// 【v1 修复问题8】循环跳空行(不递归,避免栈溢出)
// 【EOF】返回 (nil, nil)
func (r *TXTReader) Read() (*Recipient, error) {
	for {
		if !r.scanner.Scan() {
			if err := r.scanner.Err(); err != nil {
				return nil, err
			}
			return nil, nil
		}

		r.lineNumber++
		// 【安全】TXT 每行是邮箱地址,SanitizeLine 剥离内嵌 CRLF(防旧式 Mac CR 或误注入)
		email := security.SanitizeLine(r.scanner.Text())
		if email == "" {
			continue
		}

		return &Recipient{
			Email:        email,
			CustomFields: make(map[string]string),
			LineNumber:   r.lineNumber,
		}, nil
	}
}

// Count 统计非空行数(不影响当前读取位置)
//
// 【契约】v2 与 v1 TXTReader.Count 语义完全一致 —— seek 回原位置
func (r *TXTReader) Count() (int64, error) {
	currentPos, _ := r.file.Seek(0, io.SeekCurrent)
	if _, err := r.file.Seek(0, io.SeekStart); err != nil {
		return 0, err
	}

	scanner := bufio.NewScanner(r.file)
	var count int64
	for scanner.Scan() {
		if strings.TrimSpace(scanner.Text()) != "" {
			count++
		}
	}

	// 恢复位置(不管 seek 是否成功)
	_, _ = r.file.Seek(currentPos, io.SeekStart)
	return count, scanner.Err()
}

// Close 关闭文件
func (r *TXTReader) Close() error {
	return r.file.Close()
}
