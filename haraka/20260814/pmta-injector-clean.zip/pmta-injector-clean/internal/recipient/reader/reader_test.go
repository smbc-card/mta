package reader

import (
	"os"
	"path/filepath"
	"testing"
)

func writeFile(t *testing.T, name, content string) string {
	dir := t.TempDir()
	p := filepath.Join(dir, name)
	if err := os.WriteFile(p, []byte(content), 0644); err != nil {
		t.Fatalf("write:%v", err)
	}
	return p
}

// ============================================================================
// New 分派
// ============================================================================

func TestNew_ByExtension(t *testing.T) {
	// .csv → CSV
	p := writeFile(t, "data.csv", "a@x.com,Alice\n")
	r, err := New(p, Options{})
	if err != nil {
		t.Fatalf("csv new:%v", err)
	}
	defer r.Close()
	if _, ok := r.(*CSVReader); !ok {
		t.Errorf(".csv 应返回 CSVReader")
	}

	// .txt → TXT
	p2 := writeFile(t, "list.txt", "a@x.com\n")
	r2, _ := New(p2, Options{})
	defer r2.Close()
	if _, ok := r2.(*TXTReader); !ok {
		t.Errorf(".txt 应返回 TXTReader")
	}

	// 未知扩展 → CSV(v1 默认)
	p3 := writeFile(t, "data.xyz", "a@x.com\n")
	r3, _ := New(p3, Options{})
	defer r3.Close()
	if _, ok := r3.(*CSVReader); !ok {
		t.Errorf("未知扩展应默认 CSV")
	}
}

func TestNew_ExplicitFormat(t *testing.T) {
	p := writeFile(t, "list.dat", "a@x.com\n")
	r, err := New(p, Options{Format: "txt"})
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	defer r.Close()
	if _, ok := r.(*TXTReader); !ok {
		t.Errorf("Format=txt 应返回 TXTReader")
	}
}

func TestNew_UnsupportedFormat(t *testing.T) {
	p := writeFile(t, "d.txt", "")
	_, err := New(p, Options{Format: "json"})
	if err == nil {
		t.Error("json 未实现应返回 err")
	}
}

func TestNew_FileNotFound(t *testing.T) {
	_, err := New("/nonexistent.csv", Options{})
	if err == nil {
		t.Error("不存在应 err")
	}
}

// ============================================================================
// CSVReader — 有 header
// ============================================================================

func TestCSVReader_WithHeader_StandardFields(t *testing.T) {
	p := writeFile(t, "d.csv", "email,name,firstname,lastname\na@x.com,Alice,Ali,Smith\n")
	r, err := NewCSVReader(p, Options{CSVHasHeader: true})
	if err != nil {
		t.Fatalf("new:%v", err)
	}
	defer r.Close()

	rc, err := r.Read()
	if err != nil {
		t.Fatalf("read:%v", err)
	}
	if rc.Email != "a@x.com" || rc.Name != "Alice" || rc.FirstName != "Ali" || rc.LastName != "Smith" {
		t.Errorf("字段:%+v", rc)
	}
	if rc.LineNumber != 2 { // header=1, 数据=2
		t.Errorf("LineNumber:%d, want=2", rc.LineNumber)
	}
}

func TestCSVReader_WithHeader_EmailAliases(t *testing.T) {
	// email 别名:e-mail, mail, emailaddress, email_address
	cases := []struct {
		header string
	}{
		{"e-mail"},
		{"mail"},
		{"emailaddress"},
		{"email_address"},
	}
	for _, c := range cases {
		p := writeFile(t, "d.csv", c.header+"\na@x.com\n")
		r, _ := NewCSVReader(p, Options{CSVHasHeader: true})
		rc, _ := r.Read()
		r.Close()
		if rc.Email != "a@x.com" {
			t.Errorf("别名 %q 应识别为 email:%+v", c.header, rc)
		}
	}
}

func TestCSVReader_WithHeader_CustomFields(t *testing.T) {
	p := writeFile(t, "d.csv", "email,age,city\na@x.com,30,NY\n")
	r, _ := NewCSVReader(p, Options{CSVHasHeader: true})
	defer r.Close()
	rc, _ := r.Read()
	if rc.CustomFields["age"] != "30" || rc.CustomFields["city"] != "NY" {
		t.Errorf("CustomFields:%+v", rc.CustomFields)
	}
}

func TestCSVReader_WithHeader_FieldMapping(t *testing.T) {
	// "用户邮箱" 通过 mapping 映射到 "email"
	p := writeFile(t, "d.csv", "用户邮箱,姓名\na@x.com,Alice\n")
	r, _ := NewCSVReader(p, Options{
		CSVHasHeader:    true,
		CSVFieldMapping: map[string]string{"用户邮箱": "email", "姓名": "name"},
	})
	defer r.Close()
	rc, _ := r.Read()
	if rc.Email != "a@x.com" {
		t.Errorf("mapping 未生效:%+v", rc)
	}
	if rc.Name != "Alice" {
		t.Errorf("Name mapping 未生效:%+v", rc)
	}
}

// ============================================================================
// CSVReader — 无 header
// ============================================================================

func TestCSVReader_NoHeader_PositionMapping(t *testing.T) {
	p := writeFile(t, "d.csv", "a@x.com,Alice,Ali,Smith,30,NY\n")
	r, _ := NewCSVReader(p, Options{CSVHasHeader: false})
	defer r.Close()
	rc, _ := r.Read()
	if rc.Email != "a@x.com" || rc.Name != "Alice" || rc.FirstName != "Ali" || rc.LastName != "Smith" {
		t.Errorf("字段:%+v", rc)
	}
	if rc.CustomFields["field0"] != "30" || rc.CustomFields["field1"] != "NY" {
		t.Errorf("field0/1:%+v", rc.CustomFields)
	}
}

// ============================================================================
// CSVReader — Name 兜底 + 特殊
// ============================================================================

func TestCSVReader_NameFallback(t *testing.T) {
	p := writeFile(t, "d.csv", "email,firstname,lastname\na@x.com,Ali,Smith\n")
	r, _ := NewCSVReader(p, Options{CSVHasHeader: true})
	defer r.Close()
	rc, _ := r.Read()
	if rc.Name != "Ali Smith" {
		t.Errorf("Name 兜底:%q, want='Ali Smith'", rc.Name)
	}
}

func TestCSVReader_CustomDelimiter(t *testing.T) {
	p := writeFile(t, "d.csv", "email;name\na@x.com;Alice\n")
	r, _ := NewCSVReader(p, Options{CSVHasHeader: true, CSVDelimiter: ";"})
	defer r.Close()
	rc, _ := r.Read()
	if rc.Email != "a@x.com" || rc.Name != "Alice" {
		t.Errorf("自定义分隔符:%+v", rc)
	}
}

func TestCSVReader_ReadEOF(t *testing.T) {
	p := writeFile(t, "d.csv", "a@x.com\n")
	r, _ := NewCSVReader(p, Options{CSVHasHeader: false})
	defer r.Close()
	_, _ = r.Read()               // 消费唯一一行
	rc, err := r.Read()           // 应 EOF
	if err != nil || rc != nil {
		t.Errorf("EOF 应返回 (nil, nil):rc=%+v, err=%v", rc, err)
	}
}

func TestCSVReader_Count(t *testing.T) {
	p := writeFile(t, "d.csv", "email\na@x.com\nb@y.com\n")
	r, _ := NewCSVReader(p, Options{CSVHasHeader: true})
	defer r.Close()
	n, err := r.Count()
	if err != nil {
		t.Fatalf("count:%v", err)
	}
	if n != 2 { // header 减 1
		t.Errorf("Count:%d, want=2", n)
	}
}

func TestCSVReader_Count_NoHeader(t *testing.T) {
	p := writeFile(t, "d.csv", "a@x.com\nb@y.com\n")
	r, _ := NewCSVReader(p, Options{CSVHasHeader: false})
	defer r.Close()
	n, _ := r.Count()
	if n != 2 {
		t.Errorf("无 header Count:%d, want=2", n)
	}
}

// ============================================================================
// TXTReader
// ============================================================================

func TestTXTReader_Read(t *testing.T) {
	p := writeFile(t, "d.txt", "a@x.com\nb@y.com\nc@z.com\n")
	r, err := NewTXTReader(p)
	if err != nil {
		t.Fatalf("new:%v", err)
	}
	defer r.Close()

	for i, want := range []string{"a@x.com", "b@y.com", "c@z.com"} {
		rc, _ := r.Read()
		if rc.Email != want {
			t.Errorf("[%d]:%q, want=%q", i, rc.Email, want)
		}
		if rc.LineNumber != i+1 {
			t.Errorf("[%d] LineNumber:%d, want=%d", i, rc.LineNumber, i+1)
		}
	}
	rc, err := r.Read()
	if rc != nil || err != nil {
		t.Errorf("EOF:%+v, %v", rc, err)
	}
}

func TestTXTReader_SkipEmptyLines(t *testing.T) {
	// v1 修复问题8:循环跳空行,不递归(避免大量空行栈溢出)
	p := writeFile(t, "d.txt", "\n\n\na@x.com\n\n\nb@y.com\n\n")
	r, _ := NewTXTReader(p)
	defer r.Close()

	rc, _ := r.Read()
	if rc.Email != "a@x.com" {
		t.Errorf("第 1 个:%+v", rc)
	}
	rc, _ = r.Read()
	if rc.Email != "b@y.com" {
		t.Errorf("第 2 个:%+v", rc)
	}
}

func TestTXTReader_Count(t *testing.T) {
	p := writeFile(t, "d.txt", "a@x.com\n\nb@y.com\nc@z.com\n\n")
	r, _ := NewTXTReader(p)
	defer r.Close()
	n, _ := r.Count()
	if n != 3 {
		t.Errorf("Count:%d, want=3", n)
	}
}
