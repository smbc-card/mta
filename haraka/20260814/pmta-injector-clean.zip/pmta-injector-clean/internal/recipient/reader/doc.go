// Package reader 收件人读取抽象(CSV/TXT 文件迭代器)
//
// 【契约】v2 与 v1 reader/reader.go(430 行)语义等价;§7 8 步行处理由 emaillist 子包
//
// 【设计】
//   - Reader interface —— dispatcher 依赖注入,便于测试用 fake
//   - CSVReader / TXTReader 具体实现
//   - New(path, cfg) 根据扩展名 / cfg.Recipients.Format 分派
//
// 【状态】per-Reader 独立 —— 一个 Reader 只被一个 goroutine 读(dispatcher read loop 里主线程)
// 不需要线程安全
//
// 【依赖】config —— 读 cfg.Recipients.{Delimiter, HasHeader, SkipLines, Format}
package reader
