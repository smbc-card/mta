package telemetry

import (
	"log/slog"
	"testing"
)

func TestParseLevel(t *testing.T) {
	cases := []struct {
		name    string
		input   string
		want    slog.Level
		wantErr bool
	}{
		// 标准取值(§1.1 契约)
		{"debug 小写", "debug", slog.LevelDebug, false},
		{"info 小写", "info", slog.LevelInfo, false},
		{"warn 小写", "warn", slog.LevelWarn, false},
		{"error 小写", "error", slog.LevelError, false},

		// 大小写不敏感
		{"DEBUG 全大写", "DEBUG", slog.LevelDebug, false},
		{"Info 首字母大写", "Info", slog.LevelInfo, false},
		{"WARN 全大写", "WARN", slog.LevelWarn, false},
		{"ERROR 全大写", "ERROR", slog.LevelError, false},

		// warning 别名(常见拼写)
		{"warning 别名", "warning", slog.LevelWarn, false},
		{"Warning 别名首大", "Warning", slog.LevelWarn, false},

		// 空串默认 info
		{"空串默认 info", "", slog.LevelInfo, false},

		// TrimSpace 支持
		{"前后空格", "  info  ", slog.LevelInfo, false},

		// 未知取值:返回 error 但级别兜底 info
		{"未知 verbose", "verbose", slog.LevelInfo, true},
		{"未知 trace", "trace", slog.LevelInfo, true},
		{"未知乱码", "xyz123", slog.LevelInfo, true},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, err := ParseLevel(c.input)
			if got != c.want {
				t.Errorf("ParseLevel(%q) level = %v, 期望 %v", c.input, got, c.want)
			}
			if (err != nil) != c.wantErr {
				t.Errorf("ParseLevel(%q) err = %v, 期望 wantErr=%v", c.input, err, c.wantErr)
			}
		})
	}
}
