# internal/telemetry

**用途**:v2 里 slog 日志的初始化基础设施(依赖注入 + 结构化输出)。

## 快速开始

**生产**(JSON 输出到文件):

```go
import "__MODULE_PLACEHOLDER__/internal/telemetry"

logger, closer, err := telemetry.Init(telemetry.Options{
    Level:        "info",
    Format:       "json",
    LogFile:      "/var/log/pmta-injector/app.log",
    SetAsDefault: true,
})
if err != nil { ... }
defer closer.Close()  // ⚠️ 必须 defer 关闭,否则 Windows 下会出现文件句柄泄漏

logger.Info("send.start", "job_id", jobID, "workers", 50)
```

**开发**(Text 输出到 stdout):

```go
logger, closer, _ := telemetry.Init(telemetry.Options{
    Level:  "debug",
    Format: "text",
})
defer closer.Close()  // stdout 场景 closer 是 nopCloser,Close 无副作用,但保持一致性

logger.Debug("worker.started", "worker_id", 3)
```

## Init 返回值(3 元组)

| 返回值 | 类型 | 说明 |
|--------|------|------|
| logger | `*slog.Logger` | 初始化好的 logger 实例 |
| closer | `io.Closer` | **必须** `defer closer.Close()` —— stdout 时 no-op,文件时 `*os.File` |
| err | `error` | Level 解析失败 / 文件打开失败 / 未知 Format 等 |

## Options 字段

| 字段 | 类型 | 默认 | 语义 |
|------|------|------|------|
| `Level` | string | `"info"` | 日志级别:`debug/info/warn/error`(大小写不敏感) |
| `Format` | string | `"json"` | 格式:`json`(生产)/`text`(开发) |
| `LogFile` | string | `""`(stdout) | 输出文件绝对路径;非空时自动创建父目录 + 追加模式打开 |
| `SetAsDefault` | bool | `false` | 是否同时 `slog.SetDefault(logger)` |

## 依赖注入策略

**Day 7 C 方案**:**不依赖 config/types 具体 struct** —— 通过 Options 结构接收原始参数。

- cmd/ 层负责从 `config.AppConfig` 字段转成 `telemetry.Options`,再传入 Init
- 避免 telemetry 包 import config/types → 保持包依赖清晰(telemetry 是"最底层"基础设施)

**为什么这么设计**:如果 telemetry 直接引 `config.AppConfig`,那 telemetry 就依赖 config 包,而 config 包又可能依赖 telemetry 日志 → 循环依赖风险 + 层次混乱。

## ParseLevel 支持的取值

| 输入 | 输出 |
|------|------|
| `"debug"` / `"DEBUG"` / `"Debug"` | `slog.LevelDebug` |
| `"info"` / `"INFO"` / `""`(默认) | `slog.LevelInfo` |
| `"warn"` / `"warning"` / `"WARN"` | `slog.LevelWarn` |
| `"error"` / `"ERROR"` | `slog.LevelError` |
| 其他 | `slog.LevelInfo` + `error` |

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| 启动信息 | `fmt.Println("=====PMTA Injector 启动=====")` + `Printf("任务ID: %s", ...)` | `logger.Info("send.start", "job_id", ...)` JSON |
| 进度回调 | `\r[进度] X/Y (Z%) ...` 覆盖单行 | `logger.Info("send.progress", "processed", X, "total", Y, ...)` 每次一行(**5 项必然差异之一**) |
| 完成结果 | `Printf` 多行文本 | `logger.Info("send.done", "total", ..., "success", ..., "failed", ...)` |
| 错误 | `fmt.Fprintf(os.Stderr, "错误:...")` | `logger.Error("send.error", "email", ..., "err", ...)` |

**v2 契约 §2.2 说明**:printStartInfo/printResult 文本格式改 slog 结构化字段,属"5 项必然差异"之一。

## 未来扩展(Week 3+ 有需要时加)

- **日轮转**:目前 `os.OpenFile` 单文件追加,大文件需要 rotate。可加 `Close()` API + 用户空间 rotate 逻辑
- **event 常量**:定义 `events.go` 集中命名(SendStart/SendDone/WorkerError 等),避免各处 typo
- **context 传播**:用 `slog.With(ctx, ...)` 携带 request_id / job_id 等
- **metrics**:接 OpenTelemetry 或 Prometheus 导出器(v2 计划外,Week 8+ 视需要)

## 测试

```bash
go test -cover ./internal/telemetry/...
# 预期覆盖率 ≥ 90%
```
