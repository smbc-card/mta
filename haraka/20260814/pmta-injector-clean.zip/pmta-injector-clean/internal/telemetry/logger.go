// Package telemetry 提供 v2 里 slog 日志的初始化基础设施
//
// 【依赖注入策略 D7-C】不依赖 config/types 具体 struct —— 通过 Options 结构接收原始参数。
// cmd/ 层负责从 config.AppConfig 字段转成 Options,再传入 Init。
//
// 【Week 2 Day 7 骨架】只提供 Init + ParseLevel。
// 具体的 event 命名(如 send.start / send.done)留给 Week 3 dispatcher 重写时加 events.go。
//
// 【与 v1 的差异】
//   - v1 用 fmt.Printf/Println 混乱输出 —— printStartInfo/printResult 等文本
//   - v2 走 slog 结构化输出 —— 属"5 项必然差异"之一(§2.2)
package telemetry

import (
	"fmt"
	"io"
	"log/slog"
	"os"
	"path/filepath"
)

// Options telemetry 初始化选项(不引用 config.AppConfig,避免包依赖)
type Options struct {
	// Level 日志级别字符串:"debug" / "info" / "warn" / "error" / ""(默认 info)
	// 参考 ParseLevel 支持的取值集合
	Level string

	// Format 输出格式:
	//   - "json"(推荐生产)——机器可解析,结构化字段
	//   - "text"(推荐开发)——人可读,单行
	//   - ""(默认)——json
	Format string

	// LogFile 输出目标文件路径:
	//   - ""(默认)——输出到 stdout
	//   - 非空 ——追加模式写入指定文件;文件不存在自动创建;父目录不存在自动 MkdirAll
	LogFile string

	// SetAsDefault 是否同时 slog.SetDefault(logger)
	//   - true(推荐)——设为全局默认,后续 slog.Info(...) 直接用
	//   - false —— 只返回 logger,不动全局
	SetAsDefault bool
}

// nopCloser 无操作的 io.Closer(stdout 场景用,Close 立即返回 nil)
type nopCloser struct{}

func (nopCloser) Close() error { return nil }

// Init 从 Options 初始化 slog logger
//
// 返回值:
//   - *slog.Logger:初始化好的 logger 实例
//   - io.Closer:资源清理器,**调用方必须 defer closer.Close()** —— stdout 场景是 no-op;
//     文件场景是文件句柄,不 Close 会造成:
//       - Windows:进程内文件被句柄占用,单测 TempDir cleanup 会失败
//       - Linux:句柄泄漏(但 OS 允许删除仍被打开的文件,危害小)
//   - error:Level 解析失败 / 文件打开失败等
//
// 用法示例:
//
//	logger, closer, err := telemetry.Init(telemetry.Options{
//	    Level:        "info",
//	    Format:       "json",
//	    LogFile:      "/var/log/pmta-injector/app.log",
//	    SetAsDefault: true,
//	})
//	if err != nil { ... }
//	defer closer.Close()
//	logger.Info("send.start", "job_id", jobID)
//
// 若需要中途关闭+重开(如日轮转),Week 3+ 扩展 Rotate API。
func Init(opts Options) (*slog.Logger, io.Closer, error) {
	// 1. 解析 level
	level, err := ParseLevel(opts.Level)
	if err != nil {
		return nil, nil, fmt.Errorf("telemetry.Init 解析 level 失败: %w", err)
	}

	// 2. 选择输出目标 + 准备 closer
	var out io.Writer
	var closer io.Closer = nopCloser{}
	if opts.LogFile == "" {
		out = os.Stdout
	} else {
		// 自动创建父目录
		if err := os.MkdirAll(filepath.Dir(opts.LogFile), 0755); err != nil {
			return nil, nil, fmt.Errorf("telemetry.Init 创建日志目录 %q 失败: %w", filepath.Dir(opts.LogFile), err)
		}
		// 追加模式打开(O_APPEND 保证并发安全 —— OS 层原子)
		f, err := os.OpenFile(opts.LogFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			return nil, nil, fmt.Errorf("telemetry.Init 打开日志文件 %q 失败: %w", opts.LogFile, err)
		}
		out = f
		closer = f
	}

	// 3. 选择 handler
	handlerOpts := &slog.HandlerOptions{Level: level}
	var handler slog.Handler
	switch opts.Format {
	case "", "json":
		handler = slog.NewJSONHandler(out, handlerOpts)
	case "text":
		handler = slog.NewTextHandler(out, handlerOpts)
	default:
		// 错误分支:先 Close 已打开的文件(避免泄漏)
		_ = closer.Close()
		return nil, nil, fmt.Errorf("telemetry.Init 未知 format %q(支持 json/text)", opts.Format)
	}

	logger := slog.New(handler)

	// 4. 可选:设为全局默认
	if opts.SetAsDefault {
		slog.SetDefault(logger)
	}

	return logger, closer, nil
}
