package telemetry

import (
	"fmt"
	"log/slog"
	"strings"
)

// ParseLevel 从字符串解析为 slog.Level
//
// 支持的输入(大小写不敏感):
//   - "debug"  → slog.LevelDebug
//   - "info"   → slog.LevelInfo
//   - "warn"   → slog.LevelWarn  (也接受 "warning")
//   - "error"  → slog.LevelError
//   - ""(空串)→ slog.LevelInfo(默认,与 config §1.1 契约一致)
//
// 其他输入返回 error(级 slog.LevelInfo 作为兜底,但同时报错让调用方感知)。
func ParseLevel(s string) (slog.Level, error) {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "":
		return slog.LevelInfo, nil
	case "debug":
		return slog.LevelDebug, nil
	case "info":
		return slog.LevelInfo, nil
	case "warn", "warning":
		return slog.LevelWarn, nil
	case "error":
		return slog.LevelError, nil
	default:
		return slog.LevelInfo, fmt.Errorf("未知 log level %q(支持 debug/info/warn/error)", s)
	}
}
