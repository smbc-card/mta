package telemetry

import (
	"encoding/json"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// TestInit_ReturnsNonNilLogger 基础 sanity
func TestInit_ReturnsNonNilLogger(t *testing.T) {
	l, closer, err := Init(Options{Level: "info", Format: "json"})
	if err != nil {
		t.Fatalf("Init 报错: %v", err)
	}
	defer closer.Close()
	if l == nil {
		t.Fatal("Init 返回 nil logger")
	}
	if closer == nil {
		t.Fatal("Init 返回 nil closer")
	}
}

// TestInit_DefaultOptions 全默认(空 Options)应正常工作
func TestInit_DefaultOptions(t *testing.T) {
	l, closer, err := Init(Options{})
	if err != nil {
		t.Fatalf("Init 空 Options 报错: %v", err)
	}
	defer closer.Close()
	if l == nil {
		t.Fatal("Init 空 Options 返回 nil")
	}
	l.Debug("test debug")
	l.Info("test info")
	l.Warn("test warn")
	l.Error("test error")
}

// TestInit_InvalidLevel 未知 level 应返回 error
func TestInit_InvalidLevel(t *testing.T) {
	_, _, err := Init(Options{Level: "verbose"})
	if err == nil {
		t.Error("Init(Level=verbose) 应返回 error")
	}
}

// TestInit_InvalidFormat 未知 format 应返回 error
func TestInit_InvalidFormat(t *testing.T) {
	_, _, err := Init(Options{Format: "xml"})
	if err == nil {
		t.Error("Init(Format=xml) 应返回 error")
	}
}

// TestInit_InvalidFormat_ClosesFile 未知 format 时若已打开文件应关闭
func TestInit_InvalidFormat_ClosesFile(t *testing.T) {
	tmp := filepath.Join(t.TempDir(), "log.jsonl")
	_, _, err := Init(Options{Format: "xml", LogFile: tmp})
	if err == nil {
		t.Fatal("Init(Format=xml) 应返回 error")
	}
	// 文件应能被删除(说明句柄已关闭)—— TempDir cleanup 会验证这点
}

// TestInit_JSONFormat 生成的 JSON 应能被解析
func TestInit_JSONFormat(t *testing.T) {
	tmp := filepath.Join(t.TempDir(), "log.jsonl")
	l, closer, err := Init(Options{Level: "info", Format: "json", LogFile: tmp})
	if err != nil {
		t.Fatalf("Init 报错: %v", err)
	}

	l.Info("send.start", "job_id", "job-test-001", "workers", 50)
	// 立即关闭,才能读文件内容
	if err := closer.Close(); err != nil {
		t.Fatalf("Close 报错: %v", err)
	}

	data, err := os.ReadFile(tmp)
	if err != nil {
		t.Fatalf("读取日志文件失败: %v", err)
	}

	lines := strings.Split(strings.TrimSpace(string(data)), "\n")
	if len(lines) < 1 {
		t.Fatal("日志文件应至少 1 行")
	}

	for i, line := range lines {
		var m map[string]any
		if err := json.Unmarshal([]byte(line), &m); err != nil {
			t.Errorf("第 %d 行不是合法 JSON: %v\n内容: %s", i, err, line)
			continue
		}
		if m["msg"] != "send.start" {
			t.Errorf("第 %d 行 msg 应为 send.start, 得到 %v", i, m["msg"])
		}
		if m["job_id"] != "job-test-001" {
			t.Errorf("第 %d 行 job_id 应为 job-test-001, 得到 %v", i, m["job_id"])
		}
		w, ok := m["workers"].(float64)
		if !ok || w != 50 {
			t.Errorf("第 %d 行 workers 应为 50, 得到 %v", i, m["workers"])
		}
	}
}

// TestInit_TextFormat 生成的 text 格式包含 msg
func TestInit_TextFormat(t *testing.T) {
	tmp := filepath.Join(t.TempDir(), "log.txt")
	l, closer, err := Init(Options{Level: "info", Format: "text", LogFile: tmp})
	if err != nil {
		t.Fatalf("Init 报错: %v", err)
	}

	l.Info("send.done", "success", 100)
	closer.Close()

	data, err := os.ReadFile(tmp)
	if err != nil {
		t.Fatalf("读取失败: %v", err)
	}
	content := string(data)
	if !strings.Contains(content, "send.done") {
		t.Errorf("text 输出应包含 msg 'send.done',内容:\n%s", content)
	}
	if !strings.Contains(content, "success=100") {
		t.Errorf("text 输出应包含 'success=100',内容:\n%s", content)
	}
}

// TestInit_LevelFiltering debug 消息在 level=info 时应被过滤
func TestInit_LevelFiltering(t *testing.T) {
	tmp := filepath.Join(t.TempDir(), "log.jsonl")
	l, closer, err := Init(Options{Level: "info", Format: "json", LogFile: tmp})
	if err != nil {
		t.Fatalf("Init 报错: %v", err)
	}

	l.Debug("should be filtered")
	l.Info("should appear")
	closer.Close()

	data, _ := os.ReadFile(tmp)
	content := string(data)

	if strings.Contains(content, "should be filtered") {
		t.Error("level=info 时 Debug 消息不应输出")
	}
	if !strings.Contains(content, "should appear") {
		t.Error("level=info 时 Info 消息应输出")
	}
}

// TestInit_LevelFiltering_Debug debug level 时所有级别都应输出
func TestInit_LevelFiltering_Debug(t *testing.T) {
	tmp := filepath.Join(t.TempDir(), "log.jsonl")
	l, closer, err := Init(Options{Level: "debug", Format: "json", LogFile: tmp})
	if err != nil {
		t.Fatalf("Init 报错: %v", err)
	}

	l.Debug("debug msg")
	l.Info("info msg")
	l.Warn("warn msg")
	l.Error("error msg")
	closer.Close()

	data, _ := os.ReadFile(tmp)
	content := string(data)

	for _, expected := range []string{"debug msg", "info msg", "warn msg", "error msg"} {
		if !strings.Contains(content, expected) {
			t.Errorf("level=debug 时应包含 %q,内容:\n%s", expected, content)
		}
	}
}

// TestInit_LogFileAppend 追加模式:多次 Init 同一文件不覆盖
func TestInit_LogFileAppend(t *testing.T) {
	tmp := filepath.Join(t.TempDir(), "append.jsonl")

	// 第 1 次 Init
	l1, closer1, err := Init(Options{Level: "info", Format: "json", LogFile: tmp})
	if err != nil {
		t.Fatalf("第 1 次 Init: %v", err)
	}
	l1.Info("first")
	closer1.Close()

	// 第 2 次 Init 同一文件(模拟进程重启)
	l2, closer2, err := Init(Options{Level: "info", Format: "json", LogFile: tmp})
	if err != nil {
		t.Fatalf("第 2 次 Init: %v", err)
	}
	l2.Info("second")
	closer2.Close()

	data, _ := os.ReadFile(tmp)
	content := string(data)

	if !strings.Contains(content, "first") {
		t.Error("追加模式:第 1 次的 'first' 应保留")
	}
	if !strings.Contains(content, "second") {
		t.Error("追加模式:第 2 次的 'second' 应写入")
	}
}

// TestInit_LogFileAutoMkdir 父目录不存在时应自动创建
func TestInit_LogFileAutoMkdir(t *testing.T) {
	baseDir := t.TempDir()
	nestedDir := filepath.Join(baseDir, "a", "b", "c")
	tmp := filepath.Join(nestedDir, "log.jsonl")

	l, closer, err := Init(Options{Level: "info", LogFile: tmp})
	if err != nil {
		t.Fatalf("Init 报错(应自动 mkdir): %v", err)
	}
	l.Info("nested")
	closer.Close()

	if _, err := os.Stat(tmp); err != nil {
		t.Errorf("日志文件应已创建: %v", err)
	}
}

// TestInit_SetAsDefault SetAsDefault=true 后 slog.Info 应用同一 handler
func TestInit_SetAsDefault(t *testing.T) {
	// 备份并恢复全局 default(避免影响其他测试)
	originalDefault := slog.Default()
	t.Cleanup(func() { slog.SetDefault(originalDefault) })

	tmp := filepath.Join(t.TempDir(), "default.jsonl")
	_, closer, err := Init(Options{Level: "info", Format: "json", LogFile: tmp, SetAsDefault: true})
	if err != nil {
		t.Fatalf("Init 报错: %v", err)
	}

	slog.Info("global.event", "key", "val")
	closer.Close()

	data, _ := os.ReadFile(tmp)
	if !strings.Contains(string(data), "global.event") {
		t.Error("SetAsDefault=true 后 slog.Info 全局调用应写入配置文件")
	}
}

// TestInit_SetAsDefaultFalse 默认不动全局 default logger
func TestInit_SetAsDefaultFalse(t *testing.T) {
	originalDefault := slog.Default()
	t.Cleanup(func() { slog.SetDefault(originalDefault) })

	tmp := filepath.Join(t.TempDir(), "not_default.jsonl")
	_, closer, err := Init(Options{Level: "info", Format: "json", LogFile: tmp, SetAsDefault: false})
	if err != nil {
		t.Fatalf("Init 报错: %v", err)
	}
	defer closer.Close()

	if slog.Default() != originalDefault {
		t.Error("SetAsDefault=false 时不应替换 slog.Default")
	}
}

// TestNopCloser_Close nopCloser 应无错关闭
func TestNopCloser_Close(t *testing.T) {
	c := nopCloser{}
	if err := c.Close(); err != nil {
		t.Errorf("nopCloser.Close 应返回 nil,得到 %v", err)
	}
	// 多次 Close 也应 OK
	if err := c.Close(); err != nil {
		t.Errorf("多次 Close 应返回 nil,得到 %v", err)
	}
}
