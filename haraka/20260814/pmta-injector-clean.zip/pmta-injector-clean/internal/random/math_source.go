package random

import (
	cryptorand "crypto/rand"
	"encoding/binary"
	"math/rand"
	"time"
)

// cryptoSeed64 从 crypto/rand 抽 8 字节生成 seed;失败时兜底 time.Now().UnixNano()
//
// 【为什么用 crypto/rand】math/rand.NewSource 需 int64 seed;time.Now().UnixNano() 分辨率
// 有限(Windows ~100ns)导致同纳秒创建的多 Source 拿到相同 seed(v1 v62 修复的 bug)。
// crypto/rand 提供不可预测的 64 bit entropy,消除碰撞。
func cryptoSeed64() int64 {
	var b [8]byte
	if _, err := cryptorand.Read(b[:]); err != nil {
		// crypto/rand 失败极罕见(OS entropy pool 不可用),兜底 time.UnixNano
		return time.Now().UnixNano()
	}
	return int64(binary.LittleEndian.Uint64(b[:]))
}

// mathSource 基于 math/rand.Rand 的 Source 实现
type mathSource struct {
	r *rand.Rand
}

// NewFixedSource 创建固定 seed 的 Source(**测试用**)
//
// 保证输出跨次可复现——同一 seed 每次运行都产出完全相同的随机序列。
//
// 用法示例:
//
//	src := random.NewFixedSource(42)
//	for i := 0; i < 10; i++ {
//	    println(src.Intn(100))  // 跨次运行都是同一 10 个数
//	}
//
// 注意:seed=0 也是合法固定种子(不特殊),与 math/rand.NewSource(0) 一致行为。
func NewFixedSource(seed int64) Source {
	return &mathSource{r: rand.New(rand.NewSource(seed))}
}

// NewSystemSource 创建系统随机 seed 的 Source(**通用/单例生产用**)
//
// 内部 seed 来自 crypto/rand(不可预测,不受纳秒精度限制)。
//
// 【选择】
//   - 单例场景(如 selector 池、messageid 生成器):用本函数
//   - dispatcher per-worker 场景:改用 NewWorkerSource(workerID),严格消除同纳秒 seed 碰撞
//
// 【历史】v1 v62 修复了同纳秒多 worker time.UnixNano seed 碰撞导致的随机序列退化;
// v2 直接用 crypto/rand 从根源避免此问题。
func NewSystemSource() Source {
	return &mathSource{r: rand.New(rand.NewSource(cryptoSeed64()))}
}

// NewWorkerSource 创建 per-worker 独立 seed 的 Source(**dispatcher 生产用**)
//
// seed = crypto/rand(8 字节) XOR (workerID × 1_000_000_007)
//
// 【与 v1 v62 对齐】v1 headers.go::cryptoSeed 就是这个模式 —— 消除同纳秒多 worker 相同
// seed 导致的随机序列碰撞。多个 worker 拿到严格独立的初始化状态。
//
// 【为什么 XOR 大素数】纯 workerID 序号(0..N)只占低几位,与 crypto entropy XOR 后差异
// 不明显;乘以大素数(2^31 附近的 Mersenne 素数)让 workerID 差异扩散到全部 64 bit。
func NewWorkerSource(workerID int) Source {
	seed := cryptoSeed64() ^ (int64(workerID) * 1_000_000_007)
	return &mathSource{r: rand.New(rand.NewSource(seed))}
}

// ===== Source interface 实现 =====

func (s *mathSource) Intn(n int) int {
	return s.r.Intn(n)
}

func (s *mathSource) Int63() int64 {
	return s.r.Int63()
}

func (s *mathSource) Read(p []byte) (int, error) {
	return s.r.Read(p)
}

func (s *mathSource) Shuffle(n int, swap func(i, j int)) {
	s.r.Shuffle(n, swap)
}

func (s *mathSource) Float64() float64 {
	return s.r.Float64()
}
