// Package random 定义 v2 里所有随机数生成的抽象接口
//
// 依赖注入友好:测试期传入 NewFixedSource(seed) 保证输出可复现;
// 生产传入 NewSystemSource() 用系统随机 seed。
//
// 【并发安全约定】重要:
//   - Source 实现基于 math/rand.Rand,**非并发安全**
//   - 使用方约定:每 worker/context 独立 Source 实例(参考 v1 v62/v64 修复方向)
//   - 若跨 goroutine 共享 Source,使用方需自行加 mutex 保护
//
// 【Week 2 Day 6 骨架】方法集限定为 5 个,覆盖 v1 实际用到的调用。
// 未来若用到 Perm/Int31n/Uint32 等再扩展。
package random

// Source 随机数生成接口
type Source interface {
	// Intn 返回 [0, n) 的随机整数;n <= 0 时行为未定义(建议调用方保证 n > 0)
	Intn(n int) int

	// Int63 返回 [0, 2^63) 的随机 int64
	Int63() int64

	// Read 用随机字节填充 p,返回 len(p) 和 nil
	// 与 math/rand.Rand.Read 语义一致(不等价 crypto/rand.Read,后者用于密码学场景)
	Read(p []byte) (n int, err error)

	// Shuffle 洗牌 [0, n) 索引,通过 swap 交换实现(Fisher-Yates)
	Shuffle(n int, swap func(i, j int))

	// Float64 返回 [0.0, 1.0) 的随机浮点数
	Float64() float64
}
