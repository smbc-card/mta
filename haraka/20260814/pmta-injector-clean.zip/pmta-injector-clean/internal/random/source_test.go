package random

import (
	"bytes"
	"testing"
)

// TestFixedSource_Reproducibility 验证 seed 相同 → 输出完全一致(可复现性核心)
func TestFixedSource_Reproducibility(t *testing.T) {
	seed := int64(42)
	n := 100

	src1 := NewFixedSource(seed)
	src2 := NewFixedSource(seed)

	for i := 0; i < n; i++ {
		v1 := src1.Intn(1000000)
		v2 := src2.Intn(1000000)
		if v1 != v2 {
			t.Fatalf("Intn 第 %d 次: seed=%d 应产生相同序列,得到 %d vs %d", i, seed, v1, v2)
		}
	}
}

// TestFixedSource_DifferentSeeds 不同 seed 应产生大部分不同的序列
func TestFixedSource_DifferentSeeds(t *testing.T) {
	src1 := NewFixedSource(1)
	src2 := NewFixedSource(2)

	identical := 0
	total := 20
	for i := 0; i < total; i++ {
		if src1.Intn(1000) == src2.Intn(1000) {
			identical++
		}
	}
	// 概率上应 <= 5 个碰撞(1/1000 * 20 期望 0.02,允许统计波动)
	if identical >= 15 {
		t.Errorf("seed=1 vs seed=2 应产生大部分不同的序列,%d/%d 相同(过多)", identical, total)
	}
}

// TestFixedSource_Intn 边界:Intn(n) 返回值必须在 [0, n)
func TestFixedSource_Intn(t *testing.T) {
	src := NewFixedSource(42)
	for i := 0; i < 100; i++ {
		v := src.Intn(10)
		if v < 0 || v >= 10 {
			t.Fatalf("Intn(10) 返回 %d,超出 [0, 10) 范围", v)
		}
	}
}

// TestFixedSource_Int63 边界:Int63 返回值必须非负
func TestFixedSource_Int63(t *testing.T) {
	src := NewFixedSource(42)
	for i := 0; i < 100; i++ {
		v := src.Int63()
		if v < 0 {
			t.Fatalf("Int63 返回 %d,应 >= 0", v)
		}
	}
}

// TestFixedSource_Float64 边界:Float64 返回值必须在 [0.0, 1.0)
func TestFixedSource_Float64(t *testing.T) {
	src := NewFixedSource(42)
	for i := 0; i < 100; i++ {
		v := src.Float64()
		if v < 0.0 || v >= 1.0 {
			t.Fatalf("Float64 返回 %f,应在 [0.0, 1.0)", v)
		}
	}
}

// TestFixedSource_Read 相同 seed 的 Read 应产生相同字节
func TestFixedSource_Read(t *testing.T) {
	src1 := NewFixedSource(42)
	src2 := NewFixedSource(42)

	b1 := make([]byte, 128)
	b2 := make([]byte, 128)

	n1, err1 := src1.Read(b1)
	n2, err2 := src2.Read(b2)

	if err1 != nil || err2 != nil {
		t.Fatalf("Read 报错: err1=%v err2=%v", err1, err2)
	}
	if n1 != len(b1) || n2 != len(b2) {
		t.Fatalf("Read 返回长度 %d,%d,期望 %d", n1, n2, len(b1))
	}
	if !bytes.Equal(b1, b2) {
		t.Fatalf("相同 seed 的 Read 应产生相同字节:\nb1=%x\nb2=%x", b1, b2)
	}
}

// TestFixedSource_Shuffle 相同 seed 的 Shuffle 应产生相同结果
func TestFixedSource_Shuffle(t *testing.T) {
	src1 := NewFixedSource(42)
	src2 := NewFixedSource(42)

	slice1 := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	slice2 := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

	src1.Shuffle(len(slice1), func(i, j int) { slice1[i], slice1[j] = slice1[j], slice1[i] })
	src2.Shuffle(len(slice2), func(i, j int) { slice2[i], slice2[j] = slice2[j], slice2[i] })

	for i := range slice1 {
		if slice1[i] != slice2[i] {
			t.Fatalf("相同 seed 的 Shuffle 应产生相同结果:\nslice1=%v\nslice2=%v", slice1, slice2)
		}
	}
}

// TestSystemSource_NoPanic 系统 Source 各方法调用不 panic
func TestSystemSource_NoPanic(t *testing.T) {
	src := NewSystemSource()
	if src == nil {
		t.Fatal("NewSystemSource 返回 nil")
	}

	_ = src.Intn(100)
	_ = src.Int63()
	_ = src.Float64()

	b := make([]byte, 16)
	if _, err := src.Read(b); err != nil {
		t.Fatalf("Read 报错: %v", err)
	}

	slice := []int{1, 2, 3}
	src.Shuffle(len(slice), func(i, j int) { slice[i], slice[j] = slice[j], slice[i] })
}

// TestSystemSource_FreshSeed 相隔时间的两个 System Source 应产出不同序列
// (即使不能完全避免同纳秒场景,大部分情况下不同)
func TestSystemSource_FreshSeed(t *testing.T) {
	src1 := NewSystemSource()
	// 不 Sleep,直接创建第 2 个 —— 如果 nanosecond 分辨率足够,seed 不同
	src2 := NewSystemSource()

	// 只做 sanity check:至少能跑,不强要求 seed 不同
	// (在快速机器上同纳秒创建可能得到相同 seed,不算错)
	_ = src1.Intn(10)
	_ = src2.Intn(10)
}
