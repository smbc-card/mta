# internal/random

**用途**:v2 里所有随机数生成的抽象接口 + 具体实现,支持依赖注入。

## 快速开始

**生产代码**(用系统随机 seed):

```go
import "__MODULE_PLACEHOLDER__/internal/random"

src := random.NewSystemSource()
n := src.Intn(100)  // [0, 100) 随机整数
```

**测试代码**(用固定 seed,保证跨次可复现):

```go
src := random.NewFixedSource(42)
n := src.Intn(100)  // 每次跑都是同一个数
```

## Source interface 方法集(5 个)

| 方法 | 语义 | 对应 math/rand |
|------|------|----------------|
| `Intn(n int) int` | [0, n) 随机整数 | `rand.Intn` |
| `Int63() int64` | [0, 2^63) 随机 int64 | `rand.Int63` |
| `Read(p []byte) (n int, err error)` | 用随机字节填充 p | `rand.Read` |
| `Shuffle(n int, swap func(i, j int))` | 洗牌 [0, n) 索引 | `rand.Shuffle` |
| `Float64() float64` | [0.0, 1.0) 随机浮点 | `rand.Float64` |

## ⚠️ 并发安全约定

**Source 实现基于 `math/rand.Rand`,非并发安全**。使用方约定:

- **每 worker/context 独立 Source 实例**(参考 v1 v62/v64 修复方向)
- 若跨 goroutine 共享 Source,使用方需自行加 mutex 保护

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| 生产随机 | 包级 `rand.Intn` / `rand.Read`(不可注入) | `NewSystemSource().Intn(...)` |
| per-worker RNG | `cryptoSeed(workerID)` + `rand.New(...)` | `NewFixedSource(seed)` per worker |
| 测试固定 | Day 4 补丁改源码(patchRand) | `NewFixedSource(42)` 依赖注入,无需改源码 |
| 并发行为 | 包级 rand 有隐性 race(v62 未完全修) | 强制约定"per worker 独立实例",无 race |

## 未来扩展

- `NewCryptoSource() Source` —— 用 `crypto/rand` seed(v1 里 cryptoSeed 的 v2 抽象)
- `NewMockSource(sequence []int) Source` —— 单测用的固定序列(不用 seed,更可控)

Week 3+ 有需要时再加,当前不做。

## 测试

```bash
go test -race -cover ./internal/random/...
# 预期覆盖率 ≥ 90%
```
