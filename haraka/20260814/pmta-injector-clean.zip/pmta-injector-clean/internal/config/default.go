package config

import "runtime"

// Default 返回带默认值的 Config —— 与 v1 config.go::Default() 完全一致
//
// 【默认值来源】v1 config/config.go:448-505(Day 3 Read 精确复制)
// 【契约要求】v2 必须保持所有默认值一字节不变。若某天要改,需在契约附录 B 记录。
func Default() *Config {
	return &Config{
		App: AppConfig{
			Name:     "pmta-injector",
			Version:  "2.0.0",
			LogLevel: "info",
			LogFile:  "/var/log/pmta-injector/app.log",
		},
		MtaType: "pmta",
		Sender: SenderConfig{
			Mode:            "auto",
			FromAddress:     "noreply@example.com",
			FromName:        "Example Company",
			DisplayNames:    []string{},
			DisplayNameMode: "random",
		},
		PMTA: PMTAConfig{
			VirtualMTA: "pmta-vmta1",
			PickupDir:  "/var/spool/pmta/pickup",
			TempDir:    "/var/spool/pmta/tmp",
			FileMode:   0644,
			DirMode:    0755,
		},
		SMTP: SMTPConfig{
			Enabled:    true,
			Host:       "127.0.0.1",
			Port:       25,
			UseAuth:    false,
			UseTLS:     false,
			SkipVerify: true,
			Timeout:    30,
			MaxConn:    50,
		},
		Performance: PerformanceConfig{
			Workers:          runtime.NumCPU() * 10,
			BatchSize:        1000,
			ChannelBuffer:    10000,
			MemoryWarningMB:  500,
			ProgressInterval: 1,
			MaxInterval:      100,
			BatchPause:       5,
			RetryCount:       3,
			RetryInterval:    1000,
		},
		Email: EmailConfig{
			Subject:          "Welcome",
			Subjects:         []string{},
			SubjectMode:      "random",
			TemplatePaths:    []string{},
			TemplateMode:     "random",
			ConvertTxtToHtml: true,
			Charset:          "UTF-8",
			ContentType:      "text/html",
			MimeMode:         "standard",
			CustomHeaders:    make(map[string]string),
		},
		Attachments: AttachmentsConfig{
			Mode:  "sequential",
			Files: []string{},
		},
		Recipients: RecipientsConfig{
			Format:           "auto",
			RemoveDuplicates: true,
			FilterInvalid:    true,
			CSV: CSVConfig{
				Delimiter:    ",",
				HasHeader:    true,
				FieldMapping: map[string]string{},
			},
		},
		Job: JobConfig{
			IDPrefix:        "job",
			IncludeInHeader: true,
		},
		Output: OutputConfig{
			ProgressInterval: 1,
			ShowProgressBar:  true,
			ProgressFile:     "/tmp/progress.json",
			ResultFile:       "/tmp/result.json",
			ErrorFile:        "/tmp/errors.log",
			SaveLog:          true,
			SaveFailedEmails: true,
			LogDirectory:     "/var/log/pmta-injector",
		},
		Template: TemplateConfig{
			GlobalVariables: make(map[string]interface{}),
		},
		Encoding: EncodingConfig{
			Charset:        "UTF-8",
			HeaderEncoding: "base64",
			BodyEncoding:   "base64",
		},
		Variables: VariablesConfig{
			AmountMin:           10000,
			AmountMax:           100000,
			AmountUseSeparator:  true,
			CustomVariableFiles: make(map[string]string),
		},
		Headers: HeadersConfig{
			XPriorityValue:   "random",
			ImportanceValue:  "random",
			ReplyToMode:      "from_address",
			ReturnPathMode:   "from_address",
			AcceptLangValue:  "random",
			ContentLangValue: "random",
		},
		// 【2026-05-26 CC/BCC】默认行为:收件人启用(向后兼容旧版 config.json),CC/BCC 默认禁用
		Recipient: RecipientControlConfig{Enabled: true},
		CC:        CCConfig{Enabled: false, PerEmail: 1},
		BCC:       BCCConfig{Enabled: false, PerEmail: 1},
	}
}
