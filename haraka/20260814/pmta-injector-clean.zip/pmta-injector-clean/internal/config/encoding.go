package config

// EncodingConfig 编码策略 —— 契约 §1.13
type EncodingConfig struct {
	Charset        string `yaml:"charset"`         // 编码字符集
	HeaderEncoding string `yaml:"header_encoding"` // 邮件头编码:"base64" / "qp" / "none"
	BodyEncoding   string `yaml:"body_encoding"`   // 主体编码:"base64" / "qp" / "7bit" / "8bit"
	RandomEncoding bool   `yaml:"random_encoding"` // 随机切换编码
}
