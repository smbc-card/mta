package config

// PerformanceConfig 并发 / 限流 / 重试 —— 契约 §1.6
type PerformanceConfig struct {
	Workers          int `yaml:"workers"`           // worker 并发数;≤0 时 LoadFromFile 回退默认(NumCPU × 10,契约 §1.23)
	RateLimit        int `yaml:"rate_limit"`        // 每秒最大投递数;> 0 启用 RateLimiter,= 0 不限速
	BatchSize        int `yaml:"batch_size"`        // 批大小
	ChannelBuffer    int `yaml:"channel_buffer"`    // 分发 channel 缓冲
	MemoryWarningMB  int `yaml:"memory_warning_mb"` // 内存告警阈值(MB)
	ProgressInterval int `yaml:"progress_interval"` // 进度回写间隔(秒)
	MinInterval      int `yaml:"min_interval"`      // worker 每邮件最小间隔(ms)
	MaxInterval      int `yaml:"max_interval"`      // worker 每邮件最大间隔(ms)
	BatchPause       int `yaml:"batch_pause"`       // 批间暂停(秒)
	RetryCount       int `yaml:"retry_count"`       // 单封重试次数
	RetryInterval    int `yaml:"retry_interval"`    // 重试间隔(ms)
}
