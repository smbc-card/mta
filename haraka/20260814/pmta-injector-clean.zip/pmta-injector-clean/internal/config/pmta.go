package config

// PMTAConfig PowerMTA pickup 目录相关字段
//
// 【⚠️ 全部字段 DEPRECATED】—— 契约 §1.4(2026-08-06 用户实操判断)
//
// PMTA 5.0r8 不接受 pickup 提交:PMTA config 里虽可配 `<source {/var/spool/pmta/pickup}>` 段,
// 但实测未跑通。生产实际走 SMTP(smtp.enabled=true 抢先),此 struct 4 个字段生产未消费。
//
// 【为什么保留】:
//   1. 向后兼容 C# UI 序列化(C# 端生成 config.yaml 时总是写这几个字段)
//   2. 留后路(未来 PMTA 版本升级支持 pickup / 或换 MTA)
//
// 【v2 契约】保留字段名 + 类型 + 默认值,不做重构;单元测试不覆盖(生产不消费)。
//
// virtual_mta 字段例外:**仍在生产使用**(作为 PowerMTA `x-virtual-mta` 头值),不 DEPRECATED。
type PMTAConfig struct {
	VirtualMTA string `yaml:"virtual_mta"` // ✅ 生产使用中,PowerMTA `x-virtual-mta` 头值

	PickupDir string `yaml:"pickup_dir"` // DEPRECATED 见上
	TempDir   string `yaml:"temp_dir"`   // DEPRECATED 见上
	FileMode  uint32 `yaml:"file_mode"`  // DEPRECATED 见上(注:YAML 里 0644 会被解析为十进制 644,与 v1 一致行为)
	DirMode   uint32 `yaml:"dir_mode"`   // DEPRECATED 见上
}
