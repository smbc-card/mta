package config

// SenderConfig 发件人身份 —— 契约 §1.3
type SenderConfig struct {
	// Mode 发件模式
	//
	// 【DEPRECATED】v1 Go 端 0 引用(config.go:46 定义,无消费点)。
	// 字段保留以防破坏 C# YAML 序列化,Go 端读入即丢弃。
	// v2 契约:保持"读入即丢弃"行为,不做任何逻辑。
	Mode string `yaml:"mode"`

	FromAddress  string `yaml:"from_address"`
	FromName     string `yaml:"from_name"`
	EnvelopeFrom string `yaml:"envelope_from"` // 空时 LoadFromFile 回退到 FromAddress(契约 §1.23)
	ReplyTo      string `yaml:"reply_to"`

	DisplayNames    []string `yaml:"display_names"`
	DisplayNameMode string   `yaml:"display_name_mode"` // "sequential" = 按序;其他值(含 "random") = 随机

	// DisplayNameBidiReverse 显示名字节反转 + RLO 回正(仅 UTF-8 生效,反指纹)
	DisplayNameBidiReverse bool `yaml:"display_name_bidi_reverse"`

	// OrgDomain 发件方组织域(C# 端 DomainClassifier 计算,Go 端消费)
	// 用于 Message-ID 域名策略(Headers.MessageIDUseOrgDomain=true 时用它作为 @ 右侧域名)
	// 空串时 GenerateCustomMessageID 回退原行为(用 EnvelopeFrom 域)
	OrgDomain string `yaml:"org_domain,omitempty"`

	// Timezone 邮件 Date 头的时区(IANA 名如 "Asia/Tokyo" / "UTC")
	// 【D-019】默认空 → time.Local(与生产 Linux 服务器时区一致;Windows 开发时手动填 JST 保对齐)
	// 【契约】v2 新增字段;v1 config 无此字段 → yaml 解析后为空 → 走 time.Local 兜底
	// 【值】任何合法 IANA 时区名;非法值 → 静默降级 time.Local(不 err;避免破坏启动)
	Timezone string `yaml:"timezone,omitempty"`
}
