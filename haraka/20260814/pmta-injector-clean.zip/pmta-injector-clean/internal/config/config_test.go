package config

import (
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

// ===== Default() =====

func TestDefault_ReturnsNonNil(t *testing.T) {
	cfg := Default()
	if cfg == nil {
		t.Fatal("Default() 返回 nil")
	}
}

// TestDefault_KeyFieldValues 验证关键默认值(v1 config.go:448-505 精确复制)
func TestDefault_KeyFieldValues(t *testing.T) {
	cfg := Default()

	// App
	if cfg.App.Name != "pmta-injector" {
		t.Errorf("App.Name = %q, 期望 pmta-injector", cfg.App.Name)
	}
	if cfg.App.LogLevel != "info" {
		t.Errorf("App.LogLevel = %q, 期望 info", cfg.App.LogLevel)
	}

	// MtaType
	if cfg.MtaType != "pmta" {
		t.Errorf("MtaType = %q, 期望 pmta", cfg.MtaType)
	}

	// Sender
	if cfg.Sender.Mode != "auto" {
		t.Errorf("Sender.Mode = %q, 期望 auto", cfg.Sender.Mode)
	}
	if cfg.Sender.DisplayNameMode != "random" {
		t.Errorf("Sender.DisplayNameMode = %q, 期望 random", cfg.Sender.DisplayNameMode)
	}

	// PMTA(DEPRECATED 字段的默认值)
	if cfg.PMTA.VirtualMTA != "pmta-vmta1" {
		t.Errorf("PMTA.VirtualMTA = %q, 期望 pmta-vmta1", cfg.PMTA.VirtualMTA)
	}
	if cfg.PMTA.FileMode != 0644 {
		t.Errorf("PMTA.FileMode = %d, 期望 0644(= 420 十进制)", cfg.PMTA.FileMode)
	}
	if cfg.PMTA.DirMode != 0755 {
		t.Errorf("PMTA.DirMode = %d, 期望 0755(= 493 十进制)", cfg.PMTA.DirMode)
	}

	// SMTP(生产主路径)
	if !cfg.SMTP.Enabled {
		t.Error("SMTP.Enabled 默认应为 true(生产主路径)")
	}
	if cfg.SMTP.Host != "127.0.0.1" || cfg.SMTP.Port != 25 {
		t.Errorf("SMTP.Host:Port = %s:%d, 期望 127.0.0.1:25", cfg.SMTP.Host, cfg.SMTP.Port)
	}

	// Performance(Workers 是 runtime 相关,验证 NumCPU 相关性)
	expectedWorkers := runtime.NumCPU() * 10
	if cfg.Performance.Workers != expectedWorkers {
		t.Errorf("Performance.Workers = %d, 期望 NumCPU × 10 = %d", cfg.Performance.Workers, expectedWorkers)
	}
	if cfg.Performance.BatchSize != 1000 {
		t.Errorf("Performance.BatchSize = %d, 期望 1000", cfg.Performance.BatchSize)
	}

	// Recipient / CC / BCC(CC/BCC 三组对称默认)
	if !cfg.Recipient.Enabled {
		t.Error("Recipient.Enabled 默认应为 true")
	}
	if cfg.CC.Enabled {
		t.Error("CC.Enabled 默认应为 false")
	}
	if cfg.CC.PerEmail != 1 {
		t.Errorf("CC.PerEmail 默认应为 1, 得到 %d", cfg.CC.PerEmail)
	}
	if cfg.BCC.Enabled {
		t.Error("BCC.Enabled 默认应为 false")
	}

	// Headers(默认值全部是空/false,只有几个 *Value 字段是 "random")
	if cfg.Headers.XPriorityValue != "random" {
		t.Errorf("Headers.XPriorityValue 默认应为 random, 得到 %q", cfg.Headers.XPriorityValue)
	}
	if cfg.Headers.ReplyToMode != "from_address" {
		t.Errorf("Headers.ReplyToMode 默认应为 from_address, 得到 %q", cfg.Headers.ReplyToMode)
	}
}

// ===== IsPMTA / IsHaraka =====

func TestIsPMTA_EmptyOrPmta(t *testing.T) {
	cases := []struct {
		mtaType string
		want    bool
	}{
		{"", true},   // 空串等价 pmta
		{"pmta", true},
		{"haraka", false},
		{"unknown", false},
	}
	for _, c := range cases {
		cfg := &Config{MtaType: c.mtaType}
		if got := cfg.IsPMTA(); got != c.want {
			t.Errorf("IsPMTA(mta_type=%q) = %v, 期望 %v", c.mtaType, got, c.want)
		}
	}
}

func TestIsHaraka(t *testing.T) {
	cases := []struct {
		mtaType string
		want    bool
	}{
		{"", false},
		{"pmta", false},
		{"haraka", true},
		{"unknown", false},
	}
	for _, c := range cases {
		cfg := &Config{MtaType: c.mtaType}
		if got := cfg.IsHaraka(); got != c.want {
			t.Errorf("IsHaraka(mta_type=%q) = %v, 期望 %v", c.mtaType, got, c.want)
		}
	}
}

// ===== LoadFromFile =====

// TestLoad_FileNotFound 文件不存在应报错
func TestLoad_FileNotFound(t *testing.T) {
	_, err := LoadFromFile("/nonexistent/path/config.yaml")
	if err == nil {
		t.Error("LoadFromFile 不存在文件应返回 error")
	}
}

// TestLoad_InvalidYAML 非法 YAML 应报错
func TestLoad_InvalidYAML(t *testing.T) {
	tmp := filepath.Join(t.TempDir(), "bad.yaml")
	if err := os.WriteFile(tmp, []byte("this is:\n  - not: {balanced yaml"), 0644); err != nil {
		t.Fatal(err)
	}
	_, err := LoadFromFile(tmp)
	if err == nil {
		t.Error("LoadFromFile 非法 YAML 应返回 error")
	}
}

// TestLoad_FallbackEnvelopeFrom §1.23 fallback 1
func TestLoad_FallbackEnvelopeFrom(t *testing.T) {
	yaml := `
sender:
  from_address: "alice@example.com"
  envelope_from: ""
`
	tmp := filepath.Join(t.TempDir(), "fb1.yaml")
	if err := os.WriteFile(tmp, []byte(yaml), 0644); err != nil {
		t.Fatal(err)
	}

	cfg, err := LoadFromFile(tmp)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Sender.EnvelopeFrom != "alice@example.com" {
		t.Errorf("EnvelopeFrom fallback 未生效: 得到 %q, 期望 alice@example.com",
			cfg.Sender.EnvelopeFrom)
	}
}

// TestLoad_FallbackWorkers §1.23 fallback 2
func TestLoad_FallbackWorkers(t *testing.T) {
	yaml := `
performance:
  workers: 0
`
	tmp := filepath.Join(t.TempDir(), "fb2.yaml")
	if err := os.WriteFile(tmp, []byte(yaml), 0644); err != nil {
		t.Fatal(err)
	}

	cfg, err := LoadFromFile(tmp)
	if err != nil {
		t.Fatal(err)
	}
	expected := runtime.NumCPU() * 10
	if cfg.Performance.Workers != expected {
		t.Errorf("Workers fallback 未生效: 得到 %d, 期望 %d", cfg.Performance.Workers, expected)
	}
}

// TestLoad_FallbackWorkers_Negative Workers=-1 也应触发 fallback
func TestLoad_FallbackWorkers_Negative(t *testing.T) {
	yaml := `
performance:
  workers: -1
`
	tmp := filepath.Join(t.TempDir(), "fb2neg.yaml")
	os.WriteFile(tmp, []byte(yaml), 0644)

	cfg, err := LoadFromFile(tmp)
	if err != nil {
		t.Fatal(err)
	}
	expected := runtime.NumCPU() * 10
	if cfg.Performance.Workers != expected {
		t.Errorf("Workers=-1 fallback 未生效: 得到 %d, 期望 %d", cfg.Performance.Workers, expected)
	}
}

// TestSaveLoadRoundtrip Save 后 Load 应能得到相同 Config
func TestSaveLoadRoundtrip(t *testing.T) {
	orig := Default()
	orig.Sender.FromAddress = "test@example.com"
	orig.Sender.EnvelopeFrom = "test@example.com" // 显式设置,避免触发 fallback 后不一致
	orig.Job.ID = "test-job-001"
	orig.CC.Enabled = true
	orig.CC.PerEmail = 3

	tmp := filepath.Join(t.TempDir(), "roundtrip.yaml")
	if err := orig.Save(tmp); err != nil {
		t.Fatalf("Save 报错: %v", err)
	}

	loaded, err := LoadFromFile(tmp)
	if err != nil {
		t.Fatalf("Load 报错: %v", err)
	}

	// 关键字段应一致
	if loaded.Sender.FromAddress != orig.Sender.FromAddress {
		t.Errorf("Sender.FromAddress 不一致: %q vs %q", loaded.Sender.FromAddress, orig.Sender.FromAddress)
	}
	if loaded.Job.ID != orig.Job.ID {
		t.Errorf("Job.ID 不一致: %q vs %q", loaded.Job.ID, orig.Job.ID)
	}
	if loaded.CC.Enabled != orig.CC.Enabled {
		t.Errorf("CC.Enabled 不一致: %v vs %v", loaded.CC.Enabled, orig.CC.Enabled)
	}
	if loaded.CC.PerEmail != orig.CC.PerEmail {
		t.Errorf("CC.PerEmail 不一致: %d vs %d", loaded.CC.PerEmail, orig.CC.PerEmail)
	}
}

// TestSaveLoad_YAMLStable Default 的 Save + Load + Save 应产出相同 YAML 字节
// (比 DeepEqual 更宽容,允许 slice nil vs [] 等内存差异,但要求 YAML 表示稳定)
func TestSaveLoad_YAMLStable(t *testing.T) {
	orig := Default()
	orig.Sender.EnvelopeFrom = orig.Sender.FromAddress

	tmp1 := filepath.Join(t.TempDir(), "s1.yaml")
	if err := orig.Save(tmp1); err != nil {
		t.Fatal(err)
	}

	loaded, err := LoadFromFile(tmp1)
	if err != nil {
		t.Fatal(err)
	}

	tmp2 := filepath.Join(t.TempDir(), "s2.yaml")
	if err := loaded.Save(tmp2); err != nil {
		t.Fatal(err)
	}

	data1, _ := os.ReadFile(tmp1)
	data2, _ := os.ReadFile(tmp2)
	if string(data1) != string(data2) {
		t.Errorf("2 次 Save 输出应字节相同(YAML 表示稳定)\n=1=(%d bytes)\n%s\n=2=(%d bytes)\n%s",
			len(data1), data1, len(data2), data2)
	}
}
