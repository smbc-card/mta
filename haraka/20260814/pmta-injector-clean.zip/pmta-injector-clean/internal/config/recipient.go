package config

// RecipientControlConfig 收件人功能启用开关 —— 契约 §1.19
//
// 【CC/BCC 三组对称之一】字段全部 omitempty。
//
// 【语义】:
//   - Enabled=true(默认):正常处理 recipients.csv 中每个 Email,主邮件投递 + 触发 CC/BCC 独立邮件循环
//   - Enabled=false:跳过 Email 为空的合成主收件人(C# 端在收件人禁用场景下生成 1 行空 Email CSV 占位),
//     但仍触发 CC/BCC 独立邮件循环(由 CC/BCC 池本身驱动)
type RecipientControlConfig struct {
	Enabled bool `yaml:"enabled"`
}
