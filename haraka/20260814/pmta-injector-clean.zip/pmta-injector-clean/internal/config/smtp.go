package config

// SMTPConfig SMTP 配置 —— 契约 §1.5
//
// 【⚠️ 关键角色】SMTP 是 **PMTA 生产的主投递路径**,不仅 Haraka 分支用。
// 生产 pmta-injector 通过 SMTP 发到本地 PMTA 的 `127.0.0.1:25`,命中 PMTA config 里的
// `<source 127.0.0.1>` 免认证段(生产 use_auth: false)。
//
// 【投递优先级】(v1 injector/injector.go:52-65 实际逻辑):
//
//	if cfg.SMTP.Enabled          → newSMTP(cfg)     // 生产走这里
//	elif cfg.PMTA.PickupDir != "" → newPickup(cfg)  // DEPRECATED
//	else                          → disabled
//
// 【含义】即使 mta_type="pmta" 也可能走 SMTP(生产就是这样);mta_type 与投递路径无关。
type SMTPConfig struct {
	Enabled    bool   `yaml:"enabled"` // 路径决定字段:true 走 SMTP;false + PMTA.PickupDir != "" 走 pickup(DEPRECATED)
	Host       string `yaml:"host"`
	Port       int    `yaml:"port"`
	UseAuth    bool   `yaml:"use_auth"`
	Username   string `yaml:"username"`
	Password   string `yaml:"password"`
	UseTLS     bool   `yaml:"use_tls"`
	SkipVerify bool   `yaml:"skip_verify"`
	Timeout    int    `yaml:"timeout"`  // 秒
	MaxConn    int    `yaml:"max_conn"` // 连接池最大连接数
}
