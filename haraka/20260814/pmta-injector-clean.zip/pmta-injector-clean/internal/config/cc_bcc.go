package config

// CCConfig 抄送配置(独立邮件路径)—— 契约 §1.20
//
// 【CC/BCC 三组对称之二】字段全部 omitempty(顶层 CC 字段整体 omitempty)。
//
// 【运行时行为】:
//   - Enabled=true 且 FilePath 非空时,Go 端从 FilePath 加载抄送地址池
//   - 主邮件:To=收件人,Cc=本封分配的 PerEmail 个抄送地址(让收件人能看到抄送列表)
//   - 抄送独立邮件:每个抄送地址单独生成 1 封独立 raw 邮件(独立 Message-ID/boundary/时间戳),
//     该独立邮件的 To 头 = 抄送地址本身(不含 Cc 头,避免泄漏)
//   - 消费策略:D3 决策按 worker 原子索引消费,池消费完即停
//   - PerEmail 运行时 clamp 到 [1, 100](详见契约 §9.1)
type CCConfig struct {
	Enabled  bool   `yaml:"enabled"`
	FilePath string `yaml:"file_path"` // 远端 cc.txt 绝对路径
	PerEmail int    `yaml:"per_email"` // 每封主邮件对应的 CC 数(消费完即停);运行时 clamp 到 [1, 100]
}

// BCCConfig 密送配置(纯独立邮件路径,不在主邮件头出现)—— 契约 §1.21
//
// 【CC/BCC 三组对称之三】字段全部 omitempty(顶层 BCC 字段整体 omitempty)。
//
// 【与 CC 的差异】:
//   - 主邮件永远不写 Bcc 头(BCC 收件人对彼此和主收件人都不可见)
//   - 每个 BCC 单独发独立邮件(独立 Message-ID,不含 Bcc/Cc 头)
type BCCConfig struct {
	Enabled  bool   `yaml:"enabled"`
	FilePath string `yaml:"file_path"`
	PerEmail int    `yaml:"per_email"` // 运行时 clamp 到 [1, 100]
}
