# internal/config

**用途**:v2 里 pmta-injector 的配置 struct + 加载/保存 API。

## 【契约锁定】YAML tag 与 v1 100% 一致

所有 struct 字段的 `yaml:"xxx"` tag 与 v1 `config/config.go` **一字不差**(契约 §1)。

**禁止**:改字段名 / 删字段 / 改 yaml tag。
**允许**:新增字段(需契约 §1 + 附录 B 变更历史登记)。

## 文件组织(23 文件)

**顶层**:

- `config.go` — `Config` 主 struct + `IsPMTA` / `IsHaraka`

**21 个子 struct**(按 v1 顺序,每个 struct 一个文件):

| 文件 | 对应契约 | struct |
|------|----------|--------|
| `sender.go` | §1.3 | SenderConfig |
| `pmta.go` | §1.4 | PMTAConfig(**4 字段 DEPRECATED**) |
| `smtp.go` | §1.5 | SMTPConfig(**主投递路径**) |
| `performance.go` | §1.6 | PerformanceConfig |
| `email.go` | §1.7 | EmailConfig + EmbeddedImageConfig |
| `attachments.go` | §1.8 | AttachmentsConfig + CustomAttachmentConfig |
| `recipients.go` | §1.9 | RecipientsConfig + CSVConfig |
| `job.go` | §1.10 | JobConfig |
| `output.go` | §1.11 | OutputConfig |
| `template.go` | §1.12 | TemplateConfig |
| `encoding.go` | §1.13 | EncodingConfig |
| `variables.go` | §1.14 | VariablesConfig |
| `headers.go` | §1.15 | HeadersConfig(~85 字段,按功能分组注释) |
| `zero_width.go` | §1.16 | ZeroWidthConfig |
| `image_noise.go` | §1.17 | ImageNoiseConfig |
| `unsubscribe_server.go` | §1.18 | UnsubscribeServerConfig |
| `recipient.go` | §1.19 | RecipientControlConfig |
| `cc_bcc.go` | §1.20-1.21 | CCConfig + BCCConfig |

**函数**:

- `default.go` — `Default() *Config`(与 v1 默认值一字节一致)
- `load.go` — `LoadFromFile(path)` + `Save(path)` + §1.23 两条 fallback

**测试**:

- `config_test.go` — Default / IsPMTA / IsHaraka / LoadFromFile / Save 单测
- `golden_test.go` — 5 场景 config.yaml 加载 + roundtrip + 关键字段字节一致性验证

## 【DEPRECATED 字段清单】

| 字段 | 契约 | 说明 |
|------|------|------|
| `sender.mode` | §1.3 | v1 Go 端 0 引用,保留字段防破坏 C# 序列化 |
| `pmta.pickup_dir` | §1.4 | PMTA 5.0r8 不接受 pickup(用户实操判断),字段保留但生产未消费 |
| `pmta.temp_dir` | §1.4 | 同上 |
| `pmta.file_mode` | §1.4 | 同上(注:YAML 里 0644 解析为十进制 644,与 v1 一致) |
| `pmta.dir_mode` | §1.4 | 同上 |

**v2 契约**:保留字段 + 类型 + 默认值,不做重构;单元测试不覆盖(生产不消费)。

## 【§1.23 两条 fallback】(LoadFromFile 里实现)

1. `Sender.EnvelopeFrom == ""` → 回退到 `Sender.FromAddress`
2. `Performance.Workers <= 0` → 回退到 `runtime.NumCPU() * 10`

**新增行为**:v2 用 `slog.Debug` 记录 fallback 触发,便于 debug 时看清"哪些字段走了 fallback"。

## 快速开始

```go
import "__MODULE_PLACEHOLDER__/internal/config"

// 加载配置(缺字段走 Default)
cfg, err := config.LoadFromFile("/etc/pmta-injector/config.yaml")
if err != nil { ... }

// 保存配置
if err := cfg.Save("/tmp/config.yaml"); err != nil { ... }

// 判断分支
if cfg.IsPMTA() { ... }
```

## 与 v1 的对比

| 项 | v1 | v2 |
|----|-----|-----|
| 文件组织 | 单文件 `config/config.go`(534 行,难 review) | 21 struct 拆多个文件(每个 <100 行,易 review) |
| YAML tag | ✅ | ✅(100% 一致) |
| Default() | ✅ | ✅(字节一致) |
| 2 条 fallback | ✅ 静默 | ✅ + `slog.Debug` 记录 |
| DEPRECATED 注释 | 无 | ✅ 每处显式标注 + 说明 |
| 单测 | ❌ 零单测 | ✅ Default / IsPMTA / Load / Save + 5 场景 golden test |

## 测试

```bash
go test -cover ./internal/config/...
# 预期:覆盖率 ≥ 85%
```
