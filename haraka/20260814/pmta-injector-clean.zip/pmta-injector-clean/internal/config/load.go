package config

import (
	"fmt"
	"log/slog"
	"os"
	"runtime"

	"gopkg.in/yaml.v3"
)

// LoadFromFile 从 YAML 文件加载配置
//
// 处理流程:
//  1. 读文件
//  2. 用 Default() 兜底(缺字段走默认值)
//  3. yaml.Unmarshal(data, cfg) 覆盖显式设置的字段
//  4. 应用 §1.23 两条特殊 fallback:
//     - Sender.EnvelopeFrom 空 → 回退 FromAddress
//     - Performance.Workers ≤0 → 回退 NumCPU × 10
//
// 【关键】fallback 用 slog.Debug 记录 —— 未来 debug 时可看到"哪些字段走了 fallback"。
func LoadFromFile(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("读取配置文件失败: %w", err)
	}
	cfg := Default()
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("解析配置文件失败: %w", err)
	}

	// 【§1.23 fallback 1】Sender.EnvelopeFrom 空 → FromAddress
	if cfg.Sender.EnvelopeFrom == "" {
		slog.Debug("config.load: EnvelopeFrom 空,回退到 FromAddress",
			"from_address", cfg.Sender.FromAddress)
		cfg.Sender.EnvelopeFrom = cfg.Sender.FromAddress
	}

	// 【§1.23 fallback 2】Performance.Workers ≤0 → NumCPU * 10
	if cfg.Performance.Workers <= 0 {
		fallback := runtime.NumCPU() * 10
		slog.Debug("config.load: Workers ≤ 0,回退到 NumCPU × 10",
			"workers_default", fallback, "num_cpu", runtime.NumCPU())
		cfg.Performance.Workers = fallback
	}

	return cfg, nil
}

// Save 将配置序列化为 YAML 写入文件
//
// 【文件权限】0644 —— 与 v1 保持一致(config.go:530)。
func (c *Config) Save(path string) error {
	data, err := yaml.Marshal(c)
	if err != nil {
		return fmt.Errorf("序列化配置失败: %w", err)
	}
	if err := os.WriteFile(path, data, 0644); err != nil {
		return fmt.Errorf("写入配置文件失败: %w", err)
	}
	return nil
}
