package config

// AttachmentsConfig 附件配置 —— 契约 §1.8
type AttachmentsConfig struct {
	Enabled bool     `yaml:"enabled"`
	Mode    string   `yaml:"mode"`  // 仅 enabled=true 时生效:"random" = 随机;其他值(含 "sequential") = 按序
	Files   []string `yaml:"files"` // 上传附件文件列表(绝对路径)

	// Custom 自定义随机附件(与上传附件叠加共存;即使没上传附件也生成)
	Custom CustomAttachmentConfig `yaml:"custom"`
}

// CustomAttachmentConfig 自定义随机附件参数
//
// 【契约 §1.8】与 C# `AppConfig` / `GenerateConfigYaml` 契约字节一致。
type CustomAttachmentConfig struct {
	Enabled bool `yaml:"enabled"`

	NameMode    string `yaml:"name_mode"` // "random" | "fixed"
	NameMin     int    `yaml:"name_min"`
	NameMax     int    `yaml:"name_max"`
	FixedName   string `yaml:"fixed_name"`

	SuffixMode  string `yaml:"suffix_mode"` // "random" | "fixed"
	SuffixMin   int    `yaml:"suffix_min"`
	SuffixMax   int    `yaml:"suffix_max"`
	FixedSuffix string `yaml:"fixed_suffix"`

	ContentLinesMin int `yaml:"content_lines_min"`
	ContentLinesMax int `yaml:"content_lines_max"`
	ContentCharsMin int `yaml:"content_chars_min"`
	ContentCharsMax int `yaml:"content_chars_max"`
}
