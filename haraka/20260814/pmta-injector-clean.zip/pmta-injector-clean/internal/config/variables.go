package config

// VariablesConfig 变量池 —— 契约 §1.14
type VariablesConfig struct {
	AmountMin          float64 `yaml:"amount_min"`
	AmountMax          float64 `yaml:"amount_max"`
	AmountDecimals     int     `yaml:"amount_decimals"`
	AmountUseSeparator bool    `yaml:"amount_use_separator"`

	CustomVariableFiles map[string]string `yaml:"custom_variable_files"` // 自定义变量文件(变量名 → 文件路径)
}
