package config

// ZeroWidthConfig 零宽字符反指纹 —— 契约 §1.16
type ZeroWidthConfig struct {
	Enabled         bool `yaml:"enabled"`
	Subject         bool `yaml:"subject"`
	DisplayName     bool `yaml:"display_name"`
	TemplateContent bool `yaml:"template_content"`
}
