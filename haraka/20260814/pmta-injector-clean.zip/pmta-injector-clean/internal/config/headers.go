package config

// HeadersConfig 邮件头开关 —— 契约 §1.15
//
// 【最大 struct】v1 里 ~85 个字段。此处按功能分组用注释隔开,便于查阅。
// **不要拆嵌套 struct** —— 会破坏 YAML tag 层级(如 `list_unsubscribe` 会变成 `p0.list_unsubscribe`)。
//
// 【字段来源清单】(按 v1 config.go 出现顺序):
//
//	基础邮件头(§1.15.1)  22 字段
//	P0 送达率刚需(§1.15.2)  4 字段
//	P1 反指纹高真实感(§1.15.3)  9 字段
//	P2 Outlook 风格 + 行为标识(§1.15.4)  7 字段
//	P3 营销活动 + 联动组(§1.15.5)  5 字段
//	企业网关联动(§1.15.5 后半)  4 字段
//	方案 B 5 个新独立头(§1.15.2-1.15.4 补充)  5 字段
//	ESP Received(§1.15.6)  6 字段
//	随机使用(§1.15.7)  3 字段
//	Message-ID 风格(§1.15.8)  3 字段
//	DKIM h= 字段(§1.15.11)  3 字段
//	Return-Path 简洁化(§1.15.11)  1 字段
//	Received 随机模板(§1.15.10)  3 字段
//	List-Unsubscribe 4 模式(§1.15.9)  7 字段
//	大小写 + 乱序(§1.15.12)  3 字段
type HeadersConfig struct {
	// ===================================================================
	// 基础邮件头开关(§1.15.1)
	// ===================================================================
	Enabled           bool   `yaml:"enabled"` // 总开关(必开,否则所有子开关无效)
	Received          bool   `yaml:"received"`
	DkimSignature     bool   `yaml:"dkim_signature"`
	XMailer           bool   `yaml:"x_mailer"`
	XPriority         bool   `yaml:"x_priority"`
	XPriorityValue    string `yaml:"x_priority_value"` // "random" / "N" / "N (Name)"(生产用 "3 (Normal)")
	Importance        bool   `yaml:"importance"`
	ImportanceValue   string `yaml:"importance_value"` // "random" / "high" / "normal" / "low"
	MessageID         bool   `yaml:"message_id"`
	ReplyTo           bool   `yaml:"reply_to"`
	ReplyToMode       string `yaml:"reply_to_mode"` // "random_prefix" / "from_address"(其他值等价 from_address)
	ReturnPath        bool   `yaml:"return_path"`
	ReturnPathMode    string `yaml:"return_path_mode"` // 同 ReplyToMode
	AcceptLanguage    bool   `yaml:"accept_language"`
	AcceptLangValue   string `yaml:"accept_language_value"`  // "ja"/"en"/"ja-JP"/"en-US"/"zh-CN";其他值 = 5 项随机
	ContentLanguage   bool   `yaml:"content_language"`
	ContentLangValue  string `yaml:"content_language_value"`
	CustomHeadersText string `yaml:"custom_headers_text"` // 多行自定义头文本

	// 【Haraka26】自定义 From 邮箱地址
	CustomFromEnabled bool     `yaml:"custom_from_enabled"`
	CustomFromMode    string   `yaml:"custom_from_mode"` // "sequential" | "random"
	CustomFromEmails  []string `yaml:"custom_from_emails"`

	// 【Haraka26】显示名支持 \r\n
	DisplayNameNewline bool `yaml:"display_name_newline"`

	// ===================================================================
	// P0 送达率刚需(§1.15.2)—— 勾了总加,不参与随机
	// ===================================================================
	ListUnsubscribe     bool `yaml:"list_unsubscribe"`
	ListUnsubscribePost bool `yaml:"list_unsubscribe_post"`
	FeedbackID          bool `yaml:"feedback_id"`
	Precedence          bool `yaml:"precedence"`

	// ===================================================================
	// P1 反指纹高真实感(§1.15.3)
	// ===================================================================
	ErrorsTo       bool `yaml:"errors_to"`
	Sender         bool `yaml:"sender"`
	Organization   bool `yaml:"organization"`
	XOriginatingIP bool `yaml:"x_originating_ip"`
	AutoSubmitted  bool `yaml:"auto_submitted"`
	Comments       bool `yaml:"comments"`
	Keywords       bool `yaml:"keywords"`
	XReportAbuse   bool `yaml:"x_report_abuse"`
	XCSAComplaints bool `yaml:"x_csa_complaints"`

	// ===================================================================
	// P2 Outlook 风格(§1.15.4)
	// ===================================================================
	XMSMailPriority       bool `yaml:"x_msmail_priority"`
	ThreadIndex           bool `yaml:"thread_index"`
	ThreadTopic           bool `yaml:"thread_topic"`
	XAutoResponseSuppress bool `yaml:"x_auto_response_suppress"`

	// P2 行为标识
	ReturnReceiptTo           bool `yaml:"return_receipt_to"`
	DispositionNotificationTo bool `yaml:"disposition_notification_to"`
	XEntityRefID              bool `yaml:"x_entity_ref_id"`

	// ===================================================================
	// P3 营销活动(§1.15.5)
	// ===================================================================
	XCampaignID bool `yaml:"x_campaign_id"`
	XMailerLID  bool `yaml:"x_mailer_lid"`
	CampaignID  bool `yaml:"campaign_id"`

	// P3 联动组(一个开关 → 多个头)
	XTMASGroup bool `yaml:"x_tm_as_group"` // Trend Micro X-TM-AS-* 6 头
	XSFMCGroup bool `yaml:"x_sfmc_group"`  // Salesforce X-SFMC-Stack + x-job

	// ===================================================================
	// 【2026-05-18】4 组企业网关联动头(§1.15.5 后半)
	// ===================================================================
	XBarracudaGroup  bool `yaml:"x_barracuda_group"`  // Barracuda 6 头
	XProofpointGroup bool `yaml:"x_proofpoint_group"` // Proofpoint 4 头
	XMimecastGroup   bool `yaml:"x_mimecast_group"`   // Mimecast 4 头
	XSymantecGroup   bool `yaml:"x_symantec_group"`   // Symantec MessageLabs 4 头

	// ===================================================================
	// 【扩展邮件头 v2 2026-05-15】方案 B 5 个新独立头(§1.15.2-1.15.4 补充)
	// ===================================================================
	ListID               bool `yaml:"list_id"`                 // P0 新增(与 List-Unsubscribe 配套)
	XOriginatingEmail    bool `yaml:"x_originating_email"`     // P1 新增(与 X-Originating-IP 配套)
	XMimeOLE             bool `yaml:"x_mime_ole"`              // P2 Outlook 新增
	XMailerVersion       bool `yaml:"x_mailer_version"`        // P2 Outlook 新增
	XOriginalArrivalTime bool `yaml:"x_original_arrival_time"` // P2 Outlook 新增

	// ===================================================================
	// 【ESP Received 2026-05-20】5 个特定 ESP 风格 Received 头(§1.15.6)
	// 拼接顺序:三井 → docomo → au → softbank → 雅虎 → 原 Received
	// ===================================================================
	ReceivedYahoo       bool   `yaml:"received_yahoo"`
	ReceivedYahooIPMode string `yaml:"received_yahoo_ip_mode"` // "yahoo" = CIDR 池 / "random" = 全球公网
	ReceivedAu          bool   `yaml:"received_au"`
	ReceivedSoftbank    bool   `yaml:"received_softbank"`
	ReceivedDocomo      bool   `yaml:"received_docomo"`
	ReceivedMitsui      bool   `yaml:"received_mitsui"`

	// ===================================================================
	// 随机使用邮件头(§1.15.7)
	// ===================================================================
	RandomEnabled bool `yaml:"random_enabled"`
	RandomMin     int  `yaml:"random_min"` // 范围下限,[1, 10]
	RandomMax     int  `yaml:"random_max"` // 范围上限,[1, 10]

	// ===================================================================
	// 【2026-06-17 从 Haraka 移植】Message-ID 风格选择器(§1.15.8)
	// ===================================================================
	MessageIDRandomAll    bool     `yaml:"message_id_random_all"`
	MessageIDStyles       []string `yaml:"message_id_styles,omitempty"`         // 与 C# MessageIdStyleForm 字节一致
	MessageIDUseOrgDomain bool     `yaml:"message_id_use_org_domain,omitempty"` // true = @右侧用 Sender.OrgDomain

	// ===================================================================
	// 【2026-07-23 新架构 P2-8】DKIM h= 字段自定义(§1.15.11)
	// ===================================================================
	DkimHFieldsCustomEnabled bool     `yaml:"dkim_h_fields_custom_enabled,omitempty"` // 方案 B 伪 DKIM
	DkimHFieldsList          []string `yaml:"dkim_h_fields_list,omitempty"`
	DkimHFieldsMasterEnabled bool     `yaml:"dkim_h_fields_master_enabled,omitempty"` // 【方案 β】UI 主开关

	// ===================================================================
	// 【2026-07-23 新架构 P1-7】Return-Path 简洁化(§1.15.11)
	// ===================================================================
	//
	// 本字段仅记录状态(供未来扩展),当前 Go 端不消费 —— 真正的 VERP 关闭由 PMTA config
	// `<source 127.0.0.1>` 段追加 `verp-default no` 完成(部署时 PowerMtaDeployer 处理)。
	SimpleReturnPath bool `yaml:"simple_return_path,omitempty"`

	// ===================================================================
	// 【2026-05-24】Received(随机)自定义模板池(§1.15.10)
	// α 模板模式,TextBox 存模板原文;模板内可含变量占位符
	// 插入位置:雅虎 → Received(随机)→ 原 Received
	// ===================================================================
	ReceivedRandomEnabled   bool     `yaml:"received_random_enabled,omitempty"`
	ReceivedRandomMode      string   `yaml:"received_random_mode,omitempty"` // "sequential" | "random"
	ReceivedRandomTemplates []string `yaml:"received_random_templates,omitempty"`

	// ===================================================================
	// 【2026-05-24】List-Unsubscribe 4 模式(§1.15.9)
	// default = 老版本 mailto: 占位;real = 真实 HTTPS 退订;custom / random 用户自定义模板池
	// ===================================================================
	ListUnsubMode            string   `yaml:"list_unsub_mode,omitempty"` // "default" | "real" | "custom" | "random"
	ListUnsubRealTemplates   []string `yaml:"list_unsub_real_templates,omitempty"`
	ListUnsubRealMode        string   `yaml:"list_unsub_real_mode,omitempty"` // "sequential" | "random"
	ListUnsubCustomTemplates []string `yaml:"list_unsub_custom_templates,omitempty"`
	ListUnsubCustomMode      string   `yaml:"list_unsub_custom_mode,omitempty"`
	ListUnsubRandomTemplates []string `yaml:"list_unsub_random_templates,omitempty"`
	ListUnsubRandomMode      string   `yaml:"list_unsub_random_mode,omitempty"`

	// ===================================================================
	// 【2026-05-31】字段名随机大小写 + 邮件头排序乱序(§1.15.12)
	// ===================================================================
	RandomCase   bool   `yaml:"random_case,omitempty"`   // 每个字段名逐字符 50/50 随机大小写
	ShuffleOrder bool   `yaml:"shuffle_order,omitempty"` // 温和锚定式乱序
	CaseMode     string `yaml:"case_mode,omitempty"`     // 空 = "random"(默认);预留 "stylepool" 切换点
}
