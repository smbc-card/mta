package config

// OutputConfig 输出文件路径与开关 —— 契约 §1.11
//
// 【关键契约】ProgressFile 所在目录被 §5 STOP 文件机制轮询(dir(ProgressFile) + "/STOP")。
type OutputConfig struct {
	ProgressInterval int  `yaml:"progress_interval"` // progress.json 回写间隔(秒)
	ShowProgressBar  bool `yaml:"show_progress_bar"` // 控制台进度条(v2 走 slog,字段保留)

	ProgressFile string `yaml:"progress_file"` // 进度文件绝对路径(C# UI 端轮询读取,写入走 tmp + rename 原子)
	ResultFile   string `yaml:"result_file"`   // 结果文件绝对路径(C# UI 端读取,原子写)
	ErrorFile    string `yaml:"error_file"`    // 错误日志绝对路径

	SaveLog          bool   `yaml:"save_log"`           // 保存日志到 log_directory
	SaveFailedEmails bool   `yaml:"save_failed_emails"` // 失败邮件保存到 log_directory/failed/
	LogDirectory     string `yaml:"log_directory"`      // 日志目录(含失败邮件、CSV 报告)
}
