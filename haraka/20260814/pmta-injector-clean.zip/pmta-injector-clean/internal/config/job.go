package config

// JobConfig 作业 ID —— 契约 §1.10
//
// 【生产实际行为】(2026-08-06 从 office.gogomorocco.com 采样实测):
//   - C# UI 端总是通过 CLI `--job-id` 覆盖 Job.ID(即使 config.yaml 里也写了)
//   - 实际格式:`job-YYYYMMDD-HHMMSS-XXXXXX`(末尾 6 位 hex 防同秒碰撞)
//   - 示例:`job-20260806-155158-eb7e7b`
//
// 【v2 契约】Go 端 fallback 生成(不带 hex 后缀)必须保留,供命令行手动调用兜底。
type JobConfig struct {
	ID              string `yaml:"id"`                // 作业 ID(空则 Go 端 fallback 生成 `<id_prefix>-<20060102-150405>`)
	IDPrefix        string `yaml:"id_prefix"`         // 作业 ID 前缀(Go 端 fallback 生成时用)
	IncludeInHeader bool   `yaml:"include_in_header"` // 是否把 job_id 写入 `x-job` 邮件头(PMTA 追踪)
}
