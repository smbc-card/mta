package config

// EmailConfig 邮件主题 / 模板 / MIME / CID 图片 —— 契约 §1.7
type EmailConfig struct {
	Subject     string   `yaml:"subject"`      // 单一主题(未启用随机时)
	Subjects    []string `yaml:"subjects"`     // 随机主题池
	SubjectMode string   `yaml:"subject_mode"` // "sequential" = 按序;其他值 = 随机

	SubjectBidiReverse bool `yaml:"subject_bidi_reverse"` // 主题字节反转 + RLO 回正(仅 UTF-8 生效)

	TemplatePath  string   `yaml:"template_path"`  // 单一模板路径(未启用随机时)
	TemplatePaths []string `yaml:"template_paths"` // 随机模板池
	TemplateMode  string   `yaml:"template_mode"`  // "sequential" = 按序;其他值 = 随机

	ConvertTxtToHtml bool   `yaml:"convert_txt_to_html"` // .txt 模板自动包裹为 HTML
	Charset          string `yaml:"charset"`             // 主体字符集
	ContentType      string `yaml:"content_type"`        // 主体 MIME 类型
	IncludeTextPart  bool   `yaml:"include_text_part"`   // multipart/alternative 时是否附 text/plain
	MimeMode         string `yaml:"mime_mode"`           // "standard" | "alternative" | "full"

	CustomHeaders  map[string]string     `yaml:"custom_headers"`  // 自定义头(键值对)
	EmbeddedImages []EmbeddedImageConfig `yaml:"embedded_images"` // CID 内嵌图片列表
}

// EmbeddedImageConfig CID 内嵌图片配置 —— 契约 §1.7 子表
type EmbeddedImageConfig struct {
	CID         string `yaml:"cid"`          // Content-ID 标识(对应 HTML 里的 cid:xxx)
	Path        string `yaml:"path"`         // 图片文件路径
	ContentType string `yaml:"content_type"` // MIME 类型(image/png, image/jpeg 等)
}
