// Package config 定义 v2 里 pmta-injector 的配置 struct
//
// 【契约锁定】所有 YAML tag 与 v1 `config/config.go` **100% 保持一致**(契约 §1 锁死)。
// 不允许改名 / 删除现有字段。允许新增字段,但需在契约 §1 + 附录 B 变更历史登记。
//
// 【Week 2 Day 8 拆分策略】v1 config.go(534 行单文件)→ v2 内部按 struct 拆多个文件,
// 但每个 struct 定义完整在一个文件里(Go 不允许 struct 跨文件定义)。
//
// 【DEPRECATED 字段】部分字段虽然定义存在但 Go 端不消费(见各 struct 注释):
//   - sender.mode(v1 Go 端 0 引用,C# 序列化保留)
//   - pmta.pickup_dir / temp_dir / file_mode / dir_mode(PMTA 5.0r8 不接受 pickup,详见契约 §1.4)
package config

// Config 主配置结构 —— 与 v1 config.go 的 Config 字段名 + yaml tag 完全一致
//
// 【字段顺序】保持与 v1 相同 —— yaml.Marshal 输出顺序影响运维 diff 便利性
// 【DryRun 字段】yaml:"-" 表示不参与 YAML 序列化,仅由 CLI `--dry-run` flag 注入(见契约 §1.22)
type Config struct {
	App               AppConfig               `yaml:"app"`
	MtaType           string                  `yaml:"mta_type"` // "pmta" 或 "haraka",控制邮件头行为(不控制投递路径,见契约 §1.2)
	Sender            SenderConfig            `yaml:"sender"`
	PMTA              PMTAConfig              `yaml:"pmta"`
	SMTP              SMTPConfig              `yaml:"smtp"`
	Performance       PerformanceConfig       `yaml:"performance"`
	Email             EmailConfig             `yaml:"email"`
	Attachments       AttachmentsConfig       `yaml:"attachments"`
	Recipients        RecipientsConfig        `yaml:"recipients"`
	Job               JobConfig               `yaml:"job"`
	Output            OutputConfig            `yaml:"output"`
	Template          TemplateConfig          `yaml:"template"`
	Encoding          EncodingConfig          `yaml:"encoding"`
	Variables         VariablesConfig         `yaml:"variables"`
	Headers           HeadersConfig           `yaml:"headers"`
	ZeroWidth         ZeroWidthConfig         `yaml:"zero_width"`
	ImageNoise        ImageNoiseConfig        `yaml:"image_noise"`
	UnsubscribeServer UnsubscribeServerConfig `yaml:"unsubscribe_server,omitempty"`
	Recipient         RecipientControlConfig  `yaml:"recipient,omitempty"`
	CC                CCConfig                `yaml:"cc,omitempty"`
	BCC               BCCConfig               `yaml:"bcc,omitempty"`
	DryRun            bool                    `yaml:"-"` // CLI 注入(--dry-run),不参与 YAML
}

// AppConfig 应用元信息 + 日志(契约 §1.1)
type AppConfig struct {
	Name     string `yaml:"name"`
	Version  string `yaml:"version"`
	LogLevel string `yaml:"log_level"`
	LogFile  string `yaml:"log_file"`
}

// IsPMTA 判断是否为 PowerMTA 模式(空串等价 "pmta")—— 契约 §1.2
// **注意**:此方法只控制**是否加 `x-virtual-mta`/`x-job` 邮件头**,**不控制投递路径**
// 投递路径由 SMTP.Enabled 决定(见契约 §1.5)
func (c *Config) IsPMTA() bool {
	return c.MtaType == "" || c.MtaType == "pmta"
}

// IsHaraka 判断是否为 Haraka 模式 —— 契约 §1.2
func (c *Config) IsHaraka() bool {
	return c.MtaType == "haraka"
}
