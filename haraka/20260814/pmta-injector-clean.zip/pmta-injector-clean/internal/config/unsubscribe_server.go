package config

// UnsubscribeServerConfig HTTP 退订服务器配置 —— 契约 §1.18
//
// 【仅 serve 子命令读取】send 子命令忽略。字段全部 omitempty。
//
// 【生产运行时约束】(见契约 §8):
//   - tls.Config.GetCertificate 每次握手回调重读证书文件(v2 加 5 秒 mtime 缓存)
//   - HTML 实例签名启动时一次随机 + X-Robots-Tag: noindex, nofollow
//   - Host 头不匹配 domain → 404(防 IP 扫描)
type UnsubscribeServerConfig struct {
	Enabled     bool   `yaml:"enabled,omitempty"`
	ListenHTTP  string `yaml:"listen_http,omitempty"`  // 默认 ":80",301 重定向到 HTTPS
	ListenHTTPS string `yaml:"listen_https,omitempty"` // 默认 ":443"
	CertFile    string `yaml:"cert_file,omitempty"`    // /etc/pmta/certs/fullchain_{domain}.pem
	KeyFile     string `yaml:"key_file,omitempty"`     // /etc/pmta/certs/privkey_{domain}.pem
	Domain      string `yaml:"domain,omitempty"`       // 服务器主域名(HTML 标题展示 + Host 校验)
}
