package config

// ImageNoiseConfig 图片噪点反指纹 —— 契约 §1.17
type ImageNoiseConfig struct {
	Enabled bool `yaml:"enabled"`
}
