package config

// RecipientsConfig 收件人 CSV 加载 —— 契约 §1.9
type RecipientsConfig struct {
	FilePath  string `yaml:"file_path"`  // 收件人文件绝对路径
	Format    string `yaml:"format"`     // "auto" / "csv" / "txt"
	SkipLines int    `yaml:"skip_lines"` // 跳过开头 N 行

	CSV CSVConfig `yaml:"csv"`

	RemoveDuplicates bool `yaml:"remove_duplicates"` // 去重(按 Email 字段)
	FilterInvalid    bool `yaml:"filter_invalid"`    // 过滤无效邮箱(Go 端不校验,C# 已过滤)
}

// CSVConfig CSV 解析参数 —— 契约 §1.9 子表
type CSVConfig struct {
	Delimiter    string            `yaml:"delimiter"`     // CSV 分隔符
	HasHeader    bool              `yaml:"has_header"`    // 首行是否表头
	FieldMapping map[string]string `yaml:"field_mapping"` // 字段名映射(CSV 列名 → 内部字段名)
}
