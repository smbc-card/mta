package config

// TemplateConfig 模板全局变量 —— 契约 §1.12
//
// 【生产实际】(2026-08-06 采样):平铺 12 个字符串变量
// (server_hostname / server_domain / server_subdomain / server_fulldomain /
// from_address / from_name / date / time / datetime / year / month / day)。
//
// map[string]interface{} 类型可接受任意值,生产实际全用 string。
type TemplateConfig struct {
	GlobalVariables map[string]interface{} `yaml:"global_variables"`
}
