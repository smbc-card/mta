package pickup

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"sync/atomic"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/inject"
)

// PickupInjector 实现 inject.Injector(pickup 分支)
//
// 【契约】v2 与 v1 injector.injectPickup 语义完全一致
//
// 【原子写 3 步】(v1 一致)
//  1. 生成唯一文件名:msg_<UnixNano>_<8位seq>.eml
//  2. 先写 tempDir/{filename}
//  3. os.Rename → pickupDir/{filename}(**同一文件系统必须**,rename 才原子)
//
// 【线程安全】seq 用 atomic.Uint64;文件写盘由 OS 保证同名唯一(seq 保证不冲突)
type PickupInjector struct {
	pickupDir string
	tempDir   string
	fileMode  os.FileMode
	clk       clock.Clock
	seq       uint64
}

// New 创建 PickupInjector
//
// 【契约】v2 与 v1 injector.newPickup 语义完全一致
//
// 【行为】
//   - 读 cfg.PMTA.{PickupDir, TempDir, FileMode}
//   - TempDir 空 → fallback PickupDir(v1 一致)
//   - FileMode 0 → 兜底 0644(v1 一致 —— 注意 v1 YAML 里 0644 被解析为十进制 644,契约冻结)
//   - ensureDirWritable 校验两目录(实际写入 .write_test 文件测试可写性)
//
// 【失败】任一目录不存在 / 不可写 → 返回 err
func New(cfg *config.Config, clk clock.Clock) (*PickupInjector, error) {
	pickupDir := cfg.PMTA.PickupDir
	if pickupDir == "" {
		return nil, fmt.Errorf("pickup: PickupDir 未配置")
	}

	tempDir := cfg.PMTA.TempDir
	if tempDir == "" {
		tempDir = pickupDir // v1 一致的 fallback
	}

	fileMode := os.FileMode(cfg.PMTA.FileMode)
	if fileMode == 0 {
		fileMode = 0644 // v1 一致的默认(八进制,与 YAML 数字 644 不同)
	}

	// 目录校验:PickupDir 必须可写;TempDir 若与 PickupDir 不同也必须可写
	if err := ensureDirWritable(pickupDir); err != nil {
		return nil, fmt.Errorf("pickup: PickupDir %q: %w", pickupDir, err)
	}
	if tempDir != pickupDir {
		if err := ensureDirWritable(tempDir); err != nil {
			return nil, fmt.Errorf("pickup: TempDir %q: %w", tempDir, err)
		}
	}

	return &PickupInjector{
		pickupDir: pickupDir,
		tempDir:   tempDir,
		fileMode:  fileMode,
		clk:       clk,
	}, nil
}

// Send 实现 inject.Injector(pickup 原子写)
//
// 【契约】v2 与 v1 injector.injectPickup 语义一致
//
// 【文件名】msg_<UnixNano>_<8位seq>.eml
//   - UnixNano 保跨秒唯一
//   - atomic.AddUint64(&seq) 保同秒内多 worker 唯一
//
// 【失败清理】rename 失败 → os.Remove(temp),避免残留
//
// 【CHK-4】pickup 本地 IO 快(<10ms),不需 ctx 监听;但接口签名要求
// ctx 参数保留 —— 未来若加大量并发 IO 队列可利用
func (p *PickupInjector) Send(ctx context.Context, eml inject.Email) error {
	_ = ctx // pickup 本地 IO 快,不响应 ctx(接口签名匹配即可)
	seq := atomic.AddUint64(&p.seq, 1)
	filename := fmt.Sprintf("msg_%d_%08d.eml", p.clk.Now().UnixNano(), seq)

	tempPath := filepath.Join(p.tempDir, filename)
	finalPath := filepath.Join(p.pickupDir, filename)

	// 写 temp
	if err := os.WriteFile(tempPath, []byte(eml.Raw()), p.fileMode); err != nil {
		return fmt.Errorf("pickup: write temp %q: %w", tempPath, err)
	}

	// 原子 rename → pickup
	if err := os.Rename(tempPath, finalPath); err != nil {
		_ = os.Remove(tempPath) // 清理残留
		return fmt.Errorf("pickup: rename %q → %q: %w", tempPath, finalPath, err)
	}

	return nil
}

// Close 实现 inject.Injector(pickup 无资源释放)
func (p *PickupInjector) Close() error { return nil }

// Mode 实现 inject.Injector
func (p *PickupInjector) Mode() string { return inject.ModePickup }

// Enabled 实现 inject.Injector
func (p *PickupInjector) Enabled() bool { return true }

// SeqCount 返回当前 seq 计数(供 stats / 调试用)
func (p *PickupInjector) SeqCount() uint64 { return atomic.LoadUint64(&p.seq) }

// ensureDirWritable 校验目录存在 + 可写(通过创建 .write_test 临时文件)
//
// 【契约】v2 与 v1 injector.ensureDirWritable 完全一致
func ensureDirWritable(dir string) error {
	info, err := os.Stat(dir)
	if err != nil {
		return fmt.Errorf("目录不存在: %w", err)
	}
	if !info.IsDir() {
		return fmt.Errorf("路径不是目录")
	}
	// 尝试创建临时文件校验可写性
	testFile := filepath.Join(dir, ".write_test")
	f, err := os.Create(testFile)
	if err != nil {
		return fmt.Errorf("目录不可写: %w", err)
	}
	_ = f.Close()
	_ = os.Remove(testFile)
	return nil
}
