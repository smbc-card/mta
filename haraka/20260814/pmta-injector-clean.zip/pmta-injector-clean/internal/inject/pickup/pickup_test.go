package pickup

import (
	"context"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/inject"
)

// fakeEmail 实现 inject.Email
type fakeEmail struct{ from, to, raw string }

func (e *fakeEmail) Raw() string          { return e.raw }
func (e *fakeEmail) EnvelopeFrom() string { return e.from }
func (e *fakeEmail) EnvelopeTo() string   { return e.to }

var fixedTime = time.Date(2026, 8, 8, 12, 0, 0, 123456789, time.UTC)

func makeCfg(pickupDir, tempDir string, fileMode uint32) *config.Config {
	return &config.Config{
		PMTA: config.PMTAConfig{
			PickupDir: pickupDir,
			TempDir:   tempDir,
			FileMode:  fileMode,
		},
	}
}

// ============================================================================
// New —— 边界
// ============================================================================

func TestNew_Success(t *testing.T) {
	dir := t.TempDir()
	inj, err := New(makeCfg(dir, "", 0), clock.NewFixedClock(fixedTime))
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if inj.Mode() != inject.ModePickup {
		t.Errorf("Mode: %s, want=%s", inj.Mode(), inject.ModePickup)
	}
	if !inj.Enabled() {
		t.Error("Enabled 应 true")
	}
	if inj.pickupDir != dir || inj.tempDir != dir {
		t.Errorf("空 tempDir 应 fallback pickupDir")
	}
	if inj.fileMode != 0644 {
		t.Errorf("空 FileMode 应默认 0644,got=%o", inj.fileMode)
	}
}

func TestNew_SeparateTempDir(t *testing.T) {
	pickupDir := t.TempDir()
	tempDir := t.TempDir()
	inj, err := New(makeCfg(pickupDir, tempDir, 0644), clock.NewFixedClock(fixedTime))
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if inj.tempDir != tempDir || inj.pickupDir != pickupDir {
		t.Error("独立 tempDir 未生效")
	}
}

func TestNew_PickupDirEmpty(t *testing.T) {
	_, err := New(makeCfg("", "", 0), clock.NewFixedClock(fixedTime))
	if err == nil {
		t.Error("PickupDir 空应 err")
	}
}

func TestNew_PickupDirNotExist(t *testing.T) {
	_, err := New(makeCfg("/nonexistent/definitely/not/here", "", 0), clock.NewFixedClock(fixedTime))
	if err == nil {
		t.Error("PickupDir 不存在应 err")
	}
}

func TestNew_TempDirNotExist(t *testing.T) {
	pickupDir := t.TempDir()
	_, err := New(makeCfg(pickupDir, "/nonexistent/xxx", 0), clock.NewFixedClock(fixedTime))
	if err == nil {
		t.Error("TempDir 不存在应 err")
	}
}

func TestNew_PickupDirIsFile(t *testing.T) {
	// 目录路径实际是文件 → 不是目录 → err
	dir := t.TempDir()
	f := filepath.Join(dir, "file")
	_ = os.WriteFile(f, []byte("x"), 0644)
	_, err := New(makeCfg(f, "", 0), clock.NewFixedClock(fixedTime))
	if err == nil {
		t.Error("PickupDir 是文件应 err")
	}
}

// ============================================================================
// Send —— 3 步原子写
// ============================================================================

func TestSend_WritesToPickupDir(t *testing.T) {
	dir := t.TempDir()
	inj, _ := New(makeCfg(dir, "", 0), clock.NewFixedClock(fixedTime))

	eml := &fakeEmail{raw: "email content here"}
	if err := inj.Send(context.Background(), eml); err != nil {
		t.Fatalf("Send: %v", err)
	}

	// 找 pickupDir 里的 msg_*.eml 文件
	entries, _ := os.ReadDir(dir)
	var found string
	for _, e := range entries {
		if strings.HasPrefix(e.Name(), "msg_") && strings.HasSuffix(e.Name(), ".eml") {
			found = e.Name()
			break
		}
	}
	if found == "" {
		t.Fatal("未找到 msg_*.eml")
	}

	// 内容匹配
	data, _ := os.ReadFile(filepath.Join(dir, found))
	if string(data) != "email content here" {
		t.Errorf("内容:%q", data)
	}
}

func TestSend_FilenameFormat(t *testing.T) {
	// 文件名格式:msg_<UnixNano>_<8位seq>.eml
	dir := t.TempDir()
	inj, _ := New(makeCfg(dir, "", 0), clock.NewFixedClock(fixedTime))

	_ = inj.Send(context.Background(), &fakeEmail{raw: "x"})
	entries, _ := os.ReadDir(dir)
	if len(entries) != 1 {
		t.Fatalf("应 1 个文件:%d", len(entries))
	}
	name := entries[0].Name()
	re := regexp.MustCompile(`^msg_\d+_\d{8}\.eml$`)
	if !re.MatchString(name) {
		t.Errorf("文件名格式:%s", name)
	}
	// UnixNano == fixedTime.UnixNano()
	wantNano := fixedTime.UnixNano()
	wantPrefix := "msg_" + strings.TrimSpace(itoa(wantNano)) + "_"
	if !strings.HasPrefix(name, wantPrefix) {
		t.Errorf("nano 部分:want prefix=%s got=%s", wantPrefix, name)
	}
	// seq=00000001(第 1 次)
	if !strings.HasSuffix(name, "_00000001.eml") {
		t.Errorf("seq 部分:%s, want *_00000001.eml", name)
	}
}

func TestSend_SeqIncrement(t *testing.T) {
	dir := t.TempDir()
	inj, _ := New(makeCfg(dir, "", 0), clock.NewFixedClock(fixedTime))

	// 3 次 Send → seq 1/2/3
	for i := 0; i < 3; i++ {
		_ = inj.Send(context.Background(), &fakeEmail{raw: "x"})
	}
	if inj.SeqCount() != 3 {
		t.Errorf("SeqCount:%d, want=3", inj.SeqCount())
	}

	entries, _ := os.ReadDir(dir)
	if len(entries) != 3 {
		t.Errorf("应 3 个 msg 文件:%d", len(entries))
	}
	// 找 seq_00000001/00000002/00000003
	found := map[string]bool{}
	for _, e := range entries {
		for _, want := range []string{"00000001", "00000002", "00000003"} {
			if strings.Contains(e.Name(), want) {
				found[want] = true
			}
		}
	}
	if len(found) != 3 {
		t.Errorf("3 个 seq 不齐:%+v", found)
	}
}

func TestSend_SeparateTempDir_RenamesToPickup(t *testing.T) {
	pickupDir := t.TempDir()
	tempDir := t.TempDir()
	inj, _ := New(makeCfg(pickupDir, tempDir, 0644), clock.NewFixedClock(fixedTime))

	_ = inj.Send(context.Background(), &fakeEmail{raw: "content"})

	// tempDir 应无 msg_*(rename 已走)
	tempEntries, _ := os.ReadDir(tempDir)
	for _, e := range tempEntries {
		if strings.HasPrefix(e.Name(), "msg_") {
			t.Errorf("tempDir 不应残留 msg_*:%s", e.Name())
		}
	}
	// pickupDir 应有 msg_*
	pickupEntries, _ := os.ReadDir(pickupDir)
	found := false
	for _, e := range pickupEntries {
		if strings.HasPrefix(e.Name(), "msg_") {
			found = true
		}
	}
	if !found {
		t.Error("pickupDir 应有 msg_*")
	}
}

// ============================================================================
// 并发 —— 多 worker atomic seq
// ============================================================================

func TestSend_ConcurrentSeqUnique(t *testing.T) {
	dir := t.TempDir()
	inj, _ := New(makeCfg(dir, "", 0), clock.NewFixedClock(fixedTime))

	var wg sync.WaitGroup
	const total = 50
	for i := 0; i < total; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_ = inj.Send(context.Background(), &fakeEmail{raw: "x"})
		}()
	}
	wg.Wait()

	entries, _ := os.ReadDir(dir)
	// 应 50 个 msg_* 文件(seq 保证唯一)
	msgCount := 0
	for _, e := range entries {
		if strings.HasPrefix(e.Name(), "msg_") {
			msgCount++
		}
	}
	if msgCount != total {
		t.Errorf("msg 文件数:%d, want=%d(atomic seq 应保证唯一)", msgCount, total)
	}
	if inj.SeqCount() != total {
		t.Errorf("SeqCount:%d, want=%d", inj.SeqCount(), total)
	}
}

// ============================================================================
// 其他接口
// ============================================================================

func TestClose_NoOp(t *testing.T) {
	dir := t.TempDir()
	inj, _ := New(makeCfg(dir, "", 0), clock.NewFixedClock(fixedTime))
	if err := inj.Close(); err != nil {
		t.Errorf("Close: %v", err)
	}
}

func TestMode_Enabled(t *testing.T) {
	dir := t.TempDir()
	inj, _ := New(makeCfg(dir, "", 0), clock.NewFixedClock(fixedTime))
	if inj.Mode() != inject.ModePickup {
		t.Errorf("Mode: %s", inj.Mode())
	}
	if !inj.Enabled() {
		t.Error("Enabled 应 true")
	}
}

// ============================================================================
// ensureDirWritable(直接测)
// ============================================================================

func TestEnsureDirWritable_Success(t *testing.T) {
	dir := t.TempDir()
	if err := ensureDirWritable(dir); err != nil {
		t.Errorf("valid dir: %v", err)
	}
}

func TestEnsureDirWritable_NotExist(t *testing.T) {
	if err := ensureDirWritable("/nonexistent/xxx"); err == nil {
		t.Error("不存在应 err")
	}
}

func TestEnsureDirWritable_IsFile(t *testing.T) {
	dir := t.TempDir()
	f := filepath.Join(dir, "file")
	_ = os.WriteFile(f, []byte("x"), 0644)
	if err := ensureDirWritable(f); err == nil {
		t.Error("是文件应 err")
	}
}

// ============================================================================
// helper —— 简单 int→str
// ============================================================================

func itoa(v int64) string {
	if v == 0 {
		return "0"
	}
	neg := v < 0
	if neg {
		v = -v
	}
	var buf [20]byte
	i := len(buf)
	for v > 0 {
		i--
		buf[i] = byte('0' + v%10)
		v /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
