// Package pickup PMTA Pickup 目录原子写(高吞吐邮件注入)
//
// 【契约】v2 与 v1 injector.injectPickup 语义等价
//
// 【原子写 3 步】
//  1. 生成唯一文件名:msg_<UnixNano>_<8位seq>.eml
//     - UnixNano 保跨秒唯一
//     - atomic.AddUint64(&seq) 保同秒内多 worker 唯一
//  2. 先写 tempDir/{filename}(避免 PMTA 读到写了一半的文件)
//  3. os.Rename → pickupDir/{filename}(**同一文件系统必须**,rename 才原子)
//
// 【文件权限】cfg.PMTA.FileMode(默认 0644)
//
// 【失败清理】rename 失败时 os.Remove(temp),避免残留
//
// 【D22-3 复现性】v2 用注入 clock.Clock 替代 time.Now();seq 用 atomic.Uint64
//
// 【依赖】config + clock + 标准库 os + path/filepath
package pickup
