package inject

import (
	"context"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
)

// Email dispatcher 传给 Injector 的邮件抽象(避免 import render)
//
// 【依赖倒置】render.Email 天然实现此接口(Raw/EnvelopeFrom/EnvelopeTo 方法)
type Email interface {
	Raw() string
	EnvelopeFrom() string
	EnvelopeTo() string
}

// Injector 邮件注入器接口
//
// 【契约】v2 与 v1 Injector 语义等价(增加接口抽象)
// 【CHK-4 P27 修复】Send 增加 ctx 参数 —— ctx.cancel 时 in-flight send 应快速返回 err
type Injector interface {
	// Send 注入单封邮件;ctx.cancel 时 5s 内 return err(SMTP 分支用 SetDeadline 强制)
	Send(ctx context.Context, eml Email) error

	// Close 关闭注入器(释放 SMTP 连接池等资源)
	Close() error

	// Mode 返回模式标识("smtp" / "pickup" / "disabled")
	Mode() string

	// Enabled 是否启用(disabled 时 Send 直接返回 nil)
	Enabled() bool
}

// Mode 常量
const (
	ModeSMTP     = "smtp"
	ModePickup   = "pickup"
	ModeDisabled = "disabled"
)

// New 根据 cfg 创建 Injector(3 分支路由)
//
// 【Day 30-31 实现】3 分支:
//   1. cfg.DryRun=true → disabled(**修 v1 P12 bug**)
//   2. cfg.SMTP.Enabled=true → smtp.New(cfg)
//   3. cfg.PMTA.PickupDir!="" → pickup.New(cfg, clk)
//   4. 兜底 → disabled
//
// 【参数 clk】pickup 需要生成 msg_<UnixNano>_<seq>.eml 文件名;通过 clk 注入保测试可复现
func New(cfg *config.Config, clk clock.Clock) (Injector, error) {
	// Day 30-31 实现
	return &disabledInjector{}, nil
}

// disabledInjector 空实现(dry-run 或都不启用时)
type disabledInjector struct{}

func (d *disabledInjector) Send(_ context.Context, _ Email) error { return nil }
func (d *disabledInjector) Close() error       { return nil }
func (d *disabledInjector) Mode() string       { return ModeDisabled }
func (d *disabledInjector) Enabled() bool      { return false }
