// Package inject 邮件注入器顶层(SMTP / pickup / disabled 三分支路由)
//
// 【契约】v2 与 v1 injector/injector.go(269 行)语义等价;修 v1 P12 bug(dry-run 也创建 SMTP 连接池)
//
// 【3 分支决策】New(cfg):
//  1. cfg.DryRun=true → 【v2 新增】返回 disabled Injector(**修 P12 bug**)
//  2. cfg.SMTP.Enabled=true → smtp.New(cfg)(SMTP client + Pool)
//  3. cfg.SMTP.Enabled=false && cfg.PMTA.PickupDir!="" → pickup.New(cfg, clk)(原子写)
//  4. 都不满足 → disabled Injector(空 Send —— 兼容特殊场景)
//
// 【接口】Injector interface —— dispatcher 依赖注入,便于测试用 fake
//
// 【线程安全】SMTP/pickup 实现方保证(SMTP.Pool 内部 mutex;pickup 原子 seq)
package inject
