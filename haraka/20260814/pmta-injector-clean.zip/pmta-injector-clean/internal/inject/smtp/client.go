package smtp

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

// Client SMTP 单连接封装
//
// 【契约】v2 与 v1 smtp/client.go::Client 语义完全一致(照搬移植)
//
// 【线程安全】非线程安全;Pool 保证同一 Client 不并发使用
type Client struct {
	conn       net.Conn
	reader     *bufio.Reader
	writer     *bufio.Writer
	addr       string
	timeout    time.Duration
	extensions map[string]string
	lastUsed   time.Time
	sendCount  int
}

// connect 建立 TCP → 可选 TLS → EHLO → 可选 AUTH,返回 Client
//
// 【契约】v2 与 v1 connect 语义完全一致
//
// 【失败清理】任一步失败 → conn.Close + 返回 err
func connect(addr string, timeout time.Duration, useTLS bool, skipVerify bool, auth *AuthConfig) (*Client, error) {
	// TCP dial
	dialer := net.Dialer{Timeout: timeout}
	conn, err := dialer.Dial("tcp", addr)
	if err != nil {
		return nil, fmt.Errorf("smtp: dial %s: %w", addr, err)
	}

	// TLS(可选)
	if useTLS {
		host, _, _ := net.SplitHostPort(addr)
		tlsConfig := &tls.Config{
			ServerName:         host,
			InsecureSkipVerify: skipVerify,
		}
		conn = tls.Client(conn, tlsConfig)
	}

	c := &Client{
		conn:       conn,
		reader:     bufio.NewReader(conn),
		writer:     bufio.NewWriter(conn),
		addr:       addr,
		timeout:    timeout,
		extensions: make(map[string]string),
		lastUsed:   time.Now(),
	}
	_ = conn.SetDeadline(time.Now().Add(timeout))

	// 读欢迎(220)
	code, _, err := c.readResponse()
	if err != nil {
		_ = conn.Close()
		return nil, fmt.Errorf("smtp: greeting: %w", err)
	}
	if code != 220 {
		_ = conn.Close()
		return nil, fmt.Errorf("smtp: greeting rejected: code=%d", code)
	}

	// EHLO
	hostname, _ := os.Hostname()
	if hostname == "" {
		hostname = "localhost"
	}
	code, lines, err := c.command("EHLO %s", hostname)
	if err != nil {
		_ = conn.Close()
		return nil, fmt.Errorf("smtp: EHLO: %w", err)
	}
	if code != 250 {
		_ = conn.Close()
		return nil, fmt.Errorf("smtp: EHLO rejected: code=%d", code)
	}
	c.parseExtensions(lines)

	// AUTH(可选)
	if auth != nil && auth.UseAuth && auth.Username != "" {
		if err := c.authenticate(auth); err != nil {
			_ = conn.Close()
			return nil, fmt.Errorf("smtp: auth: %w", err)
		}
	}

	return c, nil
}

// authenticate AUTH PLAIN → 失败降级 LOGIN
//
// 【契约】v2 与 v1 authenticate 语义完全一致
func (c *Client) authenticate(auth *AuthConfig) error {
	if !c.HasExtension("AUTH") {
		// 服务器不宣告 AUTH → 假设本地免认证放行(v1 一致)
		return nil
	}

	// PLAIN: base64("\0user\0pass")
	authStr := "\x00" + auth.Username + "\x00" + auth.Password
	encoded := base64.StdEncoding.EncodeToString([]byte(authStr))

	code, lines, err := c.command("AUTH PLAIN %s", encoded)
	if err != nil {
		return fmt.Errorf("AUTH PLAIN: %w", err)
	}
	if code == 235 {
		return nil
	}
	// PLAIN 失败 → 降级 LOGIN
	if code == 504 || code == 535 || code == 503 {
		return c.authenticateLogin(auth)
	}
	errMsg := ""
	if len(lines) > 0 {
		errMsg = lines[0]
	}
	return fmt.Errorf("AUTH PLAIN rejected [%d]: %s", code, errMsg)
}

// authenticateLogin AUTH LOGIN 分 3 步:command / user / pass
func (c *Client) authenticateLogin(auth *AuthConfig) error {
	code, _, err := c.command("AUTH LOGIN")
	if err != nil {
		return fmt.Errorf("AUTH LOGIN: %w", err)
	}
	if code != 334 {
		return fmt.Errorf("AUTH LOGIN rejected: code=%d", code)
	}

	code, _, err = c.command(base64.StdEncoding.EncodeToString([]byte(auth.Username)))
	if err != nil {
		return fmt.Errorf("send username: %w", err)
	}
	if code != 334 {
		return fmt.Errorf("username rejected: code=%d", code)
	}

	code, lines, err := c.command(base64.StdEncoding.EncodeToString([]byte(auth.Password)))
	if err != nil {
		return fmt.Errorf("send password: %w", err)
	}
	if code != 235 {
		errMsg := ""
		if len(lines) > 0 {
			errMsg = lines[0]
		}
		return fmt.Errorf("AUTH LOGIN rejected [%d]: %s", code, errMsg)
	}
	return nil
}

// Send 发送单封邮件(MAIL FROM → RCPT TO → DATA → body → .CRLF)
//
// 【契约】v2 与 v1 Send 语义完全一致
//
// 【CHK-4 P27】起 goroutine 监听 ctx.Done() → SetDeadline(now)让 Read/Write 立即返回 err
// ctx.cancel 后 in-flight send 5s 内返回 err(而非等 timeout)
//
// 【安全】SMTP 协议以 \r\n 分隔命令;from/to 若含 CR/LF 会注入额外 MAIL FROM/RCPT TO/RSET
// 等命令(经典 SMTP command injection)。上游 reader 已 sanitize,这里是最后一道防线 ——
// fail-fast 拒发,避免静默过滤掉部分字符后发到错误地址。
func (c *Client) Send(ctx context.Context, from, to string, msg []byte) error {
	// 【安全 assert】envelope 里若有 CRLF 立即拒绝(即使上游漏过滤)
	if strings.ContainsAny(from, "\r\n") {
		return fmt.Errorf("smtp: envelope from contains CRLF (injection attempt?): %q", from)
	}
	if strings.ContainsAny(to, "\r\n") {
		return fmt.Errorf("smtp: envelope to contains CRLF (injection attempt?): %q", to)
	}

	// 【M3 修 2026-08-13】入口 fail-fast:若 ctx 已 canceled,立即返回,不发起 SMTP 会话
	// 之前的实现里 ctx-canceled 状态下仍会走完整 30s SMTP 才 fail,违反 CHK-4 "5s 内退出"
	if err := ctx.Err(); err != nil {
		return err
	}

	// 【M3 修】先设置正常 timeout deadline,再起 ctx 监听 goroutine
	// 顺序敏感:若倒序,ctx-Done 时 goroutine 抢先设 deadline=now,后续 SetDeadline(timeout)
	// 会覆盖它,goroutine 已退出不会重触发 → in-flight 走完整 timeout
	_ = c.conn.SetDeadline(time.Now().Add(c.timeout))
	c.lastUsed = time.Now()

	// ctx 监听 goroutine:cancel 时立即 SetDeadline(now)
	sendDone := make(chan struct{})
	defer close(sendDone)
	go func() {
		select {
		case <-ctx.Done():
			_ = c.conn.SetDeadline(time.Now()) // 立即触发 Read/Write err
		case <-sendDone:
		}
	}()

	// 1. MAIL FROM
	code, lines, err := c.command("MAIL FROM:<%s>", from)
	if err != nil {
		return fmt.Errorf("MAIL FROM: %w", err)
	}
	if code != 250 {
		return fmt.Errorf("MAIL FROM rejected [%d]: %s", code, firstLine(lines))
	}

	// 2. RCPT TO
	code, lines, err = c.command("RCPT TO:<%s>", to)
	if err != nil {
		return fmt.Errorf("RCPT TO: %w", err)
	}
	if code != 250 && code != 251 {
		return fmt.Errorf("RCPT TO rejected [%d]: %s", code, firstLine(lines))
	}

	// 3. DATA
	code, lines, err = c.command("DATA")
	if err != nil {
		return fmt.Errorf("DATA: %w", err)
	}
	if code != 354 {
		return fmt.Errorf("DATA rejected [%d]: %s", code, firstLine(lines))
	}

	// 4. body(dot-stuffing + 末尾 .CRLF)
	escapedMsg := escapeDotsInMessage(msg)
	if _, err := c.writer.Write(escapedMsg); err != nil {
		return fmt.Errorf("write body: %w", err)
	}
	if !bytes.HasSuffix(escapedMsg, []byte("\r\n")) {
		_, _ = c.writer.WriteString("\r\n")
	}
	if _, err := c.writer.WriteString(".\r\n"); err != nil {
		return fmt.Errorf("write dot-crlf: %w", err)
	}
	if err := c.writer.Flush(); err != nil {
		return fmt.Errorf("flush: %w", err)
	}

	// 5. 服务器确认
	code, lines, err = c.readResponse()
	if err != nil {
		return fmt.Errorf("await confirm: %w", err)
	}
	if code != 250 {
		return fmt.Errorf("body rejected [%d]: %s", code, firstLine(lines))
	}

	c.sendCount++
	return nil
}

// Reset 发 RSET 重置连接状态(供 Pool.put 复用连接前)
func (c *Client) Reset() error {
	_ = c.conn.SetDeadline(time.Now().Add(c.timeout))
	code, _, err := c.command("RSET")
	if err != nil {
		return err
	}
	if code != 250 {
		return fmt.Errorf("RSET rejected: code=%d", code)
	}
	return nil
}

// Noop 发 NOOP 探活(供 IsHealthy 用)
func (c *Client) Noop() error {
	_ = c.conn.SetDeadline(time.Now().Add(5 * time.Second))
	code, _, err := c.command("NOOP")
	if err != nil {
		return err
	}
	if code != 250 {
		return fmt.Errorf("NOOP rejected: code=%d", code)
	}
	return nil
}

// IsHealthy > 30s 未用 → 发 NOOP 探活;否则返回 true
func (c *Client) IsHealthy() bool {
	if time.Since(c.lastUsed) > 30*time.Second {
		return c.Noop() == nil
	}
	return true
}

// Close 发 QUIT 后关闭 TCP 连接
func (c *Client) Close() error {
	if c.conn == nil {
		return nil
	}
	_ = c.conn.SetDeadline(time.Now().Add(5 * time.Second))
	_, _, _ = c.command("QUIT")
	return c.conn.Close()
}

// SendCount 已发送邮件数
func (c *Client) SendCount() int { return c.sendCount }

// LastUsed 最后使用时间
func (c *Client) LastUsed() time.Time { return c.lastUsed }

// command 发命令 + 读响应
func (c *Client) command(format string, args ...interface{}) (int, []string, error) {
	cmd := fmt.Sprintf(format, args...)
	if _, err := c.writer.WriteString(cmd + "\r\n"); err != nil {
		return 0, nil, fmt.Errorf("send cmd: %w", err)
	}
	if err := c.writer.Flush(); err != nil {
		return 0, nil, fmt.Errorf("flush cmd: %w", err)
	}
	return c.readResponse()
}

// readResponse 读多行 SMTP 响应(支持连续行 "XXX-..." 与结束行 "XXX ...")
func (c *Client) readResponse() (int, []string, error) {
	var lines []string
	for {
		line, err := c.reader.ReadString('\n')
		if err != nil {
			return 0, nil, fmt.Errorf("read: %w", err)
		}
		line = strings.TrimRight(line, "\r\n")
		lines = append(lines, line)

		if len(line) < 3 {
			return 0, lines, fmt.Errorf("bad response: %q", line)
		}
		code, err := strconv.Atoi(line[:3])
		if err != nil {
			return 0, lines, fmt.Errorf("bad code: %q", line)
		}
		if len(line) == 3 || line[3] != '-' {
			return code, lines, nil
		}
	}
}

// parseExtensions 从 EHLO 响应(去掉响应码)提取扩展名(大写)+ 值
func (c *Client) parseExtensions(lines []string) {
	for _, line := range lines {
		if len(line) < 4 {
			continue
		}
		ext := line[4:]
		parts := strings.SplitN(ext, " ", 2)
		name := strings.ToUpper(parts[0])
		value := ""
		if len(parts) > 1 {
			value = parts[1]
		}
		c.extensions[name] = value
	}
}

// HasExtension 服务器是否支持某扩展
func (c *Client) HasExtension(name string) bool {
	_, ok := c.extensions[strings.ToUpper(name)]
	return ok
}

// escapeDotsInMessage 行首点 dot-stuffing(SMTP 透明传输,RFC 5321 §4.5.2)
//
// 【契约】v2 与 v1 escapeDotsInMessage 语义完全一致 —— 现改为包级函数(不需 receiver)
//
// 【规则】
//   - msg[0]=='.' → 首字符补一个 '.'
//   - '\n' 后紧跟 '.' → 中间插一个 '.'
func escapeDotsInMessage(msg []byte) []byte {
	var result bytes.Buffer
	result.Grow(len(msg) + 100)

	if len(msg) > 0 && msg[0] == '.' {
		result.WriteByte('.')
	}
	for i := 0; i < len(msg); i++ {
		result.WriteByte(msg[i])
		if msg[i] == '\n' && i+1 < len(msg) && msg[i+1] == '.' {
			result.WriteByte('.')
		}
	}
	return result.Bytes()
}

// firstLine helper:取切片首元素或空
func firstLine(lines []string) string {
	if len(lines) > 0 {
		return lines[0]
	}
	return ""
}
