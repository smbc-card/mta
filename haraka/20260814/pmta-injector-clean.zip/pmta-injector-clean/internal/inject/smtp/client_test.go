package smtp

import (
	"context"
	"strings"
	"testing"
	"time"
)

// ============================================================================
// escapeDotsInMessage
// ============================================================================

func TestEscapeDotsInMessage(t *testing.T) {
	cases := []struct {
		name string
		in   string
		want string
	}{
		{"empty", "", ""},
		{"no dots", "hello", "hello"},
		{"leading dot", ".hello", "..hello"},
		{"midline dot", "line1\n.dotline", "line1\n..dotline"},
		{"multiple lines", "a\n.b\nc\n.d", "a\n..b\nc\n..d"},
		{"no newline before dot", "a.b", "a.b"},        // 中间点不转义
		{"just newline", "\n", "\n"},
		{"newline then normal", "\nhello", "\nhello"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got := string(escapeDotsInMessage([]byte(c.in)))
			if got != c.want {
				t.Errorf("in=%q\n got=%q\nwant=%q", c.in, got, c.want)
			}
		})
	}
}

// ============================================================================
// Client 端到端(mock server)
// ============================================================================

func TestClient_Connect_Send_Close(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	c, err := connect(s.Addr(), 2*time.Second, false, false, nil)
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	defer c.Close()

	if err := c.Send(context.Background(), "from@x", "to@y", []byte("hello world\r\n")); err != nil {
		t.Fatalf("send: %v", err)
	}
	if c.SendCount() != 1 {
		t.Errorf("SendCount: %d, want=1", c.SendCount())
	}
	if s.sendCount.Load() != 1 {
		t.Errorf("server sendCount: %d, want=1", s.sendCount.Load())
	}
}

func TestClient_WithAuth_PLAIN_Success(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	c, err := connect(s.Addr(), 2*time.Second, false, false, &AuthConfig{
		UseAuth: true, Username: "user", Password: "pass",
	})
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	defer c.Close()

	if s.authCount.Load() != 1 {
		t.Errorf("AUTH count: %d, want=1", s.authCount.Load())
	}
}

func TestClient_AuthFailed(t *testing.T) {
	s := newFakeSMTPServer(t)
	s.failAuth.Store(true)
	defer s.Close()

	_, err := connect(s.Addr(), 2*time.Second, false, false, &AuthConfig{
		UseAuth: true, Username: "user", Password: "pass",
	})
	if err == nil {
		t.Fatal("auth 失败应返回 err")
	}
	if !strings.Contains(err.Error(), "auth") {
		t.Errorf("err 应含 'auth':%v", err)
	}
}

func TestClient_NoAuthExtension_SkipAuth(t *testing.T) {
	// 服务器不宣告 AUTH 扩展 → 客户端跳过 AUTH(v1 一致的宽容)
	s := newFakeSMTPServer(t)
	s.authRequired.Store(false)
	defer s.Close()

	c, err := connect(s.Addr(), 2*time.Second, false, false, &AuthConfig{
		UseAuth: true, Username: "u", Password: "p",
	})
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	defer c.Close()
	// 服务器不应收到 AUTH 命令
	if s.authCount.Load() != 0 {
		t.Errorf("不宣告 AUTH 时不应认证,got=%d", s.authCount.Load())
	}
}

func TestClient_RcptRejected(t *testing.T) {
	s := newFakeSMTPServer(t)
	s.failRcpt.Store(true)
	defer s.Close()

	c, _ := connect(s.Addr(), 2*time.Second, false, false, nil)
	defer c.Close()

	err := c.Send(context.Background(), "from@x", "bad@y", []byte("body\r\n"))
	if err == nil {
		t.Fatal("RCPT 被拒应返回 err")
	}
	if !strings.Contains(err.Error(), "RCPT") {
		t.Errorf("err 应含 RCPT:%v", err)
	}
}

func TestClient_DataRejected(t *testing.T) {
	s := newFakeSMTPServer(t)
	s.failData.Store(true)
	defer s.Close()

	c, _ := connect(s.Addr(), 2*time.Second, false, false, nil)
	defer c.Close()

	err := c.Send(context.Background(), "from@x", "to@y", []byte("body\r\n"))
	if err == nil {
		t.Fatal("DATA body 被拒应返回 err")
	}
}

func TestClient_Reset_Noop(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()
	c, _ := connect(s.Addr(), 2*time.Second, false, false, nil)
	defer c.Close()

	if err := c.Reset(); err != nil {
		t.Errorf("Reset: %v", err)
	}
	if err := c.Noop(); err != nil {
		t.Errorf("Noop: %v", err)
	}
}

func TestClient_IsHealthy(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()
	c, _ := connect(s.Addr(), 2*time.Second, false, false, nil)
	defer c.Close()

	// 刚连上 → 30s 内不发 NOOP,直接 healthy
	if !c.IsHealthy() {
		t.Error("刚连上应 healthy")
	}
	// 手动改 lastUsed 到 40s 前 → 触发 NOOP
	c.lastUsed = time.Now().Add(-40 * time.Second)
	if !c.IsHealthy() {
		t.Error("NOOP 应 healthy")
	}
}

func TestClient_HasExtension(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()
	c, _ := connect(s.Addr(), 2*time.Second, false, false, nil)
	defer c.Close()

	// mock server 宣告 AUTH
	if !c.HasExtension("AUTH") {
		t.Error("AUTH 应支持")
	}
	if !c.HasExtension("auth") { // 大小写不敏感
		t.Error("auth(lowercase) 应支持")
	}
	if c.HasExtension("SIZE") {
		t.Error("SIZE 未宣告应 false")
	}
}

func TestClient_ConnectFail(t *testing.T) {
	// 连接一个不存在的端口
	_, err := connect("127.0.0.1:1", 500*time.Millisecond, false, false, nil)
	if err == nil {
		t.Error("连接不存在端口应 err")
	}
}

func TestClient_Send_LargeMessage(t *testing.T) {
	// 测试 dot-stuffing:body 里含行首点
	s := newFakeSMTPServer(t)
	defer s.Close()

	c, _ := connect(s.Addr(), 2*time.Second, false, false, nil)
	defer c.Close()

	msg := []byte("line1\r\n.dotline\r\nline3\r\n")
	if err := c.Send(context.Background(), "from@x", "to@y", msg); err != nil {
		t.Fatalf("send: %v", err)
	}
}

func TestClient_Send_NoTrailingCRLF(t *testing.T) {
	// body 无末尾 CRLF → Send 应自动补
	s := newFakeSMTPServer(t)
	defer s.Close()
	c, _ := connect(s.Addr(), 2*time.Second, false, false, nil)
	defer c.Close()

	if err := c.Send(context.Background(), "from@x", "to@y", []byte("no crlf")); err != nil {
		t.Errorf("send without CRLF: %v", err)
	}
}

// readResponse 多行通过端到端 mock server 天然覆盖(EHLO 就是多行 "250-... 250 ..." 场景)
