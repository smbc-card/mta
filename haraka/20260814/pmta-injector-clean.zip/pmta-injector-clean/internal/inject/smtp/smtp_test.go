package smtp

import (
	"context"
	"net"
	"strconv"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/inject"
)

// fakeEmail 实现 inject.Email
type fakeEmail struct{ from, to, raw string }

func (e *fakeEmail) Raw() string          { return e.raw }
func (e *fakeEmail) EnvelopeFrom() string { return e.from }
func (e *fakeEmail) EnvelopeTo() string   { return e.to }

// makeCfg 从 fakeSMTPServer.Addr() 构造 minimal cfg
func makeCfg(addr string, useAuth bool) *config.Config {
	host, portStr, _ := net.SplitHostPort(addr)
	port, _ := strconv.Atoi(portStr)
	cfg := &config.Config{
		Performance: config.PerformanceConfig{Workers: 5},
		SMTP: config.SMTPConfig{
			Host:    host,
			Port:    port,
			Timeout: 2,
			UseAuth: useAuth,
		},
	}
	if useAuth {
		cfg.SMTP.Username = "u"
		cfg.SMTP.Password = "p"
	}
	return cfg
}

// ============================================================================
// SMTPInjector.New
// ============================================================================

func TestSMTPInjector_New_Success(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	inj, err := New(makeCfg(s.Addr(), false))
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	defer inj.Close()

	if inj.Mode() != inject.ModeSMTP {
		t.Errorf("Mode: %s, want=%s", inj.Mode(), inject.ModeSMTP)
	}
	if !inj.Enabled() {
		t.Error("Enabled 应 true")
	}
	if inj.Addr() != s.Addr() {
		t.Errorf("Addr: %s, want=%s", inj.Addr(), s.Addr())
	}
}

func TestSMTPInjector_New_WithAuth(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	inj, err := New(makeCfg(s.Addr(), true))
	if err != nil {
		t.Fatalf("New with auth: %v", err)
	}
	defer inj.Close()

	// 预连接触发 1 次 AUTH
	if s.authCount.Load() != 1 {
		t.Errorf("authCount: %d, want=1", s.authCount.Load())
	}
}

func TestSMTPInjector_New_ConnectFail(t *testing.T) {
	cfg := &config.Config{
		Performance: config.PerformanceConfig{Workers: 5},
		SMTP: config.SMTPConfig{Host: "127.0.0.1", Port: 1, Timeout: 1},
	}
	_, err := New(cfg)
	if err == nil {
		t.Error("连接不存在端口应 err")
	}
}

// ============================================================================
// SMTPInjector.Send
// ============================================================================

func TestSMTPInjector_Send(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	inj, _ := New(makeCfg(s.Addr(), false))
	defer inj.Close()

	eml := &fakeEmail{from: "from@x", to: "to@y", raw: "hi\r\n"}
	if err := inj.Send(context.Background(), eml); err != nil {
		t.Fatalf("Send: %v", err)
	}
	if s.sendCount.Load() != 1 {
		t.Errorf("sendCount: %d, want=1", s.sendCount.Load())
	}
}

// ============================================================================
// SMTPInjector.Stats + 池大小策略
// ============================================================================

func TestSMTPInjector_Stats(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	inj, _ := New(makeCfg(s.Addr(), false))
	defer inj.Close()

	// 发几次
	_ = inj.Send(context.Background(), &fakeEmail{"from@x", "to@y", "b\r\n"})
	_ = inj.Send(context.Background(), &fakeEmail{"from@x", "to@y", "b\r\n"})

	st := inj.Stats()
	if st.TotalSent != 2 {
		t.Errorf("Stats.TotalSent: %d, want=2", st.TotalSent)
	}
}

func TestSMTPInjector_Stats_NilPool(t *testing.T) {
	// disabled Injector(pool=nil)
	inj := &SMTPInjector{}
	st := inj.Stats()
	if st != (PoolStats{}) {
		t.Errorf("nil pool Stats 应零值:%+v", st)
	}
}

// ============================================================================
// SMTPInjector.Close 幂等
// ============================================================================

func TestSMTPInjector_Close_Idempotent(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()
	inj, _ := New(makeCfg(s.Addr(), false))

	if err := inj.Close(); err != nil {
		t.Errorf("Close: %v", err)
	}
	if err := inj.Close(); err != nil {
		t.Errorf("重复 Close: %v", err)
	}
}
