// Package smtp SMTP 邮件投递(连接池 + TLS + AUTH + 重试)
//
// 【契约】v2 与 v1 smtp/{client.go 393 行 + pool.go 302 行} 语义等价
//
// 【设计】
//   - Pool:连接池(默认 poolSize 由 cfg 决定或 min(workers, 100))
//   - Client:单连接封装(每 100 封重连,避免 MTA session 疲劳)
//   - TLS / AUTH 按 cfg 决定
//   - SendWithRetry:失败重试 2 次(与 v1 一致)
//
// 【线程安全】Pool 内部 mutex 保护 conn 出借;并发 Send 安全
//
// 【依赖】config + 标准库 net/smtp + crypto/tls
package smtp
