package smtp

import (
	"context"
	"fmt"
	"time"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/inject"
)

// AuthConfig SMTP AUTH 配置
//
// 【契约】v2 与 v1 smtp.AuthConfig 字段完全一致
type AuthConfig struct {
	UseAuth  bool
	Username string
	Password string
}

// PoolConfig SMTP 连接池配置
//
// 【契约】v2 与 v1 smtp.PoolConfig 字段完全一致
type PoolConfig struct {
	Addr           string        // "host:port"
	Size           int           // 连接池大小(默认 10)
	Timeout        time.Duration // 单次操作超时(dial / read / write;默认 30s)
	UseTLS         bool
	SkipVerify     bool
	MaxSendPerConn int         // 单连接最大发送次数(默认 100;超过重建)
	Auth           *AuthConfig // nil 时不 AUTH
}

// SMTPInjector 实现 inject.Injector(SMTP 分支)
type SMTPInjector struct {
	pool *Pool
	addr string
}

// New 创建 SMTPInjector(读 cfg.SMTP 构造 PoolConfig + NewPool)
//
// 【契约】v2 与 v1 injector.newSMTP 语义完全一致
//
// 【失败】cfg.SMTP.Host/Port 未配 → err;pool 预连接失败 → err
func New(cfg *config.Config) (*SMTPInjector, error) {
	addr := fmt.Sprintf("%s:%d", cfg.SMTP.Host, cfg.SMTP.Port)

	// 连接池大小策略(v1 一致):
	//   cfg.SMTP.MaxConn > 0 → 直接用
	//   否则 → min(max(Workers, 10), 100)
	poolSize := cfg.SMTP.MaxConn
	if poolSize <= 0 {
		poolSize = cfg.Performance.Workers
		if poolSize > 100 {
			poolSize = 100
		}
		if poolSize < 10 {
			poolSize = 10
		}
	}

	var authCfg *AuthConfig
	if cfg.SMTP.UseAuth && cfg.SMTP.Username != "" {
		authCfg = &AuthConfig{
			UseAuth:  true,
			Username: cfg.SMTP.Username,
			Password: cfg.SMTP.Password,
		}
	}

	poolConfig := PoolConfig{
		Addr:           addr,
		Size:           poolSize,
		Timeout:        time.Duration(cfg.SMTP.Timeout) * time.Second,
		UseTLS:         cfg.SMTP.UseTLS,
		SkipVerify:     cfg.SMTP.SkipVerify,
		MaxSendPerConn: 100, // v1 硬编码 100
		Auth:           authCfg,
	}

	pool, err := NewPool(poolConfig)
	if err != nil {
		return nil, fmt.Errorf("smtp: create pool: %w", err)
	}

	return &SMTPInjector{
		pool: pool,
		addr: addr,
	}, nil
}

// Send 实现 inject.Injector
//
// 【重试】默认 2 次(与 v1 dispatcher 传参一致)
// 【CHK-4】ctx 传给 pool.SendWithRetry;cancel 时中断重试 + client.SetDeadline
func (s *SMTPInjector) Send(ctx context.Context, eml inject.Email) error {
	return s.pool.SendWithRetry(ctx, eml.EnvelopeFrom(), eml.EnvelopeTo(), []byte(eml.Raw()), 2)
}

// Close 实现 inject.Injector
func (s *SMTPInjector) Close() error {
	if s.pool != nil {
		s.pool.Close()
	}
	return nil
}

// Mode 实现 inject.Injector
func (s *SMTPInjector) Mode() string { return inject.ModeSMTP }

// Enabled 实现 inject.Injector
func (s *SMTPInjector) Enabled() bool { return true }

// Addr 返回 SMTP 服务器地址(供 log / stats 用)
func (s *SMTPInjector) Addr() string { return s.addr }

// Stats 返回池统计(供 stats endpoint 用)
func (s *SMTPInjector) Stats() PoolStats {
	if s.pool == nil {
		return PoolStats{}
	}
	return s.pool.Stats()
}
