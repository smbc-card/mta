package smtp

import (
	"context"
	"strings"
	"sync"
	"testing"
	"time"
)

// ============================================================================
// NewPool 边界
// ============================================================================

func TestNewPool_Success(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	p, err := NewPool(PoolConfig{
		Addr:    s.Addr(),
		Size:    3,
		Timeout: 2 * time.Second,
	})
	if err != nil {
		t.Fatalf("NewPool: %v", err)
	}
	defer p.Close()

	if p.Size() != 3 {
		t.Errorf("Size: %d, want=3", p.Size())
	}
	// 预连接了 1 个
	if p.ActiveCount() != 1 {
		t.Errorf("ActiveCount 预连接后:%d, want=1", p.ActiveCount())
	}
}

func TestNewPool_Defaults(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	// Size/Timeout/MaxSendPerConn 都 0 → 用默认
	p, err := NewPool(PoolConfig{Addr: s.Addr()})
	if err != nil {
		t.Fatalf("NewPool: %v", err)
	}
	defer p.Close()
	if p.Size() != 10 {
		t.Errorf("默认 Size:%d, want=10", p.Size())
	}
	if p.config.MaxSendPerConn != 100 {
		t.Errorf("默认 MaxSendPerConn:%d, want=100", p.config.MaxSendPerConn)
	}
	if p.config.Timeout != 30*time.Second {
		t.Errorf("默认 Timeout:%v, want=30s", p.config.Timeout)
	}
}

func TestNewPool_ConnectFail(t *testing.T) {
	_, err := NewPool(PoolConfig{
		Addr:    "127.0.0.1:1",
		Timeout: 500 * time.Millisecond,
	})
	if err == nil {
		t.Error("连接失败应 err")
	}
}

// ============================================================================
// Send / SendWithRetry
// ============================================================================

func TestPool_Send_Success(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	p, _ := NewPool(PoolConfig{Addr: s.Addr(), Size: 2, Timeout: 2 * time.Second})
	defer p.Close()

	for i := 0; i < 5; i++ {
		if err := p.Send(context.Background(), "from@x", "to@y", []byte("hello\r\n")); err != nil {
			t.Fatalf("Send %d: %v", i, err)
		}
	}
	if p.TotalSent() != 5 {
		t.Errorf("TotalSent: %d, want=5", p.TotalSent())
	}
	if s.sendCount.Load() != 5 {
		t.Errorf("server sendCount: %d, want=5", s.sendCount.Load())
	}
}

func TestPool_Send_RcptFail(t *testing.T) {
	s := newFakeSMTPServer(t)
	s.failRcpt.Store(true)
	defer s.Close()

	p, _ := NewPool(PoolConfig{Addr: s.Addr(), Size: 1, Timeout: 2 * time.Second})
	defer p.Close()

	err := p.Send(context.Background(), "from@x", "bad@y", []byte("body\r\n"))
	if err == nil {
		t.Fatal("Rcpt fail 应 err")
	}
	// 失败后连接应被 discard(active 减 1)
	// pool 预连接 1 + 失败后 discard = 0
	if p.ActiveCount() != 0 {
		t.Errorf("失败后 active:%d, want=0", p.ActiveCount())
	}
}

func TestPool_SendWithRetry(t *testing.T) {
	// 全部失败场景 → maxRetries+1 次后返回 err
	s := newFakeSMTPServer(t)
	s.failRcpt.Store(true)
	defer s.Close()

	p, _ := NewPool(PoolConfig{Addr: s.Addr(), Size: 3, Timeout: 2 * time.Second})
	defer p.Close()

	err := p.SendWithRetry(context.Background(), "from@x", "bad@y", []byte("body\r\n"), 2)
	if err == nil {
		t.Fatal("全部失败应 err")
	}
	if !strings.Contains(err.Error(), "retries=2") {
		t.Errorf("err 应含 'retries=2':%v", err)
	}
}

func TestPool_SendWithRetry_Success(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	p, _ := NewPool(PoolConfig{Addr: s.Addr(), Size: 2, Timeout: 2 * time.Second})
	defer p.Close()

	if err := p.SendWithRetry(context.Background(), "from@x", "to@y", []byte("body\r\n"), 2); err != nil {
		t.Fatalf("SendWithRetry: %v", err)
	}
	// 只应发 1 次(首次成功)
	if s.sendCount.Load() != 1 {
		t.Errorf("sendCount: %d, want=1", s.sendCount.Load())
	}
}

// ============================================================================
// 并发 + 连接复用
// ============================================================================

func TestPool_Concurrent(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	p, _ := NewPool(PoolConfig{Addr: s.Addr(), Size: 5, Timeout: 3 * time.Second})
	defer p.Close()

	var wg sync.WaitGroup
	const total = 50
	for i := 0; i < total; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_ = p.Send(context.Background(), "from@x", "to@y", []byte("body\r\n"))
		}()
	}
	wg.Wait()

	if p.TotalSent() != total {
		t.Errorf("TotalSent: %d, want=%d", p.TotalSent(), total)
	}
	// active 应 ≤ Size(5)
	if p.ActiveCount() > 5 {
		t.Errorf("active 超 Size:%d", p.ActiveCount())
	}
}

// ============================================================================
// shouldReplaceClient / MaxSendPerConn
// ============================================================================

func TestPool_MaxSendPerConn_ReplacesClient(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	// 单连接发 5 次后重建(总共发 12 次 → 至少 2 次重建)
	p, _ := NewPool(PoolConfig{
		Addr: s.Addr(), Size: 1, Timeout: 2 * time.Second,
		MaxSendPerConn: 5,
	})
	defer p.Close()

	for i := 0; i < 12; i++ {
		if err := p.Send(context.Background(), "from@x", "to@y", []byte("body\r\n")); err != nil {
			t.Fatalf("Send %d: %v", i, err)
		}
	}
	stats := p.Stats()
	// 创建应 ≥ 3 (初始 1 + 至少 2 次重建)
	if stats.Created < 3 {
		t.Errorf("Created:%d, want ≥3(应触发重建)", stats.Created)
	}
	// TotalSent == 12
	if stats.TotalSent != 12 {
		t.Errorf("TotalSent:%d, want=12", stats.TotalSent)
	}
}

// ============================================================================
// Close 幂等
// ============================================================================

func TestPool_Close_Idempotent(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	p, _ := NewPool(PoolConfig{Addr: s.Addr(), Size: 2, Timeout: 2 * time.Second})
	p.Close()
	p.Close() // 第 2 次不应 panic
	p.Close()

	if !p.IsClosed() {
		t.Error("Close 后应 IsClosed=true")
	}
	// Close 后 Send 应 err
	err := p.Send(context.Background(), "from@x", "to@y", []byte("body\r\n"))
	if err == nil {
		t.Error("Close 后 Send 应 err")
	}
}

// ============================================================================
// Stats
// ============================================================================

func TestPool_Stats(t *testing.T) {
	s := newFakeSMTPServer(t)
	defer s.Close()

	p, _ := NewPool(PoolConfig{Addr: s.Addr(), Size: 3, Timeout: 2 * time.Second})
	defer p.Close()

	// 发 3 次
	for i := 0; i < 3; i++ {
		_ = p.Send(context.Background(), "from@x", "to@y", []byte("b\r\n"))
	}
	st := p.Stats()
	if st.Size != 3 {
		t.Errorf("Size:%d, want=3", st.Size)
	}
	if st.TotalSent != 3 {
		t.Errorf("TotalSent:%d, want=3", st.TotalSent)
	}
	if st.Created < 1 {
		t.Errorf("Created:%d, want ≥1", st.Created)
	}
}

// ============================================================================
// SMTPInjector wrapper(通过 fake cfg 构造 —— 需要 config 支撑,故用 minimal cfg)
// ============================================================================
// 【注意】SMTPInjector.New 需要 *config.Config,含 SMTP.Host/Port 等
// 直接测试 wrapper 需引 config 包;此处通过 fake server 端口构造 Config 测

// SMTPInjector 测试见 smtp_test.go(避免文件过长)
