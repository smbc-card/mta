package smtp

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"
)

// Pool SMTP 连接池
//
// 【契约】v2 与 v1 smtp/pool.go::Pool 语义完全一致
//
// 【线程安全】所有字段访问用 atomic;clients channel 天然并发安全;mu 只保护 Close 序列化
type Pool struct {
	config PoolConfig

	clients   chan *Client
	mu        sync.Mutex
	closed    int32
	active    int32
	created   int64
	failed    int64
	reused    int64
	totalSent int64
}

// PoolStats 连接池统计
type PoolStats struct {
	Active    int
	Available int
	Size      int
	Created   int64
	Failed    int64
	Reused    int64
	TotalSent int64
	Closed    bool
}

// NewPool 创建 SMTP 连接池(v1 v9 修复问题9:含 nil-safe)
//
// 【契约】v2 与 v1 NewPool 语义完全一致
//
// 【预连接】启动时 createNew 一个连接验证配置(dial 失败则 New 失败)
func NewPool(config PoolConfig) (*Pool, error) {
	if config.Size <= 0 {
		config.Size = 10
	}
	if config.Timeout <= 0 {
		config.Timeout = 30 * time.Second
	}
	if config.MaxSendPerConn <= 0 {
		config.MaxSendPerConn = 100
	}

	p := &Pool{
		config:  config,
		clients: make(chan *Client, config.Size),
	}

	// 预创建 1 连接以校验配置正确
	client, err := p.createNew()
	if err != nil {
		return nil, fmt.Errorf("smtp: pool init connect %s: %w", config.Addr, err)
	}
	p.clients <- client
	return p, nil
}

// Send 发一封(自动管理连接)
//
// 【CHK-4】ctx.cancel 会传给 client.Send → SetDeadline 立即返回 err
func (p *Pool) Send(ctx context.Context, from, to string, msg []byte) error {
	client, err := p.get()
	if err != nil {
		return fmt.Errorf("get conn: %w", err)
	}

	if err := client.Send(ctx, from, to, msg); err != nil {
		p.discard(client)
		return err
	}
	p.put(client)
	atomic.AddInt64(&p.totalSent, 1)
	return nil
}

// SendWithRetry 失败重试 maxRetries 次(每次 sleep 100*(i+1) ms)
//
// 【契约】v2 与 v1 SendWithRetry 语义完全一致(默认 2 次重试,与 v1 dispatcher 传参一致)
//
// 【CHK-4】重试 sleep 前检查 ctx.Done —— cancel 后立即返回,不继续重试
func (p *Pool) SendWithRetry(ctx context.Context, from, to string, msg []byte, maxRetries int) error {
	var lastErr error
	for i := 0; i <= maxRetries; i++ {
		if err := p.Send(ctx, from, to, msg); err == nil {
			return nil
		} else {
			lastErr = err
		}
		if i == maxRetries {
			break
		}
		// sleep 前检查 ctx.Done()
		select {
		case <-ctx.Done():
			return fmt.Errorf("send failed (retries=%d, ctx canceled): %w", i, lastErr)
		case <-time.After(time.Duration(100*(i+1)) * time.Millisecond):
		}
	}
	return fmt.Errorf("send failed (retries=%d): %w", maxRetries, lastErr)
}

// get 从池取或创建新连接
//
// 【v1 修复问题9】nil 检查(chan close 后可能取到 nil)
func (p *Pool) get() (*Client, error) {
	if atomic.LoadInt32(&p.closed) == 1 {
		return nil, fmt.Errorf("pool closed")
	}

	select {
	case client := <-p.clients:
		if client == nil {
			return nil, fmt.Errorf("pool closed")
		}
		if p.shouldReplaceClient(client) {
			_ = client.Close()
			atomic.AddInt32(&p.active, -1)
			return p.createNew()
		}
		atomic.AddInt64(&p.reused, 1)
		return client, nil

	default:
		// 池空 + active < size → 创建新
		if atomic.LoadInt32(&p.active) < int32(p.config.Size) {
			return p.createNew()
		}
		// active 已满 → 等待
		select {
		case client := <-p.clients:
			if client == nil {
				return nil, fmt.Errorf("pool closed")
			}
			if p.shouldReplaceClient(client) {
				_ = client.Close()
				atomic.AddInt32(&p.active, -1)
				return p.createNew()
			}
			atomic.AddInt64(&p.reused, 1)
			return client, nil
		case <-time.After(p.config.Timeout):
			return nil, fmt.Errorf("get conn timeout")
		}
	}
}

// put 归还连接(健康 + Reset OK → 放回;否则关闭)
func (p *Pool) put(client *Client) {
	if client == nil {
		return
	}
	if atomic.LoadInt32(&p.closed) == 1 {
		_ = client.Close()
		atomic.AddInt32(&p.active, -1)
		return
	}
	if p.shouldReplaceClient(client) {
		_ = client.Close()
		atomic.AddInt32(&p.active, -1)
		return
	}
	if err := client.Reset(); err != nil {
		_ = client.Close()
		atomic.AddInt32(&p.active, -1)
		return
	}
	select {
	case p.clients <- client:
	default:
		// 池已满 → 关闭
		_ = client.Close()
		atomic.AddInt32(&p.active, -1)
	}
}

// discard 直接丢弃(发送失败时)
func (p *Pool) discard(client *Client) {
	if client == nil {
		return
	}
	_ = client.Close()
	atomic.AddInt32(&p.active, -1)
}

// shouldReplaceClient 是否需要替换连接
//
// 【判定】
//  1. IsHealthy 失败(NOOP 探活失败)
//  2. sendCount ≥ MaxSendPerConn(避免 MTA session 疲劳)
func (p *Pool) shouldReplaceClient(client *Client) bool {
	if !client.IsHealthy() {
		return true
	}
	if p.config.MaxSendPerConn > 0 && client.SendCount() >= p.config.MaxSendPerConn {
		return true
	}
	return false
}

// createNew 建立新连接
func (p *Pool) createNew() (*Client, error) {
	client, err := connect(p.config.Addr, p.config.Timeout, p.config.UseTLS, p.config.SkipVerify, p.config.Auth)
	if err != nil {
		atomic.AddInt64(&p.failed, 1)
		return nil, err
	}
	atomic.AddInt32(&p.active, 1)
	atomic.AddInt64(&p.created, 1)
	return client, nil
}

// Close 关闭连接池(CAS 保幂等)
func (p *Pool) Close() {
	if !atomic.CompareAndSwapInt32(&p.closed, 0, 1) {
		return
	}
	p.mu.Lock()
	defer p.mu.Unlock()

	close(p.clients)
	for client := range p.clients {
		_ = client.Close()
	}
	atomic.StoreInt32(&p.active, 0)
}

// Stats 池统计快照
func (p *Pool) Stats() PoolStats {
	return PoolStats{
		Active:    int(atomic.LoadInt32(&p.active)),
		Available: len(p.clients),
		Size:      p.config.Size,
		Created:   atomic.LoadInt64(&p.created),
		Failed:    atomic.LoadInt64(&p.failed),
		Reused:    atomic.LoadInt64(&p.reused),
		TotalSent: atomic.LoadInt64(&p.totalSent),
		Closed:    atomic.LoadInt32(&p.closed) == 1,
	}
}

// IsClosed 是否已关闭
func (p *Pool) IsClosed() bool { return atomic.LoadInt32(&p.closed) == 1 }

// Size 池大小
func (p *Pool) Size() int { return p.config.Size }

// ActiveCount 当前活跃连接数
func (p *Pool) ActiveCount() int { return int(atomic.LoadInt32(&p.active)) }

// TotalSent 累计发送数
func (p *Pool) TotalSent() int64 { return atomic.LoadInt64(&p.totalSent) }
