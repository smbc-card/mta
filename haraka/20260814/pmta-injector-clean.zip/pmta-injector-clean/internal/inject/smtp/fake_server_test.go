package smtp

import (
	"bufio"
	"fmt"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// fakeSMTPServer 简易 SMTP 服务器(测试用)
//
// 【行为】按 v1 客户端预期的 SMTP 序列响应
// 【可配置】failAuth / failRcpt / failData 触发对应命令返回失败码
type fakeSMTPServer struct {
	addr    string
	listen  net.Listener
	stopped atomic.Bool

	// 计数(用于断言)
	connCount  atomic.Int64
	sendCount  atomic.Int64
	authCount  atomic.Int64
	quitCount  atomic.Int64

	// 可配置行为
	failAuth  atomic.Bool  // AUTH 返回 535
	failRcpt  atomic.Bool  // RCPT TO 返回 550
	failData  atomic.Bool  // DATA body 返回 554
	authRequired atomic.Bool // EHLO 是否宣告 AUTH 扩展

	wg sync.WaitGroup
}

// newFakeSMTPServer 启动本地 SMTP 服务(监听随机端口)
func newFakeSMTPServer(t *testing.T) *fakeSMTPServer {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	s := &fakeSMTPServer{
		listen: ln,
		addr:   ln.Addr().String(),
	}
	s.authRequired.Store(true) // 默认宣告 AUTH

	s.wg.Add(1)
	go s.acceptLoop()
	return s
}

// Addr 返回监听地址
func (s *fakeSMTPServer) Addr() string { return s.addr }

// Close 停止服务器
func (s *fakeSMTPServer) Close() {
	s.stopped.Store(true)
	_ = s.listen.Close()
	s.wg.Wait()
}

// acceptLoop 接受连接
func (s *fakeSMTPServer) acceptLoop() {
	defer s.wg.Done()
	for {
		conn, err := s.listen.Accept()
		if err != nil {
			return // listener closed
		}
		s.connCount.Add(1)
		s.wg.Add(1)
		go s.handleConn(conn)
	}
}

// handleConn 处理单个连接
func (s *fakeSMTPServer) handleConn(conn net.Conn) {
	defer s.wg.Done()
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(10 * time.Second))

	reader := bufio.NewReader(conn)
	writer := bufio.NewWriter(conn)

	// 欢迎
	fmt.Fprintf(writer, "220 mock ready\r\n")
	_ = writer.Flush()

	inDATA := false
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			return
		}
		line = strings.TrimRight(line, "\r\n")

		if inDATA {
			if line == "." {
				inDATA = false
				if s.failData.Load() {
					fmt.Fprintf(writer, "554 body rejected\r\n")
				} else {
					s.sendCount.Add(1)
					fmt.Fprintf(writer, "250 ok\r\n")
				}
				_ = writer.Flush()
			}
			continue
		}

		upper := strings.ToUpper(line)
		switch {
		case strings.HasPrefix(upper, "EHLO"):
			if s.authRequired.Load() {
				fmt.Fprintf(writer, "250-mock\r\n")
				fmt.Fprintf(writer, "250 AUTH PLAIN LOGIN\r\n")
			} else {
				fmt.Fprintf(writer, "250 mock\r\n")
			}
		case strings.HasPrefix(upper, "AUTH PLAIN"):
			s.authCount.Add(1)
			if s.failAuth.Load() {
				fmt.Fprintf(writer, "535 auth failed\r\n")
			} else {
				fmt.Fprintf(writer, "235 auth ok\r\n")
			}
		case strings.HasPrefix(upper, "AUTH LOGIN"):
			s.authCount.Add(1)
			// 3 阶段
			fmt.Fprintf(writer, "334 VXNlcm5hbWU6\r\n") // "Username:"
			_ = writer.Flush()
			_, _ = reader.ReadString('\n') // user
			fmt.Fprintf(writer, "334 UGFzc3dvcmQ6\r\n") // "Password:"
			_ = writer.Flush()
			_, _ = reader.ReadString('\n') // pass
			if s.failAuth.Load() {
				fmt.Fprintf(writer, "535 auth failed\r\n")
			} else {
				fmt.Fprintf(writer, "235 auth ok\r\n")
			}
		case strings.HasPrefix(upper, "MAIL FROM"):
			fmt.Fprintf(writer, "250 sender ok\r\n")
		case strings.HasPrefix(upper, "RCPT TO"):
			if s.failRcpt.Load() {
				fmt.Fprintf(writer, "550 no such user\r\n")
			} else {
				fmt.Fprintf(writer, "250 recipient ok\r\n")
			}
		case upper == "DATA":
			fmt.Fprintf(writer, "354 end with .\r\n")
			inDATA = true
		case upper == "RSET":
			fmt.Fprintf(writer, "250 reset ok\r\n")
		case upper == "NOOP":
			fmt.Fprintf(writer, "250 noop ok\r\n")
		case upper == "QUIT":
			s.quitCount.Add(1)
			fmt.Fprintf(writer, "221 bye\r\n")
			_ = writer.Flush()
			return
		default:
			fmt.Fprintf(writer, "500 unknown\r\n")
		}
		_ = writer.Flush()
	}
}
