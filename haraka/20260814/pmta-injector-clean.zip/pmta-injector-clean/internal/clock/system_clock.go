package clock

import "time"

// systemClock 基于 time.Now() 的 Clock 实现(**生产用**)
// 无内部状态,值类型接收器足够
type systemClock struct{}

// NewSystemClock 创建生产用的系统时钟
//
// 用法:
//
//	c := clock.NewSystemClock()
//	now := c.Now()  // 等价 time.Now()
func NewSystemClock() Clock {
	return systemClock{}
}

func (systemClock) Now() time.Time {
	return time.Now()
}

func (systemClock) Since(t time.Time) time.Duration {
	return time.Since(t)
}
