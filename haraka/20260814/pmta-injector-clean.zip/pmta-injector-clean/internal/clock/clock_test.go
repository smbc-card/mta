package clock

import (
	"testing"
	"time"
)

// ===== SystemClock =====

// TestSystemClock_NowMonotonic Now() 相邻调用应单调递增(sanity check)
func TestSystemClock_NowMonotonic(t *testing.T) {
	c := NewSystemClock()
	t1 := c.Now()
	time.Sleep(1 * time.Millisecond)
	t2 := c.Now()
	if !t2.After(t1) {
		t.Errorf("SystemClock 的 Now() 应单调递增,得到 t1=%v t2=%v", t1, t2)
	}
}

// TestSystemClock_Since Since 应至少反映 Sleep 时长
func TestSystemClock_Since(t *testing.T) {
	c := NewSystemClock()
	t1 := c.Now()
	time.Sleep(2 * time.Millisecond)
	d := c.Since(t1)
	if d < 1*time.Millisecond {
		t.Errorf("Since 应 >= 1ms,得到 %v", d)
	}
}

// ===== FixedClock =====

// TestFixedClock_NowReturnsFixed 多次调用 Now() 都返回同一时刻
func TestFixedClock_NowReturnsFixed(t *testing.T) {
	jst := time.FixedZone("JST", 9*3600)
	fixed := time.Date(2026, 8, 7, 15, 52, 1, 0, jst)

	c := NewFixedClock(fixed)

	for i := 0; i < 10; i++ {
		got := c.Now()
		if !got.Equal(fixed) {
			t.Errorf("第 %d 次: Now() 应返回 %v, 得到 %v", i, fixed, got)
		}
	}
}

// TestFixedClock_Since_Past Since 相对固定时间计算,不受真实流逝影响
func TestFixedClock_Since_Past(t *testing.T) {
	jst := time.FixedZone("JST", 9*3600)
	fixed := time.Date(2026, 8, 7, 15, 52, 1, 0, jst)
	c := NewFixedClock(fixed)

	past := fixed.Add(-5 * time.Minute)
	d := c.Since(past)
	if d != 5*time.Minute {
		t.Errorf("Since(past) 应返回 5m, 得到 %v", d)
	}
}

// TestFixedClock_Since_Future 未来时间的 Since 应返回负值
func TestFixedClock_Since_Future(t *testing.T) {
	jst := time.FixedZone("JST", 9*3600)
	fixed := time.Date(2026, 8, 7, 15, 52, 1, 0, jst)
	c := NewFixedClock(fixed)

	future := fixed.Add(1 * time.Minute)
	d := c.Since(future)
	if d != -1*time.Minute {
		t.Errorf("Since(future) 应返回 -1m, 得到 %v", d)
	}
}

// TestFixedClock_TimezonePreserved 时区应从构造时传入的 time.Time 保留
func TestFixedClock_TimezonePreserved(t *testing.T) {
	jst := time.FixedZone("JST", 9*3600)
	fixed := time.Date(2026, 8, 7, 15, 52, 1, 0, jst)
	c := NewFixedClock(fixed)

	got := c.Now()
	name, offset := got.Zone()
	if name != "JST" {
		t.Errorf("时区名应保留 JST, 得到 %q", name)
	}
	if offset != 9*3600 {
		t.Errorf("时区偏移应保留 +09:00 (9*3600s), 得到 %d s", offset)
	}
}

// TestFixedClock_UTC 支持 UTC 时区
func TestFixedClock_UTC(t *testing.T) {
	fixed := time.Date(2026, 8, 7, 15, 52, 1, 0, time.UTC)
	c := NewFixedClock(fixed)

	got := c.Now()
	if got.Location() != time.UTC {
		t.Errorf("UTC 时区应保留,得到 %v", got.Location())
	}
}
