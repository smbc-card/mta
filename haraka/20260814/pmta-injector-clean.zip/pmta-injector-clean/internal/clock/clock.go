// Package clock 定义 v2 里所有时间源的抽象接口
//
// 依赖注入友好:测试期传入 NewFixedClock(t) 保证时间固定;
// 生产传入 NewSystemClock() 用真实时间。
//
// 【Week 2 Day 6 骨架】方法集限定为 2 个(Now / Since),覆盖 v1 实际用到的场景。
// 未来若用到 Sleep/After/NewTimer/NewTicker 等测试痛点再扩展。
package clock

import "time"

// Clock 时间源接口
type Clock interface {
	// Now 返回"当前"时间
	// SystemClock 返回 time.Now();FixedClock 返回构造时传入的固定值
	Now() time.Time

	// Since 返回从 t 到"当前时间"的持续时长,等价于 clock.Now().Sub(t)
	// FixedClock 里 Since 也用固定值计算(不会因真实时间流逝而变)
	Since(t time.Time) time.Duration
}
