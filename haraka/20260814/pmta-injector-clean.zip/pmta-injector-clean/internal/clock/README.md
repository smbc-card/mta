# internal/clock

**用途**:v2 里所有时间源的抽象接口 + 具体实现,支持依赖注入。

## 快速开始

**生产代码**(用真实时间):

```go
import "__MODULE_PLACEHOLDER__/internal/clock"

c := clock.NewSystemClock()
now := c.Now()  // 等价 time.Now()
```

**测试代码**(固定时间,跨次可复现):

```go
import "time"

jst := time.FixedZone("JST", 9*3600)
fixed := time.Date(2026, 8, 7, 15, 52, 1, 0, jst)
c := clock.NewFixedClock(fixed)
c.Now()  // 永远返回 2026-08-07 15:52:01 +09:00
```

## Clock interface 方法集(2 个)

| 方法 | 语义 |
|------|------|
| `Now() time.Time` | 返回当前时间(SystemClock 返回 time.Now,FixedClock 返回构造值) |
| `Since(t time.Time) time.Duration` | 返回 Now() - t |

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| 生产读时间 | 包级 `time.Now()`(不可注入) | `NewSystemClock().Now()` |
| Day 4 测试固定时间 | patchFixedTime 补丁改源码 | `NewFixedClock(t)` 依赖注入 |
| Received 时间链 | 递减 `time.Now()`(每封不一样,难 diff) | 传入 Fixed → Now 稳定,便于跨次 diff |

## 未来扩展

Week 3+ 若用到,补齐:

- `Sleep(d time.Duration)` —— 可模拟的睡眠(FakeClock 立即返回)
- `After(d time.Duration) <-chan time.Time` —— 可模拟的 After
- `NewTimer(d time.Duration) Timer` —— 可模拟的 Timer/Ticker
- `FreezableClock` —— `Advance(d)` 前进时间(比 FixedClock 更灵活,支持模拟时间流逝)

当前 Day 6 只需 Now + Since,不过度设计。

## 测试

```bash
go test -cover ./internal/clock/...
# 预期覆盖率 ≥ 90%
```
