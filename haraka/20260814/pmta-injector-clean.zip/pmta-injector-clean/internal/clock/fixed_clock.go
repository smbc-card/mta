package clock

import "time"

// fixedClock 固定时间的 Clock 实现(**测试用**)
// 所有 Now() 调用都返回构造时传入的时间
type fixedClock struct {
	t time.Time
}

// NewFixedClock 创建固定时间的 Clock
//
// 保证跨次调用返回同一时刻,适用于:
//   - 单测里需要"当前时间"确定的场景
//   - v1 Day 4 补丁里 patchFixedTime 的 v2 抽象替代
//
// 用法示例:
//
//	jst := time.FixedZone("JST", 9*3600)
//	fixed := time.Date(2026, 8, 7, 15, 52, 1, 0, jst)
//	c := clock.NewFixedClock(fixed)
//	c.Now()  // 永远返回 2026-08-07 15:52:01 +09:00
//	c.Since(fixed.Add(-5*time.Minute))  // 5m0s(固定值,不受实际流逝影响)
func NewFixedClock(t time.Time) Clock {
	return &fixedClock{t: t}
}

func (c *fixedClock) Now() time.Time {
	return c.t
}

func (c *fixedClock) Since(t time.Time) time.Duration {
	return c.t.Sub(t)
}
