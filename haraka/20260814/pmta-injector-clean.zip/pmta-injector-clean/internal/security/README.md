# internal/security

**用途**:v2 里所有安全过滤 / 清理逻辑的集中所在。

【Week 2 Day 9 骨架】只提供 `sanitize`(CRLF 过滤 + BOM 剥离 + TrimSpace)。
未来若加入其他安全逻辑(邮箱白名单 / 签名验证等),各自独立文件。

## API 一览

### 纯函数(并发安全)

```go
// TrimSpace + 内部 CRLF 替换空格 + 再次 TrimSpace
func SanitizeLine(s string) string

// 与 SanitizeLine 语义等价,只是命名更契合"邮件头值"场景
func SanitizeHeaderValue(v string) string
```

### 有状态 struct(每文件一个实例)

```go
// BOMStripper 首行 UTF-8 BOM 剥离器
type BOMStripper struct { ... }
func NewBOMStripper() *BOMStripper
func (s *BOMStripper) Strip(line string) string   // 首次剥 BOM,后续原样返回
func (s *BOMStripper) IsDone() bool
```

## 快速开始

**用于 ReadEmailList**(参考 v1 reader/reader.go:398-424 的 ReadEmailList 契约 §7):

```go
import "__MODULE_PLACEHOLDER__/internal/security"

stripper := security.NewBOMStripper()
for scanner.Scan() {
    line := security.SanitizeLine(scanner.Text())
    if line == "" { continue }  // 空行跳过
    line = stripper.Strip(line)  // 首行 BOM
    line = security.SanitizeLine(line)  // BOM 剥离后可能残留 whitespace
    if line == "" { continue }
    emails = append(emails, line)
}
```

**用于邮件头值防注入**:

```go
// 用户在 name 里若含 \r\n,会被解读成额外邮件头(经典注入攻击)
name := security.SanitizeHeaderValue(userName)
subject := security.SanitizeHeaderValue(userSubject)
```

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| CRLF 过滤 | 散在 reader.go / builder.go / headers.go 多处 | 集中 `SanitizeLine` 一个函数 |
| BOM 剥离 | reader.go 里 `isFirstLine bool` 临时变量 | `BOMStripper` struct(可注入 / 单测友好) |
| TrimSpace | 手动 `strings.TrimSpace` 每处 | `SanitizeLine` 内部处理 |
| 邮件头值防注入 | 手动逐处过滤 | `SanitizeHeaderValue` 统一入口 |

## 并发安全

- **纯函数**(`SanitizeLine` / `SanitizeHeaderValue`):完全并发安全
- **`BOMStripper`**:**非并发安全**(内部 done 状态)。使用约定:**每个文件一个实例**;若跨 goroutine,外部加 mutex

## 未来扩展

Week 3+ 有需要时:

- `SanitizeCSVField` — CSV 字段过滤(去引号 / 转义 / null 检测)
- `ValidateEmailFormat(s) error` — RFC 5322 邮箱格式验证(生产 C# 已过滤,v2 只做兜底)
- `IsIPPrivate(ip net.IP) bool` — 判断私网 IP(反指纹用)

## 测试

```bash
go test -cover ./internal/security/...
# 预期覆盖率 ≥ 95%
```
