// Package security 提供 v2 里所有安全过滤/清理逻辑
//
// 【Week 2 Day 9 骨架】当前只提供 sanitize(CRLF 过滤 / BOM 剥离 / TrimSpace)。
// 未来若加入其他安全逻辑(如邮箱格式白名单 / IP 白名单 / 签名验证),各自独立文件。
//
// 【契约来源】§7 ReadEmailList 行处理规则(BOM 剥离 + CRLF 过滤 + TrimSpace + 空行跳过)。
package security

import "strings"

// utf8BOM UTF-8 字节序标记(仅可能在文件首字节出现)
// 【契约 §7 Step 7】首行 BOM 剥离;非首行不检查(BOM 只能在文件开头)
const utf8BOM = "\xEF\xBB\xBF"

// SanitizeLine 对单行做:TrimSpace + 内部 CRLF 替换空格 + 再次 TrimSpace
//
// 【处理步骤】(契约 §7 Step 4 + Step 6):
//  1. TrimSpace 首尾空白(含 \r\n\t)
//  2. 若行内含 CR/LF,替换为单空格 + 再次 TrimSpace(防止头注入)
//
// 【返回值】
//   - 输入合法邮件行 → 干净的字符串
//   - 输入全空白 / 纯 CRLF → 空串
//
// 【纯函数】并发安全,可跨 goroutine 调用。
//
// 【A1-P1 修 2026-08-14 对抗压测】剥离所有控制字符(< 0x20,含 \x00 null byte / \t /
// 其他 C0 控制符)+ DEL(0x7F);之前只处理 \r\n,恶意 CSV 里的 null byte / vertical tab
// / bell 等会绕过 sanitize 直接进 header,违反 RFC 5322 §2.2(header 只能 %d33-126)。
// 保留 space(0x20)因为它在 header 里合法。
func SanitizeLine(s string) string {
	s = strings.TrimSpace(s)
	// 快路径:纯 ASCII printable 无需处理
	needClean := false
	for i := 0; i < len(s); i++ {
		if b := s[i]; b < 0x20 || b == 0x7F {
			needClean = true
			break
		}
	}
	if !needClean {
		return s
	}
	// 慢路径:所有 < 0x20 或 == 0x7F 的字节替换为空格,再 TrimSpace 合并
	buf := make([]byte, len(s))
	for i := 0; i < len(s); i++ {
		b := s[i]
		if b < 0x20 || b == 0x7F {
			buf[i] = ' '
		} else {
			buf[i] = b
		}
	}
	return strings.TrimSpace(string(buf))
}

// SanitizeHeaderValue 邮件头值防注入(与 SanitizeLine 语义等价)
//
// 【用途】邮件头字段值(From/To/Subject/Cc 等)进入 raw 邮件前必须过滤 CR/LF,
// 否则用户输入的 name 里若含 `\r\n` 会被解读成额外邮件头(经典邮件头注入攻击)。
//
// 【为什么用同一实现】邮件行(收件人列表)和邮件头值的过滤规则完全一致,共用一个实现避免遗漏。
func SanitizeHeaderValue(v string) string {
	return SanitizeLine(v)
}

// BOMStripper 首行 UTF-8 BOM 剥离器
//
// 【使用约定】每个文件一个实例 —— done 状态是"这个 stripper 已处理过首行"级别。
// 【契约 §7 Step 7】BOM 只在**第一次**调用 Strip 时剥离,后续调用直接返回。
// 【并发】**非并发安全**(有 done 状态)。若跨 goroutine 需外部加 mutex。
//
// 【与 v1 的对齐】v1 里用 `isFirstLine bool` 标记,v2 抽出为独立 struct,更 Go 惯用。
type BOMStripper struct {
	done bool
}

// NewBOMStripper 创建一个新的 stripper 实例
func NewBOMStripper() *BOMStripper {
	return &BOMStripper{}
}

// Strip 剥离首行 BOM
//
// 【行为】
//   - 第一次调用:剥离 `\xEF\xBB\xBF` 前缀(若存在),标记 done=true
//   - 后续调用:直接返回原字符串(不再检查)
//
// 【使用模式】(参考 v1 reader/reader.go:398-424 的 ReadEmailList):
//
//	stripper := security.NewBOMStripper()
//	for scanner.Scan() {
//	    line := security.SanitizeLine(scanner.Text())
//	    if line == "" { continue }         // 空行跳过
//	    line = stripper.Strip(line)        // 首行 BOM
//	    line = strings.TrimSpace(line)     // BOM 剥离后可能残留 whitespace
//	    if line == "" { continue }
//	    emails = append(emails, line)
//	}
func (s *BOMStripper) Strip(line string) string {
	if s.done {
		return line
	}
	s.done = true
	return strings.TrimPrefix(line, utf8BOM)
}

// IsDone 报告 stripper 是否已完成首次调用
// 【用途】测试或诊断;生产代码通常不需要检查
func (s *BOMStripper) IsDone() bool {
	return s.done
}
