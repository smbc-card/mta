package security

import "testing"

// ===== SanitizeLine =====

func TestSanitizeLine(t *testing.T) {
	cases := []struct {
		name  string
		input string
		want  string
	}{
		{"纯净字符串", "alice@example.com", "alice@example.com"},
		{"首尾空格", "  alice@example.com  ", "alice@example.com"},
		{"含 tab", "\talice@example.com\t", "alice@example.com"},
		{"内部空格保留", "First Last <alice@example.com>", "First Last <alice@example.com>"},
		{"纯 CR", "alice\r@example.com", "alice @example.com"},         // \r → 1 空格
		{"纯 LF", "alice\n@example.com", "alice @example.com"},         // \n → 1 空格
		{"CRLF 混合", "alice\r\n@example.com", "alice  @example.com"},   // \r\n → 2 空格
		{"首尾 CRLF", "\r\nalice@example.com\r\n", "alice@example.com"}, // 首尾会 trim
		{"空串", "", ""},
		{"纯空白", "   \t  ", ""},
		{"纯 CRLF", "\r\n\r\n", ""},
		{"含 CR 之后 trim 空", "  \r  ", ""},
		{"注入尝试", "Alice\r\nX-Injected: evil\r\n", "Alice  X-Injected: evil"}, // \r\n → 2 空格,首尾 trim
		// 【A1-P1 回归测试 2026-08-14】剥离所有 < 0x20 控制字符 + 0x7F(DEL)
		{"含 null byte", "Nu\x00ll User", "Nu ll User"},                             // \x00 → 空格
		{"含 bell", "A\aB\aC", "A B C"},                                              // \x07 → 空格
		{"含 vertical tab", "A\vB", "A B"},                                          // \x0B → 空格
		{"含 form feed", "A\fB", "A B"},                                             // \x0C → 空格
		{"含 DEL", "A\x7FB", "A B"},                                                  // 0x7F → 空格
		{"混合控制字符", "\x00\x01Alice\x02\x03Bob\x1F", "Alice  Bob"}, // \x02\x03 中间 → 2 空格,首尾 trim
		{"printable 保留", "!@#$%^&*()_+-=", "!@#$%^&*()_+-="},                       // 所有 0x20+ printable 完好
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got := SanitizeLine(c.input)
			if got != c.want {
				t.Errorf("SanitizeLine(%q) = %q, 期望 %q", c.input, got, c.want)
			}
		})
	}
}

// TestSanitizeLine_NoAllocForClean 干净字符串路径不触发 CRLF 分支(sanity 优化路径)
func TestSanitizeLine_NoAllocForClean(t *testing.T) {
	// 无 CR/LF 的输入,只走 TrimSpace 路径(内部不做 ReplaceAll)
	got := SanitizeLine("clean@example.com")
	if got != "clean@example.com" {
		t.Errorf("干净字符串处理不应改变: %q", got)
	}
}

// ===== SanitizeHeaderValue =====

// TestSanitizeHeaderValue_SameAsSanitizeLine 与 SanitizeLine 完全一致
func TestSanitizeHeaderValue_SameAsSanitizeLine(t *testing.T) {
	inputs := []string{
		"Alice",
		"Alice\r\nX-Injected: evil",
		"  Alice  ",
		"",
	}
	for _, s := range inputs {
		if SanitizeHeaderValue(s) != SanitizeLine(s) {
			t.Errorf("SanitizeHeaderValue(%q) 应与 SanitizeLine 一致", s)
		}
	}
}

// ===== BOMStripper =====

// TestBOMStripper_FirstCall_StripsBOM 首次调用应剥离 BOM
func TestBOMStripper_FirstCall_StripsBOM(t *testing.T) {
	s := NewBOMStripper()
	got := s.Strip("\xEF\xBB\xBFalice@example.com")
	want := "alice@example.com"
	if got != want {
		t.Errorf("Strip(bom+alice) = %q, 期望 %q", got, want)
	}
	if !s.IsDone() {
		t.Error("首次 Strip 后 IsDone 应为 true")
	}
}

// TestBOMStripper_FirstCall_NoBOM 首次调用但无 BOM 也应标记 done
func TestBOMStripper_FirstCall_NoBOM(t *testing.T) {
	s := NewBOMStripper()
	got := s.Strip("alice@example.com")
	if got != "alice@example.com" {
		t.Errorf("Strip 无 BOM 应原样返回: %q", got)
	}
	if !s.IsDone() {
		t.Error("首次 Strip(即使无 BOM)后 IsDone 应为 true")
	}
}

// TestBOMStripper_SubsequentCalls_NoStrip 后续调用不再剥离,即使含 BOM(该 BOM 属于内容一部分)
func TestBOMStripper_SubsequentCalls_NoStrip(t *testing.T) {
	s := NewBOMStripper()
	s.Strip("first-line")

	// 第 2 次调用即使有 BOM 也不剥
	got := s.Strip("\xEF\xBB\xBFsecond-line")
	want := "\xEF\xBB\xBFsecond-line"
	if got != want {
		t.Errorf("非首行 Strip 应原样返回:得到 %q, 期望 %q", got, want)
	}
}

// TestBOMStripper_EmptyStringFirst 空串作为首次调用也应标记 done
func TestBOMStripper_EmptyStringFirst(t *testing.T) {
	s := NewBOMStripper()
	got := s.Strip("")
	if got != "" {
		t.Errorf("Strip(空串) = %q, 期望空", got)
	}
	if !s.IsDone() {
		t.Error("空串 Strip 也应标记 done")
	}
}

// TestBOMStripper_NewInstance_IndependentState 多个 stripper 实例状态独立
func TestBOMStripper_NewInstance_IndependentState(t *testing.T) {
	s1 := NewBOMStripper()
	s2 := NewBOMStripper()

	s1.Strip("first-of-s1")
	if !s1.IsDone() {
		t.Error("s1 首次调用后应 done")
	}
	if s2.IsDone() {
		t.Error("s2 未调用应仍 pending")
	}

	got := s2.Strip("\xEF\xBB\xBFfirst-of-s2")
	if got != "first-of-s2" {
		t.Errorf("s2 首次 Strip 应剥离 BOM: %q", got)
	}
}

// TestBOMStripper_Integration 模拟 v1 ReadEmailList 完整流程
func TestBOMStripper_Integration(t *testing.T) {
	// 模拟文件内容(带 BOM 首行 + CRLF 混合 + 空行)
	lines := []string{
		"\xEF\xBB\xBFtest01@example.com", // 首行含 BOM
		"",                                 // 空行
		"test02@example.com\r\n",           // 尾部 CRLF
		"  test03@example.com  ",           // 空格
		"Attack\r\nX-Inject: evil",         // 注入尝试
	}

	stripper := NewBOMStripper()
	var results []string

	for _, raw := range lines {
		line := SanitizeLine(raw)
		if line == "" {
			continue
		}
		line = stripper.Strip(line)
		// BOM 剥离后可能残留 whitespace
		line = SanitizeLine(line)
		if line == "" {
			continue
		}
		results = append(results, line)
	}

	expected := []string{
		"test01@example.com",      // BOM 已剥
		"test02@example.com",      // CRLF 已 trim
		"test03@example.com",      // 空格已 trim
		"Attack  X-Inject: evil",  // \r\n → 2 空格,注入失效
	}

	if len(results) != len(expected) {
		t.Fatalf("期望 %d 行,得到 %d 行: %v", len(expected), len(results), results)
	}
	for i, want := range expected {
		if results[i] != want {
			t.Errorf("行 %d:得到 %q, 期望 %q", i, results[i], want)
		}
	}
}
