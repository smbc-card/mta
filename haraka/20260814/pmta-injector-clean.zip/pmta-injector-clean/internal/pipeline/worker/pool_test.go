package worker

import (
	"context"
	"errors"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/recipient/reader"
)

// makeRecipient helper
func makeRecipient(email string, line int) *reader.Recipient {
	return &reader.Recipient{Email: email, LineNumber: line}
}

// ============================================================================
// New 边界
// ============================================================================

func TestNew_SizeClamp(t *testing.T) {
	// size < 1 应 clamp 到 1
	p := New(0, func(_ context.Context, _ Task) Result { return Result{} })
	if p.size != 1 {
		t.Errorf("size=0 应 clamp 到 1,got=%d", p.size)
	}
	p = New(-5, func(_ context.Context, _ Task) Result { return Result{} })
	if p.size != 1 {
		t.Errorf("size=-5 应 clamp 到 1")
	}
	// 正常 size 保持
	p = New(10, func(_ context.Context, _ Task) Result { return Result{} })
	if p.size != 10 {
		t.Errorf("size=10,got=%d", p.size)
	}
}

// ============================================================================
// Pool.Run 主流程
// ============================================================================

func TestPool_Run_ProcessesAll(t *testing.T) {
	// 5 recipient → 5 result(全成功)
	processed := int64(0)
	p := New(3, func(_ context.Context, task Task) Result {
		atomic.AddInt64(&processed, 1)
		return Result{Email: task.Recipient.Email, Success: true, Line: task.Recipient.LineNumber}
	})

	recipientCh := make(chan *reader.Recipient, 5)
	resultCh := make(chan Result, 5)

	for i := 1; i <= 5; i++ {
		recipientCh <- makeRecipient("u"+string(rune('0'+i))+"@x.com", i)
	}
	close(recipientCh)

	err := p.Run(context.Background(), recipientCh, resultCh)
	close(resultCh)
	if err != nil {
		t.Fatalf("Run:%v", err)
	}
	if atomic.LoadInt64(&processed) != 5 {
		t.Errorf("processed:got=%d, want=5", processed)
	}

	// 收 result:5 个,全 success
	count := 0
	for r := range resultCh {
		count++
		if !r.Success {
			t.Errorf("result 应 success:%+v", r)
		}
	}
	if count != 5 {
		t.Errorf("result 数:%d, want=5", count)
	}
}

func TestPool_Run_CtxCancelExits(t *testing.T) {
	// ctx cancel 时 worker 立即退出;返回 err = ctx.Err()
	blocker := make(chan struct{})
	p := New(2, func(ctx context.Context, task Task) Result {
		select {
		case <-blocker:
		case <-ctx.Done():
		}
		return Result{Email: task.Recipient.Email, Success: true}
	})

	recipientCh := make(chan *reader.Recipient, 10)
	resultCh := make(chan Result, 10)
	for i := 0; i < 5; i++ {
		recipientCh <- makeRecipient("u@x.com", i)
	}
	// 不 close recipientCh,让 worker 拿到就阻塞

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- p.Run(ctx, recipientCh, resultCh) }()

	time.Sleep(50 * time.Millisecond)
	cancel()

	select {
	case err := <-done:
		if err == nil {
			t.Error("cancel 后应返回 err")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("cancel 后 Run 未返回,可能死锁")
	}
	close(blocker) // 让 pending process 退出
}

func TestPool_Run_RecipientChClose_Exits(t *testing.T) {
	// recipientCh 关闭(排空后)→ Run 返回 nil
	p := New(3, func(_ context.Context, task Task) Result {
		return Result{Email: task.Recipient.Email, Success: true}
	})

	recipientCh := make(chan *reader.Recipient, 3)
	resultCh := make(chan Result, 10)

	recipientCh <- makeRecipient("a@x.com", 1)
	recipientCh <- makeRecipient("b@x.com", 2)
	close(recipientCh)

	err := p.Run(context.Background(), recipientCh, resultCh)
	if err != nil {
		t.Errorf("正常退出应 nil,got=%v", err)
	}
}

// ============================================================================
// per-recipient recover(v1 v64 修复移植)
// ============================================================================

func TestPool_Run_PerRecipientRecover(t *testing.T) {
	// 一封 panic 不杀 worker,后续继续处理
	processed := int64(0)
	panicked := int64(0)
	p := New(1, func(_ context.Context, task Task) Result {
		atomic.AddInt64(&processed, 1)
		if task.Recipient.LineNumber == 2 {
			atomic.AddInt64(&panicked, 1)
			panic("test panic")
		}
		return Result{Email: task.Recipient.Email, Success: true, Line: task.Recipient.LineNumber}
	})

	recipientCh := make(chan *reader.Recipient, 5)
	resultCh := make(chan Result, 5)
	for i := 1; i <= 5; i++ {
		recipientCh <- makeRecipient("u@x.com", i)
	}
	close(recipientCh)

	err := p.Run(context.Background(), recipientCh, resultCh)
	close(resultCh)
	if err != nil {
		t.Fatalf("Run:%v", err)
	}

	// 5 都被处理(panic 那封也算 processed)
	if atomic.LoadInt64(&processed) != 5 {
		t.Errorf("processed:%d, want=5", processed)
	}
	if atomic.LoadInt64(&panicked) != 1 {
		t.Errorf("panicked:%d, want=1", panicked)
	}

	// 收 5 result;line=2 那封应 Error 非 nil
	found := 0
	for r := range resultCh {
		found++
		if r.Line == 2 {
			if r.Success {
				t.Errorf("panic 那封应 Success=false")
			}
			if r.Error == nil {
				t.Error("panic 那封应有 Error")
			}
			if !strings.Contains(r.Error.Error(), "panic") {
				t.Errorf("Error 应含 'panic',got=%q", r.Error.Error())
			}
		}
	}
	if found != 5 {
		t.Errorf("result 数:%d, want=5", found)
	}
}

// ============================================================================
// errgroup 首个 err → 全链 cancel(D27-2 关键)
// ============================================================================

func TestPool_Run_FirstErrCancelsAll(t *testing.T) {
	// process 返回带 err 的 Result 不触发 errgroup cancel(那是业务错)
	// 但 process 若返回 err**从外层**(如死循环 panic)才触发 cancel
	// 本测试:模拟 worker 内部 select ctx.Done() 的行为
	//
	// 场景:process 慢,ctx cancel 时应立即返回
	sentinelErr := errors.New("sentinel")
	_ = sentinelErr // 保 import errors

	// 让 process 阻塞在 ctx.Done() 上,ctx 取消时立即退出
	p := New(3, func(ctx context.Context, task Task) Result {
		select {
		case <-ctx.Done():
		case <-time.After(500 * time.Millisecond):
		}
		return Result{Email: task.Recipient.Email, Success: true}
	})

	recipientCh := make(chan *reader.Recipient, 3)
	resultCh := make(chan Result, 10)
	recipientCh <- makeRecipient("a", 1)
	// 不 close,3 worker 全部 pending

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- p.Run(ctx, recipientCh, resultCh) }()

	time.Sleep(50 * time.Millisecond)
	cancel()

	select {
	case err := <-done:
		if err == nil {
			t.Error("cancel 后应返回 err")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("cancel 后 Run 未返回")
	}
}

// ============================================================================
// 并发安全(-race 测)
// ============================================================================

func TestPool_Run_HighConcurrency(t *testing.T) {
	// 100 worker × 1000 recipient → 无 race + 无 panic
	p := New(100, func(_ context.Context, task Task) Result {
		return Result{Email: task.Recipient.Email, Success: true, Line: task.Recipient.LineNumber}
	})

	recipientCh := make(chan *reader.Recipient, 100)
	resultCh := make(chan Result, 1000)

	// 生产者
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		for i := 0; i < 1000; i++ {
			recipientCh <- makeRecipient("u@x.com", i)
		}
		close(recipientCh)
	}()

	// 消费者(单 goroutine 收 result)
	var received int64
	consumerDone := make(chan struct{})
	go func() {
		for range resultCh {
			atomic.AddInt64(&received, 1)
		}
		close(consumerDone)
	}()

	err := p.Run(context.Background(), recipientCh, resultCh)
	close(resultCh)
	wg.Wait()
	<-consumerDone

	if err != nil {
		t.Fatalf("Run:%v", err)
	}
	if atomic.LoadInt64(&received) != 1000 {
		t.Errorf("received:%d, want=1000", received)
	}
}

// ============================================================================
// panicError helper
// ============================================================================

func TestPanicError_Error(t *testing.T) {
	e := &panicError{r: "boom", workerID: 42}
	if !strings.Contains(e.Error(), "42") {
		t.Errorf("Error 应含 workerID:%q", e.Error())
	}
	if !strings.Contains(e.Error(), "boom") {
		t.Errorf("Error 应含 panic 值:%q", e.Error())
	}

	// panic 值是 error 类型
	e2 := &panicError{r: errors.New("boom2"), workerID: 1}
	if !strings.Contains(e2.Error(), "boom2") {
		t.Errorf("Error 应含 error.Error():%q", e2.Error())
	}

	// panic 值是其他类型
	e3 := &panicError{r: 123, workerID: 1}
	if !strings.Contains(e3.Error(), "non-string") {
		t.Errorf("非 string/error 应含 non-string:%q", e3.Error())
	}
}
