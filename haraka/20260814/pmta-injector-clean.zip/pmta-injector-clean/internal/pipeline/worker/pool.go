package worker

import (
	"context"

	"golang.org/x/sync/errgroup"

	"__MODULE_PLACEHOLDER__/internal/recipient/reader"
)

// Task 单个 worker 处理一个 recipient 的入参
//
// 【设计】用 struct 而非多参数 —— 未来加字段(workerID / 附件上下文等)不破坏调用点
type Task struct {
	Recipient *reader.Recipient
	WorkerID  int
}

// Result 单个 worker 处理完的结果
//
// 【与 v1 WorkResult 语义等价】
type Result struct {
	Email   string
	Success bool
	Error   error
	Line    int
}

// ProcessFn 单封邮件的处理函数(dispatcher 层闭包封装 rate limit + render + inject)
//
// 【签名】(ctx, task) → Result
// 【返回 Result 而非 (Result, error)】error 走 Result.Error;返回 err 保留给 process 内部严重故障
type ProcessFn func(ctx context.Context, task Task) Result

// Pool worker 池
//
// 【字段】
//   - size:worker 数量(cfg.Performance.Workers)
//   - process:业务处理函数(dispatcher 提供,内含 rate limit + render + inject)
//
// 【线程安全】Run 里 N 个 worker 并发调 process;调用方(dispatcher)负责让 process 线程安全
type Pool struct {
	size    int
	process ProcessFn
}

// New 创建 Pool
//
// 【参数】
//   - size:worker 数(必须 ≥ 1,否则内部 clamp 为 1)
//   - process:必需(nil 会 panic on Run)
func New(size int, process ProcessFn) *Pool {
	if size < 1 {
		size = 1
	}
	return &Pool{size: size, process: process}
}

// Run 起 N 个 worker,从 recipientCh 读、process、写 resultCh
//
// 【契约】v2 与 v1 dispatcher::worker 语义等价(去掉 workersDoneCh 死锁防御)
//
// 【行为】
//   - N 个 worker 通过 errgroup 起;首个 err 触发 ctx.Cancel
//   - 每 worker 循环:select { ctx.Done | recipient, ok <- recipientCh }
//   - 读到 recipient → 调 process → 写 resultCh(带 ctx select 防阻塞)
//   - recipientCh 关闭且排空 → worker 正常退出
//
// 【必须外部关闭】
//   - recipientCh:调用方读完源(reader)后 close(触发 worker 退出)
//   - resultCh:调用方在 Run 返回**后**再 close(P25:错顺序会 collectResults 泄漏)
//
// 【返回】
//   - nil:所有 worker 正常退出(recipientCh 关闭 + 排空)
//   - ctx.Err():ctx 取消(external cancel / signal / STOP / errgroup 首 err)
//
// 【per-recipient recover】v1 v64 修复:一封 panic 不杀 worker
// v2 保留同套路 —— safeProcess 包一层 recover,把 panic 转成 Result.Error
func (p *Pool) Run(ctx context.Context, recipientCh <-chan *reader.Recipient, resultCh chan<- Result) error {
	g, gctx := errgroup.WithContext(ctx)

	for i := 0; i < p.size; i++ {
		workerID := i // 捕获闭包变量
		g.Go(func() error {
			return p.workerLoop(gctx, workerID, recipientCh, resultCh)
		})
	}

	return g.Wait()
}

// workerLoop 单个 worker 主循环
func (p *Pool) workerLoop(ctx context.Context, workerID int,
	recipientCh <-chan *reader.Recipient, resultCh chan<- Result) error {

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case rcpt, ok := <-recipientCh:
			if !ok {
				return nil // recipientCh 关闭 → worker 正常退出
			}

			// per-recipient recover(v1 v64 修复移植)
			result := p.safeProcess(ctx, Task{Recipient: rcpt, WorkerID: workerID})

			select {
			case resultCh <- result:
			case <-ctx.Done():
				return ctx.Err()
			}
		}
	}
}

// safeProcess 包一层 recover,把 panic 转成 Result.Error
//
// 【v1 v64 修复】per-recipient recover:一封 panic 不杀 worker
func (p *Pool) safeProcess(ctx context.Context, task Task) (result Result) {
	defer func() {
		if r := recover(); r != nil {
			result = Result{
				Email:   task.Recipient.Email,
				Success: false,
				Error:   &panicError{r: r, workerID: task.WorkerID},
				Line:    task.Recipient.LineNumber,
			}
		}
	}()
	return p.process(ctx, task)
}

// panicError 包装 panic 值为 error
type panicError struct {
	r        any
	workerID int
}

func (e *panicError) Error() string {
	return "worker panic (id=" + itoa(e.workerID) + "): " + toString(e.r)
}

// itoa / toString:简单转换,避免 import strconv/fmt 只为这两处
func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var buf [20]byte
	i := len(buf)
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}

func toString(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	if err, ok := v.(error); ok {
		return err.Error()
	}
	return "<non-string panic>"
}
