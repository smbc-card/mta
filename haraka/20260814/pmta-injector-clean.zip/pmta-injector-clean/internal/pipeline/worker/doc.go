// Package worker 邮件发送 worker 池(errgroup + ctx + rate limit)
//
// 【D4 决策】用 golang.org/x/sync/errgroup 替代 v1 sync.WaitGroup + workersDoneCh 死锁防御
//
// 【设计】
//   - Pool 封装 N 个 worker goroutine,每个从 recipientCh 读、执行 process、写 resultCh
//   - errgroup 首个 worker 返回 err → ctx.Cancel → 全 worker 退出(无死锁风险)
//   - rate limit 由 dispatcher 层集成到 process 内部(每 build 前 Wait)
//   - 每 worker 独立 render.Builder(与 v1 一致 —— per-worker rng seed)
//
// 【调用方】pipeline/dispatcher 负责 wire up:
//   - 建 N 个 render.Builder(不同 seed)
//   - 定义 ProcessFn 闭包(内含 render + inject + rate limit)
//   - 调 Pool.Run(ctx, recipientCh, resultCh)
//
// 【线程安全】Pool.Run 里 N 个 worker 并发跑;所有依赖须 per-worker 独立(builder / injector 见 pool)
//
// 【依赖】golang.org/x/sync/errgroup
package worker
