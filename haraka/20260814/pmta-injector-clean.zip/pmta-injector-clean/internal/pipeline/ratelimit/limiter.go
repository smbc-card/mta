package ratelimit

import (
	"context"

	"golang.org/x/time/rate"
)

// Limiter 邮件发送速率限制器
//
// 【设计】nil-safe:若 New(eps<=0),内部 l=nil,Wait 直接返回 nil(不限速)
// 这样调用方不需要 `if limiter != nil { limiter.Wait(ctx) }` 分支
type Limiter struct {
	l *rate.Limiter
}

// New 创建 Limiter
//
// 【参数 eps】每秒允许的事件数(EmailsPerSecond)
//   - eps <= 0 → 不限速(内部 l=nil,Wait 立即返回)
//   - eps > 0  → rate.NewLimiter(rate.Limit(eps), burst=1)
//
// 【burst=1】与 v1 语义一致:每次严格 1 token,不允许突发
func New(eps float64) *Limiter {
	if eps <= 0 {
		return &Limiter{l: nil}
	}
	return &Limiter{l: rate.NewLimiter(rate.Limit(eps), 1)}
}

// Wait 消费 1 token,ctx 取消时立即返回 err
//
// 【返回】
//   - 不限速时(l=nil)→ 直接返回 nil
//   - 限速时 → 阻塞至有 token 或 ctx.Done();ctx 取消时返回 ctx.Err()
func (lm *Limiter) Wait(ctx context.Context) error {
	if lm.l == nil {
		return nil
	}
	return lm.l.Wait(ctx)
}
