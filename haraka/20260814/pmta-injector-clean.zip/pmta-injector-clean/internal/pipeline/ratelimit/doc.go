// Package ratelimit 邮件发送速率限制器(x/time/rate 封装)
//
// 【D3 决策】用 golang.org/x/time/rate 替代 v1 自造 RateLimiter(v1 core/ratelimiter.go 118 行)
//
// 【设计】
//   - Limiter 封装 *rate.Limiter,提供简洁 API
//   - eps <= 0 时 New 返回 sentinel(内部 l=nil)—— Wait 直接返回 nil(不限速)
//   - eps > 0 时 rate.NewLimiter(rate.Limit(eps), 1)
//
// 【调用点】每封邮件粒度 Wait(与 v1 一致):
//   - 主邮件 wait 1 次
//   - 每个 CC 独立邮件 wait 1 次
//   - 每个 BCC 独立邮件 wait 1 次
//
// 【ctx 传播】Wait(ctx) 在 ctx.Done() 时立即返回 err —— errgroup 首 err 触发全链取消
//
// 【依赖】golang.org/x/time/rate
package ratelimit
