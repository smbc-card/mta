package ratelimit

import (
	"context"
	"sync"
	"testing"
	"time"
)

// ============================================================================
// nil-safe 分支(eps <= 0)
// ============================================================================

func TestNew_ZeroEPS_NoLimit(t *testing.T) {
	lim := New(0)
	if lim == nil {
		t.Fatal("New(0) 应返回非 nil sentinel")
	}
	if lim.l != nil {
		t.Errorf("eps=0 时内部 l 应 nil,got=%v", lim.l)
	}
}

func TestNew_NegativeEPS_NoLimit(t *testing.T) {
	lim := New(-5)
	if lim.l != nil {
		t.Error("eps<0 时内部 l 应 nil")
	}
}

func TestWait_NoLimit_ReturnsImmediately(t *testing.T) {
	lim := New(0)
	ctx := context.Background()
	start := time.Now()
	for i := 0; i < 1000; i++ {
		if err := lim.Wait(ctx); err != nil {
			t.Fatalf("第 %d 次 Wait:%v", i, err)
		}
	}
	// 1000 次 Wait 应 <10ms(不限速)
	if elapsed := time.Since(start); elapsed > 100*time.Millisecond {
		t.Errorf("不限速下 1000 次 Wait 应立即返回,耗时 %v", elapsed)
	}
}

// ============================================================================
// 限速分支(eps > 0)
// ============================================================================

func TestWait_WithLimit_Blocks(t *testing.T) {
	// eps=100 → 每次 Wait 约 10ms
	// 5 次 Wait 应约 ~40ms(首次不阻塞)
	lim := New(100)
	ctx := context.Background()
	start := time.Now()
	for i := 0; i < 5; i++ {
		if err := lim.Wait(ctx); err != nil {
			t.Fatalf("第 %d 次:%v", i, err)
		}
	}
	elapsed := time.Since(start)
	// 首次即刻,之后每次 ~10ms,4 次约 40ms;宽松 [30, 100]ms
	if elapsed < 30*time.Millisecond {
		t.Errorf("5 次 Wait(eps=100)应耗时 ≥30ms,got=%v", elapsed)
	}
	if elapsed > 200*time.Millisecond {
		t.Errorf("5 次 Wait(eps=100)应耗时 ≤200ms,got=%v", elapsed)
	}
}

// ============================================================================
// ctx 取消(D22-3 关键)
// ============================================================================

func TestWait_CtxCanceled_ReturnsError(t *testing.T) {
	lim := New(1) // 1 EPS,第二次 Wait 会阻塞 1s
	ctx, cancel := context.WithCancel(context.Background())

	// 消费第一个 token
	_ = lim.Wait(ctx)

	// 100ms 后 cancel;第二次 Wait 应在 <200ms 内返回 err
	go func() {
		time.Sleep(50 * time.Millisecond)
		cancel()
	}()

	start := time.Now()
	err := lim.Wait(ctx)
	elapsed := time.Since(start)
	if err == nil {
		t.Error("ctx cancel 后 Wait 应返回 err")
	}
	if elapsed > 500*time.Millisecond {
		t.Errorf("ctx cancel 后 Wait 应立即返回,耗时 %v", elapsed)
	}
}

// ============================================================================
// 并发安全(-race 测)
// ============================================================================

func TestWait_ConcurrentSafe(t *testing.T) {
	lim := New(10000) // 高速率,避免测试卡
	ctx := context.Background()

	var wg sync.WaitGroup
	const goroutines = 20
	const iters = 100
	for i := 0; i < goroutines; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < iters; j++ {
				_ = lim.Wait(ctx)
			}
		}()
	}
	wg.Wait()
	// 无 panic + go test -race 无 report = OK
}

func TestWait_NoLimit_ConcurrentSafe(t *testing.T) {
	// nil-safe 分支下并发也无 race
	lim := New(0)
	ctx := context.Background()

	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 1000; j++ {
				_ = lim.Wait(ctx)
			}
		}()
	}
	wg.Wait()
}
