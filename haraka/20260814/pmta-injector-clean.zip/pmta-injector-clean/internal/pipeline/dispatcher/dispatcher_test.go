package dispatcher

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/inject"
	"__MODULE_PLACEHOLDER__/internal/pipeline/ratelimit"
	"__MODULE_PLACEHOLDER__/internal/pipeline/reporter"
	"__MODULE_PLACEHOLDER__/internal/recipient/reader"
)

// ============================================================================
// fakes(测试替身)
// ============================================================================

// fakeReader 顺序返回 rcpts,读完返回 (nil, nil)
type fakeReader struct {
	rcpts []*reader.Recipient
	idx   int
}

func (f *fakeReader) Read() (*reader.Recipient, error) {
	if f.idx >= len(f.rcpts) {
		return nil, nil
	}
	r := f.rcpts[f.idx]
	f.idx++
	return r, nil
}
func (f *fakeReader) Count() (int64, error) { return int64(len(f.rcpts)), nil }
func (f *fakeReader) Close() error          { return nil }

// fakeEmail 实现 inject.Email
type fakeEmail struct{ from, to, raw string }

func (e *fakeEmail) Raw() string          { return e.raw }
func (e *fakeEmail) EnvelopeFrom() string { return e.from }
func (e *fakeEmail) EnvelopeTo() string   { return e.to }

// fakeBuilder 实现 RenderBuilder;可配置 failOn(TargetEmail 匹配就 err)
type fakeBuilder struct {
	failOn      string
	builds      atomic.Int64
	panicOn     string
	ccListSeen  atomic.Int64 // 统计 CcHeaderList 非空的 Build 调用次数
}

func (b *fakeBuilder) Build(req BuildRequest) (RenderedEmail, error) {
	b.builds.Add(1)
	if b.panicOn != "" && req.TargetEmail == b.panicOn {
		panic("test panic on " + b.panicOn)
	}
	if b.failOn != "" && req.TargetEmail == b.failOn {
		return nil, errors.New("build failed for " + b.failOn)
	}
	if len(req.CcHeaderList) > 0 {
		b.ccListSeen.Add(1)
	}
	return &fakeEmail{
		from: "sender@x.com",
		to:   req.TargetEmail,
		raw:  "fake raw for " + req.TargetEmail,
	}, nil
}

// fakeInjector 实现 inject.Injector;可配置 failEvery(第 N 次调用失败)
type fakeInjector struct {
	sends atomic.Int64
	fails atomic.Int64
}

func (i *fakeInjector) Send(_ context.Context, _ inject.Email) error { i.sends.Add(1); return nil }
func (i *fakeInjector) Close() error              { return nil }
func (i *fakeInjector) Mode() string              { return "fake" }
func (i *fakeInjector) Enabled() bool             { return true }

// ============================================================================
// helper
// ============================================================================

func makeRcpt(email string, line int) *reader.Recipient {
	return &reader.Recipient{Email: email, LineNumber: line}
}

func minCfg() *config.Config {
	return &config.Config{
		Job: config.JobConfig{ID: "test-job"},
		Performance: config.PerformanceConfig{
			Workers:          2,
			ChannelBuffer:    10,
			ProgressInterval: 1,
		},
		Recipient: config.RecipientControlConfig{Enabled: true},
	}
}

// ============================================================================
// 基础 flow
// ============================================================================

func TestDispatcher_EmptyRecipients(t *testing.T) {
	cfg := minCfg()
	rdr := &fakeReader{rcpts: nil}
	inj := &fakeInjector{}
	fb := &fakeBuilder{}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, err := d.Run(context.Background())
	if err != nil {
		t.Fatalf("Run:%v", err)
	}
	if res.Total != 0 || res.Success != 0 || res.Failed != 0 {
		t.Errorf("空 recipients 统计:%+v", res)
	}
	if inj.sends.Load() != 0 {
		t.Errorf("空 recipients 不应有 send")
	}
}

func TestDispatcher_5Recipients_AllSuccess(t *testing.T) {
	cfg := minCfg()
	rdr := &fakeReader{rcpts: []*reader.Recipient{
		makeRcpt("a@x.com", 1),
		makeRcpt("b@x.com", 2),
		makeRcpt("c@x.com", 3),
		makeRcpt("d@x.com", 4),
		makeRcpt("e@x.com", 5),
	}}
	inj := &fakeInjector{}
	fb := &fakeBuilder{}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, err := d.Run(context.Background())
	if err != nil {
		t.Fatalf("Run:%v", err)
	}
	if res.Success != 5 || res.Failed != 0 {
		t.Errorf("stats:%+v", res)
	}
	if inj.sends.Load() != 5 {
		t.Errorf("sends:%d, want=5", inj.sends.Load())
	}
	if res.Status != "completed" {
		t.Errorf("status:%s", res.Status)
	}
}

func TestDispatcher_DryRun_SkipsInjector(t *testing.T) {
	cfg := minCfg()
	cfg.DryRun = true

	rdr := &fakeReader{rcpts: []*reader.Recipient{makeRcpt("a@x.com", 1)}}
	inj := &fakeInjector{}
	fb := &fakeBuilder{}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, _ := d.Run(context.Background())
	if inj.sends.Load() != 0 {
		t.Errorf("DryRun 应跳过 Inject,got sends=%d", inj.sends.Load())
	}
	if res.Success != 1 {
		t.Errorf("DryRun 应仍计 success=1,got=%d", res.Success)
	}
}

func TestDispatcher_SkipMain(t *testing.T) {
	// cfg.Recipient.Enabled=false → 跳过主邮件(但仍占位 success)
	cfg := minCfg()
	cfg.Recipient.Enabled = false

	rdr := &fakeReader{rcpts: []*reader.Recipient{makeRcpt("a@x.com", 1)}}
	inj := &fakeInjector{}
	fb := &fakeBuilder{}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, _ := d.Run(context.Background())
	if inj.sends.Load() != 0 {
		t.Errorf("Recipient.Enabled=false 应跳 send")
	}
	if res.Success != 1 {
		t.Errorf("占位 success 应 =1,got=%d", res.Success)
	}
}

// ============================================================================
// 错误处理
// ============================================================================

func TestDispatcher_BuildFail_RecordedAsFailed(t *testing.T) {
	cfg := minCfg()
	rdr := &fakeReader{rcpts: []*reader.Recipient{
		makeRcpt("good@x.com", 1),
		makeRcpt("bad@x.com", 2),
		makeRcpt("good2@x.com", 3),
	}}
	inj := &fakeInjector{}
	fb := &fakeBuilder{failOn: "bad@x.com"}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, _ := d.Run(context.Background())
	if res.Success != 2 || res.Failed != 1 {
		t.Errorf("stats:%+v", res)
	}
	if len(res.Errors) != 1 || res.Errors[0].Email != "bad@x.com" {
		t.Errorf("errors:%+v", res.Errors)
	}
}

func TestDispatcher_BuilderPanic_RecoveredByWorker(t *testing.T) {
	// worker.Pool 有 per-recipient recover → panic 转成 Result.Error 记 failed
	cfg := minCfg()
	rdr := &fakeReader{rcpts: []*reader.Recipient{
		makeRcpt("a@x.com", 1),
		makeRcpt("panicboom@x.com", 2),
		makeRcpt("c@x.com", 3),
	}}
	inj := &fakeInjector{}
	fb := &fakeBuilder{panicOn: "panicboom@x.com"}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, err := d.Run(context.Background())
	if err != nil {
		t.Fatalf("Run:%v", err)
	}
	if res.Success != 2 {
		t.Errorf("2 应 success,got=%d", res.Success)
	}
	if res.Failed != 1 {
		t.Errorf("panic 应 failed=1,got=%d", res.Failed)
	}
}

// ============================================================================
// ctx cancel(优雅退出)
// ============================================================================

func TestDispatcher_CtxCancel_GracefulExit(t *testing.T) {
	cfg := minCfg()
	// 生成大量 recipient,让 read loop 长时间跑
	rcpts := make([]*reader.Recipient, 1000)
	for i := 0; i < 1000; i++ {
		rcpts[i] = makeRcpt("u@x.com", i+1)
	}
	rdr := &fakeReader{rcpts: rcpts}
	inj := &fakeInjector{}
	fb := &fakeBuilder{}
	factory := func(_ int) RenderBuilder { return fb }

	// 加个慢 limiter 让 Run 花时间
	limiter := ratelimit.New(10000) // 10000/s

	d := New(cfg, rdr, inj, factory, limiter, nil)

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})

	var res *reporter.Result
	go func() {
		res, _ = d.Run(ctx)
		close(done)
	}()

	// 20ms 后取消
	time.Sleep(20 * time.Millisecond)
	cancel()

	select {
	case <-done:
	case <-time.After(3 * time.Second):
		t.Fatal("cancel 后 Run 未在 3s 内返回")
	}

	if res == nil {
		t.Fatal("res nil")
	}
	if res.Status != "cancelled" {
		t.Errorf("status:%s, want=cancelled", res.Status)
	}
	// 应有部分处理完(不全)
	if res.Total >= 1000 || res.Total <= 0 {
		t.Errorf("cancelled 时 Total 应部分完成:%d", res.Total)
	}
}

// ============================================================================
// CC/BCC atomic 分配(§9 契约)
// ============================================================================

func TestDispatcher_CCBCC_AtomicDistribution(t *testing.T) {
	// 3 主 recipient + CC 池 5 个 + PerEmail=2 → 前 2 主 email 各分 2 CC = 4;第 3 主 email 分剩下的 1
	// 总 CC 独立邮件 = 5;每个 CC 都是独立 send
	dir := t.TempDir()
	ccFile := filepath.Join(dir, "cc.txt")
	_ = os.WriteFile(ccFile, []byte("c1@x\nc2@x\nc3@x\nc4@x\nc5@x\n"), 0644)

	cfg := minCfg()
	cfg.CC.Enabled = true
	cfg.CC.FilePath = ccFile
	cfg.CC.PerEmail = 2

	rdr := &fakeReader{rcpts: []*reader.Recipient{
		makeRcpt("m1@x.com", 1),
		makeRcpt("m2@x.com", 2),
		makeRcpt("m3@x.com", 3),
	}}
	inj := &fakeInjector{}
	fb := &fakeBuilder{}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, err := d.Run(context.Background())
	if err != nil {
		t.Fatalf("Run:%v", err)
	}
	// 3 主 + 5 CC = 8 send
	if inj.sends.Load() != 8 {
		t.Errorf("sends:%d, want=8(3 主 + 5 CC)", inj.sends.Load())
	}
	if res.Success != 8 {
		t.Errorf("success:%d, want=8", res.Success)
	}
	// CcHeaderList 应在 3 次主邮件里出现(每次主邮件带 ccBatch)
	// 【注意】第 3 次主邮件 ccBatch 只有 1 个(池剩 1);但仍非 nil
	if fb.ccListSeen.Load() < 2 { // 至少 2 次(前 2 主 email 有 ccBatch)
		t.Errorf("CcHeaderList 应至少 2 次非空,got=%d", fb.ccListSeen.Load())
	}
}

func TestDispatcher_ClampPerEmail(t *testing.T) {
	// PerEmail=0 → clamp 到 1;PerEmail=200 → clamp 到 100
	if clampPerEmail(0) != 1 {
		t.Error("0 → 1")
	}
	if clampPerEmail(-5) != 1 {
		t.Error("-5 → 1")
	}
	if clampPerEmail(50) != 50 {
		t.Error("50 → 50")
	}
	if clampPerEmail(200) != 100 {
		t.Error("200 → 100")
	}
}

func TestDispatcher_takeCCBatch_ConsumesPool(t *testing.T) {
	d := &Dispatcher{
		ccEnabled:  true,
		ccPool:     []string{"a", "b", "c", "d", "e"},
		ccPerEmail: 2,
	}
	// 3 次 take:[a b] [c d] [e]
	batch1 := d.takeCCBatch()
	if len(batch1) != 2 || batch1[0] != "a" || batch1[1] != "b" {
		t.Errorf("batch1:%v", batch1)
	}
	batch2 := d.takeCCBatch()
	if len(batch2) != 2 || batch2[0] != "c" || batch2[1] != "d" {
		t.Errorf("batch2:%v", batch2)
	}
	batch3 := d.takeCCBatch()
	if len(batch3) != 1 || batch3[0] != "e" {
		t.Errorf("batch3(池截断):%v", batch3)
	}
	batch4 := d.takeCCBatch()
	if batch4 != nil {
		t.Errorf("池空后应 nil:%v", batch4)
	}
}

func TestDispatcher_takeCCBatch_Disabled(t *testing.T) {
	d := &Dispatcher{ccEnabled: false}
	if d.takeCCBatch() != nil {
		t.Error("Disabled 应 nil")
	}
}

// ============================================================================
// error 上限
// ============================================================================

func TestDispatcher_ErrorsCapped_At1000(t *testing.T) {
	// 构造 1200 全 fail → errors 应只 1000
	rcpts := make([]*reader.Recipient, 1200)
	for i := range rcpts {
		rcpts[i] = makeRcpt("bad@x.com", i+1)
	}
	cfg := minCfg()
	rdr := &fakeReader{rcpts: rcpts}
	inj := &fakeInjector{}
	fb := &fakeBuilder{failOn: "bad@x.com"}
	factory := func(_ int) RenderBuilder { return fb }

	d := New(cfg, rdr, inj, factory, nil, nil)
	res, _ := d.Run(context.Background())
	if len(res.Errors) != maxErrors {
		t.Errorf("errors 应 cap 到 %d,got=%d", maxErrors, len(res.Errors))
	}
	if res.Failed != 1200 {
		t.Errorf("failed 计数应仍 1200(不受 cap 影响):%d", res.Failed)
	}
}
