// Package dispatcher 顶层邮件发送协调器(v1 core/dispatcher.go 688 行的 v2 等价)
//
// 【职责】
//  1. Run 启动时:创建 render.Builder × N(per-worker)+ Injector + Reader + 加载 CC/BCC 池
//  2. 起 3 类 goroutine:collectResults / reportProgress / worker 池
//  3. read loop:从 reader 读 → 送 recipientCh(带 ctx / workers 死锁防御)
//  4. 处理完毕:关闭 recipientCh → 等 worker 退出 → 关闭 resultCh → 等 collectResults 退出
//  5. 构建 Result 返回
//
// 【CC/BCC 分配】(§9 契约冻结):
//   - 池 Run 启动全量加载 + clamp perEmail 到 [1, 100]
//   - takeCCBatch / takeBCCBatch:atomic.AddInt64 原子取批次
//   - 主邮件带 ccBatch(CcHeaderList)+ CC/BCC 独立邮件循环
//   - 消费完即停 + 主邮件失败不跳过 CC/BCC(Q10 决策 —— 避免配额浪费)
//
// 【依赖注入】(D22-3 修 race):
//   - reader / injector / builder / limiter / reporter 全部由 New 传入
//   - Dispatcher 不 New 任何子包 —— 便于测试用 fake 替换
//
// 【线程安全】Run 里多 goroutine 访问:
//   - 统计字段(processed/success/failed):atomic
//   - errors 列表:sync.Mutex(len ≤ 1000 上限)
//   - ccIdx / bccIdx:atomic.AddInt64
//
// 【依赖】config + pipeline/{worker, ratelimit, reporter} + recipient/reader + inject
package dispatcher
