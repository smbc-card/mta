package dispatcher

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/inject"
	"__MODULE_PLACEHOLDER__/internal/pipeline/ratelimit"
	"__MODULE_PLACEHOLDER__/internal/pipeline/reporter"
	"__MODULE_PLACEHOLDER__/internal/pipeline/worker"
	"__MODULE_PLACEHOLDER__/internal/recipient/emaillist"
	"__MODULE_PLACEHOLDER__/internal/recipient/reader"
)

// BuildRequest 单封邮件的构建请求(dispatcher → RenderBuilder)
//
// 【设计】用 struct 承载所有字段,便于未来扩展(dkim 自定义 h= 等)不破坏调用
type BuildRequest struct {
	// Recipient 变量渲染上下文(FirstName/LastName/CustomFields 等)
	Recipient *reader.Recipient
	// TargetEmail 这封邮件的实际收件人
	//   - 主邮件:== Recipient.Email
	//   - CC/BCC 独立邮件:== cc/bcc 地址(变量上下文仍用 Recipient)
	TargetEmail string
	// CcHeaderList 主邮件的 Cc 头列表;CC/BCC 独立邮件传 nil
	CcHeaderList []string
}

// RenderedEmail 渲染后的邮件抽象(dispatcher 只用 3 字段 → 走 inject.Email 接口即可)
//
// 【实现】render.Email 天然满足
type RenderedEmail = inject.Email

// RenderBuilder 邮件渲染器接口
//
// 【依赖倒置】dispatcher 不 import render 具体包(避免循环)
// 【实现】app/bootstrap 层用 renderAdapter 桥接 render.Builder 到本接口
type RenderBuilder interface {
	Build(req BuildRequest) (RenderedEmail, error)
}

// BuilderFactory per-worker RenderBuilder 工厂
//
// 【设计】dispatcher 内部 for i := 0; i < workers; i++ { builders[i] = factory(i) }
// 每 worker 独立 builder(独立 rng seed,与 v1 一致)
type BuilderFactory func(workerID int) RenderBuilder

// Dispatcher 顶层协调器(v1 core/dispatcher.go 688 行的 v2 等价)
type Dispatcher struct {
	cfg      *config.Config
	reader   reader.Reader
	injector inject.Injector
	factory  BuilderFactory
	limiter  *ratelimit.Limiter
	reporter reporter.Reporter

	// 统计计数(atomic 访问)
	total     int64
	processed int64
	success   int64
	failed    int64

	startTime time.Time

	// 错误收集(Mutex 保护;上限 maxErrors)
	errors     []reporter.ErrorInfo
	errorsLock sync.Mutex

	// 【§9 CC/BCC】池 + atomic 索引
	ccEnabled   bool
	ccPool      []string
	ccIdx       int64
	ccPerEmail  int
	bccEnabled  bool
	bccPool     []string
	bccIdx      int64
	bccPerEmail int
}

// maxErrors 错误列表上限(v1 一致)
const maxErrors = 1000

// New 创建 Dispatcher
func New(
	cfg *config.Config,
	rdr reader.Reader,
	inj inject.Injector,
	factory BuilderFactory,
	limiter *ratelimit.Limiter,
	rep reporter.Reporter,
) *Dispatcher {
	if limiter == nil {
		limiter = ratelimit.New(0)
	}
	if rep == nil {
		rep = reporter.NewNoop()
	}
	return &Dispatcher{
		cfg:      cfg,
		reader:   rdr,
		injector: inj,
		factory:  factory,
		limiter:  limiter,
		reporter: rep,
		errors:   make([]reporter.ErrorInfo, 0),
	}
}

// Run 运行调度器(v1 dispatcher.Run 的 v2 等价)
//
// 【流程】
//  1. 加载 CC/BCC 池 + total 修正(消费完即停语义)
//  2. per-worker builders 构造
//  3. 建 recipientCh / resultCh
//  4. 起 3 类 goroutine:collectResults + reportProgress + worker.Pool.Run
//  5. 主 read loop:reader → recipientCh
//  6. 优雅关闭:close(recipientCh) → wait worker → close(resultCh) → wait collectResults
//  7. buildResult
//
// 【返回】
//   - (*Result, nil):正常完成
//   - (*Result, err):严重故障(CC/BCC 池加载失败等)
//   - ctx cancel:Result.Status="cancelled",返回时 nil err(优雅退出)
func (d *Dispatcher) Run(ctx context.Context) (*reporter.Result, error) {
	d.startTime = time.Now()

	// 【1】总数(reader 侧)
	total, _ := d.reader.Count()
	atomic.StoreInt64(&d.total, total)

	// 【2】加载 CC/BCC 池
	if err := d.loadCCBCCPools(); err != nil {
		return nil, err
	}

	// 【3】total 修正:主 + maxCC + maxBCC(§9 消费完即停)
	d.adjustTotalForCCBCC()

	// 【4】per-worker builders
	workers := d.cfg.Performance.Workers
	if workers < 1 {
		workers = 1
	}
	builders := make([]RenderBuilder, workers)
	for i := 0; i < workers; i++ {
		builders[i] = d.factory(i)
	}

	// 【5】channels
	buf := d.cfg.Performance.ChannelBuffer
	if buf < 1 {
		buf = workers * 2
	}
	recipientCh := make(chan *reader.Recipient, buf)
	resultCh := make(chan worker.Result, buf)

	// 【6】collectResults goroutine
	collectDone := make(chan struct{})
	go d.collectResults(resultCh, collectDone)

	// 【7】reportProgress goroutine
	progressCtx, cancelProgress := context.WithCancel(ctx)
	defer cancelProgress()
	go d.reportProgress(progressCtx)

	// 【8】worker.Pool(with per-recipient process closure)
	process := func(pctx context.Context, task worker.Task) worker.Result {
		return d.processRecipient(pctx, task, builders[task.WorkerID])
	}
	pool := worker.New(workers, process)

	// 【9】起 read loop goroutine(与 worker.Pool.Run 并发,通过 recipientCh 协调)
	readErrCh := make(chan error, 1)
	go func() {
		readErrCh <- d.readLoop(ctx, recipientCh)
		close(recipientCh)
	}()

	// 【10】worker.Pool.Run(阻塞至所有 worker 退出)
	poolErr := pool.Run(ctx, recipientCh, resultCh)

	// 【P25 顺序敏感】worker 全退出后关 resultCh → 等 collectResults 退出
	close(resultCh)
	<-collectDone

	// 停止 progress goroutine(cancelProgress 已 defer)
	cancelProgress()

	// 等 readLoop 退出(它一般在 close(recipientCh) 时已完成)
	<-readErrCh

	// 【11】buildResult
	res := d.buildResult(ctx)

	// pool err:ctx cancel 是优雅退出(不当 err)
	if poolErr != nil && !errIsCancel(poolErr, ctx) {
		return res, poolErr
	}
	return res, nil
}

// loadCCBCCPools 加载 CC/BCC 池 + clamp perEmail 到 [1, 100]
func (d *Dispatcher) loadCCBCCPools() error {
	d.ccEnabled = d.cfg.CC.Enabled && d.cfg.CC.FilePath != ""
	if d.ccEnabled {
		pool, err := emaillist.ReadEmailList(d.cfg.CC.FilePath)
		if err != nil {
			return fmt.Errorf("加载抄送列表失败: %w", err)
		}
		d.ccPool = pool
		d.ccPerEmail = clampPerEmail(d.cfg.CC.PerEmail)
	}

	d.bccEnabled = d.cfg.BCC.Enabled && d.cfg.BCC.FilePath != ""
	if d.bccEnabled {
		pool, err := emaillist.ReadEmailList(d.cfg.BCC.FilePath)
		if err != nil {
			return fmt.Errorf("加载密送列表失败: %w", err)
		}
		d.bccPool = pool
		d.bccPerEmail = clampPerEmail(d.cfg.BCC.PerEmail)
	}
	return nil
}

// clampPerEmail v1 v8.1.4 #26:clamp 到 [1, 100](与 C# UI NumericUpDown 一致)
func clampPerEmail(v int) int {
	if v < 1 {
		return 1
	}
	if v > 100 {
		return 100
	}
	return v
}

// adjustTotalForCCBCC total 修正:主邮件数 + maxCC + maxBCC(§9 消费完即停语义)
func (d *Dispatcher) adjustTotalForCCBCC() {
	main := atomic.LoadInt64(&d.total)
	if d.ccEnabled {
		maxCC := main * int64(d.ccPerEmail)
		if maxCC > int64(len(d.ccPool)) {
			maxCC = int64(len(d.ccPool))
		}
		atomic.AddInt64(&d.total, maxCC)
	}
	if d.bccEnabled {
		maxBCC := main * int64(d.bccPerEmail)
		if maxBCC > int64(len(d.bccPool)) {
			maxBCC = int64(len(d.bccPool))
		}
		atomic.AddInt64(&d.total, maxBCC)
	}
}

// readLoop 主线程从 reader 读收件人 → 送 recipientCh
//
// 【契约】v2 与 v1 dispatcher.Run 的 readLoop 语义等价
//
// 【错误处理】read 失败 → 记录 errors + 计入 failed/processed + 继续读下一行(不中断)
func (d *Dispatcher) readLoop(ctx context.Context, recipientCh chan<- *reader.Recipient) error {
	skipLines := d.cfg.Recipients.SkipLines
	lineNum := 0

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		rcpt, err := d.reader.Read()
		if err != nil {
			d.addError(reporter.ErrorInfo{
				Email: "",
				Error: fmt.Sprintf("读取收件人失败(行 %d): %v", lineNum+1, err),
				Line:  lineNum + 1,
			})
			atomic.AddInt64(&d.failed, 1)
			atomic.AddInt64(&d.processed, 1)
			continue
		}
		if rcpt == nil {
			return nil // 文件读完
		}

		lineNum++
		if lineNum <= skipLines {
			continue
		}
		rcpt.LineNumber = lineNum

		select {
		case recipientCh <- rcpt:
		case <-ctx.Done():
			return ctx.Err()
		}
	}
}

// processRecipient 处理单个 recipient(主邮件 + CC/BCC 独立邮件循环)
//
// 【契约】v2 与 v1 dispatcher.processRecipient 语义等价(§9 CC/BCC 全流程)
func (d *Dispatcher) processRecipient(ctx context.Context, task worker.Task, builder RenderBuilder) worker.Result {
	rcpt := task.Recipient
	result := worker.Result{
		Email: rcpt.Email,
		Line:  rcpt.LineNumber,
	}

	// rate limit(主邮件)
	if err := d.limiter.Wait(ctx); err != nil {
		result.Error = err
		return result
	}

	// § 9 CC/BCC:原子分配本封的子批次
	ccBatch := d.takeCCBatch()
	bccBatch := d.takeBCCBatch()

	// 主邮件
	skipMain := !d.cfg.Recipient.Enabled || rcpt.Email == ""
	if skipMain {
		result.Success = true // 占位:CSV 行已扫过
	} else {
		mainRes := d.buildAndInjectOne(ctx, rcpt, rcpt.Email, ccBatch, builder)
		result.Success = mainRes.Success
		result.Error = mainRes.Error
		// 【v8.1】主邮件失败不跳过 CC/BCC(配额已 atomic 分走)
	}

	// CC 独立邮件循环
	for _, ccAddr := range ccBatch {
		if err := d.limiter.Wait(ctx); err != nil {
			return result
		}
		if ctx.Err() != nil {
			return result
		}
		secRes := d.buildAndInjectOne(ctx, rcpt, ccAddr, nil, builder)
		atomic.AddInt64(&d.processed, 1)
		if secRes.Success {
			atomic.AddInt64(&d.success, 1)
		} else {
			atomic.AddInt64(&d.failed, 1)
			d.addError(reporter.ErrorInfo{
				Email: ccAddr,
				Error: fmt.Sprintf("[CC独立邮件 主收件人=%s] %v", rcpt.Email, secRes.Error),
				Line:  rcpt.LineNumber,
			})
		}
	}

	// BCC 独立邮件循环
	for _, bccAddr := range bccBatch {
		if err := d.limiter.Wait(ctx); err != nil {
			return result
		}
		if ctx.Err() != nil {
			return result
		}
		secRes := d.buildAndInjectOne(ctx, rcpt, bccAddr, nil, builder)
		atomic.AddInt64(&d.processed, 1)
		if secRes.Success {
			atomic.AddInt64(&d.success, 1)
		} else {
			atomic.AddInt64(&d.failed, 1)
			d.addError(reporter.ErrorInfo{
				Email: bccAddr,
				Error: fmt.Sprintf("[BCC独立邮件 主收件人=%s] %v", rcpt.Email, secRes.Error),
				Line:  rcpt.LineNumber,
			})
		}
	}

	return result
}

// buildAndInjectOne 构建单封邮件并注入(主邮件或 CC/BCC 独立邮件)
func (d *Dispatcher) buildAndInjectOne(ctx context.Context, rcpt *reader.Recipient,
	targetEmail string, ccHeaderList []string, builder RenderBuilder) worker.Result {
	result := worker.Result{
		Email: targetEmail,
		Line:  rcpt.LineNumber,
	}

	req := BuildRequest{
		Recipient:    rcpt,
		TargetEmail:  targetEmail,
		CcHeaderList: ccHeaderList,
	}
	eml, err := builder.Build(req)
	if err != nil {
		result.Error = fmt.Errorf("生成邮件失败: %w", err)
		return result
	}

	if !d.cfg.DryRun {
		if err := d.injector.Send(ctx, eml); err != nil {
			result.Error = fmt.Errorf("注入失败: %w", err)
			return result
		}
	}

	result.Success = true
	return result
}

// takeCCBatch atomic 分配 CC 子批次(§9)
func (d *Dispatcher) takeCCBatch() []string {
	if !d.ccEnabled || len(d.ccPool) == 0 || d.ccPerEmail == 0 {
		return nil
	}
	end := atomic.AddInt64(&d.ccIdx, int64(d.ccPerEmail))
	start := end - int64(d.ccPerEmail)
	poolLen := int64(len(d.ccPool))
	if start >= poolLen {
		return nil
	}
	if end > poolLen {
		end = poolLen
	}
	return d.ccPool[start:end]
}

// takeBCCBatch atomic 分配 BCC 子批次
func (d *Dispatcher) takeBCCBatch() []string {
	if !d.bccEnabled || len(d.bccPool) == 0 || d.bccPerEmail == 0 {
		return nil
	}
	end := atomic.AddInt64(&d.bccIdx, int64(d.bccPerEmail))
	start := end - int64(d.bccPerEmail)
	poolLen := int64(len(d.bccPool))
	if start >= poolLen {
		return nil
	}
	if end > poolLen {
		end = poolLen
	}
	return d.bccPool[start:end]
}

// collectResults 从 resultCh 收统计
//
// 【契约】v2 与 v1 dispatcher.collectResults 语义等价
func (d *Dispatcher) collectResults(resultCh <-chan worker.Result, done chan<- struct{}) {
	defer close(done)
	for res := range resultCh {
		atomic.AddInt64(&d.processed, 1)
		if res.Success {
			atomic.AddInt64(&d.success, 1)
		} else {
			atomic.AddInt64(&d.failed, 1)
			if res.Error != nil {
				d.addError(reporter.ErrorInfo{
					Email: res.Email,
					Error: res.Error.Error(),
					Line:  res.Line,
				})
			}
		}
	}
}

// reportProgress ticker 上报 progress.json
//
// 【契约】v2 与 v1 dispatcher.reportProgress 语义等价
func (d *Dispatcher) reportProgress(ctx context.Context) {
	interval := d.cfg.Performance.ProgressInterval
	if interval < 1 {
		interval = 1 // v1 兜底:未配置或 <1 默认 1s
	}
	ticker := time.NewTicker(time.Duration(interval) * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			_ = d.reporter.UpdateProgress(d.snapshotProgress("running"))
		}
	}
}

// snapshotProgress 抓当前统计快照
func (d *Dispatcher) snapshotProgress(status string) reporter.Progress {
	processed := atomic.LoadInt64(&d.processed)
	success := atomic.LoadInt64(&d.success)
	failed := atomic.LoadInt64(&d.failed)
	total := atomic.LoadInt64(&d.total)
	elapsed := time.Since(d.startTime).Seconds()

	var rate float64
	if elapsed > 0 {
		rate = float64(processed) / elapsed
	}
	var eta int64
	if rate > 0 && total > processed {
		eta = int64(float64(total-processed) / rate)
	}
	return reporter.Progress{
		JobID:      d.cfg.Job.ID,
		Status:     status,
		Total:      total,
		Processed:  processed,
		Success:    success,
		Failed:     failed,
		Rate:       rate,
		ETASeconds: eta,
		StartTime:  d.startTime,
		UpdateTime: time.Now(),
	}
}

// buildResult Run 结束后构建 Result
func (d *Dispatcher) buildResult(ctx context.Context) *reporter.Result {
	endTime := time.Now()
	duration := endTime.Sub(d.startTime)
	processed := atomic.LoadInt64(&d.processed)
	success := atomic.LoadInt64(&d.success)
	failed := atomic.LoadInt64(&d.failed)

	var avgRate float64
	if duration.Seconds() > 0 {
		avgRate = float64(processed) / duration.Seconds()
	}

	status := "completed"
	if ctx.Err() != nil {
		status = "cancelled"
	}

	d.errorsLock.Lock()
	errs := make([]reporter.ErrorInfo, len(d.errors))
	copy(errs, d.errors)
	d.errorsLock.Unlock()

	return &reporter.Result{
		JobID:       d.cfg.Job.ID,
		Status:      status,
		Total:       processed, // Q6:total = 实发数(v1 一致)
		Success:     success,
		Failed:      failed,
		StartTime:   d.startTime,
		EndTime:     endTime,
		Duration:    duration,
		AverageRate: avgRate,
		Errors:      errs,
	}
}

// addError 加错误(带上限保护)
func (d *Dispatcher) addError(e reporter.ErrorInfo) {
	d.errorsLock.Lock()
	defer d.errorsLock.Unlock()
	if len(d.errors) < maxErrors {
		d.errors = append(d.errors, e)
	}
}

// errIsCancel 判断 err 是否为 ctx 取消(优雅退出,不当严重故障)
func errIsCancel(err error, ctx context.Context) bool {
	if err == context.Canceled || err == context.DeadlineExceeded {
		return true
	}
	if ctx.Err() != nil {
		return true
	}
	return false
}
