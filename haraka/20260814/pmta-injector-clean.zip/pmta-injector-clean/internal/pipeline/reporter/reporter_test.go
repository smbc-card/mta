package reporter

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

// ============================================================================
// NoopReporter
// ============================================================================

func TestNoopReporter_AlwaysSucceeds(t *testing.T) {
	r := NewNoop()
	if err := r.UpdateProgress(Progress{}); err != nil {
		t.Errorf("Noop UpdateProgress:%v", err)
	}
	if err := r.SaveResult(Result{}); err != nil {
		t.Errorf("Noop SaveResult:%v", err)
	}
}

// ============================================================================
// FileReporter — 空路径 = 跳过写(不 err)
// ============================================================================

func TestFileReporter_EmptyPath_Skips(t *testing.T) {
	r := NewFileReporter("", "", "")
	if err := r.UpdateProgress(Progress{}); err != nil {
		t.Errorf("空 progressFile 应跳过:%v", err)
	}
	if err := r.SaveResult(Result{}); err != nil {
		t.Errorf("空 resultFile 应跳过:%v", err)
	}
}

// ============================================================================
// FileReporter — UpdateProgress 原子写
// ============================================================================

func TestFileReporter_UpdateProgress_WritesJSON(t *testing.T) {
	dir := t.TempDir()
	progressFile := filepath.Join(dir, "progress.json")

	r := NewFileReporter(progressFile, "", "")

	now := time.Now()
	p := Progress{
		JobID:      "job-1",
		Status:     "running",
		Total:      100,
		Processed:  50,
		Success:    45,
		Failed:     5,
		Rate:       10.5,
		ETASeconds: 20,
		StartTime:  now,
		UpdateTime: now,
	}
	if err := r.UpdateProgress(p); err != nil {
		t.Fatalf("UpdateProgress:%v", err)
	}

	// 读回验证
	data, err := os.ReadFile(progressFile)
	if err != nil {
		t.Fatalf("ReadFile:%v", err)
	}
	var got Progress
	if err := json.Unmarshal(data, &got); err != nil {
		t.Fatalf("Unmarshal:%v", err)
	}
	if got.JobID != "job-1" || got.Total != 100 || got.Processed != 50 {
		t.Errorf("字段偏离:%+v", got)
	}

	// tmp 文件应清理
	if _, err := os.Stat(progressFile + ".tmp"); !os.IsNotExist(err) {
		t.Error("tmp 文件应已 rename 走")
	}
}

func TestFileReporter_UpdateProgress_MkdirParent(t *testing.T) {
	// 父目录不存在时 New 应自动创建
	dir := t.TempDir()
	deepPath := filepath.Join(dir, "sub", "nested", "progress.json")
	r := NewFileReporter(deepPath, "", "")
	if err := r.UpdateProgress(Progress{JobID: "x"}); err != nil {
		t.Fatalf("UpdateProgress:%v", err)
	}
	if _, err := os.Stat(deepPath); err != nil {
		t.Errorf("父目录应已创建:%v", err)
	}
}

// ============================================================================
// FileReporter — SaveResult
// ============================================================================

func TestFileReporter_SaveResult_WritesJSON(t *testing.T) {
	dir := t.TempDir()
	resultFile := filepath.Join(dir, "result.json")

	r := NewFileReporter("", resultFile, "")

	start := time.Now()
	res := Result{
		JobID:       "job-1",
		Status:      "completed",
		Total:       10,
		Success:     9,
		Failed:      1,
		StartTime:   start,
		EndTime:     start.Add(5 * time.Second),
		Duration:    5 * time.Second,
		AverageRate: 2.0,
		Errors: []ErrorInfo{
			{Email: "bad@x.com", Error: "smtp failed", Line: 3},
		},
	}
	if err := r.SaveResult(res); err != nil {
		t.Fatalf("SaveResult:%v", err)
	}

	data, err := os.ReadFile(resultFile)
	if err != nil {
		t.Fatalf("ReadFile:%v", err)
	}
	// 关键字段检查(v1 契约 RFC3339 无 Nano)
	s := string(data)
	if !strings.Contains(s, `"job_id": "job-1"`) {
		t.Errorf("job_id 缺失:%s", s)
	}
	if !strings.Contains(s, `"duration_seconds": 5`) {
		t.Errorf("duration_seconds 应 5,got:%s", s)
	}
	if !strings.Contains(s, `"errors":`) {
		t.Errorf("errors 应含 —— 非空:%s", s)
	}
	// StartTime 应 RFC3339(不含小数秒)
	if strings.Contains(s, ".00") || strings.Contains(s, ".99") {
		t.Errorf("StartTime 应 RFC3339 无 Nano:%s", s)
	}
}

func TestFileReporter_SaveResult_EmptyErrorsOmitted(t *testing.T) {
	dir := t.TempDir()
	resultFile := filepath.Join(dir, "result.json")

	r := NewFileReporter("", resultFile, "")
	res := Result{
		JobID:   "job-1",
		Status:  "completed",
		Total:   10, Success: 10, Failed: 0,
		StartTime: time.Now(), EndTime: time.Now(),
	}
	if err := r.SaveResult(res); err != nil {
		t.Fatalf("SaveResult:%v", err)
	}
	data, _ := os.ReadFile(resultFile)
	// omitempty:空 errors 不应出现 key
	if strings.Contains(string(data), "errors") {
		t.Errorf("空 errors 应被 omitempty:%s", data)
	}
}

// ============================================================================
// FileReporter — errors.log(v1 语义:os.Create 覆盖写)
// ============================================================================

func TestFileReporter_SaveResult_WritesErrorsLog(t *testing.T) {
	dir := t.TempDir()
	resultFile := filepath.Join(dir, "result.json")
	errorFile := filepath.Join(dir, "errors.log")

	r := NewFileReporter("", resultFile, errorFile)
	res := Result{
		JobID: "job-1", Status: "completed", Total: 3, Success: 1, Failed: 2,
		StartTime: time.Now(), EndTime: time.Now(),
		Errors: []ErrorInfo{
			{Email: "a@x.com", Error: "err1", Line: 1},
			{Email: "b@y.com", Error: "err2", Line: 2},
		},
	}
	if err := r.SaveResult(res); err != nil {
		t.Fatalf("SaveResult:%v", err)
	}

	data, err := os.ReadFile(errorFile)
	if err != nil {
		t.Fatalf("errors.log:%v", err)
	}
	// v1 格式:"Line %d: %s - %s\n"
	if !strings.Contains(string(data), "Line 1: a@x.com - err1\n") {
		t.Errorf("errors.log 第 1 行格式:%s", data)
	}
	if !strings.Contains(string(data), "Line 2: b@y.com - err2\n") {
		t.Errorf("errors.log 第 2 行格式:%s", data)
	}
}

func TestFileReporter_SaveResult_NoErrorsLogWhenEmpty(t *testing.T) {
	// 无 errors → 不写 errors.log
	dir := t.TempDir()
	resultFile := filepath.Join(dir, "result.json")
	errorFile := filepath.Join(dir, "errors.log")

	r := NewFileReporter("", resultFile, errorFile)
	res := Result{
		JobID: "j", Status: "completed", Total: 1, Success: 1, Failed: 0,
		StartTime: time.Now(), EndTime: time.Now(),
	}
	_ = r.SaveResult(res)
	if _, err := os.Stat(errorFile); !os.IsNotExist(err) {
		t.Error("空 errors 不应写 errors.log")
	}
}

// ============================================================================
// 错误分支
// ============================================================================

func TestFileReporter_UpdateProgress_WriteFail(t *testing.T) {
	// progressFile 指向一个**目录**(而非文件)→ os.WriteFile 失败
	dir := t.TempDir()
	// 用 dir 本身作为"文件路径"—— os.WriteFile 会失败
	r := NewFileReporter(dir, "", "")
	err := r.UpdateProgress(Progress{JobID: "x"})
	if err == nil {
		t.Error("progressFile 指向目录时应返回 err")
	}
}

func TestFileReporter_SaveResult_WriteFail(t *testing.T) {
	dir := t.TempDir()
	r := NewFileReporter("", dir, "")
	err := r.SaveResult(Result{JobID: "x", StartTime: time.Now(), EndTime: time.Now()})
	if err == nil {
		t.Error("resultFile 指向目录时应返回 err")
	}
}

func TestFileReporter_SaveErrors_CreateFail(t *testing.T) {
	// errorFile 指向目录 → os.Create 失败;但主 SaveResult 应仍返回 nil(errors 写失败不影响)
	dir := t.TempDir()
	resultFile := filepath.Join(dir, "result.json")
	r := NewFileReporter("", resultFile, dir) // errorFile = dir(目录)
	res := Result{
		JobID: "j", Status: "completed", Total: 1, Failed: 1,
		StartTime: time.Now(), EndTime: time.Now(),
		Errors: []ErrorInfo{{Email: "a", Error: "e", Line: 1}},
	}
	err := r.SaveResult(res)
	if err != nil {
		t.Errorf("errors 写失败不应影响主 SaveResult:%v", err)
	}
	// result.json 应写成功
	if _, statErr := os.Stat(resultFile); statErr != nil {
		t.Errorf("result.json 应存在:%v", statErr)
	}
}

// ============================================================================
// 并发安全(-race 测:reportProgress goroutine + SaveResult 主线程并发)
// ============================================================================

func TestFileReporter_ConcurrentSafe(t *testing.T) {
	dir := t.TempDir()
	progressFile := filepath.Join(dir, "progress.json")
	resultFile := filepath.Join(dir, "result.json")

	r := NewFileReporter(progressFile, resultFile, "")

	var wg sync.WaitGroup
	// 10 goroutine 各自 UpdateProgress 100 次
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				_ = r.UpdateProgress(Progress{JobID: "job", Processed: int64(j)})
			}
		}(i)
	}
	// 1 goroutine SaveResult
	wg.Add(1)
	go func() {
		defer wg.Done()
		_ = r.SaveResult(Result{JobID: "j", StartTime: time.Now(), EndTime: time.Now()})
	}()

	wg.Wait()

	// 最终 progress.json 应存在且合法 JSON
	data, err := os.ReadFile(progressFile)
	if err != nil {
		t.Fatalf("ReadFile:%v", err)
	}
	var got Progress
	if err := json.Unmarshal(data, &got); err != nil {
		t.Errorf("最终 progress.json 非合法:%v\n%s", err, data)
	}
}
