// Package reporter 进度上报 + 结果输出(progress.json / result.json / errors.log)
//
// 【契约】v2 与 v1 reporter/reporter.go 语义等价;字节格式对齐契约 §4
//
// 【3 输出】
//   - progress.json:1s ticker 覆盖写(atomic 计数快照)
//   - result.json:Run 完成后一次性写(含 errors 列表 + duration)
//   - errors.log:【可选】v2 增强(Q7 决策:v2 升级为原子追加,v1 无此文件)
//
// 【接口 vs 实现】
//   - Reporter interface —— 让 dispatcher 依赖注入,便于测试用 fakeReporter
//   - FileReporter:生产用,写文件
//   - NoopReporter:测试或 dry-run 用(不写盘)
//
// 【线程安全】UpdateProgress 会被 reportProgress goroutine 频繁调,内部用 atomic + os.WriteFile
//
// 【依赖】只 std lib(encoding/json + os + sync)
package reporter
