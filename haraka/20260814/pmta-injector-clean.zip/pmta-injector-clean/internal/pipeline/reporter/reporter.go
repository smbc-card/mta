package reporter

import (
	"time"
)

// Progress 进度快照(§4.2 契约)
//
// 【字段】与 v1 types.Progress 完全一致
type Progress struct {
	JobID      string    `json:"job_id"`
	Status     string    `json:"status"` // "running" / "completed" / "cancelled"
	Total      int64     `json:"total"`
	Processed  int64     `json:"processed"`
	Success    int64     `json:"success"`
	Failed     int64     `json:"failed"`
	Rate       float64   `json:"rate"`
	ETASeconds int64     `json:"eta_seconds"`
	StartTime  time.Time `json:"start_time"`
	UpdateTime time.Time `json:"update_time"`
}

// ErrorInfo 单条错误信息(§4.3 契约)
type ErrorInfo struct {
	Email string `json:"email"`
	Error string `json:"error"`
	Line  int    `json:"line"`
}

// Result 最终结果(§4.3 契约)
//
// 【字段】与 v1 types.Result 完全一致
//
// 【时间格式】v1 用 RFC3339 无 Nano(Q6 契约冻结),v2 保持
// 【errors omitempty】empty 时不输出字段(§4.3 契约)
type Result struct {
	JobID       string        `json:"job_id"`
	Status      string        `json:"status"`
	Total       int64         `json:"total"`
	Success     int64         `json:"success"`
	Failed      int64         `json:"failed"`
	StartTime   time.Time     `json:"start_time"`
	EndTime     time.Time     `json:"end_time"`
	Duration    time.Duration `json:"duration"`
	AverageRate float64       `json:"average_rate"`
	Errors      []ErrorInfo   `json:"errors,omitempty"`
}

// Reporter 进度上报接口
//
// 【设计】依赖注入,dispatcher 通过接口引用;测试用 NoopReporter
type Reporter interface {
	UpdateProgress(p Progress) error
	SaveResult(r Result) error
}

// NoopReporter 测试/dry-run 用(不写盘)
//
// 【线程安全】无状态,天然线程安全
type NoopReporter struct{}

// NewNoop 创建 NoopReporter
func NewNoop() Reporter {
	return &NoopReporter{}
}

// UpdateProgress noop
func (NoopReporter) UpdateProgress(_ Progress) error { return nil }

// SaveResult noop
func (NoopReporter) SaveResult(_ Result) error { return nil }
