package reporter

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// FileReporter 文件系统 Reporter(v1 reporter/reporter.go 154 行的 v2 等价)
//
// 【原子写】progress.json / result.json 都用 tempFile + os.Rename(同一文件系统)—— 与 v1 一致
//
// 【errors.log】(Q7 契约冻结:v1 = os.Create 覆盖写;v2 保 v1 简单版,不做 append 升级)
//
// 【线程安全】所有写操作用同一把 mu 保护(reportProgress goroutine 与 SaveResult 主线程可能并发)
type FileReporter struct {
	progressFile string
	resultFile   string
	errorFile    string
	mu           sync.Mutex
}

// NewFileReporter 创建 FileReporter
//
// 【参数】3 路径为空时对应功能跳过(与 v1 一致 —— cfg 字段空则不写)
// 【副作用】自动创建 3 路径的父目录(MkdirAll 0755)
//
// 【设计】不 import config —— 由调用方从 cfg.Output 挑字段传入
func NewFileReporter(progressFile, resultFile, errorFile string) *FileReporter {
	if progressFile != "" {
		_ = os.MkdirAll(filepath.Dir(progressFile), 0755)
	}
	if resultFile != "" {
		_ = os.MkdirAll(filepath.Dir(resultFile), 0755)
	}
	if errorFile != "" {
		_ = os.MkdirAll(filepath.Dir(errorFile), 0755)
	}
	return &FileReporter{
		progressFile: progressFile,
		resultFile:   resultFile,
		errorFile:    errorFile,
	}
}

// UpdateProgress 覆盖写 progress.json(原子)
//
// 【契约】v2 与 v1 reporter.UpdateProgress 语义一致
//
// 【原子写】tempFile(.tmp 后缀)→ Rename;失败清理 tempFile
//
// 【空场景】progressFile == "" → 直接返回 nil(不写)
func (r *FileReporter) UpdateProgress(p Progress) error {
	if r.progressFile == "" {
		return nil
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	data, err := json.MarshalIndent(p, "", "  ")
	if err != nil {
		return fmt.Errorf("序列化进度失败: %w", err)
	}

	tempFile := r.progressFile + ".tmp"
	if err := os.WriteFile(tempFile, data, 0644); err != nil {
		return fmt.Errorf("写入进度文件失败: %w", err)
	}
	if err := os.Rename(tempFile, r.progressFile); err != nil {
		_ = os.Remove(tempFile)
		return fmt.Errorf("移动进度文件失败: %w", err)
	}
	return nil
}

// resultOutput SaveResult 用的可序列化格式(避免 Duration 直接编码为 int64 纳秒)
//
// 【契约】v2 与 v1 reporter.SaveResult 里的 anonymous struct 字段完全一致
//   - StartTime / EndTime → RFC3339 字符串(Q6 契约:无 Nano)
//   - DurationSeconds → float64(而非 Duration 类型)
//   - Errors omitempty
type resultOutput struct {
	JobID           string      `json:"job_id"`
	Status          string      `json:"status"`
	Total           int64       `json:"total"`
	Success         int64       `json:"success"`
	Failed          int64       `json:"failed"`
	StartTime       string      `json:"start_time"`
	EndTime         string      `json:"end_time"`
	DurationSeconds float64     `json:"duration_seconds"`
	AverageRate     float64     `json:"average_rate"`
	Errors          []ErrorInfo `json:"errors,omitempty"`
}

// SaveResult 一次性写 result.json(+ 可选 errors.log)
//
// 【契约】v2 与 v1 reporter.SaveResult 语义一致
//
// 【空场景】resultFile == "" → 直接返回 nil
//
// 【错误处理】result.json 写完成功后,若有 errors 且 errorFile != "" → saveErrors
// (errors 写失败不影响主返回)
func (r *FileReporter) SaveResult(res Result) error {
	if r.resultFile == "" {
		return nil
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	output := resultOutput{
		JobID:           res.JobID,
		Status:          res.Status,
		Total:           res.Total,
		Success:         res.Success,
		Failed:          res.Failed,
		StartTime:       res.StartTime.Format(time.RFC3339),
		EndTime:         res.EndTime.Format(time.RFC3339),
		DurationSeconds: res.Duration.Seconds(),
		AverageRate:     res.AverageRate,
		Errors:          res.Errors,
	}

	data, err := json.MarshalIndent(output, "", "  ")
	if err != nil {
		return fmt.Errorf("序列化结果失败: %w", err)
	}

	tempFile := r.resultFile + ".tmp"
	if err := os.WriteFile(tempFile, data, 0644); err != nil {
		return fmt.Errorf("写入结果文件失败: %w", err)
	}
	if err := os.Rename(tempFile, r.resultFile); err != nil {
		_ = os.Remove(tempFile)
		return fmt.Errorf("移动结果文件失败: %w", err)
	}

	// 有错误 → 写 errors.log(失败不影响主返回)
	if len(res.Errors) > 0 && r.errorFile != "" {
		_ = r.saveErrors(res.Errors)
	}

	return nil
}

// saveErrors 写 errors.log(v1 语义:os.Create 覆盖写,不 append)
//
// 【契约】v2 与 v1 reporter.saveErrors 完全一致(Q7 决策保 v1 简单版)
func (r *FileReporter) saveErrors(errors []ErrorInfo) error {
	f, err := os.Create(r.errorFile)
	if err != nil {
		return err
	}
	defer f.Close()

	for _, e := range errors {
		if _, err := fmt.Fprintf(f, "Line %d: %s - %s\n", e.Line, e.Email, e.Error); err != nil {
			return err
		}
	}
	return nil
}
