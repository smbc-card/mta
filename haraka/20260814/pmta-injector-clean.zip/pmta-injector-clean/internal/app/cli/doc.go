// Package cli 命令行接口(cobra 封装)
//
// 【Week 6 状态】骨架保留,**Week 7 可能与 cmd/ 合并或替代**
//
// 【当前】cmd/ 已实现 4 命令(root / send / validate / serve),Week 6 不必重复
//
// 【未来重构方向】(不属于 Week 6):
//   - 若需要更多 CLI 逻辑(帮助文档 / 子命令树扩展)→ 迁移到本包
//   - cmd/ 保留薄壳:main → cli.Execute()
package cli
