package bootstrap

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/config"
)

// ============================================================================
// ensurePickupDirs D-015
// ============================================================================

func TestEnsurePickupDirs_Empty_NoOp(t *testing.T) {
	cfg := &config.Config{}
	if err := ensurePickupDirs(cfg); err != nil {
		t.Errorf("空 PickupDir 应 no-op,got err=%v", err)
	}
}

func TestEnsurePickupDirs_CreatesBoth(t *testing.T) {
	tmp := t.TempDir()
	cfg := &config.Config{}
	cfg.PMTA.PickupDir = filepath.Join(tmp, "pickup", "sub")
	cfg.PMTA.TempDir = filepath.Join(tmp, "temp", "sub2")

	if err := ensurePickupDirs(cfg); err != nil {
		t.Fatalf("ensurePickupDirs: %v", err)
	}
	if info, err := os.Stat(cfg.PMTA.PickupDir); err != nil || !info.IsDir() {
		t.Errorf("PickupDir 未创建")
	}
	if info, err := os.Stat(cfg.PMTA.TempDir); err != nil || !info.IsDir() {
		t.Errorf("TempDir 未创建")
	}
}

func TestEnsurePickupDirs_Idempotent(t *testing.T) {
	tmp := t.TempDir()
	cfg := &config.Config{}
	cfg.PMTA.PickupDir = tmp
	cfg.PMTA.TempDir = tmp

	// 两次不应 err
	if err := ensurePickupDirs(cfg); err != nil {
		t.Fatalf("首次: %v", err)
	}
	if err := ensurePickupDirs(cfg); err != nil {
		t.Fatalf("重复: %v", err)
	}
}

func TestEnsurePickupDirs_TempDirEqualsPickup_SingleMkdir(t *testing.T) {
	tmp := t.TempDir()
	cfg := &config.Config{}
	cfg.PMTA.PickupDir = filepath.Join(tmp, "pickup")
	cfg.PMTA.TempDir = filepath.Join(tmp, "pickup") // 同路径

	if err := ensurePickupDirs(cfg); err != nil {
		t.Fatalf("ensurePickupDirs: %v", err)
	}
	if _, err := os.Stat(cfg.PMTA.PickupDir); err != nil {
		t.Errorf("PickupDir 未创建")
	}
}

func TestEnsurePickupDirs_TempDirEmpty_OnlyPickup(t *testing.T) {
	tmp := t.TempDir()
	cfg := &config.Config{}
	cfg.PMTA.PickupDir = filepath.Join(tmp, "pickup")
	// TempDir 留空

	if err := ensurePickupDirs(cfg); err != nil {
		t.Fatalf("ensurePickupDirs: %v", err)
	}
	if _, err := os.Stat(cfg.PMTA.PickupDir); err != nil {
		t.Errorf("PickupDir 未创建")
	}
}

// ============================================================================
// loadAttachments D-012
// ============================================================================

func TestLoadAttachments_DisabledOrEmpty(t *testing.T) {
	// Enabled=false
	cfg := &config.Config{}
	cfg.Attachments.Enabled = false
	cfg.Attachments.Files = []string{"any.txt"} // 即使有文件也不加载

	got, err := loadAttachments(cfg)
	if err != nil {
		t.Errorf("Enabled=false 应 nil, got err=%v", err)
	}
	if got != nil {
		t.Errorf("应返回 nil, got %d items", len(got))
	}

	// Enabled=true 但 Files 空
	cfg.Attachments.Enabled = true
	cfg.Attachments.Files = nil
	got, _ = loadAttachments(cfg)
	if got != nil {
		t.Error("空 Files 应返回 nil")
	}
}

func TestLoadAttachments_SingleFile(t *testing.T) {
	tmp := t.TempDir()
	path := filepath.Join(tmp, "test.pdf")
	if err := os.WriteFile(path, []byte("PDF-CONTENT"), 0o644); err != nil {
		t.Fatal(err)
	}

	cfg := &config.Config{}
	cfg.Attachments.Enabled = true
	cfg.Attachments.Files = []string{path}

	got, err := loadAttachments(cfg)
	if err != nil {
		t.Fatalf("loadAttachments: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("应 1 个附件, got %d", len(got))
	}
	if got[0].FileName != "test.pdf" {
		t.Errorf("FileName=%q", got[0].FileName)
	}
	if got[0].MIMEType != "application/pdf" {
		t.Errorf("MIMEType=%q, want=application/pdf", got[0].MIMEType)
	}
	if string(got[0].Data) != "PDF-CONTENT" {
		t.Errorf("Data=%q", got[0].Data)
	}
	if got[0].ContentID != "" || got[0].IsInline {
		t.Error("普通附件不应有 ContentID / IsInline")
	}
}

func TestLoadAttachments_MissingFile_Err(t *testing.T) {
	cfg := &config.Config{}
	cfg.Attachments.Enabled = true
	cfg.Attachments.Files = []string{"/nonexistent/file.txt"}

	_, err := loadAttachments(cfg)
	if err == nil {
		t.Error("不存在文件应 err")
	}
	if !strings.Contains(err.Error(), "read attachment") {
		t.Errorf("err 应含 'read attachment', got: %v", err)
	}
}

func TestLoadAttachments_SkipsEmptyPath(t *testing.T) {
	tmp := t.TempDir()
	path := filepath.Join(tmp, "a.txt")
	_ = os.WriteFile(path, []byte("x"), 0o644)

	cfg := &config.Config{}
	cfg.Attachments.Enabled = true
	cfg.Attachments.Files = []string{"", path, ""}

	got, err := loadAttachments(cfg)
	if err != nil {
		t.Fatalf("loadAttachments: %v", err)
	}
	if len(got) != 1 {
		t.Errorf("应过滤空路径, got %d", len(got))
	}
}

// ============================================================================
// loadEmbeddedImages D-013
// ============================================================================

func TestLoadEmbeddedImages_Empty(t *testing.T) {
	cfg := &config.Config{}
	got, err := loadEmbeddedImages(cfg)
	if err != nil {
		t.Errorf("空 list 应 nil,got err=%v", err)
	}
	if got != nil {
		t.Error("应返回 nil")
	}
}

func TestLoadEmbeddedImages_Success(t *testing.T) {
	tmp := t.TempDir()
	path := filepath.Join(tmp, "banner.png")
	_ = os.WriteFile(path, []byte{0x89, 0x50, 0x4E, 0x47}, 0o644)

	cfg := &config.Config{}
	cfg.Email.EmbeddedImages = []config.EmbeddedImageConfig{
		{CID: "banner", Path: path, ContentType: "image/png"},
	}

	got, err := loadEmbeddedImages(cfg)
	if err != nil {
		t.Fatalf("loadEmbeddedImages: %v", err)
	}
	if len(got) != 1 {
		t.Fatalf("应 1 个, got %d", len(got))
	}
	if got[0].ContentID != "banner" {
		t.Errorf("ContentID=%q", got[0].ContentID)
	}
	if !got[0].IsInline {
		t.Error("IsInline 应 true")
	}
	if got[0].MIMEType != "image/png" {
		t.Errorf("MIMEType=%q", got[0].MIMEType)
	}
}

func TestLoadEmbeddedImages_SkipsMissingCID(t *testing.T) {
	tmp := t.TempDir()
	path := filepath.Join(tmp, "a.png")
	_ = os.WriteFile(path, []byte("x"), 0o644)

	cfg := &config.Config{}
	cfg.Email.EmbeddedImages = []config.EmbeddedImageConfig{
		{CID: "", Path: path},          // 无 CID 跳过
		{CID: "valid", Path: path},
	}

	got, err := loadEmbeddedImages(cfg)
	if err != nil {
		t.Fatalf("loadEmbeddedImages: %v", err)
	}
	if len(got) != 1 {
		t.Errorf("应过滤无 CID, got %d", len(got))
	}
}

func TestLoadEmbeddedImages_EmptyPath_Err(t *testing.T) {
	cfg := &config.Config{}
	cfg.Email.EmbeddedImages = []config.EmbeddedImageConfig{
		{CID: "x", Path: ""},
	}
	_, err := loadEmbeddedImages(cfg)
	if err == nil {
		t.Error("CID 非空但 Path 空应 err")
	}
}

func TestLoadEmbeddedImages_MissingFile_Err(t *testing.T) {
	cfg := &config.Config{}
	cfg.Email.EmbeddedImages = []config.EmbeddedImageConfig{
		{CID: "x", Path: "/nonexistent/img.png"},
	}
	_, err := loadEmbeddedImages(cfg)
	if err == nil {
		t.Error("不存在文件应 err")
	}
}

func TestLoadEmbeddedImages_MissingContentType_Guessed(t *testing.T) {
	tmp := t.TempDir()
	path := filepath.Join(tmp, "photo.jpg")
	_ = os.WriteFile(path, []byte{0xFF, 0xD8}, 0o644)

	cfg := &config.Config{}
	cfg.Email.EmbeddedImages = []config.EmbeddedImageConfig{
		{CID: "photo", Path: path}, // 无 ContentType
	}
	got, err := loadEmbeddedImages(cfg)
	if err != nil {
		t.Fatalf("loadEmbeddedImages: %v", err)
	}
	if got[0].MIMEType != "image/jpeg" {
		t.Errorf("应从 .jpg 推断为 image/jpeg, got %q", got[0].MIMEType)
	}
}

// ============================================================================
// guessMIMEType
// ============================================================================

func TestGuessMIMEType(t *testing.T) {
	cases := []struct {
		path string
		want string
	}{
		{"a.pdf", "application/pdf"},
		{"a.PDF", "application/pdf"}, // 大小写
		{"a.png", "image/png"},
		{"a.jpg", "image/jpeg"},
		{"a.jpeg", "image/jpeg"},
		{"a.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
		{"a.zip", "application/zip"},
		{"a.unknown", "application/octet-stream"},
		{"noext", "application/octet-stream"},
		{"", "application/octet-stream"},
	}
	for _, c := range cases {
		got := guessMIMEType(c.path)
		if got != c.want {
			t.Errorf("guessMIMEType(%q)=%q want=%q", c.path, got, c.want)
		}
	}
}
