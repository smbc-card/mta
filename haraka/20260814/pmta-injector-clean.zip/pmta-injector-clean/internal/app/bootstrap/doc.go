// Package bootstrap 应用启动 / 主生命周期管理
//
// 【契约】v2 主入口 —— main 只是薄壳,业务全走 bootstrap.Run
//
// 【职责】
//   1. ctx 初始化(context.WithCancel)
//   2. signal handler(SIGINT / SIGTERM → cancel;SIGHUP 预留但忽略 —— Q8 决策)
//   3. STOP 文件轮询(1s ticker → cancel + os.Remove —— §5 契约)
//   4. wire up 12 子包:reader / injector / builder factory / limiter / reporter / dispatcher
//   5. dispatcher.Run(ctx) 阻塞主循环
//   6. rep.SaveResult(result)
//   7. graceful exit
//
// 【依赖】几乎所有 internal 包(顶层协调层)
package bootstrap
