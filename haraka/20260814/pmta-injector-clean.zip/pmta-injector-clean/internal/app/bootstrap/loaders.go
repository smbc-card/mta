package bootstrap

// bootstrap 层的启动预处理辅助:
//   - ensurePickupDirs —— D-015:PickupDir + TempDir 预建(pickup.New 只 stat)
//   - loadAttachments  —— D-012:cfg.Attachments.Files 一次读盘 → []mime.Attachment
//   - loadEmbeddedImages —— D-013:cfg.Email.EmbeddedImages 一次读盘 → []mime.Attachment
//
// 【设计】全部启动阻塞:失败硬阻塞,不到 worker 才发现附件读不到

import (
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/mail/mime"
	"__MODULE_PLACEHOLDER__/internal/security"
)

// ensurePickupDirs D-015:走 pickup 分支前 MkdirAll PickupDir + TempDir
//
// 【幂等】MkdirAll 已存在则 no-op;权限用 0755(v1 一致)
// 【契约】TempDir 空则不建(pickup.New 会 fallback 到 PickupDir)
func ensurePickupDirs(cfg *config.Config) error {
	if cfg.PMTA.PickupDir == "" {
		return nil
	}
	if err := os.MkdirAll(cfg.PMTA.PickupDir, 0o755); err != nil {
		return fmt.Errorf("mkdir pickup_dir %q: %w", cfg.PMTA.PickupDir, err)
	}
	if cfg.PMTA.TempDir != "" && cfg.PMTA.TempDir != cfg.PMTA.PickupDir {
		if err := os.MkdirAll(cfg.PMTA.TempDir, 0o755); err != nil {
			return fmt.Errorf("mkdir temp_dir %q: %w", cfg.PMTA.TempDir, err)
		}
	}
	return nil
}

// loadAttachments D-012:cfg.Attachments.Files 一次读盘
//
// 【行为】
//   - Enabled=false 或 Files 空 → 返回 nil(render 走无附件路径)
//   - 逐文件 os.ReadFile;任一失败 → err(硬阻塞)
//   - MIMEType 从文件扩展名推断(不推断也没关系,mime 层会用 application/octet-stream 兜底)
//
// 【与 v1 差异】v1 Attachments.Mode 支持 "random" / "sequential";v2 首版**全部附件都发**
// (Mode 决策 Week 8+ 补;当前所有附件都注入 —— 与生产实际使用一致,C# UI 一般只配 1-3 个)
func loadAttachments(cfg *config.Config) ([]mime.Attachment, error) {
	if !cfg.Attachments.Enabled || len(cfg.Attachments.Files) == 0 {
		return nil, nil
	}

	out := make([]mime.Attachment, 0, len(cfg.Attachments.Files))
	for _, path := range cfg.Attachments.Files {
		if path == "" {
			continue
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return nil, fmt.Errorf("read attachment %q: %w", path, err)
		}
		out = append(out, mime.Attachment{
			FileName: filepath.Base(path),
			MIMEType: guessMIMEType(path),
			Data:     data,
			// ContentID/IsInline 留空 —— 普通附件走 multipart/mixed
		})
	}
	return out, nil
}

// loadEmbeddedImages D-013:cfg.Email.EmbeddedImages 一次读盘
//
// 【行为】
//   - 空列表 → 返回 nil(render 走无内嵌图路径)
//   - CID 空 → 跳过(内嵌图必须有 CID 才能被 HTML 引用)
//   - Path 空或读盘失败 → err
//   - ContentType 空 → 从扩展名推断
//
// 【契约】ContentID 非空 + IsInline=true → mime 层走 multipart/related 分支
func loadEmbeddedImages(cfg *config.Config) ([]mime.Attachment, error) {
	if len(cfg.Email.EmbeddedImages) == 0 {
		return nil, nil
	}

	out := make([]mime.Attachment, 0, len(cfg.Email.EmbeddedImages))
	for _, img := range cfg.Email.EmbeddedImages {
		if img.CID == "" {
			continue // 无 CID 无法被 HTML 引用
		}
		if img.Path == "" {
			return nil, fmt.Errorf("embedded image cid=%q: path 空", img.CID)
		}
		data, err := os.ReadFile(img.Path)
		if err != nil {
			return nil, fmt.Errorf("read embedded image cid=%q path=%q: %w", img.CID, img.Path, err)
		}
		mimeType := img.ContentType
		if mimeType == "" {
			mimeType = guessMIMEType(img.Path)
		}
		out = append(out, mime.Attachment{
			FileName:  filepath.Base(img.Path),
			MIMEType:  mimeType,
			Data:      data,
			ContentID: img.CID,
			IsInline:  true,
		})
	}
	return out, nil
}

// loadTemplates A3:cfg.Email.TemplatePaths 全部一次读盘为 []string(html contents)
//
// 【行为】
//   - len(TemplatePaths)>0:全部读盘按顺序返回;失败硬阻塞
//   - TemplatePaths 空且 TemplatePath 非空:单值兜底,返回 []string{content}
//   - 都空:返回 []string{subject}(冒烟场景兜底,与 v2 之前行为一致)
//
// 【返回】按 template_mode(random/sequential)per-recipient 挑一个作为 HTMLBody
func loadTemplates(cfg *config.Config, subjectFallback string) ([]string, error) {
	paths := cfg.Email.TemplatePaths
	if len(paths) == 0 && cfg.Email.TemplatePath != "" {
		paths = []string{cfg.Email.TemplatePath}
	}
	if len(paths) == 0 {
		// 【R5(d) 修 2026-08-14】兜底 subject 当 body 是异常路径,不该在生产触发
		slog.Warn("bootstrap.loadTemplates: no template configured, falling back to subject as body (unusual)", "subject_len", len(subjectFallback))
		return []string{subjectFallback}, nil
	}
	out := make([]string, 0, len(paths))
	for _, path := range paths {
		if path == "" {
			continue
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return nil, fmt.Errorf("read template %q: %w", path, err)
		}
		out = append(out, string(data))
	}
	if len(out) == 0 {
		slog.Warn("bootstrap.loadTemplates: all template paths empty/skipped, falling back to subject as body")
		return []string{subjectFallback}, nil
	}
	return out, nil
}

// loadCustomVariables A6:cfg.Variables.CustomVariableFiles 启动时一次读盘
//
// 【行为】
//   - 空 map → 返回 nil({CUSTOM:name} 会返回空串)
//   - 逐 (varName → filePath) 读盘,按 \n 切行,SanitizeLine 剥离 CRLF + 跳空行
//   - 任一文件读失败 → err(硬阻塞;避免 worker 阶段静默降级)
//
// 【返回】map[varName][]string:{CUSTOM:name} 随机抽 / {CUSTOM:name:seq} 顺序抽 / {CUSTOM:name:random} 显式随机
//
// 【与 v1 差异】v1 里 CustomVariableFiles 由 email/variables.go 每封邮件按需读盘(有 mtime cache);
// v2 启动时一次读盘缓存到 map,避免 hot path IO。
func loadCustomVariables(cfg *config.Config) (map[string][]string, error) {
	if len(cfg.Variables.CustomVariableFiles) == 0 {
		return nil, nil
	}

	out := make(map[string][]string, len(cfg.Variables.CustomVariableFiles))
	for varName, path := range cfg.Variables.CustomVariableFiles {
		if varName == "" || path == "" {
			continue
		}
		// 【R3 修 2026-08-14】key 必须 lowercase —— basic/custom.go:41 查找端 ToLower;
		// v1 email/variables.go:120 存/查两端都 lower。之前 v2 只查端 lower → config key 带大写
		// (URL / Colors / FirstName)时 100% miss 返回空串
		key := strings.ToLower(varName)
		raw, err := os.ReadFile(path)
		if err != nil {
			return nil, fmt.Errorf("read custom variable %q from %q: %w", varName, path, err)
		}
		lines := make([]string, 0, 128)
		for _, line := range strings.Split(string(raw), "\n") {
			// 【R5(b) 修 2026-08-14】用 SanitizeLine 与 docstring 一致;剥离行末 \r 之外
			// 还剥离行内嵌 \r(旧式 Mac 换行 / 恶意投毒),防绕过下游 sanitize 到达 body
			line = security.SanitizeLine(line)
			if line == "" {
				continue
			}
			lines = append(lines, line)
		}
		if len(lines) > 0 {
			out[key] = lines
		}
	}
	if len(out) == 0 {
		return nil, nil
	}
	return out, nil
}

// guessMIMEType 从扩展名推断 MIME 类型
//
// 【简化】只列常见类型;未知走 application/octet-stream
// 【与 v1 差异】v1 用 mime.TypeByExtension(依赖 stdlib mime 包);v2 硬编码常见类型避免额外 import
func guessMIMEType(path string) string {
	ext := strings.ToLower(filepath.Ext(path))
	switch ext {
	case ".txt":
		return "text/plain"
	case ".html", ".htm":
		return "text/html"
	case ".pdf":
		return "application/pdf"
	case ".doc":
		return "application/msword"
	case ".docx":
		return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
	case ".xls":
		return "application/vnd.ms-excel"
	case ".xlsx":
		return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
	case ".png":
		return "image/png"
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".gif":
		return "image/gif"
	case ".svg":
		return "image/svg+xml"
	case ".webp":
		return "image/webp"
	case ".zip":
		return "application/zip"
	case ".json":
		return "application/json"
	case ".xml":
		return "application/xml"
	default:
		return "application/octet-stream"
	}
}
