package bootstrap

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/inject"
	"__MODULE_PLACEHOLDER__/internal/inject/pickup"
	"__MODULE_PLACEHOLDER__/internal/inject/smtp"
	"__MODULE_PLACEHOLDER__/internal/mail/mime"
	"__MODULE_PLACEHOLDER__/internal/mail/render"
	"__MODULE_PLACEHOLDER__/internal/pipeline/dispatcher"
	"__MODULE_PLACEHOLDER__/internal/pipeline/ratelimit"
	"__MODULE_PLACEHOLDER__/internal/pipeline/reporter"
	"__MODULE_PLACEHOLDER__/internal/random"
	"__MODULE_PLACEHOLDER__/internal/recipient/reader"
)

// RunOptions 启动选项(cmd/send.go 传入的 flags)
//
// 【设计】用 struct 而非多参数 —— 未来加字段不破坏调用
type RunOptions struct {
	Quiet   bool
	Verbose bool
	DryRun  bool // 命令行覆盖 cfg.DryRun
	JobID   string // 命令行 --job-id 覆盖 cfg.Job.ID
}

// Run 应用主生命周期(v1 cmd/send.go::runSend 的 v2 等价)
//
// 【流程】
//  1. flags override cfg
//  2. 生成 Job.ID
//  3. 建 reader / injector / limiter / reporter / factory / dispatcher
//  4. ctx + signal + STOP watcher(§5+§6 契约)
//  5. dispatcher.Run(ctx) 阻塞
//  6. reporter.SaveResult
//  7. Close 释放资源
//
// 【返回】
//   - (*Result, nil):正常完成或优雅退出
//   - (*Result, err):严重故障
func Run(cfg *config.Config, opts RunOptions) (*reporter.Result, error) {
	// 【1】opts override cfg
	if opts.DryRun {
		cfg.DryRun = true
	}
	if opts.JobID != "" {
		cfg.Job.ID = opts.JobID
	}

	// 【2】JobID 兜底
	if cfg.Job.ID == "" {
		cfg.Job.ID = fmt.Sprintf("%s-%s", cfg.Job.IDPrefix, time.Now().Format("20060102-150405"))
	}

	// 【3】clock(系统时钟)
	clk := clock.NewSystemClock()

	// 【4】reader
	rdr, err := reader.New(cfg.Recipients.FilePath, reader.Options{
		Format:          cfg.Recipients.Format,
		CSVDelimiter:    cfg.Recipients.CSV.Delimiter,
		CSVHasHeader:    cfg.Recipients.CSV.HasHeader,
		CSVFieldMapping: cfg.Recipients.CSV.FieldMapping,
	})
	if err != nil {
		return nil, fmt.Errorf("bootstrap: create reader: %w", err)
	}
	defer rdr.Close()

	// 【5】injector 4 分支路由(避免 inject 顶层循环 import,在 bootstrap 层 switch)
	//   1. DryRun=true → disabled(**修 v1 P12 bug**:v1 dry-run 也创 SMTP 连接池)
	//   2. SMTP.Enabled=true → smtp.New
	//   3. PMTA.PickupDir!="" → pickup.New
	//   4. 兜底 → disabled
	//
	// 【D-015】走 pickup 分支前预建 PickupDir + TempDir(pickup.New 只 stat 存在性,不 MkdirAll)
	var inj inject.Injector
	switch {
	case cfg.DryRun:
		inj, _ = inject.New(cfg, clk) // 返回 disabled sentinel
	case cfg.SMTP.Enabled:
		var sErr error
		inj, sErr = smtp.New(cfg)
		if sErr != nil {
			return nil, fmt.Errorf("bootstrap: smtp.New: %w", sErr)
		}
	case cfg.PMTA.PickupDir != "":
		// 【D-015】pickup 目录预建(幂等)
		if err := ensurePickupDirs(cfg); err != nil {
			return nil, fmt.Errorf("bootstrap: ensure pickup dirs: %w", err)
		}
		var pErr error
		inj, pErr = pickup.New(cfg, clk)
		if pErr != nil {
			return nil, fmt.Errorf("bootstrap: pickup.New: %w", pErr)
		}
	default:
		inj, _ = inject.New(cfg, clk) // 都不满足也 disabled
	}
	defer inj.Close()

	// 【6】rate limiter
	limiter := ratelimit.New(float64(cfg.Performance.RateLimit))

	// 【7】reporter
	rep := reporter.NewFileReporter(
		cfg.Output.ProgressFile,
		cfg.Output.ResultFile,
		cfg.Output.ErrorFile,
	)

	// 【8】render 模板加载(bootstrap 层做 —— 一次读盘,全 worker 共享只读内容)
	// 【A2/A3】subjects/templates 池化:优先 Subjects/TemplatePaths;单值向下兼容
	subject := cfg.Email.Subject

	// A2 主题池:优先 Subjects,fallback 到单值 Subject
	subjects := cfg.Email.Subjects
	if len(subjects) == 0 && subject != "" {
		subjects = []string{subject}
	}
	if len(subjects) == 0 {
		subjects = []string{""} // 兜底空 subject(与之前行为一致)
	}

	// A3 模板池:优先 TemplatePaths,fallback 到单值 TemplatePath,再 fallback 到 subject
	htmlBodies, err := loadTemplates(cfg, subject)
	if err != nil {
		return nil, fmt.Errorf("bootstrap: load templates: %w", err)
	}

	// 【D-012】附件预读盘(启动时一次读全部;失败硬阻塞,不到 worker 才发现)
	attachments, err := loadAttachments(cfg)
	if err != nil {
		return nil, fmt.Errorf("bootstrap: load attachments: %w", err)
	}

	// 【D-013】内嵌图预读盘(同 D-012;CID + IsInline=true)
	embeddedImgs, err := loadEmbeddedImages(cfg)
	if err != nil {
		return nil, fmt.Errorf("bootstrap: load embedded images: %w", err)
	}

	// 【A6 修复 2026-08-13】自定义变量池预读盘(cfg.Variables.CustomVariableFiles)
	// {CUSTOM:name} / {CUSTOM:name:seq} / {CUSTOM:name:random} 需要;不加载会永远返回空串
	customVars, err := loadCustomVariables(cfg)
	if err != nil {
		return nil, fmt.Errorf("bootstrap: load custom variables: %w", err)
	}

	// 【9】BuilderFactory(每 worker 独立 render.Builder + 独立 rng seed)
	// 【D22-4】cache=nil(所有附件已 pre-load,不需要 SHA256 cache)
	factory := func(workerID int) dispatcher.RenderBuilder {
		// 【B1 修复】per-worker rng 用 NewWorkerSource(workerID):crypto/rand seed XOR workerID*prime
		// —— 消除 v1 v62 修过的"同纳秒多 worker seed 碰撞导致随机序列相同"bug
		rng := random.NewWorkerSource(workerID)
		builder := render.New(cfg, rng, clk, nil, customVars)
		// A1 显示名池 / A4 自定义 From 池(空则 render.Build 走 cfg.Sender 默认)
		// 【R5(a) 修 2026-08-14】各池启动时过滤空串条目 —— 避免 pickPoolOne 挑到空串
		// 后 render.Recipient.DisplayName/FromAddress/... 被判 "" → 静默回退 cfg 默认。
		// 与 v1 行为的区别:v1 允许 pool 里出现空条目直通输出(某些反指纹用例故意),
		// v2 选择过滤以匹配 fallback 语义;C# UI 场景下几乎不会配空条目,风险低
		var customFroms []string
		if cfg.Headers.CustomFromEnabled {
			customFroms = filterEmpty(cfg.Headers.CustomFromEmails)
		}
		return &renderAdapter{
			builder:      builder,
			attachments:  attachments,
			embeddedImgs: embeddedImgs,
			// A5:附件轮转状态(per-worker;rng 与 builder 同源)
			attachMode: cfg.Attachments.Mode,
			attachRng:  rng,
			// A1..A4:4 池 + mode + per-worker seqIdx
			subjects:        filterEmpty(subjects),
			subjectMode:     cfg.Email.SubjectMode,
			htmlBodies:      htmlBodies, // 模板 body 允许空(loadTemplates 已保证非空)
			templateMode:    cfg.Email.TemplateMode,
			displayNames:    filterEmpty(cfg.Sender.DisplayNames),
			displayNameMode: cfg.Sender.DisplayNameMode,
			customFroms:     customFroms,
			customFromMode:  cfg.Headers.CustomFromMode,
		}
	}

	// 【10】dispatcher
	d := dispatcher.New(cfg, rdr, inj, factory, limiter, rep)

	// 【11】ctx + signal + STOP watcher
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// signal handler(SIGINT/SIGTERM → cancel;SIGHUP 忽略 —— Q8 决策)
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	defer signal.Stop(sigCh)
	go func() {
		select {
		case <-sigCh:
			cancel()
		case <-ctx.Done():
		}
	}()

	// STOP 文件轮询(§5 契约)—— 只在 progressFile 目录下监视
	if cfg.Output.ProgressFile != "" {
		stopFile := filepath.Join(filepath.Dir(cfg.Output.ProgressFile), "STOP")
		go watchStopFile(ctx, stopFile, cancel)
	}

	// 【12】dispatcher.Run(阻塞主循环)
	res, runErr := d.Run(ctx)

	// 【13】reporter.SaveResult(即使 runErr 也要保存)
	if res != nil {
		_ = rep.SaveResult(*res)
	}

	if runErr != nil {
		return res, runErr
	}
	return res, nil
}

// watchStopFile §5 契约:1s ticker 检查 STOP 文件;发现即 cancel + 消费(os.Remove)
func watchStopFile(ctx context.Context, stopFile string, cancel context.CancelFunc) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			if _, err := os.Stat(stopFile); err == nil {
				cancel()
				_ = os.Remove(stopFile) // §5 消费语义
				return
			}
		}
	}
}

// ============================================================================
// renderAdapter:桥接 dispatcher.RenderBuilder → render.Builder
// ============================================================================

// renderAdapter 把 dispatcher.BuildRequest 转成 render.Recipient,再调 render.Builder
//
// 【设计】dispatcher 不 import render(避免循环);bootstrap 层做桥接
//
// 【subject/htmlBody/attachments/embeddedImgs 共享】per-worker adapter 持有同一份只读内容
// (bootstrap 启动时一次读盘)
//
// 【A5 修复 2026-08-13】按 cfg.Attachments.Mode 每封挑 1 个附件(v1 行为):
//   - "random" → per-worker rng 随机抽 1
//   - 其他(含 "sequential") → seqIdx++ 轮转
// per-worker 状态天然无 race(每 worker 独占 adapter 实例;factory 每次调用产 new)
type renderAdapter struct {
	builder      *render.Builder
	attachments  []mime.Attachment // D-012 预读盘(全池)
	embeddedImgs []mime.Attachment // D-013 预读盘(全部内嵌图)

	// A5:附件选择状态(per-worker,无并发)
	attachMode string
	attachRng  random.Source
	attachSeq  int

	// A1..A4:4 池 + mode + per-worker seqIdx(每 worker 独立实例,无 race)
	subjects        []string
	subjectMode     string
	subjectSeq      int
	htmlBodies      []string
	templateMode    string
	templateSeq     int
	displayNames    []string
	displayNameMode string
	displayNameSeq  int
	customFroms     []string
	customFromMode  string
	customFromSeq   int
}

// pickPoolOne A1..A4 通用:根据 mode 从 pool 挑 1 个;empty pool 返回 ""
//
// 【R2 修 2026-08-14】v1 各池 mode 默认方向不同 —— 必须区分:
//   - subject/template/displayName(v1 email/variables.go:626/642/658):
//     `if Mode=="sequential" seq else random` → 默认 random,用 defaultRandom=true 调
//   - customFrom(v1 email/builder.go:247):
//     `if Mode=="random" random else seq` → 默认 seq,用 defaultRandom=false 调
//   - attachments(v1 email/builder.go:1007):同 customFrom,由 pickAttachments 自己处理
//
// 【行为】
//   - len==0 → ""(caller 使用默认值)
//   - len==1 → 单值(mode 不生效)
//   - len>=2 + 匹配 mode → 对应分支
//   - len>=2 + mode 空/typo → defaultRandom 决定 random 或 sequential(与 v1 一致)
func (a *renderAdapter) pickPoolOne(pool []string, mode string, seq *int, defaultRandom bool) string {
	n := len(pool)
	if n == 0 {
		return ""
	}
	if n == 1 {
		return pool[0]
	}
	// 显式匹配优先
	if strings.EqualFold(mode, "random") {
		if a.attachRng != nil {
			return pool[a.attachRng.Intn(n)]
		}
		// rng 缺失兜底走 seq
	} else if strings.EqualFold(mode, "sequential") {
		idx := *seq % n
		*seq++
		return pool[idx]
	}
	// 空 mode 或 typo → 走 default 方向(与 v1 各字段的 fallback 一致)
	if defaultRandom && a.attachRng != nil {
		return pool[a.attachRng.Intn(n)]
	}
	idx := *seq % n
	*seq++
	return pool[idx]
}

// pickAttachments A5:根据 cfg.Attachments.Mode 从 pre-load 池挑 1 个;≤1 时原样返回
//
// 【契约】v1 email/builder.go::getAttachments 语义:每封邮件只挂 1 个(非全部);
//   - 0 附件:nil
//   - 1 附件:返回该 1(mode 不生效)
//   - N 附件 + mode="random":per-worker rng 抽 1
//   - N 附件 + 其他(含 "sequential"/""):seqIdx++ % N
func (a *renderAdapter) pickAttachments() []mime.Attachment {
	n := len(a.attachments)
	if n == 0 {
		return nil
	}
	if n == 1 {
		return a.attachments
	}
	var idx int
	if strings.EqualFold(a.attachMode, "random") && a.attachRng != nil {
		idx = a.attachRng.Intn(n)
	} else {
		idx = a.attachSeq % n
		a.attachSeq++
	}
	return a.attachments[idx : idx+1]
}

// Build 实现 dispatcher.RenderBuilder
//
// 【D-011】PMTA 控制头由 render.Build 从 cfg.PMTA.VirtualMTA + cfg.Job.ID 取(recipient 字段为空时兜底)
// 【D-014】req.CcHeaderList 透传给 render.Recipient.CcHeaderList
// 【A5】attachments 每封按 mode 挑 1(不再全挂)
func (a *renderAdapter) Build(req dispatcher.BuildRequest) (dispatcher.RenderedEmail, error) {
	// A1..A4:每封 per-worker 池化挑选;空池 → 空串 → render.Build 走 cfg 默认
	rcpt := &render.Recipient{
		Email:        req.TargetEmail,
		Name:         req.Recipient.Name,
		FirstName:    req.Recipient.FirstName,
		LastName:     req.Recipient.LastName,
		CustomFields: req.Recipient.CustomFields,
		// A1/A2/A3 默认 random(v1 GetNextSubject/Template/DisplayName);A4 默认 seq(v1 CustomFrom)
		Subject:      a.pickPoolOne(a.subjects, a.subjectMode, &a.subjectSeq, true),           // A2
		HTMLBody:     a.pickPoolOne(a.htmlBodies, a.templateMode, &a.templateSeq, true),       // A3
		DisplayName:  a.pickPoolOne(a.displayNames, a.displayNameMode, &a.displayNameSeq, true), // A1
		FromAddress:  a.pickPoolOne(a.customFroms, a.customFromMode, &a.customFromSeq, false),   // A4
		CcHeaderList: req.CcHeaderList,     // D-014
		Attachments:  a.pickAttachments(),  // A5:每封挑 1
		EmbeddedImgs: a.embeddedImgs,       // D-013(内嵌图与附件语义不同,全传)
		// VirtualMTA / JobID 留空 → render.Build 从 cfg 取(D-011)
	}

	email, err := a.builder.Build(rcpt)
	if err != nil {
		return nil, err
	}
	return &renderEmailAdapter{e: email}, nil
}

// ============================================================================
// renderEmailAdapter:桥接 render.Email → inject.Email 接口
// ============================================================================

// renderEmailAdapter 把 render.Email struct 桥接到 inject.Email interface
//
// 【为什么需要】render.Email 字段名 EnvelopeFrom/EnvelopeTo 与 inject.Email interface
// 方法名冲突(Go 语法禁止字段和方法同名)—— 用 adapter 包一层解决
type renderEmailAdapter struct {
	e *render.Email
}

func (a *renderEmailAdapter) Raw() string          { return a.e.RawContent }
func (a *renderEmailAdapter) EnvelopeFrom() string { return a.e.EnvelopeFrom }
func (a *renderEmailAdapter) EnvelopeTo() string   { return a.e.EnvelopeTo }

// filterEmpty 过滤 slice 里的空串/纯 whitespace 条目
//
// 【用途】R5(a) 各池启动时过滤,避免 pickPoolOne 挑到空条目触发 fallback 到 cfg 默认
// 【返回】新 slice(不修改原 slice)
func filterEmpty(in []string) []string {
	if len(in) == 0 {
		return in
	}
	out := make([]string, 0, len(in))
	for _, s := range in {
		if strings.TrimSpace(s) != "" {
			out = append(out, s)
		}
	}
	return out
}

// ============================================================================
// 未使用 import 消除
// ============================================================================
var _ = mime.NewSyncMapCache // 仅为保 import(未来 cache 启用时用)
var _ = strings.TrimSpace    // 仅为保 import
