package bootstrap

// R2/R3 回归测试(2026-08-14):
// - R2: pickPoolOne mode 默认方向 —— subject/template/displayName 默认 random,customFrom 默认 seq
// - R3: loadCustomVariables 存储端必须 lowercase key

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// mkAdapter 建一个最小 renderAdapter 用于 pickPoolOne 单测
func mkAdapter(seed int64) *renderAdapter {
	return &renderAdapter{
		attachRng: random.NewFixedSource(seed),
	}
}

// TestR2_PickPoolOne_ModeSequential_ExplicitAlwaysSeq —— 显式 "sequential" 走 seq 无论 default
func TestR2_PickPoolOne_ModeSequential_ExplicitAlwaysSeq(t *testing.T) {
	pool := []string{"A", "B", "C"}
	for _, defaultRandom := range []bool{true, false} {
		a := mkAdapter(42)
		seq := 0
		got := []string{
			a.pickPoolOne(pool, "sequential", &seq, defaultRandom),
			a.pickPoolOne(pool, "sequential", &seq, defaultRandom),
			a.pickPoolOne(pool, "sequential", &seq, defaultRandom),
			a.pickPoolOne(pool, "sequential", &seq, defaultRandom),
		}
		want := []string{"A", "B", "C", "A"}
		for i, v := range want {
			if got[i] != v {
				t.Errorf("defaultRandom=%v i=%d: got=%q want=%q(seq=%v)", defaultRandom, i, got[i], v, got)
			}
		}
	}
}

// TestR2_PickPoolOne_ModeRandom_ExplicitAlwaysRandom —— 显式 "random" 走 random 无论 default
func TestR2_PickPoolOne_ModeRandom_ExplicitAlwaysRandom(t *testing.T) {
	pool := []string{"A", "B", "C"}
	for _, defaultRandom := range []bool{true, false} {
		a := mkAdapter(42)
		seq := 0
		// FixedSource(42) 决定序列;调 3 次不应递增 seq
		_ = a.pickPoolOne(pool, "random", &seq, defaultRandom)
		_ = a.pickPoolOne(pool, "random", &seq, defaultRandom)
		_ = a.pickPoolOne(pool, "random", &seq, defaultRandom)
		if seq != 0 {
			t.Errorf("defaultRandom=%v: random mode should not increment seq, got seq=%d", defaultRandom, seq)
		}
	}
}

// TestR2_PickPoolOne_EmptyMode_DefaultDirection —— 空 mode(subject/template/displayName v1 默认 random)
func TestR2_PickPoolOne_EmptyMode_DefaultRandom_NoSeqBump(t *testing.T) {
	pool := []string{"A", "B", "C"}
	a := mkAdapter(42)
	seq := 0
	_ = a.pickPoolOne(pool, "", &seq, true) // defaultRandom=true → 走 random
	_ = a.pickPoolOne(pool, "", &seq, true)
	if seq != 0 {
		t.Errorf("defaultRandom=true + empty mode: 应走 random,seq 应保持 0, got seq=%d", seq)
	}
}

// TestR2_PickPoolOne_EmptyMode_DefaultSeq_BumpsSeq —— 空 mode + defaultRandom=false(customFrom v1 默认 seq)
func TestR2_PickPoolOne_EmptyMode_DefaultSeq_BumpsSeq(t *testing.T) {
	pool := []string{"A", "B", "C"}
	a := mkAdapter(42)
	seq := 0
	got1 := a.pickPoolOne(pool, "", &seq, false)
	got2 := a.pickPoolOne(pool, "", &seq, false)
	got3 := a.pickPoolOne(pool, "", &seq, false)
	if got1 != "A" || got2 != "B" || got3 != "C" {
		t.Errorf("defaultRandom=false + empty mode: 应走 seq, got=%v,%v,%v", got1, got2, got3)
	}
	if seq != 3 {
		t.Errorf("expect seq=3, got %d", seq)
	}
}

// TestR2_PickPoolOne_EmptyPool_ReturnsBlank —— len==0 返回 ""
func TestR2_PickPoolOne_EmptyPool_ReturnsBlank(t *testing.T) {
	a := mkAdapter(42)
	seq := 0
	if got := a.pickPoolOne(nil, "random", &seq, true); got != "" {
		t.Errorf("empty pool should return empty, got %q", got)
	}
	if got := a.pickPoolOne([]string{}, "sequential", &seq, false); got != "" {
		t.Errorf("empty pool should return empty, got %q", got)
	}
}

// TestR2_PickPoolOne_SinglePool_NoBump —— len==1 不消耗 seq
func TestR2_PickPoolOne_SinglePool_NoBump(t *testing.T) {
	a := mkAdapter(42)
	seq := 5
	got := a.pickPoolOne([]string{"only"}, "random", &seq, true)
	if got != "only" {
		t.Errorf("got %q", got)
	}
	if seq != 5 {
		t.Errorf("single-element pool should not bump seq, got seq=%d", seq)
	}
}

// TestR2_PickPoolOne_TypoMode_FallsBackToDefault —— 未识别 mode(typo/mixed case)走 default
func TestR2_PickPoolOne_TypoMode_FallsBackToDefault(t *testing.T) {
	pool := []string{"A", "B", "C"}
	// default random 场景:typo mode → random(v1 subject/template/displayName 行为)
	a := mkAdapter(42)
	seq := 0
	_ = a.pickPoolOne(pool, "rand", &seq, true)
	_ = a.pickPoolOne(pool, "Sequential", &seq, true) // EqualFold match "sequential"!
	// "Sequential" 会命中 EqualFold("sequential"),消耗 seq
	if seq != 1 {
		t.Errorf(`"Sequential" EqualFold match should bump seq once, got seq=%d`, seq)
	}
	// typo "rand" 走 default(random),不消耗 seq
	// (第 1 次调用 seq=0,rand → 走 default;seq 仍应为 0 后来被 Sequential 加到 1)
}

// ============================================================================
// R3: loadCustomVariables lowercase 存储 key
// ============================================================================

func TestR3_LoadCustomVariables_LowercaseKey(t *testing.T) {
	tmp := t.TempDir()
	// 建 3 个变量文件,配置 key 用不同大小写
	files := map[string][]string{
		"URLS":    {"https://a.com", "https://b.com"},
		"Colors":  {"red", "green", "blue"},
		"product": {"apple", "banana"},
	}
	for name, lines := range files {
		p := filepath.Join(tmp, name+".txt")
		if err := os.WriteFile(p, []byte(strings.Join(lines, "\n")), 0644); err != nil {
			t.Fatal(err)
		}
	}

	cfg := &config.Config{
		Variables: config.VariablesConfig{
			CustomVariableFiles: map[string]string{
				"URLS":    filepath.Join(tmp, "URLS.txt"),
				"Colors":  filepath.Join(tmp, "Colors.txt"),
				"product": filepath.Join(tmp, "product.txt"),
			},
		},
	}
	out, err := loadCustomVariables(cfg)
	if err != nil {
		t.Fatalf("loadCustomVariables: %v", err)
	}

	// 期望:所有 key 存进去都是 lowercase(与 basic/custom.go:41 查找端一致)
	for _, want := range []string{"urls", "colors", "product"} {
		if _, ok := out[want]; !ok {
			t.Errorf("expect lowercase key %q in map, got keys=%v", want, mapKeys(out))
		}
	}
	// 反向断言:大写 key 不应出现
	for _, notWant := range []string{"URLS", "Colors"} {
		if _, ok := out[notWant]; ok {
			t.Errorf("uppercase key %q should NOT be in map (indicates lowercase 未落实)", notWant)
		}
	}
	// 内容正确
	if urls := out["urls"]; len(urls) != 2 || urls[0] != "https://a.com" {
		t.Errorf("urls content wrong: %v", urls)
	}
}

// TestR3_LoadCustomVariables_SanitizeLineDropsCRLF —— R5(b) 顺带:SanitizeLine 剥离行内 \r
func TestR3_LoadCustomVariables_SanitizeLineDropsCRLF(t *testing.T) {
	tmp := t.TempDir()
	// 文件含旧式 Mac 混合(\r 单独作分隔 + \r\n)
	p := filepath.Join(tmp, "poison.txt")
	// 写入:"line1\rEMBED\r\nline2\n" —— 若只按 \n 分割 + TrimRight("\r"):
	//   part0 = "line1\rEMBED\r" → TrimRight → "line1\rEMBED"(内嵌 \r 残留)
	//   part1 = "line2"
	// 若走 SanitizeLine:内嵌 \r → 空格 → "line1 EMBED"
	if err := os.WriteFile(p, []byte("line1\rEMBED\r\nline2\n"), 0644); err != nil {
		t.Fatal(err)
	}
	cfg := &config.Config{
		Variables: config.VariablesConfig{
			CustomVariableFiles: map[string]string{"poison": p},
		},
	}
	out, err := loadCustomVariables(cfg)
	if err != nil {
		t.Fatal(err)
	}
	poison := out["poison"]
	for i, line := range poison {
		if strings.ContainsAny(line, "\r\n") {
			t.Errorf("line[%d]=%q 仍含 CR/LF,SanitizeLine 未生效", i, line)
		}
	}
}

func mapKeys(m map[string][]string) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}
