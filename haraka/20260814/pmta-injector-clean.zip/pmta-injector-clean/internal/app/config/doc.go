// Package config【骨架保留】—— 与 internal/config 目录**同名**,可能重复
//
// 【Week 6 状态】不实现;Week 7+ 决定命运
//
// 【推测意图】Day 1 骨架期可能预留给"应用级配置加载 orchestrator"(区别于 internal/config 的 pure struct)
// —— 但 internal/config 里 load.go 已含此逻辑
//
// 【决议】保留骨架 doc.go 声明包存在(避免 go build 空目录警告);Week 7 review 时决定合并或删
package config
