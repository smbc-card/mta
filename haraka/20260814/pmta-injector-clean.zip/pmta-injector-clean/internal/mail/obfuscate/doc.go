// Package obfuscate 邮件内容反指纹混淆(文本零宽 / BiDi 反转 / 图像噪声)
//
// 【3 类混淆】
//   - 文本零宽注入(InsertZeroWidth):在文本/HTML 中插入 U+200B/200C/200D 等零宽字符
//     视觉上不可见,但改变文本 SHA256/哈希指纹,反垃圾邮件难以模式匹配
//   - BiDi 反转隐藏(BidiReverseHide):用 U+202E RLO / U+202D LRO 逆向重叠字符
//     反指纹但对 ASCII/日文/CJK 场景友好(可选禁用不支持 BiDi 的字符集)
//   - 图像噪声(AddImageNoise):在图片尾部追加随机字节,改变文件 SHA256
//     不影响图片显示(尾部 padding 被解码器忽略),但每邮件的嵌入图各不相同
//
// 【D22-3 修 race 6/6】v1 里所有 3 类混淆都用**包级 math/rand** —— 并发写触发 race。
// v2 全部改为 Noiser struct + 注入 random.Source(per-worker 独立,无锁)。
//
// 【契约】v2 输出格式与 v1 完全一致(混淆算法不变,只改 rng 源)—— 反指纹语义等价。
//
// 【依赖】random.Source 一个 —— 无其他依赖
package obfuscate
