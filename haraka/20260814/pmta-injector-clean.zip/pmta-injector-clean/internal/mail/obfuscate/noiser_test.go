package obfuscate

import (
	"bytes"
	"image"
	"image/color"
	"image/jpeg"
	"image/png"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/random"
)

func newTestNoiser(seed int64) *Noiser {
	return New(random.NewFixedSource(seed))
}

// ============================================================================
// 契约锁
// ============================================================================

func TestZeroWidthCharsCount(t *testing.T) {
	// v1 硬约束 5 个字符
	if got := len(zeroWidthChars); got != 5 {
		t.Fatalf("zeroWidthChars 数量偏离契约:got=%d, want=5", got)
	}
	// 每个字符必须是有效零宽 rune
	wantSet := map[rune]bool{
		0x200B: true, 0x200C: true, 0x200D: true, 0xFEFF: true, 0x2060: true,
	}
	for _, ch := range zeroWidthChars {
		if !wantSet[ch] {
			t.Errorf("非法零宽字符 U+%04X", ch)
		}
	}
}

func TestExcludeCharsBasics(t *testing.T) {
	// 关键排除项必须存在
	must := []rune{'0', '9', '-', '.', ',', ':', '/', ' ', '\n', '\t', '@', '{', '}', '<', '>'}
	for _, ch := range must {
		if !excludeChars[ch] {
			t.Errorf("excludeChars 缺少必需字符 %q", ch)
		}
	}
}

// ============================================================================
// Noiser 构造
// ============================================================================

func TestNoiser_New(t *testing.T) {
	n := New(random.NewFixedSource(42))
	if n == nil {
		t.Fatal("New 返回 nil")
	}
	if n.rng == nil {
		t.Fatal("rng 未初始化")
	}
}

// ============================================================================
// InsertZeroWidth
// ============================================================================

func TestInsertZeroWidth_Empty(t *testing.T) {
	n := newTestNoiser(42)
	if got := n.InsertZeroWidth("", false); got != "" {
		t.Errorf("空输入:%q", got)
	}
}

func TestInsertZeroWidth_PureNumeric_NoInsert(t *testing.T) {
	// 全数字/标点 → 无安全位置 → 原样返回
	n := newTestNoiser(42)
	in := "12345 - 67890"
	if got := n.InsertZeroWidth(in, false); got != in {
		t.Errorf("全数字应不变:in=%q, got=%q", in, got)
	}
}

func TestInsertZeroWidth_CJK_HasInsert(t *testing.T) {
	// CJK 汉字应产生插入 → 输出比输入长
	n := newTestNoiser(42)
	in := "你好世界这是测试文本内容"
	got := n.InsertZeroWidth(in, false)
	if len(got) <= len(in) {
		t.Errorf("CJK 应有插入:in=%d bytes, got=%d bytes", len(in), len(got))
	}
	// 去掉零宽字符后应等于原文
	stripped := stripZeroWidth(got)
	if stripped != in {
		t.Errorf("去零宽应还原:%q vs %q", stripped, in)
	}
}

func TestInsertZeroWidth_Latin_HasInsert(t *testing.T) {
	n := newTestNoiser(42)
	in := "HelloWorldThisIsATestOfLatinTextInsertion"
	got := n.InsertZeroWidth(in, false)
	if len(got) <= len(in) {
		t.Errorf("Latin 应有插入:in=%d, got=%d", len(in), len(got))
	}
	if stripZeroWidth(got) != in {
		t.Errorf("去零宽应还原")
	}
}

func TestInsertZeroWidth_SkipVariable(t *testing.T) {
	// {VAR} 内不插;外部字母/CJK 可插
	n := newTestNoiser(42)
	in := "prefix{VARIABLE_NAME}suffix"
	got := n.InsertZeroWidth(in, false)
	// 提取 {} 之间的内容,应保留原样
	start := strings.Index(got, "{")
	end := strings.Index(got, "}")
	if start < 0 || end < 0 {
		t.Fatalf("变量标记丢失:%q", got)
	}
	varPart := got[start : end+1]
	if varPart != "{VARIABLE_NAME}" {
		t.Errorf("变量内容被改:%q", varPart)
	}
}

func TestInsertZeroWidth_SkipHTMLTag(t *testing.T) {
	// <p>标签始终不插(不受 isHTML 影响)
	n := newTestNoiser(42)
	in := "<p class=\"x\">HELLO</p>"
	got := n.InsertZeroWidth(in, true)
	// 提取 <> 之间的标签部分,应无插入
	tagStart := strings.Index(got, "<")
	tagEnd := strings.Index(got, ">")
	if tagStart < 0 || tagEnd < 0 {
		t.Fatalf("标签丢失:%q", got)
	}
	tagPart := got[tagStart : tagEnd+1]
	if tagPart != `<p class="x">` {
		t.Errorf("标签内容被改:%q", tagPart)
	}
}

func TestInsertZeroWidth_SkipHTMLEntity_WhenHTML(t *testing.T) {
	// &amp; 内不插(isHTML=true)
	n := newTestNoiser(42)
	in := "AB&amp;CD"
	got := n.InsertZeroWidth(in, true)
	if !strings.Contains(got, "&amp;") {
		t.Errorf("HTML 实体被改:%q", got)
	}
}

func TestInsertZeroWidth_SkipURL(t *testing.T) {
	// http:// 到空白/引号前的字符都不插
	n := newTestNoiser(42)
	in := "AAAAA https://example.com/path BBBBB"
	got := n.InsertZeroWidth(in, false)
	// URL 部分应完整
	if !strings.Contains(got, "https://example.com/path") {
		t.Errorf("URL 被改:%q", got)
	}
}

func TestInsertZeroWidth_Reproducibility(t *testing.T) {
	n1 := newTestNoiser(42)
	n2 := newTestNoiser(42)
	in := "HelloWorldThisIsATestOfReproducibility"
	if n1.InsertZeroWidth(in, false) != n2.InsertZeroWidth(in, false) {
		t.Error("复现失败")
	}
}

func TestInsertZeroWidth_MultiLine(t *testing.T) {
	// 多行分别处理,\n 保留
	n := newTestNoiser(42)
	in := "line1abc\nline2def\nline3ghi"
	got := n.InsertZeroWidth(in, false)
	// 应有 2 个 \n
	if strings.Count(got, "\n") != 2 {
		t.Errorf("换行数:%d, want=2", strings.Count(got, "\n"))
	}
}

// ============================================================================
// BidiReverseHide
// ============================================================================

func TestBidiReverseHide_Empty(t *testing.T) {
	n := newTestNoiser(42)
	if got := n.BidiReverseHide(""); got != "" {
		t.Errorf("空输入:%q", got)
	}
}

func TestBidiReverseHide_Format(t *testing.T) {
	// "AB" → [LRI][RLO]BA[PDF][PDI]
	n := newTestNoiser(42)
	got := n.BidiReverseHide("AB")
	runes := []rune(got)
	if len(runes) != 6 {
		t.Fatalf("长度:%d, want=6", len(runes))
	}
	if runes[0] != 0x2066 {
		t.Errorf("[0] 应 LRI(2066):U+%04X", runes[0])
	}
	if runes[1] != 0x202E {
		t.Errorf("[1] 应 RLO(202E):U+%04X", runes[1])
	}
	if runes[2] != 'B' {
		t.Errorf("[2] 应 B(反序):%q", runes[2])
	}
	if runes[3] != 'A' {
		t.Errorf("[3] 应 A(反序):%q", runes[3])
	}
	if runes[4] != 0x202C {
		t.Errorf("[4] 应 PDF(202C):U+%04X", runes[4])
	}
	if runes[5] != 0x2069 {
		t.Errorf("[5] 应 PDI(2069):U+%04X", runes[5])
	}
}

func TestBidiReverseHide_CJK(t *testing.T) {
	n := newTestNoiser(42)
	got := n.BidiReverseHide("你好")
	runes := []rune(got)
	if len(runes) != 6 {
		t.Fatalf("CJK 反序长度:%d, want=6", len(runes))
	}
	// 中间是反序:好, 你
	if runes[2] != '好' || runes[3] != '你' {
		t.Errorf("CJK 反序:[2]=%q [3]=%q, want=好, 你", runes[2], runes[3])
	}
}

func TestBidiCharsetSupported(t *testing.T) {
	cases := []struct {
		charset string
		want    bool
	}{
		{"UTF-8", true},
		{"utf-8", true},
		{"UTF8", true},
		{"utf8", true},
		{"", true}, // 空视为 UTF-8
		{"  UTF-8  ", true},
		{"iso-2022-jp", false},
		{"Shift_JIS", false},
		{"GBK", false},
		{"EUC-JP", false},
	}
	for _, c := range cases {
		if got := BidiCharsetSupported(c.charset); got != c.want {
			t.Errorf("charset=%q:got=%v, want=%v", c.charset, got, c.want)
		}
	}
}

// ============================================================================
// AddImageNoise
// ============================================================================

func TestAddImageNoise_UnsupportedFormat(t *testing.T) {
	// .txt 应只加尾部字节
	n := newTestNoiser(42)
	orig := []byte("hello world text data")
	got := n.AddImageNoise(orig, "file.txt")
	if len(got) < len(orig)+4 || len(got) > len(orig)+16 {
		t.Errorf(".txt 尾部字节应 +4..16:orig=%d got=%d", len(orig), len(got))
	}
	// 前 N 字节应完全一致
	if string(got[:len(orig)]) != string(orig) {
		t.Error(".txt 数据前段应不变")
	}
}

func TestAddImageNoise_PNG(t *testing.T) {
	// 生成 1x1 红色 PNG
	n := newTestNoiser(42)
	origPNG := makeTestPNG(t)
	got := n.AddImageNoise(origPNG, "test.png")
	// 输出应可解码为图像
	img, _, err := image.Decode(bytes.NewReader(got))
	if err != nil {
		t.Fatalf("解码失败:%v", err)
	}
	bounds := img.Bounds()
	if bounds.Dx() != 1 || bounds.Dy() != 1 {
		t.Errorf("图像尺寸:%dx%d, want=1x1", bounds.Dx(), bounds.Dy())
	}
	// 字节应不同(pixel 微调 + 尾部字节)
	if bytes.Equal(got, origPNG) {
		t.Error("PNG 数据应变化")
	}
}

func TestAddImageNoise_JPG(t *testing.T) {
	n := newTestNoiser(42)
	origJPG := makeTestJPG(t)
	got := n.AddImageNoise(origJPG, "test.jpg")
	// 应可解码
	_, _, err := image.Decode(bytes.NewReader(got))
	if err != nil {
		t.Fatalf("解码失败:%v", err)
	}
	// 字节应不同
	if bytes.Equal(got, origJPG) {
		t.Error("JPG 数据应变化")
	}
}

func TestAddImageNoise_DecodeFailFallback(t *testing.T) {
	// 假 PNG(尾缀是 .png 但内容无效)→ decode 失败 → 只加尾部
	n := newTestNoiser(42)
	fake := []byte("not a real png data")
	got := n.AddImageNoise(fake, "fake.png")
	// 前 N 字节不变
	if string(got[:len(fake)]) != string(fake) {
		t.Error("decode 失败应保留原数据前段")
	}
	// 尾部 +4..16 字节
	if len(got) < len(fake)+4 || len(got) > len(fake)+16 {
		t.Errorf("尾部字节数:%d..16, got=%d", 4, len(got)-len(fake))
	}
}

func TestAppendTrailingNoise_Length(t *testing.T) {
	// 抽 20 次,每次长度应在 [orig+4, orig+16]
	n := newTestNoiser(42)
	orig := []byte("base")
	for i := 0; i < 20; i++ {
		got := n.appendTrailingNoise(orig)
		diff := len(got) - len(orig)
		if diff < 4 || diff > 16 {
			t.Errorf("第 %d 次尾部字节数:%d, want 4-16", i, diff)
		}
	}
}

// ============================================================================
// clampU8
// ============================================================================

func TestClampU8(t *testing.T) {
	cases := []struct {
		in   int
		want uint8
	}{
		{-100, 0},
		{-1, 0},
		{0, 0},
		{100, 100},
		{255, 255},
		{256, 255},
		{9999, 255},
	}
	for _, c := range cases {
		if got := clampU8(c.in); got != c.want {
			t.Errorf("clampU8(%d):got=%d, want=%d", c.in, got, c.want)
		}
	}
}

// ============================================================================
// 辅助
// ============================================================================

// stripZeroWidth 去除所有 5 种零宽字符,验证 InsertZeroWidth 未破坏原文
func stripZeroWidth(s string) string {
	var b strings.Builder
	for _, r := range s {
		if r == 0x200B || r == 0x200C || r == 0x200D || r == 0xFEFF || r == 0x2060 {
			continue
		}
		b.WriteRune(r)
	}
	return b.String()
}

// makeTestPNG 生成 1x1 红色 PNG(测试用)
func makeTestPNG(t *testing.T) []byte {
	img := image.NewRGBA(image.Rect(0, 0, 1, 1))
	img.Set(0, 0, color.RGBA{R: 255, A: 255})
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		t.Fatalf("makeTestPNG:%v", err)
	}
	return buf.Bytes()
}

// makeTestJPG 生成 8x8 红色 JPG(JPEG 最小 DCT 块 8x8;1x1 也可但可能编码失败)
func makeTestJPG(t *testing.T) []byte {
	img := image.NewRGBA(image.Rect(0, 0, 8, 8))
	for y := 0; y < 8; y++ {
		for x := 0; x < 8; x++ {
			img.Set(x, y, color.RGBA{R: 255, A: 255})
		}
	}
	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, img, &jpeg.Options{Quality: 90}); err != nil {
		t.Fatalf("makeTestJPG:%v", err)
	}
	return buf.Bytes()
}
