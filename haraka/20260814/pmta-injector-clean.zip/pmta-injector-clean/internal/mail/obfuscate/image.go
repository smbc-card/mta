package obfuscate

import (
	"bytes"
	"image"
	"image/color"
	"image/jpeg"
	"image/png"
	"strings"
)

// ============================================================================
// 图像噪声(v1 email/noise.go)
// ============================================================================

// AddImageNoise 给图片添加噪点(修改 1-5 个像素 + 尾部追加随机字节)
//
// 【契约】v2 与 v1 email/noise.go::AddImageNoise 语义完全一致
//
// 【支持格式】.jpg / .jpeg / .png(其他格式仅追加尾部随机字节)
//
// 【D22-3 race 修复】v1 用包级 rand;v2 用 n.rng 注入
//
// 【原理】
//  1. 微调 1-5 个随机像素的 RGB(±3,肉眼不可见)
//  2. JPEG 用随机质量 90-95 重编码(增加字节差异)
//  3. 尾部追加 4-16 字节随机数据(解码器忽略,但文件哈希变)
//
// 【降级路径】(任一失败 → 直接走尾部追加,保证永不 panic)
//   - 不支持格式 → 只加尾部
//   - image.Decode 失败 → 只加尾部
//   - 宽/高 < 1 → 只加尾部
//   - 重编码失败 → 只加尾部
func (n *Noiser) AddImageNoise(imgBytes []byte, filename string) []byte {
	lowerName := strings.ToLower(filename)

	var isJPEG, isPNG bool
	if strings.HasSuffix(lowerName, ".jpg") || strings.HasSuffix(lowerName, ".jpeg") {
		isJPEG = true
	} else if strings.HasSuffix(lowerName, ".png") {
		isPNG = true
	}

	if !isJPEG && !isPNG {
		return n.appendTrailingNoise(imgBytes)
	}

	// 解码图片
	reader := bytes.NewReader(imgBytes)
	img, _, err := image.Decode(reader)
	if err != nil {
		return n.appendTrailingNoise(imgBytes)
	}

	// 转为可修改的 RGBA
	bounds := img.Bounds()
	rgba := image.NewRGBA(bounds)
	for y := bounds.Min.Y; y < bounds.Max.Y; y++ {
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			rgba.Set(x, y, img.At(x, y))
		}
	}

	// 修改 1-5 个随机像素(RGB 微调 ±3,肉眼不可见)
	pixelCount := 1 + n.rng.Intn(5)
	width := bounds.Dx()
	height := bounds.Dy()
	if width < 1 || height < 1 {
		return n.appendTrailingNoise(imgBytes)
	}

	for i := 0; i < pixelCount; i++ {
		x := bounds.Min.X + n.rng.Intn(width)
		y := bounds.Min.Y + n.rng.Intn(height)
		origColor := rgba.At(x, y)
		r, g, b, a := origColor.RGBA()

		newR := clampU8(int(r>>8) + n.rng.Intn(7) - 3)
		newG := clampU8(int(g>>8) + n.rng.Intn(7) - 3)
		newB := clampU8(int(b>>8) + n.rng.Intn(7) - 3)
		rgba.Set(x, y, color.RGBA{R: newR, G: newG, B: newB, A: uint8(a >> 8)})
	}

	// 重新编码
	var buf bytes.Buffer
	if isJPEG {
		// JPEG 随机质量 90-95(进一步增加字节差异)
		quality := 90 + n.rng.Intn(6)
		err = jpeg.Encode(&buf, rgba, &jpeg.Options{Quality: quality})
	} else {
		err = png.Encode(&buf, rgba)
	}
	if err != nil {
		return n.appendTrailingNoise(imgBytes)
	}

	// 追加尾部随机字节
	return n.appendTrailingNoise(buf.Bytes())
}

// appendTrailingNoise 在图片文件末尾追加 4-16 字节随机数据
//
// 【契约】v2 与 v1 email/noise.go::appendTrailingNoise 语义一致
//
// 【原理】JPEG/PNG 解码器忽略尾部多余数据,但文件哈希完全不同
func (n *Noiser) appendTrailingNoise(data []byte) []byte {
	noiseLen := 4 + n.rng.Intn(13) // 4-16 字节
	noise := make([]byte, noiseLen)
	// 直接 Read 一次填充(比逐字节 Intn 快)
	_, _ = n.rng.Read(noise)
	return append(data, noise...)
}

// clampU8 将整数限制在 0-255 范围
//
// 【契约】v2 与 v1 email/noise.go::clampU8 完全一致
func clampU8(v int) uint8 {
	if v < 0 {
		return 0
	}
	if v > 255 {
		return 255
	}
	return uint8(v)
}
