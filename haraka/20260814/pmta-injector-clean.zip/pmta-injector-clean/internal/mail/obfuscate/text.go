package obfuscate

import (
	"strings"
	"unicode"
)

// ============================================================================
// 零宽字符注入(v1 email/zerowidth.go)
// ============================================================================

// zeroWidthChars 5 种零宽字符池(混用增加指纹多样性)
//
// 【契约】v2 与 v1 email/zerowidth.go::zeroWidthChars 完全一致
//
// 【重要】用 hex 常量而非 rune literal —— U+FEFF(BOM)出现在源码中间会被 Go 编译器拒绝
// (P21 踩坑:Write 工具把 '​' 转义序列解释成字面字符,产生 BOM;改用 rune(0xXXXX) 规避)
var zeroWidthChars = []rune{
	rune(0x200B), // ZERO WIDTH SPACE
	rune(0x200C), // ZERO WIDTH NON-JOINER
	rune(0x200D), // ZERO WIDTH JOINER
	rune(0xFEFF), // ZERO WIDTH NO-BREAK SPACE (BOM 字符)
	rune(0x2060), // WORD JOINER
}

// excludeChars 排除字符表(标点/数字/空白等 —— 不在其上插入零宽)
//
// 【契约】v2 与 v1 email/zerowidth.go::excludeChars 完全一致(含中英标点混合)
//
// 【全角标点】用 \u 转义避免源码文件的字符编码问题
var excludeChars = map[rune]bool{
	// ASCII 数字
	'0': true, '1': true, '2': true, '3': true, '4': true,
	'5': true, '6': true, '7': true, '8': true, '9': true,
	// ASCII 标点
	'-': true, ',': true, '.': true, ':': true, '/': true,
	'\\': true, '*': true, '?': true, '!': true, '@': true,
	'#': true, '$': true, '%': true, '^': true, '&': true,
	'(': true, ')': true, '=': true, '[': true, ']': true,
	'{': true, '}': true, ';': true, '\'': true, '"': true,
	'<': true, '>': true, '+': true, '_': true,
	// 空白
	'\r': true, '\n': true, '\t': true, ' ': true,
	// 中英标点(v1 excludeChars 里的全部,用 \u 转义)
	'，': true, // FULLWIDTH COMMA (，)
	'。': true, // IDEOGRAPHIC FULL STOP (。)
	'：': true, // FULLWIDTH COLON (:)
	'？': true, // FULLWIDTH QUESTION MARK (?)
	'；': true, // FULLWIDTH SEMICOLON (;)
	'【': true, // LEFT BLACK LENTICULAR BRACKET (【)
	'】': true, // RIGHT BLACK LENTICULAR BRACKET (】)
	'‘': true, // LEFT SINGLE QUOTATION MARK (v1 excludeChars 里有)
	'“': true, // LEFT DOUBLE QUOTATION MARK
	'《': true, // LEFT DOUBLE ANGLE BRACKET (《)
	'》': true, // RIGHT DOUBLE ANGLE BRACKET (》)
	'「': true, // LEFT CORNER BRACKET (「)
	'」': true, // RIGHT CORNER BRACKET (」)
	'『': true, // LEFT WHITE CORNER BRACKET (『)
	'』': true, // RIGHT WHITE CORNER BRACKET (』)
	'、': true, // IDEOGRAPHIC COMMA (、)
	'・': true, // KATAKANA MIDDLE DOT (・)
}

// InsertZeroWidth 在文本/HTML 中随机插入零宽字符
//
// 【契约】v2 与 v1 email/zerowidth.go::InsertZeroWidth 语义完全一致
//
// 【参数】
//   - text:输入文本
//   - isHTML:true 时避开 &xxx; HTML 实体(& 到 ; 之间不插);<xxx> 标签始终排除
//
// 【返回】混淆后的文本(长度增加,视觉不可见)
//
// 【D22-3 race 修复】v1 用包级 rand.Intn/Shuffle;v2 用 n.rng 注入
func (n *Noiser) InsertZeroWidth(text string, isHTML bool) string {
	if text == "" {
		return text
	}

	lines := strings.Split(text, "\n")
	var result strings.Builder
	result.Grow(len(text) * 2)

	for lineIdx, line := range lines {
		if lineIdx > 0 {
			result.WriteByte('\n')
		}
		result.WriteString(n.insertZeroWidthInLine(line, isHTML))
	}

	return result.String()
}

// insertZeroWidthInLine 对单行文本插入零宽字符(核心算法)
//
// 【契约】v2 与 v1 insertZeroWidthInLine 完全一致
//
// 【4 步算法】
//  1. 标记每个字符是否在"禁区"内({} 变量 / <> 标签 / &; HTML 实体 / http:// URL)
//  2. 收集所有安全位置(字母/CJK 且不在禁区)
//  3. 随机 1-5 个位置(不超过安全位置数),Fisher-Yates 打乱取前 count 个
//  4. 构建结果:每个字符后按需追加一个随机零宽字符
func (n *Noiser) insertZeroWidthInLine(line string, isHTML bool) string {
	if len(line) == 0 {
		return line
	}

	runes := []rune(line)
	sz := len(runes)

	// 第 1 步:禁区判定
	inTag := false      // 在 HTML 标签 <...> 内
	inVariable := false // 在变量 {...} 内
	inEntity := false   // 在 HTML 实体 &...; 内
	inURL := false      // 在 URL 内
	safe := make([]bool, sz)

	for i, r := range runes {
		// URL 检测:http:// 或 https:// 开头
		if !inURL && !inTag && !inVariable {
			if r == 'h' && i+7 < sz {
				rest := string(runes[i:])
				if strings.HasPrefix(rest, "http://") || strings.HasPrefix(rest, "https://") {
					inURL = true
				}
			}
		}

		// URL 结束检测:遇到空白 / < / " / ' / > / \r\n 则结束
		if inURL {
			if r == ' ' || r == '\t' || r == '<' || r == '"' || r == '\'' || r == '>' || r == '\r' || r == '\n' {
				inURL = false
			} else {
				safe[i] = false
				continue
			}
		}

		// 更新禁区状态(<> 标签始终排除,不受 isHTML 限制)
		switch {
		case r == '{':
			inVariable = true
		case r == '}':
			inVariable = false
			safe[i] = false
			continue
		case r == '<':
			inTag = true
		case r == '>':
			inTag = false
			safe[i] = false
			continue
		case r == '&' && isHTML:
			inEntity = true
		case r == ';' && inEntity:
			inEntity = false
			safe[i] = false
			continue
		}

		// 在禁区内 → 不安全
		if inTag || inVariable || inEntity {
			safe[i] = false
			continue
		}

		// 排除字符 → 不安全
		if excludeChars[r] {
			safe[i] = false
			continue
		}

		// 排除 ASCII 控制字符
		if r < 32 {
			safe[i] = false
			continue
		}

		// 必须是可见的文字字符(汉字、假名、字母等)
		if unicode.IsLetter(r) || unicode.Is(unicode.Han, r) ||
			unicode.Is(unicode.Katakana, r) || unicode.Is(unicode.Hiragana, r) {
			safe[i] = true
		}
	}

	// 第 2 步:收集安全位置
	var safePositions []int
	for i := range runes {
		if safe[i] {
			safePositions = append(safePositions, i)
		}
	}
	if len(safePositions) == 0 {
		return line
	}

	// 第 3 步:随机 1-5 个位置
	count := 1 + n.rng.Intn(5)
	if count > len(safePositions) {
		count = len(safePositions)
	}

	// Fisher-Yates 打乱(用注入 rng 的 Shuffle)
	shuffled := make([]int, len(safePositions))
	copy(shuffled, safePositions)
	n.rng.Shuffle(len(shuffled), func(i, j int) {
		shuffled[i], shuffled[j] = shuffled[j], shuffled[i]
	})
	insertPositions := make(map[int]bool, count)
	for i := 0; i < count; i++ {
		insertPositions[shuffled[i]] = true
	}

	// 第 4 步:构建结果
	var result strings.Builder
	result.Grow(len(line) + count*4)
	for i, r := range runes {
		result.WriteRune(r)
		if insertPositions[i] {
			zw := zeroWidthChars[n.rng.Intn(len(zeroWidthChars))]
			result.WriteRune(zw)
		}
	}
	return result.String()
}

// ============================================================================
// BiDi 反转隐藏(v1 email/bidi.go)
// ============================================================================
//
// 【原理】用 Unicode 6.3+ 隔离段包裹反序 rune,视觉恢复原样,但字节序列被打乱
//
// 【输出格式】[LRI(U+2066)][RLO(U+202E)][rune 反序][PDF(U+202C)][PDI(U+2069)]

const (
	bidiLRI rune = 0x2066 // Left-to-Right Isolate
	bidiRLO rune = 0x202E // Right-to-Left Override
	bidiPDF rune = 0x202C // Pop Directional Formatting
	bidiPDI rune = 0x2069 // Pop Directional Isolate
)

// BidiReverseHide 对 text 做 rune 反序 + LRI/PDI 隔离段包裹
//
// 【契约】v2 与 v1 email/bidi.go::bidiReverseHide 语义完全一致
//
// 【空串】原样返回(不加控制符)
//
// 【不使用 rng】纯字符反转,无随机性 —— Noiser method 只是为签名统一
func (n *Noiser) BidiReverseHide(text string) string {
	if text == "" {
		return text
	}
	runes := []rune(text)
	var sb strings.Builder
	sb.Grow(len(text) + 16) // 4 控制符 × 3 字节 UTF-8 = 12 字节额外开销 + 4 字节余量
	sb.WriteRune(bidiLRI)
	sb.WriteRune(bidiRLO)
	for i := len(runes) - 1; i >= 0; i-- {
		sb.WriteRune(runes[i])
	}
	sb.WriteRune(bidiPDF)
	sb.WriteRune(bidiPDI)
	return sb.String()
}

// BidiCharsetSupported 判断字符集是否支持 BiDi 控制符
//
// 【契约】v2 与 v1 email/bidi.go::bidiCharsetSupported 完全一致
//
// 【仅 UTF-8 支持】(空串默认视为 UTF-8);
// Shift_JIS / ISO-2022-JP / EUC-JP / GBK 都无法表示 U+2066/2069/202E/202C
//
// 【包级函数】不需 rng,不挂 Noiser method
func BidiCharsetSupported(charset string) bool {
	c := strings.ToUpper(strings.TrimSpace(charset))
	return c == "" || c == "UTF-8" || c == "UTF8"
}
