package obfuscate

import (
	"__MODULE_PLACEHOLDER__/internal/random"
)

// Noiser 邮件反指纹混淆器(per-worker 单实例)
//
// 【依赖注入】
//   - rng:随机源(3 类混淆共用)
//
// 【线程安全】非线程安全,per-worker 一个实例
// 【D22-3 race 修复】v1 用包级 math/rand,并发写触发 race;v2 全走注入 Source 无锁
type Noiser struct {
	rng random.Source
}

// New 创建 Noiser
//
// 【参数】rng 必需(nil 会在首次使用时 panic)
func New(rng random.Source) *Noiser {
	return &Noiser{rng: rng}
}

// method 实现拆到 text.go(zerowidth + bidi)和 image.go(AddImageNoise)
