// Package compose 邮件头后处理:字段名随机大小写 + 锚定式乱序 + DKIM 顺序重排
//
// 【入口】PostprocessMainHeaders(headers, rng, shuffleOrder, randomCase, caseMode, dkimList)
//   - 由 Week 5 builder::buildRawEmail 主头组装完成后调用
//   - 输入 mainHeaders []string(每条 "Name: value\r\n" 含可能的折叠续行)
//   - 输出后处理后的 []string(不丢头 / 不重复 / 元素集合与输入一致)
//
// 【三种后处理】(独立开关,顺序:先乱序/DKIM 再大小写):
//  1. reorderByDkimList(dkimList 非空 → 按 dkimList 顺序重排;跳过 shuffleOrder)
//  2. shuffleHeadersWithAnchors(shuffleOrder=true 且 dkimList 空)
//  3. applyCaseRandomization(randomCase=true;字段名 50/50 大小写翻转)
//
// 【方案 D 优先级】dkimList 非空 → 优先按 dkimList 顺序重排,**跳过 shuffleOrder**:
//   - PMTA 5.0r8 按邮件里 header 出现顺序生成 DKIM-Signature 的 h= 字段
//   - 控制邮件 header 顺序 = 控制 PMTA 生成的 h= 顺序
//   - 用户明确启用 DKIM 排序 = 明确要顺序控制,不该被 shuffle 打乱
//
// 【锚定优先级表】anchorPriority(值越小越靠前;不在表里的头进入可乱序池):
//   - 0:x-virtual-mta / x-job(PMTA 控制头,最顶)
//   - 1:Received-*(前缀匹配;RFC 5321 时序要求)
//   - 2:DKIM-Signature(紧随 Received 之后)
//   - 4:From / 5:To / 6:Cc / 7:Subject / 8:Date
//   - 9:Message-ID / 10:MIME-Version(在 Message-ID 之后 —— 与 append 顺序一致)
//   - (priority 3 空缺,给未来预留)
//
// 【大小写跳过名单】caseSkipNames(全小写比对,命中即保持原大小写):
//   - dkim-signature   → DKIM simple canonicalization 字节比较兼容
//   - x-virtual-mta    → PMTA 控制头字段名小写是 PMTA 配置约定
//   - x-job            → 同上
//   - x-internal-ccbcc-skip-tg → Haraka log_delivered.js 插件依赖精确扫描
//
// 【List-Unsubscribe-Post 配对】shuffle 时特殊处理:
//   - Post 头暂时从 pool 分离,shuffle 完 pool 后插回 List-Unsubscribe 之后
//   - 若 pool 里没 List-Unsubscribe(异常场景),Post 追加到末尾
//
// 【依赖】random.Source(仅 shuffleHeadersWithAnchors 需要)
// 【不 import 其他子包】(D16-1 决策;本包最独立)
package compose
