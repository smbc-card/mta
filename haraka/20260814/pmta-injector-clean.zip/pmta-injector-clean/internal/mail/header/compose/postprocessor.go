package compose

import (
	"__MODULE_PLACEHOLDER__/internal/random"
)

// Postprocessor 邮件头后处理器
//
// 【依赖注入】
//   - rng:仅 shuffleHeadersWithAnchors 需要(Fisher-Yates 洗牌)
//
// 【无状态】本包所有函数纯函数式,Postprocessor 只是 rng 的载体。
// 【线程安全】非线程安全(rng 不是并发安全),per-worker 一个实例
type Postprocessor struct {
	rng random.Source
}

// New 创建 Postprocessor
//
// 【参数】rng 必需(shuffleOrder=false 且 randomCase=false 时不会用到,但仍要求非 nil 避免使用时崩)
func New(rng random.Source) *Postprocessor {
	return &Postprocessor{rng: rng}
}

// Assemble 邮件头后处理总入口
//
// 【契约】v2 与 v1 email/headers_postprocess.go::PostprocessMainHeaders 语义完全一致
//
// 【参数】
//   - headers:输入 header 条目切片(每条 "Name: value\r\n" 含可能的折叠续行)
//   - shuffleOrder:是否启用锚定式乱序
//   - randomCase:是否启用字段名大小写随机化
//   - caseMode:预留切换点(空 = "random" 全随机;未来可扩 "stylepool")
//   - dkimList:非空 → 优先按 dkimList 顺序重排 header,跳过 shuffleOrder
//
// 【返回】后处理后的 []string(不丢头 / 不重复 / 元素集合与输入一致)
//
// 【不变量】len(output) == len(input)
//
// 【顺序】先乱序/DKIM,后随机大小写
//
//	理由:乱序时用 strings.EqualFold 比对字段名(大小写不敏感),即使先大小写化也不会失效;
//	      但先乱序保持锚定逻辑的字段名原始大小写形式(更不容易出 bug),所以选先乱序
//
// 【方案 D 优先】dkimList 非空 → 优先按 dkimList 顺序重排(reorderByDkimList),
// **跳过 shuffleOrder**。理由:DKIM 排序 = 顺序确定性(为了让 PMTA 生成期望的 h= 顺序);
// shuffleOrder = 随机顺序(反指纹)。两者本质矛盾,确定性优先。
// 用户明确启用 DKIM 排序 = 明确要顺序控制,不该被 shuffle 打乱。
//
// 【副作用】输入 headers 切片可能被就地修改(乱序时返回新切片,大小写随机化时就地修改)
func (p *Postprocessor) Assemble(headers []string, shuffleOrder, randomCase bool, caseMode string, dkimList []string) []string {
	if len(headers) == 0 {
		return headers
	}
	// 方案 D:DKIM 排序优先(非空时按 dkimList 顺序重排,跳过 shuffle)
	if len(dkimList) > 0 {
		headers = reorderByDkimList(headers, dkimList)
	} else if shuffleOrder {
		headers = shuffleHeadersWithAnchors(headers, p.rng)
	}
	if randomCase {
		headers = applyCaseRandomization(headers, p.rng, caseMode)
	}
	return headers
}
