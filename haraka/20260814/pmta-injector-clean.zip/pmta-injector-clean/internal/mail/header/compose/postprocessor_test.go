package compose

import (
	"sort"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/random"
)

func newTestPost(seed int64) *Postprocessor {
	return New(random.NewFixedSource(seed))
}

// ============================================================================
// 契约锁 —— caseSkipNames + anchorPriority 数量与内容
// ============================================================================

func TestCaseSkipNamesCount(t *testing.T) {
	// v1 硬约束 4 项 —— 加/减会破坏与 Haraka 的字节级一致性
	if got := len(caseSkipNames); got != 4 {
		t.Fatalf("caseSkipNames 项数偏离契约:got=%d, want=4", got)
	}
	for _, k := range []string{"dkim-signature", "x-virtual-mta", "x-job", "x-internal-ccbcc-skip-tg"} {
		if _, ok := caseSkipNames[k]; !ok {
			t.Errorf("缺少 caseSkipName %q", k)
		}
	}
}

func TestAnchorPriorityContract(t *testing.T) {
	// v1 硬约束:11 项 + 具体优先级不可变
	want := map[string]int{
		"x-virtual-mta":  0,
		"x-job":          0,
		"received":       1,
		"dkim-signature": 2,
		"from":           4,
		"to":             5,
		"cc":             6,
		"subject":        7,
		"date":           8,
		"message-id":     9,
		"mime-version":   10, // 2026-06-01 修:3 → 10
	}
	if len(anchorPriority) != len(want) {
		t.Fatalf("anchorPriority 项数:got=%d, want=%d", len(anchorPriority), len(want))
	}
	for k, v := range want {
		if got, ok := anchorPriority[k]; !ok || got != v {
			t.Errorf("anchorPriority[%q]=%d, want %d(ok=%v)", k, got, v, ok)
		}
	}
	// mime-version 硬约束:必须 = 10(2026-06-01 修复;若被改回 3 会破坏 append 顺序一致性)
	if anchorPriority["mime-version"] != 10 {
		t.Error("mime-version 必须锚定在 10(Message-ID 之后),不可改回 3")
	}
}

// ============================================================================
// SplitHeaderBlock (导出函数)
// ============================================================================

func TestSplitHeaderBlock_Basic(t *testing.T) {
	block := "From: a@b\r\nTo: c@d\r\nSubject: test\r\n"
	got := SplitHeaderBlock(block)
	want := []string{"From: a@b\r\n", "To: c@d\r\n", "Subject: test\r\n"}
	if len(got) != len(want) {
		t.Fatalf("len:got=%d, want=%d", len(got), len(want))
	}
	for i := range want {
		if got[i] != want[i] {
			t.Errorf("[%d]:got=%q, want=%q", i, got[i], want[i])
		}
	}
}

func TestSplitHeaderBlock_FoldedContinuation(t *testing.T) {
	// Received 头有 3 行续行
	block := "Received: from xxx\r\n (Authenticated...)\r\n by yyy\r\nFrom: a@b\r\n"
	got := SplitHeaderBlock(block)
	if len(got) != 2 {
		t.Fatalf("len:got=%d, want=2", len(got))
	}
	// 第 1 条应含 3 行折叠(3 个 \r\n)
	if !strings.HasPrefix(got[0], "Received: ") {
		t.Errorf("第 1 条前缀:%q", got[0])
	}
	if strings.Count(got[0], "\r\n") != 3 {
		t.Errorf("第 1 条应含 3 CRLF(3 行折叠):got=%d\n%q", strings.Count(got[0], "\r\n"), got[0])
	}
	if got[1] != "From: a@b\r\n" {
		t.Errorf("第 2 条:%q", got[1])
	}
}

func TestSplitHeaderBlock_EmptyInput(t *testing.T) {
	if got := SplitHeaderBlock(""); got != nil {
		t.Errorf("空输入应返回 nil:%v", got)
	}
}

func TestSplitHeaderBlock_TrailingNoCRLF(t *testing.T) {
	// 末尾无 CRLF 也能切分
	block := "From: a@b\r\nSubject: test"
	got := SplitHeaderBlock(block)
	if len(got) != 2 {
		t.Fatalf("len:got=%d", len(got))
	}
	if got[1] != "Subject: test" {
		t.Errorf("末尾无 CRLF 保留原样:%q", got[1])
	}
}

func TestSplitHeaderBlock_SkipEmptyLines(t *testing.T) {
	// 中间空行应被忽略
	block := "From: a@b\r\n\r\n\r\nTo: c@d\r\n"
	got := SplitHeaderBlock(block)
	if len(got) != 2 {
		t.Errorf("空行不应合并:len=%d", len(got))
	}
}

// ============================================================================
// extractFieldName
// ============================================================================

func TestExtractFieldName(t *testing.T) {
	cases := []struct {
		in, want string
	}{
		{"From: a@b\r\n", "from"},
		{"MESSAGE-ID: <x>\r\n", "message-id"},
		{" continuation line\r\n", ""},   // 续行(SP 开头)
		{"\tcontinuation\r\n", ""},        // 续行(TAB 开头)
		{"NoColon here\r\n", ""},
		{"", ""},
		{":empty name\r\n", ""}, // 冒号在首字符
		// 【v1 行为】首字符是空格 → 视为续行(不 TrimSpace 首字符)
		{"  From  : padded\r\n", ""},
		// 【v1 行为】字段名内含空格 → 冒号前用 TrimSpace 只 trim 前后空白
		{"From  : with-trailing-space\r\n", "from"},
	}
	for _, c := range cases {
		if got := extractFieldName(c.in); got != c.want {
			t.Errorf("in=%q:got=%q, want=%q", c.in, got, c.want)
		}
	}
}

// ============================================================================
// randomizeFieldName / applyCaseRandomization
// ============================================================================

func TestRandomizeFieldName_SkipList(t *testing.T) {
	rng := random.NewFixedSource(42)
	// caseSkipNames 里的 4 项应保持原大小写
	skipCases := []string{
		"DKIM-Signature: v=1; ...\r\n",
		"X-Virtual-MTA: mta1\r\n",
		"X-Job: job-123\r\n",
		"X-Internal-Ccbcc-Skip-Tg: 1\r\n",
	}
	for _, h := range skipCases {
		if got := randomizeFieldName(h, rng); got != h {
			t.Errorf("skip 名单应原样返回:in=%q got=%q", h, got)
		}
	}
}

func TestRandomizeFieldName_ContinuationOriginal(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 续行(SP/TAB 开头)原样返回
	cases := []string{" continuation\r\n", "\tanother\r\n", ""}
	for _, h := range cases {
		if got := randomizeFieldName(h, rng); got != h {
			t.Errorf("续行/空应原样:in=%q got=%q", h, got)
		}
	}
}

func TestRandomizeFieldName_ValuePreserved(t *testing.T) {
	rng := random.NewFixedSource(42)
	in := "From: alice@example.com\r\n"
	got := randomizeFieldName(in, rng)
	// 冒号之后完全不动(值 + \r\n)
	if !strings.HasSuffix(got, ": alice@example.com\r\n") {
		t.Errorf("值部分被改:%q", got)
	}
	// 字段名仍是 4 字符(F/r/o/m 各自随机大小写)
	colon := strings.IndexByte(got, ':')
	name := got[:colon]
	if len(name) != 4 {
		t.Errorf("字段名长度:%d, want=4", len(name))
	}
	if strings.ToLower(name) != "from" {
		t.Errorf("字段名应保 from 语义:%q", name)
	}
}

func TestRandomizeFieldName_HyphenPreserved(t *testing.T) {
	rng := random.NewFixedSource(42)
	in := "X-Mailer-Version: 1.0\r\n"
	got := randomizeFieldName(in, rng)
	// - 字符应原样保留(不参与翻转)
	if strings.Count(got, "-") != 2 {
		t.Errorf("连字符应保留:%q", got)
	}
}

func TestApplyCaseRandomization_Empty(t *testing.T) {
	rng := random.NewFixedSource(42)
	got := applyCaseRandomization(nil, rng, "")
	if got != nil {
		t.Errorf("空输入:%v", got)
	}
}

func TestApplyCaseRandomization_ChangesAtLeastOne(t *testing.T) {
	rng := random.NewFixedSource(42)
	orig := []string{"From: a@b\r\n", "To: c@d\r\n", "Subject: hi\r\n"}
	work := make([]string, len(orig))
	copy(work, orig)
	got := applyCaseRandomization(work, rng, "")
	// 至少 1 项应变化(FixedSource seed 42 下)
	changed := 0
	for i := range orig {
		if got[i] != orig[i] {
			changed++
		}
	}
	if changed == 0 {
		t.Errorf("FixedSource(42) 下应有变化,原:%v, 得:%v", orig, got)
	}
	// 语义仍等价(字段名 case-insensitive)
	for i := range orig {
		if !strings.EqualFold(extractFieldName(orig[i]), extractFieldName(got[i])) {
			t.Errorf("[%d] 字段名语义变化:%q → %q", i, orig[i], got[i])
		}
	}
}

// ============================================================================
// shuffleHeadersWithAnchors
// ============================================================================

func TestShuffle_SmallInput(t *testing.T) {
	rng := random.NewFixedSource(42)
	// ≤1 项不动
	single := []string{"From: a@b\r\n"}
	got := shuffleHeadersWithAnchors(single, rng)
	if len(got) != 1 || got[0] != single[0] {
		t.Errorf("单项应不动:%v", got)
	}
}

func TestShuffle_AnchorsInOrder(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 锚定头必须按 priority 输出:x-virtual-mta(0), Received(1), From(4), Message-ID(9), MIME-Version(10)
	input := []string{
		"X-Mailer: Outlook\r\n",       // 非锚定,进 pool
		"MIME-Version: 1.0\r\n",       // prio 10
		"From: a@b\r\n",               // prio 4
		"X-Custom: xxx\r\n",           // 非锚定
		"Received: from ...\r\n",      // prio 1
		"Message-ID: <x>\r\n",         // prio 9
		"X-Virtual-MTA: mta1\r\n",     // prio 0
	}
	got := shuffleHeadersWithAnchors(input, rng)
	if len(got) != len(input) {
		t.Fatalf("长度:got=%d, want=%d", len(got), len(input))
	}
	// 找每个锚定头的位置
	posVMTA := findIdx(got, "X-Virtual-MTA:")
	posReceived := findIdx(got, "Received:")
	posFrom := findIdx(got, "From:")
	posMID := findIdx(got, "Message-ID:")
	posMIME := findIdx(got, "MIME-Version:")

	if !(posVMTA < posReceived && posReceived < posFrom && posFrom < posMID && posMID < posMIME) {
		t.Errorf("锚定顺序错:VMTA=%d Received=%d From=%d MsgID=%d MIME=%d",
			posVMTA, posReceived, posFrom, posMID, posMIME)
	}
}

func TestShuffle_NoLoss(t *testing.T) {
	rng := random.NewFixedSource(42)
	input := []string{
		"From: a\r\n", "To: b\r\n", "Cc: c\r\n", "X-A: 1\r\n",
		"X-B: 2\r\n", "X-C: 3\r\n", "Received: r\r\n",
	}
	got := shuffleHeadersWithAnchors(input, rng)
	if len(got) != len(input) {
		t.Fatalf("长度变化:%d→%d", len(input), len(got))
	}
	// 元素集合相等(sort + 比较)
	sorted1 := make([]string, len(input))
	copy(sorted1, input)
	sort.Strings(sorted1)
	sorted2 := make([]string, len(got))
	copy(sorted2, got)
	sort.Strings(sorted2)
	for i := range sorted1 {
		if sorted1[i] != sorted2[i] {
			t.Errorf("元素集合变化:[%d]%q vs %q", i, sorted1[i], sorted2[i])
		}
	}
}

func TestShuffle_ListUnsubPostAttachedToLU(t *testing.T) {
	rng := random.NewFixedSource(42)
	input := []string{
		"From: a\r\n",
		"List-Unsubscribe: <mailto:u@x>\r\n",
		"List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n",
		"X-A: 1\r\n", "X-B: 2\r\n", "X-C: 3\r\n",
	}
	got := shuffleHeadersWithAnchors(input, rng)
	posLU := findIdx(got, "List-Unsubscribe:")
	posLUP := findIdx(got, "List-Unsubscribe-Post:")
	if posLU < 0 || posLUP < 0 {
		t.Fatalf("两头都应在:LU=%d LUP=%d", posLU, posLUP)
	}
	if posLUP != posLU+1 {
		t.Errorf("Post 应紧跟 LU:LU=%d LUP=%d(应差 1)", posLU, posLUP)
	}
}

func TestShuffle_ListUnsubPostWithoutLU(t *testing.T) {
	// 只有 Post,没有 List-Unsubscribe → Post 追加末尾
	rng := random.NewFixedSource(42)
	input := []string{
		"From: a\r\n",
		"List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n",
		"X-A: 1\r\n",
	}
	got := shuffleHeadersWithAnchors(input, rng)
	if len(got) != 3 {
		t.Fatalf("长度:%d", len(got))
	}
	// Post 应在最末尾
	if !strings.HasPrefix(got[len(got)-1], "List-Unsubscribe-Post:") {
		t.Errorf("Post 应在末尾:%v", got)
	}
}

// ============================================================================
// reorderByDkimList
// ============================================================================

func TestReorderByDkimList_EmptyList(t *testing.T) {
	headers := []string{"From: a\r\n", "To: b\r\n"}
	got := reorderByDkimList(headers, nil)
	// 空 list 应返回原 headers 不变
	if len(got) != len(headers) || got[0] != headers[0] || got[1] != headers[1] {
		t.Errorf("空 list 应不变:%v", got)
	}
}

func TestReorderByDkimList_ReordersByList(t *testing.T) {
	// dkimList = [To, From, Subject] → 邮件中按此顺序重排
	headers := []string{
		"From: a\r\n",
		"To: b\r\n",
		"Subject: hi\r\n",
	}
	got := reorderByDkimList(headers, []string{"To", "From", "Subject"})
	if got[0] != "To: b\r\n" || got[1] != "From: a\r\n" || got[2] != "Subject: hi\r\n" {
		t.Errorf("按 list 重排失败:%v", got)
	}
}

func TestReorderByDkimList_TopAnchorsFirst(t *testing.T) {
	// x-virtual-mta / Received / dkim-signature 必须在顶
	headers := []string{
		"From: a\r\n",
		"X-Virtual-MTA: mta1\r\n",
		"Received: r1\r\n",
		"To: b\r\n",
		"DKIM-Signature: v=1; ...\r\n",
	}
	got := reorderByDkimList(headers, []string{"To", "From"})
	// 前 3 项应是顶部锚定(顺序保原序:VMTA/Received/DKIM 按输入顺序)
	// 输入里 VMTA(idx 1) < Received(idx 2) < DKIM(idx 4)
	if !strings.HasPrefix(got[0], "X-Virtual-MTA:") {
		t.Errorf("[0] 应 VMTA:%q", got[0])
	}
	if !strings.HasPrefix(got[1], "Received:") {
		t.Errorf("[1] 应 Received:%q", got[1])
	}
	if !strings.HasPrefix(got[2], "DKIM-Signature:") {
		t.Errorf("[2] 应 DKIM:%q", got[2])
	}
	// 后 2 项按 dkimList: To, From
	if got[3] != "To: b\r\n" || got[4] != "From: a\r\n" {
		t.Errorf("dkim 排序错:%v", got[3:])
	}
}

func TestReorderByDkimList_UnmatchedGoToOthers(t *testing.T) {
	// dkimList 里没提到的字段 → others 池
	headers := []string{
		"From: a\r\n",
		"X-Extra: yes\r\n",
		"To: b\r\n",
	}
	got := reorderByDkimList(headers, []string{"To"})
	// 期望:[To, From (others), X-Extra (others)] 因为 To 匹配了 dkimList,From 和 X-Extra 进 others 保原序
	if got[0] != "To: b\r\n" {
		t.Errorf("[0] 应 To:%q", got[0])
	}
	if got[1] != "From: a\r\n" {
		t.Errorf("[1] 应 From(others 保原序):%q", got[1])
	}
	if got[2] != "X-Extra: yes\r\n" {
		t.Errorf("[2] 应 X-Extra(others 保原序):%q", got[2])
	}
}

func TestReorderByDkimList_CaseInsensitiveMatching(t *testing.T) {
	// dkimList=["MESSAGE-ID", "FROM"] 应匹配 "Message-ID:" 和 "From:"(大小写不敏感)
	headers := []string{"From: a\r\n", "Message-ID: <x>\r\n"}
	got := reorderByDkimList(headers, []string{"MESSAGE-ID", "FROM"})
	if got[0] != "Message-ID: <x>\r\n" || got[1] != "From: a\r\n" {
		t.Errorf("大小写不敏感匹配失败:%v", got)
	}
}

func TestReorderByDkimList_EmptyDkimEntries(t *testing.T) {
	// dkimList 全空白 → 返回原 headers
	headers := []string{"From: a\r\n"}
	got := reorderByDkimList(headers, []string{"", "  ", "\t"})
	if len(got) != 1 || got[0] != headers[0] {
		t.Errorf("全空 dkimList 应返回原:%v", got)
	}
}

func TestReorderByDkimList_NoLoss(t *testing.T) {
	headers := []string{
		"From: a\r\n", "To: b\r\n", "Subject: s\r\n",
		"X-Extra: 1\r\n", "X-Other: 2\r\n",
	}
	got := reorderByDkimList(headers, []string{"Subject", "From"})
	if len(got) != len(headers) {
		t.Errorf("长度变化:%d→%d", len(headers), len(got))
	}
	// 元素集合等价
	sortedA := append([]string(nil), headers...)
	sortedB := append([]string(nil), got...)
	sort.Strings(sortedA)
	sort.Strings(sortedB)
	for i := range sortedA {
		if sortedA[i] != sortedB[i] {
			t.Errorf("元素丢失或重复:[%d]%q vs %q", i, sortedA[i], sortedB[i])
		}
	}
}

// ============================================================================
// Assemble 主入口
// ============================================================================

func TestAssemble_Empty(t *testing.T) {
	p := newTestPost(42)
	if got := p.Assemble(nil, true, true, "", nil); got != nil {
		t.Errorf("空输入:%v", got)
	}
}

func TestAssemble_DkimListWinsOverShuffle(t *testing.T) {
	p := newTestPost(42)
	headers := []string{
		"To: b\r\n",
		"From: a\r\n",
		"Subject: hi\r\n",
	}
	// 同时启用 shuffle 和 dkimList → dkimList 优先(不 shuffle)
	got := p.Assemble(headers, true, false, "", []string{"Subject", "From", "To"})
	// 输入无顶部锚定头 → 直接按 dkimList 顺序
	want := []string{"Subject: hi\r\n", "From: a\r\n", "To: b\r\n"}
	for i := range want {
		if got[i] != want[i] {
			t.Errorf("[%d]:got=%q, want=%q", i, got[i], want[i])
		}
	}
}

func TestAssemble_ShuffleOnly(t *testing.T) {
	p := newTestPost(42)
	headers := []string{
		"X-A: 1\r\n", "X-B: 2\r\n", "X-C: 3\r\n",
		"From: a\r\n", "To: b\r\n",
	}
	got := p.Assemble(headers, true, false, "", nil)
	if len(got) != len(headers) {
		t.Errorf("长度:%d→%d", len(headers), len(got))
	}
	// From/To 锚定,应按 priority 顺序
	posFrom := findIdx(got, "From:")
	posTo := findIdx(got, "To:")
	if posFrom >= posTo {
		t.Errorf("From 应在 To 之前:From=%d To=%d", posFrom, posTo)
	}
}

func TestAssemble_RandomCaseOnly(t *testing.T) {
	p := newTestPost(42)
	headers := []string{"From: a\r\n", "To: b\r\n"}
	origLen := len(headers)
	got := p.Assemble(headers, false, true, "", nil)
	if len(got) != origLen {
		t.Errorf("长度:%d", len(got))
	}
	// 至少 1 项字段名 case 变化(FixedSource(42) 稳定)
	changed := 0
	origInputs := []string{"From: a\r\n", "To: b\r\n"}
	for i := range origInputs {
		if got[i] != origInputs[i] {
			changed++
		}
	}
	if changed == 0 {
		t.Errorf("randomCase 应改动至少 1 项:%v", got)
	}
}

func TestAssemble_BothShuffleAndRandomCase(t *testing.T) {
	p := newTestPost(42)
	headers := []string{
		"From: a\r\n", "To: b\r\n", "X-Custom: c\r\n",
	}
	got := p.Assemble(headers, true, true, "", nil)
	if len(got) != len(headers) {
		t.Errorf("长度:%d", len(got))
	}
	// From 应在 To 之前(锚定还生效,即使 case 已随机)
	posFrom := findEqualFoldIdx(got, "from:")
	posTo := findEqualFoldIdx(got, "to:")
	if posFrom >= posTo {
		t.Errorf("From/To 锚定失效:From=%d To=%d", posFrom, posTo)
	}
}

// ============================================================================
// 复现性
// ============================================================================

func TestAssemble_Reproducibility(t *testing.T) {
	makeInput := func() []string {
		return []string{
			"From: a\r\n", "To: b\r\n", "X-A: 1\r\n",
			"X-B: 2\r\n", "Subject: hi\r\n",
		}
	}
	p1 := newTestPost(42)
	p2 := newTestPost(42)
	out1 := p1.Assemble(makeInput(), true, true, "", nil)
	out2 := p2.Assemble(makeInput(), true, true, "", nil)
	if len(out1) != len(out2) {
		t.Fatalf("长度不同:%d vs %d", len(out1), len(out2))
	}
	for i := range out1 {
		if out1[i] != out2[i] {
			t.Errorf("[%d]:%q vs %q", i, out1[i], out2[i])
		}
	}
}

// ============================================================================
// 辅助
// ============================================================================

func findIdx(headers []string, prefix string) int {
	for i, h := range headers {
		if strings.HasPrefix(h, prefix) {
			return i
		}
	}
	return -1
}

func findEqualFoldIdx(headers []string, prefixLower string) int {
	for i, h := range headers {
		colon := strings.IndexByte(h, ':')
		if colon <= 0 {
			continue
		}
		name := strings.ToLower(strings.TrimSpace(h[:colon])) + ":"
		if name == prefixLower {
			return i
		}
	}
	return -1
}
