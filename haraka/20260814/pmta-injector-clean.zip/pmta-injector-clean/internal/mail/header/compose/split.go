package compose

import "strings"

// SplitHeaderBlock 把多个连续的邮件头(字符串块)按 RFC 5322 §2.2.3 折叠规则切成单条
//
// 【契约】v2 与 v1 email/headers_postprocess.go::splitHeaderBlock 语义完全一致
//
// 【导出】v2 export 为公共 API(v1 是包内私有 splitHeaderBlock)—— Week 5 builder
// 需要在拼装 raw email 时调用本函数把 header block 切成 []string 再传给 Assemble
//
// 【规则】续行(以 SP / TAB 开头的行)归属上一个头
//
// 【输入示例】(block):
//
//	"Received: from xxx\r\n (Authenticated...)\r\n by yyy\r\nFrom: a@b\r\n"
//
// 【输出】
//
//	["Received: from xxx\r\n (Authenticated...)\r\n by yyy\r\n", "From: a@b\r\n"]
//
// 【边界处理】
//   - 空字符串 → nil
//   - 末尾没有 \r\n 也能正确切分(SplitAfter 保留分隔符;无分隔符行原样保留)
//   - 多个连续空行不合并(空行不归属任何头,直接丢弃)
func SplitHeaderBlock(block string) []string {
	if block == "" {
		return nil
	}
	// SplitAfter("\n") 保留 \n;"\r\n" 切分后每行末尾 = "\r\n";单 \n 行末尾 = "\n"
	lines := strings.SplitAfter(block, "\n")
	result := make([]string, 0, 16)
	var current strings.Builder
	for _, line := range lines {
		if line == "" {
			continue
		}
		// 空白行不参与累积也不分隔(罕见,但要兼容)
		if strings.TrimRight(line, "\r\n") == "" {
			continue
		}
		if current.Len() == 0 {
			current.WriteString(line)
			continue
		}
		// 折叠续行:首字符是 SP / TAB
		first := line[0]
		if first == ' ' || first == '\t' {
			current.WriteString(line)
		} else {
			result = append(result, current.String())
			current.Reset()
			current.WriteString(line)
		}
	}
	if current.Len() > 0 {
		result = append(result, current.String())
	}
	return result
}

// extractFieldName 从一个完整 header 条目("Name: value\r\n..." 含可能的折叠续行)提取字段名(小写)
//
// 【契约】v2 与 v1 email/headers_postprocess.go::extractFieldName 语义完全一致
//
// 【返回空串场景】
//   - 空输入
//   - 续行(SP/TAB 开头,理论上不会传入,但防御性处理)
//   - 无冒号
//
// 【小写规范化】用 strings.ToLower + TrimSpace(与锚定/配对识别用 EqualFold 的语义一致)
func extractFieldName(line string) string {
	if line == "" {
		return ""
	}
	if line[0] == ' ' || line[0] == '\t' {
		return ""
	}
	colon := strings.IndexByte(line, ':')
	if colon <= 0 {
		return ""
	}
	return strings.ToLower(strings.TrimSpace(line[:colon]))
}
