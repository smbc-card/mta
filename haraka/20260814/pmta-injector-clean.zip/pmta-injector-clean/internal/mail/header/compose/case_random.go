package compose

import (
	"strings"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// caseSkipNames 字段名大小写随机化的跳过集合(全小写比对)
//
// 【契约】v2 与 v1 email/headers_postprocess.go::caseSkipNames 完全一致
//
// 【设计】两个工程(PowerMTA / Haraka)共用同一份名单(联合集),保字节级一致
//   - dkim-signature   : DKIM simple canonicalization 字节比较兼容
//   - x-virtual-mta    : PowerMTA 控制头(Haraka 路径下永远不会出现)
//   - x-job            : 同上
//   - x-internal-ccbcc-skip-tg : Haraka log_delivered.js 插件依赖精确字段名扫描
//     (PowerMTA 路径下永远不会出现,由 SkipTelegram 字段控制)
var caseSkipNames = map[string]struct{}{
	"dkim-signature":           {},
	"x-virtual-mta":            {},
	"x-job":                    {},
	"x-internal-ccbcc-skip-tg": {},
}

// randomizeFieldName 把一个 header 条目的字段名(":" 之前)逐字符随机大小写
//
// 【契约】v2 与 v1 email/headers_postprocess.go::randomizeFieldName 语义完全一致
//
// 【行为】
//   - 跳过 caseSkipNames(dkim-signature / x-virtual-mta / x-job / x-internal-ccbcc-skip-tg)
//   - 值部分(冒号之后,包括折叠续行)完全不动
//   - 续行(SP/TAB 开头)原样返回
//   - 非字母字符(数字 / -  / .)保持原样,不参与翻转
//
// 【50/50 翻转】用 rng.Intn(2) == 0 决定大写 or 小写
func randomizeFieldName(line string, rng random.Source) string {
	if line == "" || line[0] == ' ' || line[0] == '\t' {
		return line
	}
	colon := strings.IndexByte(line, ':')
	if colon <= 0 {
		return line
	}
	name := line[:colon]
	if _, skip := caseSkipNames[strings.ToLower(strings.TrimSpace(name))]; skip {
		return line
	}
	var sb strings.Builder
	sb.Grow(len(line))
	for i := 0; i < len(name); i++ {
		ch := name[i]
		isLower := ch >= 'a' && ch <= 'z'
		isUpper := ch >= 'A' && ch <= 'Z'
		if !isLower && !isUpper {
			// 数字、连字符 -、点 . 等保持原样
			sb.WriteByte(ch)
			continue
		}
		if rng.Intn(2) == 0 {
			// 取大写
			if isLower {
				sb.WriteByte(ch - 32)
			} else {
				sb.WriteByte(ch)
			}
		} else {
			// 取小写
			if isUpper {
				sb.WriteByte(ch + 32)
			} else {
				sb.WriteByte(ch)
			}
		}
	}
	// 拼上 ":" 及后续(包括所有折叠续行)
	sb.WriteString(line[colon:])
	return sb.String()
}

// applyCaseRandomization 对整个 headers 切片做字段名大小写随机化(就地修改)
//
// 【契约】v2 与 v1 email/headers_postprocess.go::applyCaseRandomization 语义完全一致
//
// 【副作用】就地修改输入切片(返回同一切片,方便链式)
// 【caseMode 预留】未来可扩展 "stylepool"(真实风格池)等;目前只走 "random" 路径
func applyCaseRandomization(headers []string, rng random.Source, caseMode string) []string {
	_ = caseMode // 预留切换点
	if len(headers) == 0 {
		return headers
	}
	for i, h := range headers {
		headers[i] = randomizeFieldName(h, rng)
	}
	return headers
}
