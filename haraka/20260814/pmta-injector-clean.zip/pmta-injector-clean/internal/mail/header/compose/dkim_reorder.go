package compose

import "strings"

// reorderByDkimList 按 dkimList 顺序重排 headers,保留顶部锚定头不动(方案 D)
//
// 【契约】v2 与 v1 email/headers_postprocess.go::reorderByDkimList 语义完全一致
//
// 【方案 D 动机】让 Go 端邮件里 header 按用户 UI 选的 DKIM h= 字段顺序输出。
// PMTA 5.0r8 收到邮件后**按邮件里 header 出现顺序生成 DKIM-Signature 的 h=**,
// 所以最终收件方看到的 h= 顺序 = 用户 UI 选的顺序(如"日本 SoftBank 风格")。
//
// 【算法】
//  1. 分离"顶部锚定头"(x-virtual-mta / x-job / Received-* / DKIM-Signature 方案 B 伪签)
//     — 这些必须保持在顶,不能被 dkim 排序影响(PMTA 控制头 / 时序头 / 伪签头)
//  2. 按 dkimList 顺序,把邮件里能匹配的字段放进 dkimSlots[]
//     — 大小写不敏感匹配(strings.ToLower 比对)
//     — dkimList 里有但邮件没的字段:该 slot 保持空(输出时跳过,不影响)
//     — 邮件里有但 dkimList 没的字段:进 others 池
//  3. 输出 = 顶部锚定头 + dkimSlots(去空) + others(保持原相对顺序)
//
// 【不变量】
//   - len(output) == len(input)(不丢头)
//   - 每个输入头精确出现一次(不重复)
//   - 顶部锚定头顺序不变
//   - dkimList 里未匹配的 slot 不占位(输出时跳过)
//
// 【边界】
//   - dkimList 为空 → 返回原 headers 不变
//   - headers 为空 → 返回原空切片
//   - dkimList 里全空白 → 返回原 headers(防御性)
//   - dkimList 里有 "x-virtual-mta"(用户手改配置) → 顶部锚定优先,不进 dkimSlots
func reorderByDkimList(headers []string, dkimList []string) []string {
	if len(headers) == 0 || len(dkimList) == 0 {
		return headers
	}

	// 顶部锚定头名单(小写比对):PMTA 控制头 + 时序头 + Go 端方案 B 伪 DKIM
	// 与 shuffleHeadersWithAnchors 里 anchorPriority 表前 3 类保持一致
	topAnchorNames := map[string]struct{}{
		"x-virtual-mta":  {},
		"x-job":          {},
		"dkim-signature": {}, // 方案 B 伪 DKIM(生成在 mainHeaders 里,不是 PMTA 加的真 DKIM)
	}

	// 建 dkim 字段名 → list 位置的映射(大小写不敏感 + 去空白)
	// 若 dkimList 内含重复,后者覆盖前者(最后一次匹配的字段占位)
	dkimIndex := make(map[string]int, len(dkimList))
	for i, name := range dkimList {
		key := strings.ToLower(strings.TrimSpace(name))
		if key == "" {
			continue
		}
		dkimIndex[key] = i
	}
	if len(dkimIndex) == 0 {
		// 全是空/空白 → 返回原 headers,防御性
		return headers
	}

	topAnchors := make([]string, 0, 8)
	dkimSlots := make([]string, len(dkimList)) // 按 dkimList 位置填充
	others := make([]string, 0, len(headers))

	for _, h := range headers {
		name := extractFieldName(h)
		if name == "" {
			// 异常条目(无字段名 / 续行 line)→ 放入 others 保守处理
			others = append(others, h)
			continue
		}
		// 顶部锚定头
		if _, isTop := topAnchorNames[name]; isTop {
			topAnchors = append(topAnchors, h)
			continue
		}
		if strings.HasPrefix(name, "received") {
			topAnchors = append(topAnchors, h)
			continue
		}
		// 在 dkim list 里的字段 → 放对应 slot
		if idx, ok := dkimIndex[name]; ok {
			dkimSlots[idx] = h
			continue
		}
		// 其他头
		others = append(others, h)
	}

	// 组装输出:topAnchors(保原序) + dkimSlots(按 list 顺序,跳过空 slot) + others(保原序)
	result := make([]string, 0, len(headers))
	result = append(result, topAnchors...)
	for _, h := range dkimSlots {
		if h != "" {
			result = append(result, h)
		}
	}
	result = append(result, others...)
	return result
}
