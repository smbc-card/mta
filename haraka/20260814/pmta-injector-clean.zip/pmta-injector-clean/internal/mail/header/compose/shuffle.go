package compose

import (
	"sort"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// anchorPriority 温和锚定模式下,定位每类头到固定 priority(越小越靠前)
//
// 【契约】v2 与 v1 email/headers_postprocess.go::anchorPriority 完全一致
//
// 【注意】"received" 是前缀匹配("Received:" 包括所有 ESP Received / Random Received / 原始 Received)
// 其它头是精确匹配
//
// 【2026-06-01 第三轮自检修复】mime-version 从 prio 3 改为 prio 10:
//
//	原因:builder.go::buildRawEmail 中 MIME-Version 是在 Message-ID 之后 append 的,
//	      如果 anchorPriority["mime-version"]=3,启用 ShuffleOrder 时 MIME-Version 会跑到 From 之前 —
//	      与"全关(ShuffleOrder=false)时按 append 顺序输出"的行为不一致,同一发件方启用/关闭乱序
//	      会产生两类邮件特征,反垃圾聚类时可能识别。
//	修复:prio 10 让 MIME-Version 锚定在 Message-ID(prio 9)之后,两种模式输出位置一致。
var anchorPriority = map[string]int{
	"x-virtual-mta":  0,
	"x-job":          0,
	"received":       1, // 前缀
	"dkim-signature": 2,
	"from":           4,
	"to":             5,
	"cc":             6,
	"subject":        7,
	"date":           8,
	"message-id":     9,
	"mime-version":   10, // 从 3 → 10
}

// shuffleHeadersWithAnchors 锚定式乱序
//
// 【契约】v2 与 v1 email/headers_postprocess.go::shuffleHeadersWithAnchors 语义完全一致
//
// 【算法】
//  1. 分离锚定头(anchorPriority 命中)和可乱序头
//  2. 把 List-Unsubscribe-Post 从可乱序池暂时分离(独立处理)
//  3. Fisher-Yates 洗牌可乱序池
//  4. 找 List-Unsubscribe 位置,后面插回 List-Unsubscribe-Post(若 LU 不存在则追加到末尾)
//  5. 锚定头按 priority 升序排,priority 相同时按原始 index 升序(同 priority 保持生成顺序)
//  6. 输出 = 锚定头序列 + 洗牌后的可乱序池
//
// 【不变量】len(output) == len(input);output 元素集合 == input 元素集合(无丢失无重复)
func shuffleHeadersWithAnchors(headers []string, rng random.Source) []string {
	if len(headers) <= 1 {
		return headers
	}

	type anchoredHeader struct {
		line      string
		priority  int
		origIndex int
	}
	anchors := make([]anchoredHeader, 0, len(headers))
	pool := make([]string, 0, len(headers))
	var listUnsubPost string // 单独捕获 list-unsubscribe-post

	for i, h := range headers {
		name := extractFieldName(h)
		if name == "" {
			// 异常条目(无字段名),保守地放进可乱池
			pool = append(pool, h)
			continue
		}
		// Received 系列(包括 ESP Received / Random Received / 原始 Received)前缀匹配
		if strings.HasPrefix(name, "received") {
			anchors = append(anchors, anchoredHeader{h, anchorPriority["received"], i})
			continue
		}
		// 精确匹配
		if prio, ok := anchorPriority[name]; ok {
			anchors = append(anchors, anchoredHeader{h, prio, i})
			continue
		}
		// 特殊配对:list-unsubscribe-post 暂时拿出
		if name == "list-unsubscribe-post" {
			// 多个 Post 头理论上不会出现,但兼容性保留最后一个
			listUnsubPost = h
			continue
		}
		// 其它头进入可乱池
		pool = append(pool, h)
	}

	// Fisher-Yates 洗牌可乱池
	for i := len(pool) - 1; i > 0; i-- {
		j := rng.Intn(i + 1)
		pool[i], pool[j] = pool[j], pool[i]
	}

	// 把 list-unsubscribe-post 插回 list-unsubscribe 之后
	// 注意:list-unsubscribe 也可能在 pool 里(它不属于锚定头)
	if listUnsubPost != "" {
		insertIdx := -1
		for i, h := range pool {
			if extractFieldName(h) == "list-unsubscribe" {
				insertIdx = i + 1
				break
			}
		}
		if insertIdx >= 0 {
			// 在 pool[insertIdx] 位置插入 listUnsubPost
			newPool := make([]string, 0, len(pool)+1)
			newPool = append(newPool, pool[:insertIdx]...)
			newPool = append(newPool, listUnsubPost)
			newPool = append(newPool, pool[insertIdx:]...)
			pool = newPool
		} else {
			// 没有 List-Unsubscribe 但有 Post(异常,但兼容性处理):追加到末尾
			pool = append(pool, listUnsubPost)
		}
	}

	// 锚定头按 priority 升序;同 priority 按原 index 升序保稳定
	sort.SliceStable(anchors, func(i, j int) bool {
		if anchors[i].priority != anchors[j].priority {
			return anchors[i].priority < anchors[j].priority
		}
		return anchors[i].origIndex < anchors[j].origIndex
	})

	// 组装输出
	result := make([]string, 0, len(headers))
	for _, a := range anchors {
		result = append(result, a.line)
	}
	result = append(result, pool...)
	return result
}
