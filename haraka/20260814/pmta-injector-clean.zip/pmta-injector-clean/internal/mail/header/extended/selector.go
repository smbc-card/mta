package extended

import (
	"strings"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// 【组合寿命】当前随机组合的"使用寿命"区间:每次重抽后用 50 + rng.Intn(151) 封邮件
//
// 50 是最短(避免每封都换造成反向指纹),200 是最长(避免一组用太久全靠这几个头)
const (
	randomLifespanMin = 50
	randomLifespanGap = 151 // 上限 = Min + Gap - 1 = 200
)

// Selector 扩展邮件头生成器(per-worker 单实例)
//
// 【依赖注入】
//   - rng:随机源(P1-P3 slot 抽样 + 30 getX* 内部各种字符串池抽样)
//   - clk:时钟(X-OriginalArrivalTime 用)
//   - cfg:读 30 slot enabled 开关 + Random{Enabled,Min,Max} + 各 slot value 字段
//
// 【线程安全】非线程安全,per-worker 一个实例
//
// 【状态字段】
//   - currentSet:当前抽中的 slot 索引列表(worker 级反指纹核心)
//   - emailsLeft:当前组合还能用多少封邮件(≤0 时下封邮件触发重抽)
//   - 初始 currentSet=nil / emailsLeft=0 → 首封邮件触发首次抽样
type Selector struct {
	rng random.Source
	clk clock.Clock
	cfg *config.HeadersConfig

	currentSet []int
	emailsLeft int
}

// New 创建 Extended Selector
//
// 【参数】
//   - rng:必需
//   - clk:必需(X-OriginalArrivalTime 用)
//   - cfg:必需(nil 时 Emit* 系列返回空串)
func New(rng random.Source, clk clock.Clock, cfg *config.HeadersConfig) *Selector {
	return &Selector{
		rng:        rng,
		clk:        clk,
		cfg:        cfg,
		currentSet: nil,
		emailsLeft: 0,
	}
}

// EmitP0AndPool 生成 P0 送达率刚需头 + P1/P2/P3 随机池
//
// 【契约】v2 与 v1 email/headers.go::emitExtendedHeaders 语义一致
// (仅剥离 List-Unsubscribe / List-Unsubscribe-Post —— 由 listunsub 子包)
//
// 【返回】多行 "Header: value\r\n" 拼接;空场景返回空串
//
// 【P0 部分】(勾选了总加,不进随机池):
//   - List-ID(cfg.ListID)
//   - Feedback-ID(cfg.FeedbackID)
//   - Precedence(cfg.Precedence)
//
// 【池部分】(cfg.RandomEnabled 决定行为):
//   - RandomEnabled=false → 勾选了的全部输出(29 slot 里 enabled=true 的)
//   - RandomEnabled=true → Worker 级反指纹:
//     从候选里抽 [RandomMin, RandomMax] 个 slot,寿命 50-200 封邮件后重抽
//
// 【线程安全】非线程安全 —— 修改 s.currentSet / s.emailsLeft
func (s *Selector) EmitP0AndPool(domain string) string {
	cfg := s.cfg
	if cfg == nil {
		return ""
	}
	var sb strings.Builder

	// ----- P0 组(送达率刚需,勾了就加)-----
	if cfg.ListID {
		sb.WriteString(s.getListID(domain))
	}
	if cfg.FeedbackID {
		sb.WriteString(s.getFeedbackID(domain))
	}
	if cfg.Precedence {
		sb.WriteString(s.getPrecedence())
	}

	// ----- P1/P2/P3 池 -----
	// 收集"用户勾选了的"候选槽位索引
	candidates := make([]int, 0, len(headerSlots))
	for i, slot := range headerSlots {
		if slot.enabled(cfg) {
			candidates = append(candidates, i)
		}
	}
	if len(candidates) == 0 {
		return sb.String()
	}

	if !cfg.RandomEnabled {
		// 非随机模式:勾选了的都加
		for _, idx := range candidates {
			sb.WriteString(headerSlots[idx].generate(s, domain))
		}
		return sb.String()
	}

	// 随机模式 + worker 级反指纹:若当前组合用完寿命则重抽
	if s.emailsLeft <= 0 || len(s.currentSet) == 0 {
		s.refreshRandomHeaderSet(candidates)
	}
	s.emailsLeft--
	for _, idx := range s.currentSet {
		// 校验 idx 仍有效(用户可能在运行中改动勾选状态)
		if idx >= 0 && idx < len(headerSlots) && headerSlots[idx].enabled(cfg) {
			sb.WriteString(headerSlots[idx].generate(s, domain))
		}
	}
	return sb.String()
}

// 【8 定值 method 已迁移到 defaults.go】
// ReplyTo / ReturnPath / XMailer / XPriority / Importance / AcceptLanguage / ContentLanguage
