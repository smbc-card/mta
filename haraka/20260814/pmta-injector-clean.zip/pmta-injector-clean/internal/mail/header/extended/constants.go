package extended

// ============================================================================
// 【小字符串池】P0/P1/P2/P3 各 slot 内部的 choice 池,原样搬 v1 硬编码常量
// ============================================================================

// P0 Feedback-ID 类别池(4 条)
var feedbackCategories = []string{"newsletter", "promo", "tx", "campaign"}

// P0 Precedence 值池(4 条)
var precedenceChoices = []string{"bulk", "list", "auto_reply", "junk"}

// P1 Sender 前缀池(6 条)
var senderPrefixes = []string{"noreply", "mailer", "no-reply", "info", "newsletter", "notify"}

// P1 Organization 名称池(12 条)
var organizationNames = []string{
	"Customer Service", "Marketing Department", "Notifications",
	"Mail Service", "Newsletter Team", "Support Team",
	"Communications", "Member Services", "Contact Center",
	"Online Service", "Account Service", "Promotions",
}

// P1 Comments 值池(6 条)
var commentsChoices = []string{
	"Authenticated sender",
	"Mass mailer notification",
	"Subscriber notification",
	"Promotional email",
	"Automated delivery",
	"Transactional notification",
}

// P1 Keywords 值池(6 条)
var keywordsChoices = []string{
	"newsletter, promotion",
	"notification, account",
	"marketing, offer",
	"announcement, update",
	"transactional",
	"campaign, news",
}

// P2 X-MSMail-Priority 值池(3 条)
var xMSMailPriorityChoices = []string{"High", "Normal", "Low"}

// P2 Thread-Topic 值池(7 条)
var threadTopics = []string{
	"Information",
	"Notification",
	"Important Update",
	"Newsletter",
	"Service Update",
	"Account Activity",
	"Subscription",
}

// P2 X-Auto-Response-Suppress 值池(6 条)
var autoResponseSuppressChoices = []string{"OOF", "AutoReply", "All", "DR", "NRN", "RN"}

// P2 Return-Receipt-To 前缀池(3 条)
var returnReceiptPrefixes = []string{"noreply", "receipt", "delivery"}

// P2 Disposition-Notification-To 前缀池(3 条)
var dispositionNotificationPrefixes = []string{"noreply", "read-receipt", "notification"}

// P0 List-ID 前缀池(6 条)
var listIDPrefixes = []string{"newsletter", "promo", "notification", "list", "campaign", "updates"}

// 方案 B X-Originating-Email 前缀池(5 条)
var xOriginatingEmailPrefixes = []string{"noreply", "sender", "mailer", "notify", "info"}

// 方案 B X-MimeOLE 版本池(6 条)
var xMimeOLEVersions = []string{
	"Produced By Microsoft MimeOLE V6.00.2900.6157",
	"Produced By Microsoft MimeOLE V6.00.2900.6109",
	"Produced By Microsoft MimeOLE V6.00.2900.3138",
	"Produced By Microsoft MimeOLE V6.00.2900.2180",
	"Produced By Microsoft Exchange V14.0.694.0",
	"Produced By Microsoft Exchange V15.0.4569.1503",
}

// 方案 B X-Mailer-Version 池(6 条)
var xMailerVersions = []string{
	"16.0.5505.1000",   // Office 2016/365
	"15.0.4569.1503",   // Office 2013
	"14.0.7268.5000",   // Office 2010
	"12.0.6612.1000",   // Office 2007
	"16.0.16327.20214", // Office 365 较新
	"16.0.14931.20648", // Office 365 中等
}

// X-OriginalArrivalTime 月份缩写(3 字母,Jan..Dec)
var monthAbbrevs = []string{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}

// 定值 method:Accept-Language / Content-Language 语言池(5 条)
var languageChoices = []string{"ja", "en", "ja-JP", "en-US", "zh-CN"}

// 定值 method:X-Priority 数值池(3 条)
var xPriorityRandomChoices = []string{"1", "2", "3"}

// 定值 method:Importance 值池(3 条)
var importanceRandomChoices = []string{"high", "normal", "low"}

// ============================================================================
// 【静态字符串】v1 里以字符串常量出现的 slot 值
// ============================================================================

// P1 静态:Auto-Submitted 头(单一固定值)
const staticAutoSubmitted = "Auto-Submitted: auto-generated\r\n"

// P1 静态:X-CSA-Complaints 头(单一固定值,来自 eco.de 白名单)
const staticXCSAComplaints = "X-CSA-Complaints: whitelist-complaints@eco.de\r\n"
