package extended

import (
	"__MODULE_PLACEHOLDER__/internal/config"
)

// headerSlot 一个候选随机槽位(独立头 = 1 个头;联动组 = 多个头)
//
// 【契约】v2 与 v1 email/headers.go::headerSlot 语义一致
type headerSlot struct {
	enabled  func(cfg *config.HeadersConfig) bool
	generate func(s *Selector, domain string) string
}

// headerSlots 29 项候选池注册表(**顺序敏感,索引稳定**)
//
// 【契约】v2 与 v1 email/headers.go::extendedHeaderSlots 顺序完全一致
//
// 【P17 硬约束】不能改顺序 —— currentSet[]int 存的是索引,顺序换了会导致同一 worker
// 记忆的组合漂移(反指纹语义崩溃)
//
// 【29 slot 分布】
//   - P1(0..8):9 slot
//   - P2 Outlook(9..12):4 slot
//   - P2 行为(13..15):3 slot
//   - P3 营销(16..18):3 slot
//   - P3 联动组(19..24):6 slot
//   - 方案 B 独立(25..28):4 slot
//
// 【List-ID 不在本表】—— List-ID 是 P0(总加),由 EmitP0AndPool 直调 getListID
var headerSlots = []headerSlot{
	// ===== P1(9 slot,0..8)=====
	{func(c *config.HeadersConfig) bool { return c.ErrorsTo }, func(s *Selector, d string) string { return s.getErrorsTo(d) }},
	{func(c *config.HeadersConfig) bool { return c.Sender }, func(s *Selector, d string) string { return s.getSender(d) }},
	{func(c *config.HeadersConfig) bool { return c.Organization }, func(s *Selector, _ string) string { return s.getOrganization() }},
	{func(c *config.HeadersConfig) bool { return c.XOriginatingIP }, func(s *Selector, _ string) string { return s.getXOriginatingIP() }},
	{func(c *config.HeadersConfig) bool { return c.AutoSubmitted }, func(_ *Selector, _ string) string { return staticAutoSubmitted }},
	{func(c *config.HeadersConfig) bool { return c.Comments }, func(s *Selector, _ string) string { return s.getComments() }},
	{func(c *config.HeadersConfig) bool { return c.Keywords }, func(s *Selector, _ string) string { return s.getKeywords() }},
	{func(c *config.HeadersConfig) bool { return c.XReportAbuse }, func(s *Selector, d string) string { return s.getXReportAbuse(d) }},
	{func(c *config.HeadersConfig) bool { return c.XCSAComplaints }, func(_ *Selector, _ string) string { return staticXCSAComplaints }},

	// ===== P2 Outlook(4 slot,9..12)=====
	{func(c *config.HeadersConfig) bool { return c.XMSMailPriority }, func(s *Selector, _ string) string { return s.getXMSMailPriority() }},
	{func(c *config.HeadersConfig) bool { return c.ThreadIndex }, func(s *Selector, _ string) string { return s.getThreadIndex() }},
	{func(c *config.HeadersConfig) bool { return c.ThreadTopic }, func(s *Selector, _ string) string { return s.getThreadTopic() }},
	{func(c *config.HeadersConfig) bool { return c.XAutoResponseSuppress }, func(s *Selector, _ string) string { return s.getXAutoResponseSuppress() }},

	// ===== P2 行为(3 slot,13..15)=====
	{func(c *config.HeadersConfig) bool { return c.ReturnReceiptTo }, func(s *Selector, d string) string { return s.getReturnReceiptTo(d) }},
	{func(c *config.HeadersConfig) bool { return c.DispositionNotificationTo }, func(s *Selector, d string) string { return s.getDispositionNotificationTo(d) }},
	{func(c *config.HeadersConfig) bool { return c.XEntityRefID }, func(s *Selector, _ string) string { return "X-Entity-Ref-ID: " + randomGUID(s.rng) + "\r\n" }},

	// ===== P3 营销(3 slot,16..18)=====
	{func(c *config.HeadersConfig) bool { return c.XCampaignID }, func(s *Selector, _ string) string { return s.getXCampaignID() }},
	{func(c *config.HeadersConfig) bool { return c.XMailerLID }, func(s *Selector, _ string) string { return s.getXMailerLID() }},
	{func(c *config.HeadersConfig) bool { return c.CampaignID }, func(s *Selector, _ string) string { return s.getCampaignID() }},

	// ===== P3 联动组(6 slot,19..24)=====
	{func(c *config.HeadersConfig) bool { return c.XTMASGroup }, func(s *Selector, _ string) string { return s.getXTMASGroup() }},
	{func(c *config.HeadersConfig) bool { return c.XSFMCGroup }, func(s *Selector, _ string) string { return s.getXSFMCGroup() }},
	{func(c *config.HeadersConfig) bool { return c.XBarracudaGroup }, func(s *Selector, _ string) string { return s.getXBarracudaGroup() }},
	{func(c *config.HeadersConfig) bool { return c.XProofpointGroup }, func(s *Selector, _ string) string { return s.getXProofpointGroup() }},
	{func(c *config.HeadersConfig) bool { return c.XMimecastGroup }, func(s *Selector, _ string) string { return s.getXMimecastGroup() }},
	{func(c *config.HeadersConfig) bool { return c.XSymantecGroup }, func(s *Selector, _ string) string { return s.getXSymantecGroup() }},

	// ===== 方案 B 独立(4 slot,25..28)=====
	{func(c *config.HeadersConfig) bool { return c.XOriginatingEmail }, func(s *Selector, d string) string { return s.getXOriginatingEmail(d) }},
	{func(c *config.HeadersConfig) bool { return c.XMimeOLE }, func(s *Selector, _ string) string { return s.getXMimeOLE() }},
	{func(c *config.HeadersConfig) bool { return c.XMailerVersion }, func(s *Selector, _ string) string { return s.getXMailerVersion() }},
	{func(c *config.HeadersConfig) bool { return c.XOriginalArrivalTime }, func(s *Selector, _ string) string { return s.getXOriginalArrivalTime() }},
}

// refreshRandomHeaderSet 重抽一组随机邮件头组合(Worker 级反指纹核心)
//
// 【契约】v2 与 v1 email/headers.go::refreshRandomHeaderSet 语义完全一致
//
// 【算法】
//  1. 校验 + 修正 [RandomMin, RandomMax]:1 ≤ min ≤ max ≤ 10 且 ≤ len(candidates)
//  2. 抽样数 n ∈ [rmin, rmax]
//  3. Fisher-Yates 部分洗牌:从 candidates 抽 n 个无重复
//  4. 更新 currentSet + emailsLeft(50 + Intn(151) = 50..200 封寿命)
//
// 【副作用】直接修改 s.currentSet 和 s.emailsLeft
func (s *Selector) refreshRandomHeaderSet(candidates []int) {
	if len(candidates) == 0 {
		s.currentSet = nil
		s.emailsLeft = 0
		return
	}

	rmin := s.cfg.RandomMin
	rmax := s.cfg.RandomMax
	if rmin < 1 {
		rmin = 1
	}
	if rmax > 10 {
		rmax = 10
	}
	if rmax < rmin {
		rmax = rmin
	}
	if rmin > len(candidates) {
		rmin = len(candidates)
	}
	if rmax > len(candidates) {
		rmax = len(candidates)
	}

	var n int
	if rmin == rmax {
		n = rmin
	} else {
		n = rmin + s.rng.Intn(rmax-rmin+1)
	}
	if n > len(candidates) {
		n = len(candidates)
	}
	if n < 0 {
		n = 0
	}

	// Fisher-Yates 部分洗牌:从 candidates 抽 n 个无重复
	pool := make([]int, len(candidates))
	copy(pool, candidates)
	for i := 0; i < n; i++ {
		j := i + s.rng.Intn(len(pool)-i)
		pool[i], pool[j] = pool[j], pool[i]
	}
	chosen := make([]int, n)
	copy(chosen, pool[:n])

	s.currentSet = chosen
	s.emailsLeft = randomLifespanMin + s.rng.Intn(randomLifespanGap)
}
