package extended

import (
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/clock"
)

// ============================================================================
// P3 联动组(6 slot):每个开关 → 多个头一致输出
// v1 email/headers.go::getXTMASGroup / getXSFMCGroup / getXBarracudaGroup /
// getXProofpointGroup / getXMimecastGroup / getXSymantecGroup
//
// 【设计原则】真实场景下这些头必成组出现,缺任一个反向暴露伪造
// ============================================================================

// getXTMASGroup Trend Micro IMSS 扫描产物(6 头一致)
//
// 【契约】v2 与 v1 email/headers.go::getXTMASGroup 语义一致
//
// 【6 头】X-TM-AS-GCONF / X-TM-AS-Product-Ver / X-TMASE-Version / X-TMASE-Result /
// X-TMASE-MatchedRID / X-TMASE-SNAP-Result
func (s *Selector) getXTMASGroup() string {
	// 版本字符串固定一致(真实 Trend Micro 出站也这样)
	productVer := "IMSS-9.1.0.1195-8.1.0.1062-29286.002"

	// GCONF:90% 是 "00",10% 是 "01"
	gconf := "00"
	if s.rng.Intn(10) == 0 {
		gconf = "01"
	}

	// X-TMASE-Result:5.0-10.0 随机浮点分数
	score := 5.0 + s.rng.Float64()*5.0

	// MatchedRID:多行 base64(256 字节 → ~344 base64 字符,72 字符/行折)
	matchedRID := randomBase64Multiline(s.rng, 256)

	// SNAP-Result:1.{6}.{4}-0-1-{N}:0,{M}:0,{K}:0-0
	snap1 := 800000 + s.rng.Intn(200000)
	snap2 := s.rng.Intn(10000)
	snapN := 1 + s.rng.Intn(50)
	snapM := 1 + s.rng.Intn(50)
	snapK := 1 + s.rng.Intn(50)

	return fmt.Sprintf("X-TM-AS-GCONF: %s\r\n", gconf) +
		fmt.Sprintf("X-TM-AS-Product-Ver: %s\r\n", productVer) +
		fmt.Sprintf("X-TMASE-Version: %s\r\n", productVer) +
		fmt.Sprintf("X-TMASE-Result: 10--%.6f-10.000000\r\n", score) +
		fmt.Sprintf("X-TMASE-MatchedRID: %s\r\n", matchedRID) +
		fmt.Sprintf("X-TMASE-SNAP-Result: 1.%d.%04d-0-1-%d:0,%d:0,%d:0-0\r\n",
			snap1, snap2, snapN, snapM, snapK)
}

// getXSFMCGroup Salesforce Marketing Cloud 出站(2 头一致)
//
// 【契约】v2 与 v1 email/headers.go::getXSFMCGroup 语义一致
// 【2 头】X-SFMC-Stack + x-job
func (s *Selector) getXSFMCGroup() string {
	stack := 1 + s.rng.Intn(7) // 1-7
	job1 := 7000000 + s.rng.Intn(1000000)
	job2 := 2000000 + s.rng.Intn(1000000)
	return fmt.Sprintf("X-SFMC-Stack: %d\r\n", stack) +
		fmt.Sprintf("x-job: %d_%d\r\n", job1, job2)
}

// getXBarracudaGroup Barracuda Email Security Gateway 出站(6 头一致)
//
// 【契约】v2 与 v1 email/headers.go::getXBarracudaGroup 语义一致
// 【6 头】X-Barracuda-Connect / Start-Time / URL / Apparent-Source-IP / Spam-Score / Spam-Status
//
// 【时间】Start-Time 用 clk.Now().Unix()(v2 差异:v1 用 time.Now();复现性策略)
func (s *Selector) getXBarracudaGroup() string {
	connectDomain := generateRandomDomain(s.rng)
	connectIP := generateRandomIPRealistic(s.rng)
	sourceIP := generateRandomIPRealistic(s.rng)
	startTime := s.clkOrSystem().Now().Unix()
	port := 8000 + s.rng.Intn(1000)
	spamScore := s.rng.Float64() * 2.0
	scanTimeFrac := s.rng.Intn(100)

	return fmt.Sprintf("X-Barracuda-Connect: %s[%s]\r\n", connectDomain, connectIP) +
		fmt.Sprintf("X-Barracuda-Start-Time: %d\r\n", startTime) +
		fmt.Sprintf("X-Barracuda-URL: https://%s:%d/cgi-mod/markup.cgi\r\n", connectIP, port) +
		fmt.Sprintf("X-Barracuda-Apparent-Source-IP: %s\r\n", sourceIP) +
		fmt.Sprintf("X-Barracuda-Spam-Score: %.2f\r\n", spamScore) +
		fmt.Sprintf("X-Barracuda-Spam-Status: No, SCORE=%.2f using global-scores tests=BSF_SC0_MISMATCH_TO autolearn=disabled scantime=0.%02d\r\n",
			spamScore, scanTimeFrac)
}

// getXProofpointGroup Proofpoint Protection Server 出站(4 头一致)
//
// 【契约】v2 与 v1 email/headers.go::getXProofpointGroup 语义一致
// 【4 头】X-Proofpoint-Virus-Version / Spam-Details / GUID / ORIG-GUID
func (s *Selector) getXProofpointGroup() string {
	engineMain := 10000 + s.rng.Intn(1000)
	engineSub1 := 100 + s.rng.Intn(900)
	engineSub2 := 100 + s.rng.Intn(900)
	score := s.rng.Intn(101)
	suspect := s.rng.Intn(21)
	guid := strings.ToUpper(randomHex(s.rng, 32))
	origGuid := strings.ToUpper(randomHex(s.rng, 32))

	return fmt.Sprintf("X-Proofpoint-Virus-Version: vendor=fsecure engine=2.50.%d:6.0.%d, 1.0.%d, db=signed\r\n",
		engineMain, engineSub1, engineSub2) +
		fmt.Sprintf("X-Proofpoint-Spam-Details: rule=outbound_notspam policy=outbound score=%d suspectscore=%d spamscore=0 malwarescore=0 phishscore=0 lowpriorityscore=0 mlxscore=0 adultscore=0 mlxlogscore=0 classifier=spam adjust=0 reason=mlx scancount=1 engineversion=8.0.1-2202160000 definitions=main-2202170025\r\n",
			score, suspect) +
		fmt.Sprintf("X-Proofpoint-GUID: %s\r\n", guid) +
		fmt.Sprintf("X-Proofpoint-ORIG-GUID: %s\r\n", origGuid)
}

// getXMimecastGroup Mimecast 邮件安全网关出站(4 头一致)
//
// 【契约】v2 与 v1 email/headers.go::getXMimecastGroup 语义一致
// 【4 头】Spam-Score / Spam-Signature / Bulk-Signature / Impersonation-Protect
func (s *Selector) getXMimecastGroup() string {
	score := s.rng.Float64() * 10.0
	spamSig := randomBase64(s.rng, 24)
	bulkSig := randomHex(s.rng, 32)

	return fmt.Sprintf("X-Mimecast-Spam-Score: %.2f\r\n", score) +
		fmt.Sprintf("X-Mimecast-Spam-Signature: %s\r\n", spamSig) +
		fmt.Sprintf("X-Mimecast-Bulk-Signature: %s\r\n", bulkSig) +
		"X-Mimecast-Impersonation-Protect: Policy=Outbound; Similar Internal Domain=false; Similar Monitored External Domain=false; Custom External Domain=false; Mimecast External Domain=false; Newly Observed Domain=false; Internal User Name=false; Reply-to Address Mismatch=false; Targeted Threat Dictionary=false; Mimecast Threat Dictionary=false; Custom Threat Dictionary=false\r\n"
}

// getXSymantecGroup Symantec MessageLabs(CMAE)出站(4 头一致)
//
// 【契约】v2 与 v1 email/headers.go::getXSymantecGroup 语义一致
// 【4 头】X-CMAE-Score / X-CMAE-Analysis / X-MessageSniffer-Scan-Result / X-MessageSniffer-Rules
func (s *Selector) getXSymantecGroup() string {
	cmaeScore := s.rng.Float64() * 3.0
	cv := randomBase64(s.rng, 24)
	c := 100 + s.rng.Intn(100)
	a := randomHex(s.rng, 32)
	rulesN := s.rng.Intn(10)
	rulesM := s.rng.Intn(10)

	return fmt.Sprintf("X-CMAE-Score: %.2f\r\n", cmaeScore) +
		fmt.Sprintf("X-CMAE-Analysis: v=2.4 cv=%s c=%d a=%s\r\n", cv, c, a) +
		"X-MessageSniffer-Scan-Result: 0\r\n" +
		fmt.Sprintf("X-MessageSniffer-Rules: 0-0-0-%d-%d\r\n", rulesN, rulesM)
}

// clkOrSystem 兜底:s.clk 为 nil 时返回系统时钟(测试防御)
//
// 【正常路径】s.clk 由 New(rng, clk, cfg) 传入,不应 nil
// 【兜底】若某测试路径直接构造 Selector{} 未传 clk,不至于 panic
func (s *Selector) clkOrSystem() clock.Clock {
	if s.clk != nil {
		return s.clk
	}
	return clock.NewSystemClock()
}
