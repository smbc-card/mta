package extended

import "fmt"

// ============================================================================
// 方案 B 4 个新独立头(不含 List-ID,List-ID 在 p0.go)
// v1 email/headers.go::getXOriginatingEmail / getXMimeOLE / getXMailerVersion /
// getXOriginalArrivalTime
// ============================================================================

// getXOriginatingEmail 生成 X-Originating-Email 头
//
// 【契约】v2 与 v1 email/headers.go::getXOriginatingEmail 语义一致
// 【格式】X-Originating-Email: [{prefix}@{domain}]\r\n
// 【设计】与 X-Originating-IP 配对(早期 Hotmail/Yahoo 出站这俩一起出现)
func (s *Selector) getXOriginatingEmail(domain string) string {
	prefix := xOriginatingEmailPrefixes[s.rng.Intn(len(xOriginatingEmailPrefixes))]
	return fmt.Sprintf("X-Originating-Email: [%s@%s]\r\n", prefix, domain)
}

// getXMimeOLE 生成 X-MimeOLE 头(模拟老版 Outlook/Exchange 出站标识)
//
// 【契约】v2 与 v1 email/headers.go::getXMimeOLE 语义一致
// 【设计】反垃圾系统对老软件出站普遍宽容(企业老系统就这样)
func (s *Selector) getXMimeOLE() string {
	v := xMimeOLEVersions[s.rng.Intn(len(xMimeOLEVersions))]
	return fmt.Sprintf("X-MimeOLE: %s\r\n", v)
}

// getXMailerVersion 生成 X-Mailer-Version 头(与 X-Mailer 配套)
//
// 【契约】v2 与 v1 email/headers.go::getXMailerVersion 语义一致
// 【设计】真实 Outlook 出站两个头一起出现,孤立 X-Mailer 略不真实
func (s *Selector) getXMailerVersion() string {
	v := xMailerVersions[s.rng.Intn(len(xMailerVersions))]
	return fmt.Sprintf("X-Mailer-Version: %s\r\n", v)
}

// getXOriginalArrivalTime 生成 X-OriginalArrivalTime 头
//
// 【契约】v2 与 v1 email/headers.go::getXOriginalArrivalTime 语义一致
//
// 【格式】"dd MMM yyyy HH:mm:ss.SSSS (UTC) FILETIME=[XXXXXXXX:XXXXXXXX]"
//
// 【时间源】用 clk.Now().UTC()(v2 差异:v1 用 time.Now().UTC();复现性策略)
func (s *Selector) getXOriginalArrivalTime() string {
	now := s.clkOrSystem().Now().UTC()
	monthStr := monthAbbrevs[int(now.Month())-1]
	// FILETIME:2 段 32-bit hex(Windows FILETIME 结构;此处伪造)
	// 【v2 差异】v1 用 hg.random.Uint32();v2 用 rng.Intn 拼(random.Source 无 Uint32 方法)
	// 结果格式等价 —— 都是 8 hex 字符
	high := s.rng.Intn(0x7fffffff)*2 + s.rng.Intn(2) // 拼出 32 位随机
	low := s.rng.Intn(0x7fffffff)*2 + s.rng.Intn(2)
	return fmt.Sprintf("X-OriginalArrivalTime: %02d %s %d %02d:%02d:%02d.0000 (UTC) FILETIME=[%08X:%08X]\r\n",
		now.Day(), monthStr, now.Year(), now.Hour(), now.Minute(), now.Second(),
		high, low)
}
