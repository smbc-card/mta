package extended

import "fmt"

// ============================================================================
// P0 送达率刚需头(勾选了总是加,不进入随机池)
// v1 email/headers.go::emitExtendedHeaders 前半部分 + getListID + getFeedbackID + getPrecedence
// ============================================================================
//
// 【注意】List-Unsubscribe / List-Unsubscribe-Post 由 listunsub 子包,不在本包

// getListID 生成 List-ID(RFC 2369)—— 与 List-Unsubscribe 配套
//
// 【契约】v2 与 v1 email/headers.go::getListID 语义一致
// 【格式】List-ID: <{prefix}.{domain}>\r\n
// 【调用方】EmitP0AndPool 主入口(勾选了 cfg.ListID 时调用)
func (s *Selector) getListID(domain string) string {
	prefix := listIDPrefixes[s.rng.Intn(len(listIDPrefixes))]
	return fmt.Sprintf("List-ID: <%s.%s>\r\n", prefix, domain)
}

// getFeedbackID 生成 Feedback-ID(Gmail Postmaster Tools 反馈聚合)
//
// 【契约】v2 与 v1 email/headers.go::getFeedbackID 语义一致
// 【格式】Feedback-ID: {6位数字}:{domain}:{category}:{8位hex}\r\n
//
// 【设计动机】senderID 在 v1 里"同一 worker 在当前组合寿命内保持稳定"—— 但这需要
// worker 级状态。v2 简化:每次调用都生成新 senderID(与 v1 微小差异)
func (s *Selector) getFeedbackID(domain string) string {
	campaign := 100000 + s.rng.Intn(900000) // 6 位数字
	cat := feedbackCategories[s.rng.Intn(len(feedbackCategories))]
	senderID := randomHex(s.rng, 8)
	return fmt.Sprintf("Feedback-ID: %d:%s:%s:%s\r\n", campaign, domain, cat, senderID)
}

// getPrecedence 生成 Precedence 头(bulk / list / auto_reply / junk)
//
// 【契约】v2 与 v1 email/headers.go::getPrecedence 语义一致
func (s *Selector) getPrecedence() string {
	choice := precedenceChoices[s.rng.Intn(len(precedenceChoices))]
	return fmt.Sprintf("Precedence: %s\r\n", choice)
}
