package extended

import "fmt"

// ============================================================================
// P1 反指纹高真实感头(9 slot)
// v1 email/headers.go::getErrorsTo / getSender / getOrganization / getXOriginatingIP /
// getComments / getKeywords / getXReportAbuse
// 【静态 2 项】staticAutoSubmitted / staticXCSAComplaints 在 constants.go
// ============================================================================

// getErrorsTo 生成 Errors-To 头
//
// 【契约】v2 与 v1 email/headers.go::getErrorsTo 语义一致
// 【格式】Errors-To: bounce-{12hex}@{domain}\r\n
func (s *Selector) getErrorsTo(domain string) string {
	token := randomHex(s.rng, 12)
	return fmt.Sprintf("Errors-To: bounce-%s@%s\r\n", token, domain)
}

// getSender 生成 Sender 头
//
// 【契约】v2 与 v1 email/headers.go::getSender 语义一致
// 【格式】Sender: {prefix}@{domain}\r\n
func (s *Selector) getSender(domain string) string {
	prefix := senderPrefixes[s.rng.Intn(len(senderPrefixes))]
	return fmt.Sprintf("Sender: %s@%s\r\n", prefix, domain)
}

// getOrganization 生成 Organization 头
//
// 【契约】v2 与 v1 email/headers.go::getOrganization 语义一致
func (s *Selector) getOrganization() string {
	name := organizationNames[s.rng.Intn(len(organizationNames))]
	return fmt.Sprintf("Organization: %s\r\n", name)
}

// getXOriginatingIP 生成 X-Originating-IP 头(带 [ ] 包裹)
//
// 【契约】v2 与 v1 email/headers.go::getXOriginatingIP 语义一致
func (s *Selector) getXOriginatingIP() string {
	return fmt.Sprintf("X-Originating-IP: [%s]\r\n", generateRandomIPRealistic(s.rng))
}

// getComments 生成 Comments 头
//
// 【契约】v2 与 v1 email/headers.go::getComments 语义一致
func (s *Selector) getComments() string {
	c := commentsChoices[s.rng.Intn(len(commentsChoices))]
	return fmt.Sprintf("Comments: %s\r\n", c)
}

// getKeywords 生成 Keywords 头
//
// 【契约】v2 与 v1 email/headers.go::getKeywords 语义一致
func (s *Selector) getKeywords() string {
	k := keywordsChoices[s.rng.Intn(len(keywordsChoices))]
	return fmt.Sprintf("Keywords: %s\r\n", k)
}

// getXReportAbuse 生成 X-Report-Abuse 头
//
// 【契约】v2 与 v1 email/headers.go::getXReportAbuse 语义一致
func (s *Selector) getXReportAbuse(domain string) string {
	return fmt.Sprintf("X-Report-Abuse: Please report abuse to abuse@%s\r\n", domain)
}
