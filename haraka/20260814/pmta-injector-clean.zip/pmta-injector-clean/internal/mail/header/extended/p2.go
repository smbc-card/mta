package extended

import "fmt"

// ============================================================================
// P2 Outlook 风格(4 slot) + P2 行为标识(2 slot)
// v1 email/headers.go::getXMSMailPriority / getThreadIndex / getThreadTopic /
// getXAutoResponseSuppress / getReturnReceiptTo / getDispositionNotificationTo
// 【静态 1 项】X-Entity-Ref-ID 在 slots.go 直接生成(动态 GUID)
// ============================================================================

// ----- P2 Outlook -----

// getXMSMailPriority 生成 X-MSMail-Priority 头(High/Normal/Low)
//
// 【契约】v2 与 v1 email/headers.go::getXMSMailPriority 语义一致
func (s *Selector) getXMSMailPriority() string {
	c := xMSMailPriorityChoices[s.rng.Intn(len(xMSMailPriorityChoices))]
	return fmt.Sprintf("X-MSMail-Priority: %s\r\n", c)
}

// getThreadIndex 生成 Outlook Thread-Index(22-30 字节 base64)
//
// 【契约】v2 与 v1 email/headers.go::getThreadIndex 语义一致
// 【长度】真实 Outlook 用 28 字节左右;v1 随机 22-30 增加多样性
func (s *Selector) getThreadIndex() string {
	n := 22 + s.rng.Intn(9) // 22-30
	return fmt.Sprintf("Thread-Index: %s\r\n", randomBase64(s.rng, n))
}

// getThreadTopic 生成 Thread-Topic 头
//
// 【契约】v2 与 v1 email/headers.go::getThreadTopic 语义一致
func (s *Selector) getThreadTopic() string {
	t := threadTopics[s.rng.Intn(len(threadTopics))]
	return fmt.Sprintf("Thread-Topic: %s\r\n", t)
}

// getXAutoResponseSuppress 生成 X-Auto-Response-Suppress 头
//
// 【契约】v2 与 v1 email/headers.go::getXAutoResponseSuppress 语义一致
func (s *Selector) getXAutoResponseSuppress() string {
	c := autoResponseSuppressChoices[s.rng.Intn(len(autoResponseSuppressChoices))]
	return fmt.Sprintf("X-Auto-Response-Suppress: %s\r\n", c)
}

// ----- P2 行为标识 -----

// getReturnReceiptTo 生成 Return-Receipt-To 头
//
// 【契约】v2 与 v1 email/headers.go::getReturnReceiptTo 语义一致
// 【格式】Return-Receipt-To: <{prefix}@{domain}>\r\n
func (s *Selector) getReturnReceiptTo(domain string) string {
	prefix := returnReceiptPrefixes[s.rng.Intn(len(returnReceiptPrefixes))]
	return fmt.Sprintf("Return-Receipt-To: <%s@%s>\r\n", prefix, domain)
}

// getDispositionNotificationTo 生成 Disposition-Notification-To 头
//
// 【契约】v2 与 v1 email/headers.go::getDispositionNotificationTo 语义一致
func (s *Selector) getDispositionNotificationTo(domain string) string {
	prefix := dispositionNotificationPrefixes[s.rng.Intn(len(dispositionNotificationPrefixes))]
	return fmt.Sprintf("Disposition-Notification-To: <%s@%s>\r\n", prefix, domain)
}
