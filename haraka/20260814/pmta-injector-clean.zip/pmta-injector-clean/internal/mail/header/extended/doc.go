// Package extended 生成扩展邮件头(P0 送达率刚需 + P1/P2/P3 反指纹池 + 定值头)
//
// 【定值头 8 项】GenerateHeaders 直调,不进随机池:
//   - Reply-To / Return-Path(可 random_prefix 或 from_address 模式)
//   - X-Mailer(从 xMailerList 池抽,~200 条)
//   - X-Priority(1/2/3 或 cfg.XPriorityValue 指定)
//   - Importance(high/normal/low 或 cfg.ImportanceValue)
//   - Accept-Language / Content-Language(ja/en/ja-JP/en-US/zh-CN 或指定)
//
// 【P0 送达率刚需】emitExtendedHeaders 直调,不进随机池:
//   - List-ID(与 List-Unsubscribe 配套)
//   - Feedback-ID / Precedence
//   - (List-Unsubscribe 本身由 listunsub 子包,顶层编排时调 listunsub.Resolver)
//
// 【P1/P2/P3 随机池】30 个 headerSlot 注册表(顺序敏感,索引稳定):
//   - P1(9 slot):Errors-To / Sender / Organization / X-Originating-IP / Auto-Submitted /
//     Comments / Keywords / X-Report-Abuse / X-CSA-Complaints
//   - P2 Outlook(4 slot):X-MSMail-Priority / Thread-Index / Thread-Topic /
//     X-Auto-Response-Suppress
//   - P2 行为(3 slot):Return-Receipt-To / Disposition-Notification-To / X-Entity-Ref-ID
//   - P3 营销(3 slot):X-Campaign-ID / X-Mailer-LID / Campaign-ID
//   - P3 联动组(6 slot,单开关 → 多头一致):X-TMAS(6 头)/ X-SFMC(2 头)/
//     X-Barracuda(6 头)/ X-Proofpoint(4 头)/ X-Mimecast(4 头)/ X-Symantec(4 头)
//   - 方案 B 新独立(4 slot):X-Originating-Email / X-MimeOLE / X-Mailer-Version /
//     X-OriginalArrivalTime
//   合计 30 slot(v2 与 v1 顺序完全一致,索引稳定 —— headerCurrentSet 存索引,顺序换了 worker 记忆漂移)
//
// 【Worker 级反指纹核心】(refreshRandomHeaderSet):
//   - 从"用户勾选了的候选"里抽 N ∈ [RandomMin, RandomMax](1..10)
//   - Fisher-Yates 部分洗牌抽 N 个无重复
//   - 组合寿命 = 50 + rng.Intn(151)(即 50-200 封邮件后重抽)
//   - 目的:同 worker 内邮件特征一致(像同一系统出站),不同 worker 或长期后特征变化
//   - 避免"每封都不同"造成"该 IP 邮件特征飘忽不定"的反向指纹
//
// 【Message-ID 不在本包】由 mail/header/messageid 子包实现(Day 13 已完成)。
// 【List-Unsubscribe 不在本包】由 listunsub 子包(Day 19 完成)。
// 顶层编排(Week 5 builder)负责把三者组合起来。
//
// 【依赖】random.Source + clock.Clock + *config.HeadersConfig + data.Pool
// 【不 import 其他子包】(D16-1 决策)
package extended
