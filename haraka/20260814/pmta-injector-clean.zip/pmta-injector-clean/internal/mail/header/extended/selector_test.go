package extended

import (
	"regexp"
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

var fixedTestTime = time.Date(2026, 8, 7, 15, 30, 45, 0, time.UTC)

func newTestSelector(seed int64, cfg *config.HeadersConfig) *Selector {
	return New(random.NewFixedSource(seed), clock.NewFixedClock(fixedTestTime), cfg)
}

// ============================================================================
// 契约锁 —— 29 slot 顺序不可动
// ============================================================================

func TestHeaderSlotsCount(t *testing.T) {
	if got := len(headerSlots); got != 29 {
		t.Fatalf("headerSlots 数量偏离契约:got=%d, want=29(P17 硬约束:currentSet 存索引,顺序不可换)", got)
	}
}

func TestHeaderSlotsOrder_KeyIndexes(t *testing.T) {
	// 契约锁:每类的起始索引不可变(P17 硬约束)
	// P1 起点 = 0, P2 Outlook 起点 = 9, P2 行为 起点 = 13,
	// P3 营销 起点 = 16, P3 联动 起点 = 19, 方案 B 起点 = 25
	cfg := &config.HeadersConfig{
		ErrorsTo:             true, // slot 0
		XCSAComplaints:       true, // slot 8
		XMSMailPriority:      true, // slot 9
		XEntityRefID:         true, // slot 15
		XCampaignID:          true, // slot 16
		XTMASGroup:           true, // slot 19
		XOriginatingEmail:    true, // slot 25
		XOriginalArrivalTime: true, // slot 28
	}
	// 验证每个 slot 的 enabled(cfg) 都返回 true(证明索引-字段映射正确)
	checks := []struct {
		idx      int
		expected bool
	}{
		{0, true},   // ErrorsTo
		{8, true},   // XCSAComplaints
		{9, true},   // XMSMailPriority
		{15, true},  // XEntityRefID
		{16, true},  // XCampaignID
		{19, true},  // XTMASGroup
		{25, true},  // XOriginatingEmail
		{28, true},  // XOriginalArrivalTime
	}
	for _, c := range checks {
		if got := headerSlots[c.idx].enabled(cfg); got != c.expected {
			t.Errorf("headerSlots[%d].enabled = %v,want %v(顺序漂移风险)", c.idx, got, c.expected)
		}
	}
}

// ============================================================================
// hostgen helpers
// ============================================================================

func TestRandomHex_Extended(t *testing.T) {
	rng := random.NewFixedSource(42)
	if s := randomHex(rng, 0); s != "" {
		t.Errorf("n=0:%q", s)
	}
	if !regexp.MustCompile(`^[0-9a-f]{16}$`).MatchString(randomHex(rng, 16)) {
		t.Error("16 hex 格式")
	}
}

func TestRandomBase64_Extended(t *testing.T) {
	rng := random.NewFixedSource(42)
	if s := randomBase64(rng, 0); s != "" {
		t.Errorf("n=0:%q", s)
	}
	// 32 字节 → 44 字符 base64
	if got := randomBase64(rng, 32); len(got) != 44 {
		t.Errorf("32 字节 base64:%d,want=44", len(got))
	}
}

func TestRandomBase64Multiline_Extended(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 短(≤72 字符)不折
	short := randomBase64Multiline(rng, 32)
	if strings.Contains(short, "\r\n") {
		t.Errorf("短应不折:%q", short)
	}
	// 长(>72 字符)折
	long := randomBase64Multiline(rng, 256)
	if !strings.Contains(long, "\r\n   ") {
		t.Errorf("长应折,分隔符 '\\r\\n   ':%q", long[:min(80, len(long))])
	}
}

func TestRandomGUID(t *testing.T) {
	rng := random.NewFixedSource(42)
	g := randomGUID(rng)
	if !regexp.MustCompile(`^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$`).MatchString(g) {
		t.Errorf("GUID 格式:%q", g)
	}
}

func TestGenerateRandomIPRealistic_Extended(t *testing.T) {
	rng := random.NewFixedSource(42)
	for i := 0; i < 30; i++ {
		ip := generateRandomIPRealistic(rng)
		parts := strings.Split(ip, ".")
		if len(parts) != 4 || parts[3] == "0" || parts[3] == "255" {
			t.Errorf("第 %d 次 IP=%q 尾字节 0/255 未避开", i, ip)
		}
	}
}

func TestGenerateRandomEmailPrefix(t *testing.T) {
	rng := random.NewFixedSource(42)
	for i := 0; i < 20; i++ {
		p := generateRandomEmailPrefix(rng)
		if p == "" {
			t.Errorf("第 %d 次前缀空", i)
		}
	}
}

// ============================================================================
// P0 —— List-ID / Feedback-ID / Precedence
// ============================================================================

func TestGetListID(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	got := s.getListID("example.com")
	if !regexp.MustCompile(`^List-ID: <(newsletter|promo|notification|list|campaign|updates)\.example\.com>\r\n$`).MatchString(got) {
		t.Errorf("List-ID 格式:%q", got)
	}
}

func TestGetFeedbackID(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	got := s.getFeedbackID("example.com")
	// Feedback-ID: {6digits}:example.com:{cat}:{8hex}\r\n
	if !regexp.MustCompile(`^Feedback-ID: \d{6}:example\.com:(newsletter|promo|tx|campaign):[0-9a-f]{8}\r\n$`).MatchString(got) {
		t.Errorf("Feedback-ID 格式:%q", got)
	}
}

func TestGetPrecedence(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	got := s.getPrecedence()
	if !regexp.MustCompile(`^Precedence: (bulk|list|auto_reply|junk)\r\n$`).MatchString(got) {
		t.Errorf("Precedence 格式:%q", got)
	}
}

// ============================================================================
// P1 methods
// ============================================================================

func TestP1_All(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	// 每个 method 的输出前缀 + CRLF 结尾
	checks := []struct {
		name   string
		got    string
		prefix string
	}{
		{"ErrorsTo", s.getErrorsTo("e.com"), "Errors-To: bounce-"},
		{"Sender", s.getSender("e.com"), "Sender: "},
		{"Organization", s.getOrganization(), "Organization: "},
		{"XOriginatingIP", s.getXOriginatingIP(), "X-Originating-IP: ["},
		{"Comments", s.getComments(), "Comments: "},
		{"Keywords", s.getKeywords(), "Keywords: "},
		{"XReportAbuse", s.getXReportAbuse("e.com"), "X-Report-Abuse: Please report abuse to abuse@e.com\r\n"},
	}
	for _, c := range checks {
		if !strings.HasPrefix(c.got, c.prefix) {
			t.Errorf("%s 前缀:got=%q, want prefix=%q", c.name, c.got, c.prefix)
		}
		if !strings.HasSuffix(c.got, "\r\n") {
			t.Errorf("%s 尾部应 CRLF:%q", c.name, c.got)
		}
	}
}

// ============================================================================
// P2 methods
// ============================================================================

func TestP2_All(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	pri := s.getXMSMailPriority()
	if !regexp.MustCompile(`^X-MSMail-Priority: (High|Normal|Low)\r\n$`).MatchString(pri) {
		t.Errorf("XMSMailPriority:%q", pri)
	}
	idx := s.getThreadIndex()
	if !strings.HasPrefix(idx, "Thread-Index: ") || !strings.HasSuffix(idx, "\r\n") {
		t.Errorf("ThreadIndex:%q", idx)
	}
	topic := s.getThreadTopic()
	if !strings.HasPrefix(topic, "Thread-Topic: ") {
		t.Errorf("ThreadTopic:%q", topic)
	}
	sup := s.getXAutoResponseSuppress()
	if !regexp.MustCompile(`^X-Auto-Response-Suppress: (OOF|AutoReply|All|DR|NRN|RN)\r\n$`).MatchString(sup) {
		t.Errorf("XAutoResponseSuppress:%q", sup)
	}
	rr := s.getReturnReceiptTo("e.com")
	if !regexp.MustCompile(`^Return-Receipt-To: <(noreply|receipt|delivery)@e\.com>\r\n$`).MatchString(rr) {
		t.Errorf("ReturnReceiptTo:%q", rr)
	}
	dn := s.getDispositionNotificationTo("e.com")
	if !regexp.MustCompile(`^Disposition-Notification-To: <(noreply|read-receipt|notification)@e\.com>\r\n$`).MatchString(dn) {
		t.Errorf("DispositionNotificationTo:%q", dn)
	}
}

// ============================================================================
// P3 营销
// ============================================================================

func TestP3_Marketing(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	x := s.getXCampaignID()
	if !regexp.MustCompile(`^X-Campaign-ID: cmp-[0-9a-f]{8}\r\n$`).MatchString(x) {
		t.Errorf("XCampaignID:%q", x)
	}
	l := s.getXMailerLID()
	if !regexp.MustCompile(`^X-Mailer-LID: lid-\d{6}\r\n$`).MatchString(l) {
		t.Errorf("XMailerLID:%q", l)
	}
	c := s.getCampaignID()
	if !regexp.MustCompile(`^Campaign-ID: \d{6}\r\n$`).MatchString(c) {
		t.Errorf("CampaignID:%q", c)
	}
}

// ============================================================================
// P3 联动组
// ============================================================================

func TestGroups_XTMAS(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	out := s.getXTMASGroup()
	// 必须含 6 个头名
	for _, h := range []string{
		"X-TM-AS-GCONF:", "X-TM-AS-Product-Ver:", "X-TMASE-Version:",
		"X-TMASE-Result:", "X-TMASE-MatchedRID:", "X-TMASE-SNAP-Result:",
	} {
		if !strings.Contains(out, h) {
			t.Errorf("缺 %q\n%s", h, out)
		}
	}
	// SNAP-Result 特定格式
	if !regexp.MustCompile(`X-TMASE-SNAP-Result: 1\.\d{6}\.\d{4}-0-1-\d+:0,\d+:0,\d+:0-0`).MatchString(out) {
		t.Errorf("SNAP-Result 格式:\n%s", out)
	}
}

func TestGroups_XSFMC(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	out := s.getXSFMCGroup()
	if !strings.Contains(out, "X-SFMC-Stack: ") || !strings.Contains(out, "x-job: ") {
		t.Errorf("XSFMC 2 头:\n%s", out)
	}
}

func TestGroups_XBarracuda(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	out := s.getXBarracudaGroup()
	for _, h := range []string{
		"X-Barracuda-Connect:", "X-Barracuda-Start-Time:", "X-Barracuda-URL:",
		"X-Barracuda-Apparent-Source-IP:", "X-Barracuda-Spam-Score:", "X-Barracuda-Spam-Status:",
	} {
		if !strings.Contains(out, h) {
			t.Errorf("缺 %q\n%s", h, out)
		}
	}
	// Start-Time 应等于 FixedClock 的 Unix
	wantTS := fixedTestTime.Unix()
	if !strings.Contains(out, "X-Barracuda-Start-Time: 1786462245") && wantTS == 1786462245 {
	}
}

func TestGroups_XProofpoint(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	out := s.getXProofpointGroup()
	for _, h := range []string{"X-Proofpoint-Virus-Version:", "X-Proofpoint-Spam-Details:",
		"X-Proofpoint-GUID:", "X-Proofpoint-ORIG-GUID:"} {
		if !strings.Contains(out, h) {
			t.Errorf("缺 %q\n%s", h, out)
		}
	}
}

func TestGroups_XMimecast(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	out := s.getXMimecastGroup()
	for _, h := range []string{"X-Mimecast-Spam-Score:", "X-Mimecast-Spam-Signature:",
		"X-Mimecast-Bulk-Signature:", "X-Mimecast-Impersonation-Protect:"} {
		if !strings.Contains(out, h) {
			t.Errorf("缺 %q\n%s", h, out)
		}
	}
}

func TestGroups_XSymantec(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	out := s.getXSymantecGroup()
	for _, h := range []string{"X-CMAE-Score:", "X-CMAE-Analysis:",
		"X-MessageSniffer-Scan-Result:", "X-MessageSniffer-Rules:"} {
		if !strings.Contains(out, h) {
			t.Errorf("缺 %q\n%s", h, out)
		}
	}
}

// ============================================================================
// 方案 B 独立
// ============================================================================

func TestPlanB_All(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	if got := s.getXOriginatingEmail("e.com"); !strings.HasPrefix(got, "X-Originating-Email: [") {
		t.Errorf("XOriginatingEmail:%q", got)
	}
	if got := s.getXMimeOLE(); !strings.HasPrefix(got, "X-MimeOLE: Produced By Microsoft") {
		t.Errorf("XMimeOLE:%q", got)
	}
	if got := s.getXMailerVersion(); !strings.HasPrefix(got, "X-Mailer-Version: ") {
		t.Errorf("XMailerVersion:%q", got)
	}
	// X-OriginalArrivalTime 格式:X-OriginalArrivalTime: DD MMM YYYY HH:MM:SS.0000 (UTC) FILETIME=[X:Y]
	if got := s.getXOriginalArrivalTime(); !regexp.MustCompile(`^X-OriginalArrivalTime: \d{2} [A-Z][a-z]{2} 2026 \d{2}:\d{2}:\d{2}\.0000 \(UTC\) FILETIME=\[[0-9A-F]{8}:[0-9A-F]{8}\]\r\n$`).MatchString(got) {
		t.Errorf("XOriginalArrivalTime 格式:%q", got)
	}
}

// ============================================================================
// 8 定值 method
// ============================================================================

func TestReplyTo(t *testing.T) {
	// nil cfg → fromAddress
	s := newTestSelector(42, nil)
	if got := s.ReplyTo("orig@e.com", "e.com"); got != "orig@e.com" {
		t.Errorf("nil cfg ReplyTo:%q", got)
	}
	// from_address → fromAddress
	s2 := newTestSelector(42, &config.HeadersConfig{ReplyToMode: "from_address"})
	if got := s2.ReplyTo("orig@e.com", "e.com"); got != "orig@e.com" {
		t.Errorf("from_address:%q", got)
	}
	// random_prefix → new@e.com
	s3 := newTestSelector(42, &config.HeadersConfig{ReplyToMode: "random_prefix"})
	got := s3.ReplyTo("orig@e.com", "e.com")
	if !strings.HasSuffix(got, "@e.com") || strings.HasPrefix(got, "orig") {
		t.Errorf("random_prefix:%q", got)
	}
}

func TestReturnPath(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{ReturnPathMode: "random_prefix"})
	got := s.ReturnPath("orig@e.com", "e.com")
	if !strings.HasSuffix(got, "@e.com") || strings.HasPrefix(got, "orig") {
		t.Errorf("random_prefix:%q", got)
	}
}

func TestXMailer(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{})
	got := s.XMailer()
	if got == "" {
		t.Error("XMailer 应非空")
	}
}

func TestXPriority(t *testing.T) {
	// "1 (Highest)" → "1"
	s := newTestSelector(42, &config.HeadersConfig{XPriorityValue: "1 (Highest)"})
	if got := s.XPriority(); got != "1" {
		t.Errorf("1 (Highest):%q, want=1", got)
	}
	// "3 (Normal)" → "3"
	s2 := newTestSelector(42, &config.HeadersConfig{XPriorityValue: "3 (Normal)"})
	if got := s2.XPriority(); got != "3" {
		t.Errorf("3 (Normal):%q, want=3", got)
	}
	// "random" → 3 项之一
	s3 := newTestSelector(42, &config.HeadersConfig{XPriorityValue: "random"})
	got := s3.XPriority()
	if got != "1" && got != "2" && got != "3" {
		t.Errorf("random:%q, want 1/2/3", got)
	}
}

func TestImportance(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{ImportanceValue: "high"})
	if got := s.Importance(); got != "high" {
		t.Errorf("high:%q", got)
	}
	s2 := newTestSelector(42, &config.HeadersConfig{ImportanceValue: "random"})
	got := s2.Importance()
	if got != "high" && got != "normal" && got != "low" {
		t.Errorf("random:%q", got)
	}
}

func TestAcceptLanguage(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{AcceptLangValue: "ja"})
	if got := s.AcceptLanguage(); got != "ja" {
		t.Errorf("ja:%q", got)
	}
	s2 := newTestSelector(42, &config.HeadersConfig{AcceptLangValue: "unknown"})
	got := s2.AcceptLanguage()
	found := false
	for _, l := range languageChoices {
		if got == l {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("unknown 应 fallback 5 项之一:%q", got)
	}
}

func TestContentLanguage(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{ContentLangValue: "en-US"})
	if got := s.ContentLanguage(); got != "en-US" {
		t.Errorf("en-US:%q", got)
	}
}

// ============================================================================
// refreshRandomHeaderSet 边界
// ============================================================================

func TestRefreshRandomHeaderSet_Empty(t *testing.T) {
	s := newTestSelector(42, &config.HeadersConfig{RandomMin: 1, RandomMax: 3})
	s.refreshRandomHeaderSet(nil)
	if s.currentSet != nil || s.emailsLeft != 0 {
		t.Errorf("空 candidates 应 clear:currentSet=%v, emailsLeft=%d", s.currentSet, s.emailsLeft)
	}
}

func TestRefreshRandomHeaderSet_MinMaxClamp(t *testing.T) {
	// min=0 → 修正为 1;max=15 → 修正为 10;max<min → 修正 max=min
	s := newTestSelector(42, &config.HeadersConfig{RandomMin: 0, RandomMax: 15})
	s.refreshRandomHeaderSet([]int{0, 1, 2, 3, 4})
	// n 应在 [1, 5](rmin=1, rmax=min(10,5)=5)
	if n := len(s.currentSet); n < 1 || n > 5 {
		t.Errorf("min/max 修正后 n 越界:len(currentSet)=%d", n)
	}
	if s.emailsLeft < 50 || s.emailsLeft > 200 {
		t.Errorf("emailsLeft 应在 [50, 200]:got=%d", s.emailsLeft)
	}
}

func TestRefreshRandomHeaderSet_MinEqualsMax(t *testing.T) {
	// min=max=3 → 恰好抽 3 个
	s := newTestSelector(42, &config.HeadersConfig{RandomMin: 3, RandomMax: 3})
	s.refreshRandomHeaderSet([]int{0, 1, 2, 3, 4})
	if len(s.currentSet) != 3 {
		t.Errorf("min=max=3 应抽 3 个,got=%d", len(s.currentSet))
	}
	// 3 个应无重复
	seen := make(map[int]bool)
	for _, i := range s.currentSet {
		if seen[i] {
			t.Errorf("重复抽中 %d", i)
		}
		seen[i] = true
	}
}

func TestRefreshRandomHeaderSet_MinExceedsCandidates(t *testing.T) {
	// min=10 但只有 3 个候选 → n=3
	s := newTestSelector(42, &config.HeadersConfig{RandomMin: 10, RandomMax: 10})
	s.refreshRandomHeaderSet([]int{0, 1, 2})
	if len(s.currentSet) != 3 {
		t.Errorf("超候选数应 clamp:len=%d, want=3", len(s.currentSet))
	}
}

// ============================================================================
// EmitP0AndPool 主入口
// ============================================================================

func TestEmitP0AndPool_NilCfg(t *testing.T) {
	s := newTestSelector(42, nil)
	if got := s.EmitP0AndPool("e.com"); got != "" {
		t.Errorf("nil cfg 应返回空:%q", got)
	}
}

func TestEmitP0AndPool_P0Only(t *testing.T) {
	cfg := &config.HeadersConfig{
		ListID:     true,
		FeedbackID: true,
		Precedence: true,
	}
	s := newTestSelector(42, cfg)
	got := s.EmitP0AndPool("e.com")

	if !strings.Contains(got, "List-ID: <") {
		t.Errorf("缺 List-ID:\n%s", got)
	}
	if !strings.Contains(got, "Feedback-ID: ") {
		t.Errorf("缺 Feedback-ID:\n%s", got)
	}
	if !strings.Contains(got, "Precedence: ") {
		t.Errorf("缺 Precedence:\n%s", got)
	}
	// 只 3 头(P0)
	if strings.Count(got, "\r\n") != 3 {
		t.Errorf("应恰好 3 CRLF,got=%d:\n%s", strings.Count(got, "\r\n"), got)
	}
}

func TestEmitP0AndPool_NonRandomMode(t *testing.T) {
	// RandomEnabled=false 时,勾选了的都出
	cfg := &config.HeadersConfig{
		ErrorsTo: true, Sender: true, Organization: true,
		RandomEnabled: false,
	}
	s := newTestSelector(42, cfg)
	got := s.EmitP0AndPool("e.com")
	// 3 项都应出现
	for _, prefix := range []string{"Errors-To: bounce-", "Sender: ", "Organization: "} {
		if !strings.Contains(got, prefix) {
			t.Errorf("非随机模式应包含 %q:\n%s", prefix, got)
		}
	}
}

func TestEmitP0AndPool_RandomMode_LifespanConsumed(t *testing.T) {
	// RandomEnabled=true + Min=Max=2:每次都精确 2 头
	// 首封触发 refresh,后续 50-200 封复用组合
	cfg := &config.HeadersConfig{
		ErrorsTo: true, Sender: true, Organization: true, Comments: true, Keywords: true,
		RandomEnabled: true, RandomMin: 2, RandomMax: 2,
	}
	s := newTestSelector(42, cfg)
	first := s.EmitP0AndPool("e.com")
	// 首封应 2 头
	crlfs := strings.Count(first, "\r\n")
	if crlfs != 2 {
		t.Errorf("首封应 2 头,got=%d:\n%s", crlfs, first)
	}
	// s.emailsLeft 应被 refresh 到 50-200,然后 --
	if s.emailsLeft < 49 || s.emailsLeft > 199 {
		t.Errorf("首封后 emailsLeft 应在 [49, 199]:got=%d", s.emailsLeft)
	}
	// currentSet 应有 2 个元素
	if len(s.currentSet) != 2 {
		t.Errorf("currentSet 应 2 元素:got=%d", len(s.currentSet))
	}
}

func TestEmitP0AndPool_NoEnabledSlots(t *testing.T) {
	// 只 P0 开,没有 pool slot
	cfg := &config.HeadersConfig{ListID: true}
	s := newTestSelector(42, cfg)
	got := s.EmitP0AndPool("e.com")
	if !strings.Contains(got, "List-ID: ") {
		t.Errorf("应含 List-ID:%q", got)
	}
	// 只 1 CRLF
	if strings.Count(got, "\r\n") != 1 {
		t.Errorf("应 1 CRLF:got=%d", strings.Count(got, "\r\n"))
	}
}

// ============================================================================
// Reproducibility
// ============================================================================

func TestEmitP0AndPool_Reproducibility(t *testing.T) {
	cfg := &config.HeadersConfig{
		ListID: true, FeedbackID: true, Precedence: true,
		ErrorsTo: true, Sender: true, XCampaignID: true,
		RandomEnabled: true, RandomMin: 2, RandomMax: 3,
	}
	s1 := newTestSelector(42, cfg)
	s2 := newTestSelector(42, cfg)
	if s1.EmitP0AndPool("e.com") != s2.EmitP0AndPool("e.com") {
		t.Error("复现失败")
	}
}

// ============================================================================
// 辅助
// ============================================================================

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
