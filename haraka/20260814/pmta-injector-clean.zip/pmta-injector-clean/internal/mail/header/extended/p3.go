package extended

import "fmt"

// ============================================================================
// P3 营销活动(3 slot)
// v1 email/headers.go::getXCampaignID / getXMailerLID / getCampaignID
// ============================================================================

// getXCampaignID 生成 X-Campaign-ID 头
//
// 【契约】v2 与 v1 email/headers.go::getXCampaignID 语义一致
// 【格式】X-Campaign-ID: cmp-{8hex}\r\n
func (s *Selector) getXCampaignID() string {
	return fmt.Sprintf("X-Campaign-ID: cmp-%s\r\n", randomHex(s.rng, 8))
}

// getXMailerLID 生成 X-Mailer-LID 头
//
// 【契约】v2 与 v1 email/headers.go::getXMailerLID 语义一致
// 【格式】X-Mailer-LID: lid-{6位数字,含前导零}\r\n
func (s *Selector) getXMailerLID() string {
	return fmt.Sprintf("X-Mailer-LID: lid-%06d\r\n", s.rng.Intn(1000000))
}

// getCampaignID 生成 Campaign-ID 头
//
// 【契约】v2 与 v1 email/headers.go::getCampaignID 语义一致
// 【格式】Campaign-ID: {6位数字,含前导零}\r\n
func (s *Selector) getCampaignID() string {
	return fmt.Sprintf("Campaign-ID: %06d\r\n", s.rng.Intn(1000000))
}
