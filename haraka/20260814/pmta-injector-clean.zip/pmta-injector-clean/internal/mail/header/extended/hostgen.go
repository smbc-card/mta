package extended

import (
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/data"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// randomHex 生成 n 位十六进制字符串(小写)—— 与 messageid/dkim/received/listunsub 各自定义等价
//
// 【D16-1 决策】每包各写一份,不 import 其他子包
func randomHex(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	nBytes := (n + 1) / 2
	b := make([]byte, nBytes)
	_, _ = rng.Read(b)
	h := hex.EncodeToString(b)
	if len(h) > n {
		h = h[:n]
	}
	return h
}

// randomBase64 生成 n 字节随机数据的 base64 编码(单行,无换行)
//
// 【契约】v2 与 v1 email/headers.go::generateRandomBase64 语义等价(用注入 rng 替代 crypto/rand)
// 【用途】P2 Thread-Index / P3 联动组 X-Mimecast-Spam-Signature 等
func randomBase64(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	b := make([]byte, n)
	_, _ = rng.Read(b)
	return base64.StdEncoding.EncodeToString(b)
}

// randomBase64Multiline 生成 n 字节随机数据的 base64 编码 + 72 字符/行折行
//
// 【契约】v2 与 v1 email/headers.go::generateRandomBase64Multiline 语义等价
// 【用途】P3 X-TMASE-MatchedRID(256 字节 → ~344 base64 字符,折成 5 行)
// 【折行分隔符】"\r\n   "(3 空格 continuation,与 v1 一致)
func randomBase64Multiline(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	b := make([]byte, n)
	_, _ = rng.Read(b)
	encoded := base64.StdEncoding.EncodeToString(b)

	const lineLen = 72
	if len(encoded) <= lineLen {
		return encoded
	}
	var lines []string
	for i := 0; i < len(encoded); i += lineLen {
		end := i + lineLen
		if end > len(encoded) {
			end = len(encoded)
		}
		lines = append(lines, encoded[i:end])
	}
	return strings.Join(lines, "\r\n   ")
}

// randomGUID 生成大写 GUID 格式("XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX")
//
// 【契约】v2 与 v1 email/headers.go::generateGUID 语义等价
// 【用途】X-Entity-Ref-ID
func randomGUID(rng random.Source) string {
	b := make([]byte, 16)
	_, _ = rng.Read(b)
	return fmt.Sprintf("%08X-%04X-%04X-%04X-%012X",
		b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}

// generateRandomIPRealistic 生成真实范围的随机 IP(排除 first-octet 里明显非公网范围)
//
// 【契约】v2 与 v1 email/headers.go::generateRandomIPRealistic 语义一致
//
// 【硬编码范围】first octet 只从 6 个区间抽:
//
//	{1-9} {11-126} {128-169} {171-171} {173-191} {193-223}
//
// 【尾字节】1-254(避开网络号 0 和广播号 255)
// 【用途】X-Originating-IP、X-Barracuda-* IP 字段
func generateRandomIPRealistic(rng random.Source) string {
	validRanges := [][2]int{
		{1, 9}, {11, 126}, {128, 169}, {171, 171},
		{173, 191}, {193, 223},
	}
	r := validRanges[rng.Intn(len(validRanges))]
	first := rng.Intn(r[1]-r[0]+1) + r[0]
	second := rng.Intn(255)
	third := rng.Intn(255)
	fourth := rng.Intn(254) + 1
	return fmt.Sprintf("%d.%d.%d.%d", first, second, third, fourth)
}

// generateRandomEmailPrefix 生成随机邮箱前缀(可选 30% 概率追加 3 位数字后缀)
//
// 【契约】v2 与 v1 email/headers.go::generateRandomEmailPrefix 语义一致
// 【池】18 条硬编码前缀(v1 一致)
// 【用途】Reply-To / Return-Path 的 random_prefix 模式
func generateRandomEmailPrefix(rng random.Source) string {
	prefixes := []string{
		"noreply", "no-reply", "info", "support", "admin", "contact",
		"service", "notification", "alert", "mail", "system", "notice",
		"account", "security", "verify", "update", "billing", "help",
	}
	prefix := prefixes[rng.Intn(len(prefixes))]
	// 30% 概率追加数字后缀
	if rng.Intn(3) == 0 {
		prefix = fmt.Sprintf("%s%d", prefix, rng.Intn(100))
	}
	return prefix
}

// generateRandomDomain 生成随机域名(与 received.generateRandomDomain 语义等价)
//
// 【契约】v2 与 v1 email/headers.go::generateRandomDomain 一致
// 【用途】X-Barracuda-Connect(域名部分)
//
// 【B4 修复 2026-08-13】之前 extended 自建 4tld×5suffix 简化池,X-Barracuda-Connect 域名
// 与 v1 完全不同(格式塌成 smtp.suffix.tld,组合数 ~20 vs v1 ~92 万)。改为共享 data 包
// 3 个正式池 + 与 v1 一致的 mail.{7hex}.{tld} / smtp.{word}-{suffix}.{tld} 双格式
func generateRandomDomain(rng random.Source) string {
	tlds, _ := data.DomainTLDsPool.Get()
	// 池为空的极端兜底(embed 保证不为空,此路径实际不可达)
	if len(tlds) == 0 {
		return "mail.example.com"
	}
	if rng.Intn(2) == 0 {
		// 格式 1:mail.{7hex}.{tld}(v1 hex 长度 7,不是 6)
		return fmt.Sprintf("mail.%s.%s", randomHex(rng, 7), tlds[rng.Intn(len(tlds))])
	}
	// 格式 2:smtp.{word}-{suffix}.{tld}(v1 是双段带连字符,不是单 suffix)
	words, _ := data.DomainWordsPool.Get()
	suffixes, _ := data.DomainSuffixesPool.Get()
	if len(words) == 0 || len(suffixes) == 0 {
		return fmt.Sprintf("smtp.%s.%s", randomHex(rng, 6), tlds[rng.Intn(len(tlds))])
	}
	return fmt.Sprintf("smtp.%s-%s.%s",
		words[rng.Intn(len(words))],
		suffixes[rng.Intn(len(suffixes))],
		tlds[rng.Intn(len(tlds))])
}
