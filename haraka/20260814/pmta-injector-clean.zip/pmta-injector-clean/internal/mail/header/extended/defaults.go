package extended

import (
	"__MODULE_PLACEHOLDER__/internal/data"
)

// ============================================================================
// 8 个"定值 method"—— 由顶层 GenerateHeaders 直调,不进入随机池
// v1 email/headers.go::GenerateHeaders 主入口 + getReplyToAddress / getReturnPathAddress /
// getXPriorityValue / getImportanceValue / getAcceptLanguageValue / getContentLanguageValue
// + email/xmailer.go::getRandomXMailer
// ============================================================================

// ReplyTo 返回 Reply-To 头值(不含前缀 / 不含 CRLF)
//
// 【契约】v2 与 v1 email/headers.go::getReplyToAddress 语义一致
//
// 【模式】cfg.ReplyToMode:
//   - "random_prefix" → {generateRandomEmailPrefix()}@{domain}
//   - 其他值(含 "from_address" / 空)→ fromAddress 原值
//
// 【cfg=nil 兜底】返回 fromAddress
func (s *Selector) ReplyTo(fromAddress, domain string) string {
	if s.cfg == nil {
		return fromAddress
	}
	if s.cfg.ReplyToMode == "random_prefix" {
		return generateRandomEmailPrefix(s.rng) + "@" + domain
	}
	return fromAddress
}

// ReturnPath 返回 Return-Path 头值(不含前缀 / 不含 CRLF / 不含 <> 尖括号)
//
// 【契约】v2 与 v1 email/headers.go::getReturnPathAddress 语义一致
// 【模式】同 ReplyTo:random_prefix / from_address
func (s *Selector) ReturnPath(fromAddress, domain string) string {
	if s.cfg == nil {
		return fromAddress
	}
	if s.cfg.ReturnPathMode == "random_prefix" {
		return generateRandomEmailPrefix(s.rng) + "@" + domain
	}
	return fromAddress
}

// XMailer 返回 X-Mailer 头值(从 XMailerPool 池抽样)
//
// 【契约】v2 走 data.XMailerPool;v1 走文件级 xMailerList 变量
// 【失败兜底】池加载失败 → 返回通用兜底
func (s *Selector) XMailer() string {
	pool, err := data.XMailerPool.Get()
	if err != nil || len(pool) == 0 {
		return "Microsoft Outlook 16.0"
	}
	return pool[s.rng.Intn(len(pool))]
}

// XPriority 返回 X-Priority 头值("1" / "2" / "3")
//
// 【契约】v2 与 v1 email/headers.go::getXPriorityValue 语义一致
//
// 【模式】cfg.XPriorityValue:
//   - "1 (Highest)" → "1"
//   - "2 (High)"    → "2"
//   - "3 (Normal)"  → "3"
//   - 其他(含 "random")→ 3 项随机
//
// 【cfg=nil 兜底】随机
func (s *Selector) XPriority() string {
	if s.cfg == nil {
		return xPriorityRandomChoices[s.rng.Intn(len(xPriorityRandomChoices))]
	}
	switch s.cfg.XPriorityValue {
	case "1 (Highest)":
		return "1"
	case "2 (High)":
		return "2"
	case "3 (Normal)":
		return "3"
	default:
		return xPriorityRandomChoices[s.rng.Intn(len(xPriorityRandomChoices))]
	}
}

// Importance 返回 Importance 头值("high" / "normal" / "low")
//
// 【契约】v2 与 v1 email/headers.go::getImportanceValue 语义一致
func (s *Selector) Importance() string {
	if s.cfg == nil {
		return importanceRandomChoices[s.rng.Intn(len(importanceRandomChoices))]
	}
	switch s.cfg.ImportanceValue {
	case "high", "normal", "low":
		return s.cfg.ImportanceValue
	default:
		return importanceRandomChoices[s.rng.Intn(len(importanceRandomChoices))]
	}
}

// AcceptLanguage 返回 Accept-Language 头值(ja/en/ja-JP/en-US/zh-CN 或随机)
//
// 【契约】v2 与 v1 email/headers.go::getAcceptLanguageValue 语义一致
// 【cfg=nil 兜底】随机
func (s *Selector) AcceptLanguage() string {
	if s.cfg == nil {
		return languageChoices[s.rng.Intn(len(languageChoices))]
	}
	return pickLanguage(s.rng, s.cfg.AcceptLangValue)
}

// ContentLanguage 返回 Content-Language 头值(与 AcceptLanguage 同池)
//
// 【契约】v2 与 v1 email/headers.go::getContentLanguageValue 语义一致
func (s *Selector) ContentLanguage() string {
	if s.cfg == nil {
		return languageChoices[s.rng.Intn(len(languageChoices))]
	}
	return pickLanguage(s.rng, s.cfg.ContentLangValue)
}

// pickLanguage 语言选择公共 helper(AcceptLang / ContentLang 共用)
//
// 【规则】val 在 languageChoices 5 项之一 → 返回 val;否则从 5 项随机
func pickLanguage(rng interface {
	Intn(int) int
}, val string) string {
	for _, l := range languageChoices {
		if val == l {
			return val
		}
	}
	return languageChoices[rng.Intn(len(languageChoices))]
}
