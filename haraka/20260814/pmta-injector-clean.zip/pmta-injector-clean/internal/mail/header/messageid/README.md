# internal/mail/header/messageid

**用途**:25 种 Message-ID 风格生成器,依赖注入 random.Source + clock.Clock,测试可复现。

## 文件组织

| 文件 | 内容 |
|------|------|
| `keys.go` | 常量池:bizPrefixes(10)、platformLabels(8)、tags(9) |
| `helpers.go` | randomHex、randomAlnum、uuidV4、uuidV1、int63n、randomChoice |
| `styles.go` | 25 种风格 switch 分发 + rawURLEncode 手写实现 |
| `messageid.go` | Generator struct + New + Build + SeqIndex |

## 快速开始

```go
import (
    "__MODULE_PLACEHOLDER__/internal/clock"
    "__MODULE_PLACEHOLDER__/internal/mail/header/messageid"
    "__MODULE_PLACEHOLDER__/internal/random"
)

// 生产用
gen := messageid.New(random.NewSystemSource(), clock.NewSystemClock())
mid := gen.Build("uuid_seq", "office.gogomorocco.com")
// → "5f8c1a2b-abcd-4321-9876-0123456789ab.1@office.gogomorocco.com"

// 测试用(固定种子 + 固定时间 → 复现)
rng := random.NewFixedSource(42)
clk := clock.NewFixedClock(time.Date(2026, 8, 6, 15, 52, 1, 0, ...))
gen := messageid.New(rng, clk)
```

## 25 种风格清单

| 风格 key | 示例(左半)| 用途 |
|----------|-----------|------|
| `uuid_v4_lower` | `5f8c1a2b-abcd-4321-9876-0123456789ab` | 标准 UUIDv4 小写 |
| `uuid_v4_upper` | `5F8C1A2B-ABCD-4321-9876-0123456789AB` | 标准 UUIDv4 大写 |
| `uuid_v1` | `12345678-1234-1abc-89ab-01234567890a` | 时间型 UUIDv1 |
| `uuid_seq` | `<uuid>.1` | **v1 生产用** —— UUID + 计数器 |
| `ts_uuid_counter` | `20260806t155201-<uuid>-000001` | 时间戳 + UUID + 计数器 |
| `hex16` / `hex32` / `hex40` / `hex64` | `a1b2...` | 纯 hex |
| `hex_underscore` | `1234567890abc_defab98765432` | 双 hex 段 |
| `mixed_alnum` | `Ab3Xy9...` | 32-40 位混合字母数字 |
| `base64url` | `SGVsbG8gV29ybGQhIQ` | Base64 URL-safe(22 字符)|
| `javamail` | `1234567890.1.1723876321000` | JavaMail 格式 |
| `sendmail` | `20260806155201.a1b2c3` | Sendmail 格式 |
| `exim` | `E1XXXXXXX-XXXXXX-XX` | Exim 格式 |
| `becky` | `A1.B2.C3.D4` | Becky!(日式)大写 hex 点分 |
| `readable_ts` | `20260806155201123.abcd` | 可读时间戳 + hex |
| `ms_ts_hex` | `1723876321000.abcdef123456` | 毫秒 TS + hex |
| `ns_hex` | `1723876321000000000.abcdef123456` | 纳秒 TS + hex |
| `epoch_counter` | `1723876321.12345678` | Unix TS + 计数 |
| `bigint_hex` | `123456789012345.abcdef01` | 大整数 + hex |
| `compact_date_ns` | `20260806123456789012a1b2c3` | 紧凑日期 + ns + hex |
| `biz_prefix` | `promo_<32-hex>` | 业务前缀 + hex |
| `enterprise_multiseg` | `1723876321000.20260806.mkt.1.000042.000123` | 企业级多段 |
| `tag_uuid` | `notify-<uuid>` | 标签 + UUID |

**风格清单来源**:`data.MessageIDStyleKeysPool`(与 v1 一致)

## 计数器 `seqIdx` 说明

- **共享计数**:`javamail` / `uuid_seq` / `ts_uuid_counter` / `enterprise_multiseg` 4 种风格共享同一 `seqIdx`(与 v1 一致)
- **per-instance**:每个 `Generator` 实例独立(生产建议 per-worker 一个 Generator)
- **非线程安全**:跨 worker 共享需外部加锁(不推荐)

## 未知 key 兜底

未在 25 种风格里的 key → 自动 fallback 到 **ns_hex** 风格(`<纳秒>.<12位hex>@domain`),**永不返回空串**。

## API

```go
type Generator struct {…}

func New(rng random.Source, clk clock.Clock) *Generator
func (g *Generator) Build(styleKey, domain string) string
func (g *Generator) SeqIndex() int64  // 测试/调试用
```

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| 位置 | `email/headers.go` 里嵌入 HeaderGenerator | 独立包 `internal/mail/header/messageid` |
| 随机源 | 混用 `math/rand`(hg.random)+ `crypto/rand.Read` | 统一 `random.Source` |
| 时钟 | 直接 `time.Now()` | 注入 `clock.Clock` |
| 计数器 | `hg.messageIDSeqIdx` 挂在 HeaderGenerator | `Generator.seqIdx` 独立字段 |
| 计数器 4 风格共享 | ✅(隐式,通过 hg 实例)| ✅(显式,同 Generator 实例)|
| Int63n(N) | `hg.random.Int63n(N)`(math/rand,有 bias 修正)| `int63n(rng, N)` helper(Int63()%N,小 bias)|
| base64url | `base64.RawURLEncoding.EncodeToString` | 手写 `rawURLEncode`(依赖极简)|
| 单测 | ❌ 无 | ✅ 20+ 单测,25 风格全覆盖,含格式正则、计数器、复现性 |

## 依赖

- `internal/random` —— Source 接口
- `internal/clock` —— Clock 接口
- **不依赖**:config / telemetry / data —— 25 种风格里用到的常量池(bizPrefixes 等)直接内嵌 `keys.go`,不引 data 包(避免循环依赖 & 保持极简)

## 测试

```bash
go test -cover ./internal/mail/header/messageid/...
# 实测:98.2% coverage,25 风格全通过
```
