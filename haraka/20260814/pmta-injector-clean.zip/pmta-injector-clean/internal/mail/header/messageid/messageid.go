package messageid

import (
	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// Generator 25 种风格 Message-ID 生成器
//
// 【依赖注入】
//   - rng:随机源(测试用 FixedSource(seed=42) 固定种子)
//   - clk:时钟(测试用 FixedClock(2026-08-06T15:52:01+09:00) 固定时间)
//   - seqIdx:per-instance 计数器(单线程无锁递增,ts_uuid_counter/uuid_seq/javamail/enterprise_multiseg 用)
//
// 【线程安全】非线程安全。生产用法:每个 worker 一个 Generator 实例(v1 也是这样)。
// 若跨 worker 共享,需要外部加锁 —— 但当前设计不推荐。
type Generator struct {
	rng    random.Source
	clk    clock.Clock
	seqIdx int64
}

// New 创建 Message-ID 生成器
//
// 【参数】
//   - rng:必需(nil 会 panic on first use)
//   - clk:必需(同上)
//
// 【初始状态】seqIdx=0,第一次调用 uuid_seq 等风格时会递增为 1
func New(rng random.Source, clk clock.Clock) *Generator {
	return &Generator{
		rng:    rng,
		clk:    clk,
		seqIdx: 0,
	}
}

// Build 按 styleKey 生成 Message-ID 左半部分 + "@domain"
//
// 【返回】不含尖括号,例如 "5f8c1a2b-abcd-4321-9876-0123456789ab.1@example.com"
// 【尖括号】由外层 builder 用 "<" + Build() + ">" 包裹
// 【未知 styleKey】走兜底(ns_hex 风格),永不返回空串
// 【domain 校验】不做校验,交给外层保证 domain 合法
func (g *Generator) Build(styleKey, domain string) string {
	return g.buildByStyle(styleKey, domain)
}

// SeqIndex 返回当前计数器值(测试/调试用)
func (g *Generator) SeqIndex() int64 {
	return g.seqIdx
}
