package messageid

import (
	"encoding/hex"
	"fmt"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// randomHex 生成 n 位十六进制字符串(小写)
//
// 【实现】按 (n+1)/2 字节从 Source 读取,然后 hex.EncodeToString,取前 n 字符
// 【与 v1 randomHexString 等价】但完全用注入 Source,测试可复现
func randomHex(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	nBytes := (n + 1) / 2
	b := make([]byte, nBytes)
	_, _ = rng.Read(b)
	h := hex.EncodeToString(b)
	if len(h) > n {
		h = h[:n]
	}
	return h
}

// randomAlnum 生成 n 位混合大小写字母数字随机串(无分隔符)
//
// 【与 v1 messageIDRandAlnum 等价】alphabet 完全一致
func randomAlnum(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, n)
	_, _ = rng.Read(b)
	out := make([]byte, n)
	for i := range b {
		out[i] = alphabet[int(b[i])%len(alphabet)]
	}
	return string(out)
}

// uuidV4 生成 RFC 4122 v4 UUID
//
// 【upper=true】输出大写(如 12345678-ABCD-...)
// 【upper=false】输出小写(如 12345678-abcd-...)
//
// 【与 v1 messageIDUUIDv4 等价】按 16 字节读取 + version/variant bits 设置
func uuidV4(rng random.Source, upper bool) string {
	var b [16]byte
	_, _ = rng.Read(b[:])
	b[6] = (b[6] & 0x0f) | 0x40 // version 4
	b[8] = (b[8] & 0x3f) | 0x80 // variant 10xx
	if upper {
		return fmt.Sprintf("%08X-%04X-%04X-%04X-%012X", b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
	}
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}

// uuidV1 生成时间型 UUID v1(小写)
//
// 【实现】
//   - 时间戳:100ns 单位,起点 1582-10-15(格里高利改历)
//   - 节点:6 字节随机 + 组播位=1(非真实网卡 MAC)
//   - 时钟序列:14 位随机 + 变体位=10
//   - 版本位=1
//
// 【与 v1 messageIDUUIDv1 等价】gregorianOffset 常量一致
func uuidV1(rng random.Source, nowNanos int64) string {
	const gregorianOffset = 122192928000000000 // 1582-10-15 → 1970-01-01 的 100ns 间隔数
	ts := uint64(nowNanos/100) + gregorianOffset
	timeLow := uint32(ts & 0xffffffff)
	timeMid := uint16((ts >> 32) & 0xffff)
	timeHiVer := uint16((ts>>48)&0x0fff) | 0x1000 // version 1

	var rb [8]byte
	_, _ = rng.Read(rb[:])

	clockSeq := (uint16(rb[0])<<8|uint16(rb[1]))&0x3fff | 0x8000 // variant 10xx

	var node [6]byte
	copy(node[:], rb[2:8])
	node[0] |= 0x01 // 组播位=1,表明非真实网卡 MAC

	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x", timeLow, timeMid, timeHiVer, clockSeq, node[:])
}

// int63n 从 Source 返回 [0, n) 范围的 int64
//
// 【为什么加这个 helper】random.Source 接口没提供 Int63n(N),只有 Int63()
// 【bias 说明】Int63() % N 有微小 modulo bias,但对 Message-ID 唯一性场景不关键
// 【与 v1 hg.random.Int63n(9000000000) 等价】v1 用的是 math/rand 的 Int63n(内部有 bias 修正),
// 我们简化为 mod;测试用 FixedSource 一样可复现
func int63n(rng random.Source, n int64) int64 {
	if n <= 0 {
		return 0
	}
	v := rng.Int63()
	if v < 0 {
		v = -v
	}
	return v % n
}

// randomChoice 从字符串切片里随机选一个
//
// 【与 v1 hg.randomChoice 等价】用 Source.Intn(len) 选下标
func randomChoice(rng random.Source, items []string) string {
	if len(items) == 0 {
		return ""
	}
	return items[rng.Intn(len(items))]
}
