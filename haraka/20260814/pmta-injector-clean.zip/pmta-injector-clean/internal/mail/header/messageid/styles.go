package messageid

import (
	"fmt"
	"strings"
)

// buildByStyle 25 种风格的分发中心(与 v1 buildMessageIDByStyle 一一对应)
//
// 【返回】Message-ID 左半部分 + "@domain",不含尖括号(尖括号由 builder 包)
// 【风格覆盖】完整清单见 data.MessageIDStyleKeysPool
// 【未知 key】兜底走 default 分支,返回 ns_hex 风格(永不返回空)
func (g *Generator) buildByStyle(key, d string) string {
	now := g.clk.Now()

	switch key {
	case "uuid_v4_lower":
		return fmt.Sprintf("%s@%s", uuidV4(g.rng, false), d)

	case "hex32":
		return fmt.Sprintf("%s@%s", randomHex(g.rng, 32), d)

	case "javamail":
		g.seqIdx++
		num := int63n(g.rng, 9000000000) + 1000000000 // 10 位随机数
		return fmt.Sprintf("%d.%d.%d@%s", num, g.seqIdx, now.UnixMilli(), d)

	case "uuid_v4_upper":
		return fmt.Sprintf("%s@%s", uuidV4(g.rng, true), d)

	case "ts_uuid_counter":
		g.seqIdx++
		return fmt.Sprintf("%s-%s-%06d@%s",
			now.Format("20060102t150405"), uuidV4(g.rng, false), g.seqIdx, d)

	case "base64url":
		// 16 字节随机 → RawURLEncoding → 22 字符
		b := make([]byte, 16)
		_, _ = g.rng.Read(b)
		return fmt.Sprintf("%s@%s", rawURLEncode(b), d)

	case "readable_ts":
		ts17 := now.Format("20060102150405") + fmt.Sprintf("%03d", now.Nanosecond()/1e6)
		return fmt.Sprintf("%s.%s@%s", ts17, randomHex(g.rng, 4), d)

	case "uuid_seq":
		// 【生产用】uuid + 计数器
		g.seqIdx++
		return fmt.Sprintf("%s.%d@%s", uuidV4(g.rng, false), g.seqIdx, d)

	case "hex40":
		return fmt.Sprintf("%s@%s", randomHex(g.rng, 40), d)

	case "hex_underscore":
		return fmt.Sprintf("%s_%s@%s", randomHex(g.rng, 13), randomHex(g.rng, 13), d)

	case "ms_ts_hex":
		return fmt.Sprintf("%d.%s@%s", now.UnixMilli(), randomHex(g.rng, 12), d)

	case "uuid_v1":
		return fmt.Sprintf("%s@%s", uuidV1(g.rng, now.UnixNano()), d)

	case "biz_prefix":
		return fmt.Sprintf("%s_%s@%s", randomChoice(g.rng, bizPrefixes), randomHex(g.rng, 32), d)

	case "hex64":
		return fmt.Sprintf("%s@%s", randomHex(g.rng, 64), d)

	case "enterprise_multiseg":
		g.seqIdx++
		return fmt.Sprintf("%d.%s.%s.%d.%06d.%06d@%s",
			now.UnixMilli(), now.Format("20060102"),
			randomChoice(g.rng, platformLabels), g.seqIdx,
			int63n(g.rng, 1000000), int63n(g.rng, 1000000), d)

	case "epoch_counter":
		return fmt.Sprintf("%d.%08d@%s", now.Unix(), int63n(g.rng, 100000000), d)

	case "bigint_hex":
		return fmt.Sprintf("%d.%s@%s", g.rng.Int63(), randomHex(g.rng, 8), d)

	case "mixed_alnum":
		// 32-40 位字母数字
		length := 32 + int(int63n(g.rng, 9))
		return fmt.Sprintf("%s@%s", randomAlnum(g.rng, length), d)

	case "compact_date_ns":
		return fmt.Sprintf("%s%012d%s@%s",
			now.Format("20060102"), now.UnixNano()%1000000000000, randomHex(g.rng, 6), d)

	case "tag_uuid":
		return fmt.Sprintf("%s-%s@%s", randomChoice(g.rng, tags), uuidV4(g.rng, false), d)

	case "ns_hex":
		return fmt.Sprintf("%d.%s@%s", now.UnixNano(), randomHex(g.rng, 12), d)

	case "hex16":
		return fmt.Sprintf("%s@%s", randomHex(g.rng, 16), d)

	case "exim":
		// Exim 格式:E1XXXXXXX-XXXXXX-XX(大写 hex + 2 位大写字母)
		part1 := strings.ToUpper(randomHex(g.rng, 7))
		part2 := strings.ToUpper(randomHex(g.rng, 6))
		const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		last := make([]byte, 2)
		for i := range last {
			last[i] = letters[g.rng.Intn(len(letters))]
		}
		return fmt.Sprintf("E1%s-%s-%s@%s", part1, part2, string(last), d)

	case "sendmail":
		return fmt.Sprintf("%s.%s@%s", now.Format("20060102150405"), randomHex(g.rng, 6), d)

	case "becky":
		// Becky!(日式邮件客户端):大写 hex,4 段用点分隔
		b := make([]byte, 4)
		_, _ = g.rng.Read(b)
		return fmt.Sprintf("%02X.%02X.%02X.%02X@%s", b[0], b[1], b[2], b[3], d)

	default:
		// 未知 key 兜底:回退纳秒风(永不返回空)
		return fmt.Sprintf("%d.%s@%s", now.UnixNano(), randomHex(g.rng, 12), d)
	}
}

// rawURLEncode base64 URL-safe 编码(无填充)
//
// 【与 v1 base64.RawURLEncoding.EncodeToString 等价】
// 【为什么手写而不直接调用 encoding/base64】保持 messageid 包依赖极简;
// 未来若接入 mail/encoding 包可替换,但当前手写更透明
func rawURLEncode(data []byte) string {
	const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
	if len(data) == 0 {
		return ""
	}

	// 每 3 字节 → 4 字符;不足 3 字节 → 少填充,末尾字符数按规则
	out := make([]byte, 0, (len(data)*8+5)/6)
	for i := 0; i < len(data); i += 3 {
		var b [3]byte
		remaining := len(data) - i
		n := 3
		if remaining < 3 {
			n = remaining
		}
		for j := 0; j < n; j++ {
			b[j] = data[i+j]
		}

		out = append(out, alphabet[b[0]>>2])
		out = append(out, alphabet[((b[0]&0x03)<<4)|(b[1]>>4)])
		if n >= 2 {
			out = append(out, alphabet[((b[1]&0x0f)<<2)|(b[2]>>6)])
		}
		if n >= 3 {
			out = append(out, alphabet[b[2]&0x3f])
		}
	}
	return string(out)
}
