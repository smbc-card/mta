// Package messageid 提供 25 种 Message-ID 风格生成器
//
// 【25 种风格】完整清单见 data.MessageIDStyleKeysPool,与 v1 email/headers.go
// messageIDStyleKeys 完全一致(2026-06-17 从 Haraka 移植)。
//
// 【依赖注入】所有随机源统一用 random.Source,时钟统一用 clock.Clock,
// 测试固定种子 + 固定时间即可复现每个风格的输出。
//
// 【与 v1 的差异】
//   - v1 混用 math/rand(hg.random)+ crypto/rand.Read,v2 统一 random.Source
//   - v1 用 time.Now() 直接读系统时间,v2 用 clock.Clock 注入
//   - v1 计数器 hg.messageIDSeqIdx 挂在 HeaderGenerator 上,
//     v2 计数器 Generator.seqIdx 独立(仍是 per-instance 单线程无锁)
package messageid

// 【biz_prefix 风格】前缀候选池 —— 与 v1 email/headers.go:1438 一致
var bizPrefixes = []string{
	"mkt", "promo", "news", "notify", "sys", "mail", "camp", "info", "noreply", "alert",
}

// 【enterprise_multiseg 风格】平台标签候选池 —— 与 v1 email/headers.go:1439 一致
var platformLabels = []string{
	"promo", "news", "txn", "sys", "camp", "mkt", "bulk", "auto",
}

// 【tag_uuid 风格】标签候选池 —— 与 v1 email/headers.go:1440 一致
var tags = []string{
	"notify", "alert", "txn", "sys", "msg", "info", "mail", "auto", "noreply",
}
