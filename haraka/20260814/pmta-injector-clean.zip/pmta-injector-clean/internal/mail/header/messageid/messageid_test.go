package messageid

import (
	"regexp"
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// ===== 测试辅助 =====

// fixedTime 用于所有测试的固定时间(与 v1-patched 一致)
var fixedTime = time.Date(2026, 8, 6, 15, 52, 1, 0, time.FixedZone("JST", 9*3600))

func newTestGen() *Generator {
	rng := random.NewFixedSource(42)
	clk := clock.NewFixedClock(fixedTime)
	return New(rng, clk)
}

// ===== 25 风格全覆盖(每风格至少验证格式 + 非空 + 含 @domain) =====

func TestBuild_AllStyles(t *testing.T) {
	// 25 种风格,每种都应产生非空、含 @example.com 的 Message-ID
	styles := []string{
		"uuid_v4_lower", "hex32", "javamail", "uuid_v4_upper", "ts_uuid_counter",
		"base64url", "readable_ts", "uuid_seq", "hex40", "hex_underscore",
		"ms_ts_hex", "uuid_v1", "biz_prefix", "hex64", "enterprise_multiseg",
		"epoch_counter", "bigint_hex", "mixed_alnum", "compact_date_ns", "tag_uuid",
		"ns_hex", "hex16", "exim", "sendmail", "becky",
	}
	for _, style := range styles {
		t.Run(style, func(t *testing.T) {
			g := newTestGen()
			mid := g.Build(style, "example.com")
			if mid == "" {
				t.Fatalf("风格 %q 返回空", style)
			}
			if !strings.HasSuffix(mid, "@example.com") {
				t.Errorf("风格 %q 应以 @example.com 结尾,得到 %q", style, mid)
			}
			if strings.HasPrefix(mid, "@") {
				t.Errorf("风格 %q 左半为空,得到 %q", style, mid)
			}
		})
	}
}

// ===== 特定风格格式验证 =====

func TestBuild_UUIDv4Lower(t *testing.T) {
	g := newTestGen()
	mid := g.Build("uuid_v4_lower", "example.com")
	// 格式:xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx@example.com
	re := regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("uuid_v4_lower 格式不符,得到 %q", mid)
	}
}

func TestBuild_UUIDv4Upper(t *testing.T) {
	g := newTestGen()
	mid := g.Build("uuid_v4_upper", "example.com")
	re := regexp.MustCompile(`^[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("uuid_v4_upper 格式不符,得到 %q", mid)
	}
}

func TestBuild_Hex32(t *testing.T) {
	g := newTestGen()
	mid := g.Build("hex32", "example.com")
	// 32 位小写 hex + @domain
	re := regexp.MustCompile(`^[0-9a-f]{32}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("hex32 格式不符,得到 %q", mid)
	}
}

func TestBuild_Hex16(t *testing.T) {
	g := newTestGen()
	mid := g.Build("hex16", "example.com")
	re := regexp.MustCompile(`^[0-9a-f]{16}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("hex16 格式不符,得到 %q", mid)
	}
}

func TestBuild_Hex64(t *testing.T) {
	g := newTestGen()
	mid := g.Build("hex64", "example.com")
	re := regexp.MustCompile(`^[0-9a-f]{64}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("hex64 格式不符,得到 %q", mid)
	}
}

func TestBuild_Exim(t *testing.T) {
	g := newTestGen()
	mid := g.Build("exim", "example.com")
	// E1 + 7 位大写 hex + - + 6 位大写 hex + - + 2 位大写字母 + @domain
	re := regexp.MustCompile(`^E1[0-9A-F]{7}-[0-9A-F]{6}-[A-Z]{2}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("exim 格式不符,得到 %q", mid)
	}
}

func TestBuild_Becky(t *testing.T) {
	g := newTestGen()
	mid := g.Build("becky", "example.com")
	// 4 段 2 位大写 hex,用点分隔
	re := regexp.MustCompile(`^[0-9A-F]{2}\.[0-9A-F]{2}\.[0-9A-F]{2}\.[0-9A-F]{2}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("becky 格式不符,得到 %q", mid)
	}
}

func TestBuild_Sendmail(t *testing.T) {
	g := newTestGen()
	mid := g.Build("sendmail", "example.com")
	// 14 位日期时间 + . + 6 位 hex + @domain
	re := regexp.MustCompile(`^\d{14}\.[0-9a-f]{6}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("sendmail 格式不符,得到 %q", mid)
	}
	// 时间部分应等于 fixedTime.Format("20060102150405")
	expectedTS := fixedTime.Format("20060102150405")
	if !strings.HasPrefix(mid, expectedTS) {
		t.Errorf("sendmail 应含固定时间 %s,得到 %q", expectedTS, mid)
	}
}

func TestBuild_JavaMail(t *testing.T) {
	g := newTestGen()
	mid := g.Build("javamail", "example.com")
	// javamail 格式:num.seq.timestamp@domain
	re := regexp.MustCompile(`^\d{10}\.\d+\.\d+@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("javamail 格式不符,得到 %q", mid)
	}
}

// ===== 计数器递增验证 =====

func TestBuild_SeqCounterIncrements(t *testing.T) {
	g := newTestGen()
	// uuid_seq 每次调用应递增
	mid1 := g.Build("uuid_seq", "example.com")
	mid2 := g.Build("uuid_seq", "example.com")

	// 分离出 .{数字}@ 部分
	getSeq := func(mid string) string {
		atIdx := strings.LastIndex(mid, "@")
		if atIdx < 0 {
			return ""
		}
		left := mid[:atIdx]
		dotIdx := strings.LastIndex(left, ".")
		if dotIdx < 0 {
			return ""
		}
		return left[dotIdx+1:]
	}

	seq1 := getSeq(mid1)
	seq2 := getSeq(mid2)
	if seq1 == seq2 {
		t.Errorf("uuid_seq 应递增,两次调用得到相同 seq: %q vs %q", seq1, seq2)
	}
	if seq1 != "1" || seq2 != "2" {
		t.Errorf("期望 seq 1、2,得到 %q、%q(完整:%q vs %q)", seq1, seq2, mid1, mid2)
	}
}

func TestBuild_SeqCounterShared(t *testing.T) {
	// 【重要】javamail/uuid_seq/ts_uuid_counter/enterprise_multiseg 共享同一 seqIdx
	// v1 也是这样(hg.messageIDSeqIdx 单一)
	g := newTestGen()
	g.Build("uuid_seq", "example.com")     // seq → 1
	g.Build("javamail", "example.com")     // seq → 2
	g.Build("ts_uuid_counter", "example.com") // seq → 3

	if g.SeqIndex() != 3 {
		t.Errorf("4 种计数风格应共享 seqIdx,期望 3,得到 %d", g.SeqIndex())
	}
}

// ===== 未知 key 兜底 =====

func TestBuild_UnknownKey_Fallback(t *testing.T) {
	g := newTestGen()
	mid := g.Build("nonexistent_style_xyz", "example.com")
	if mid == "" {
		t.Fatal("未知 key 应有兜底,不能返回空")
	}
	// 兜底走 ns_hex 风:ns.hex12@domain
	re := regexp.MustCompile(`^\d+\.[0-9a-f]{12}@example\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("未知 key 应兜底为 ns_hex 风,得到 %q", mid)
	}
}

// ===== 复现性(固定种子 + 固定时钟 → 完全一致输出) =====

func TestBuild_Deterministic(t *testing.T) {
	g1 := newTestGen()
	g2 := newTestGen()

	// 用非 clock/counter 依赖的纯随机风格 hex32
	mid1 := g1.Build("hex32", "example.com")
	mid2 := g2.Build("hex32", "example.com")

	if mid1 != mid2 {
		t.Errorf("固定种子应完全复现,得到 %q vs %q", mid1, mid2)
	}
}

// ===== helpers 单测 =====

func TestRandomHex(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 长度校验
	h32 := randomHex(rng, 32)
	if len(h32) != 32 {
		t.Errorf("randomHex(32) 应返回 32 字符,得到 %d", len(h32))
	}
	// 内容应全为小写 hex
	re := regexp.MustCompile(`^[0-9a-f]+$`)
	if !re.MatchString(h32) {
		t.Errorf("randomHex 应全为小写 hex,得到 %q", h32)
	}

	// 奇数长度
	h7 := randomHex(rng, 7)
	if len(h7) != 7 {
		t.Errorf("randomHex(7) 应返回 7 字符,得到 %d", len(h7))
	}

	// 0 长度
	h0 := randomHex(rng, 0)
	if h0 != "" {
		t.Errorf("randomHex(0) 应返回空,得到 %q", h0)
	}
}

func TestRandomAlnum(t *testing.T) {
	rng := random.NewFixedSource(42)
	s := randomAlnum(rng, 40)
	if len(s) != 40 {
		t.Errorf("randomAlnum(40) 应返回 40 字符,得到 %d", len(s))
	}
	re := regexp.MustCompile(`^[0-9A-Za-z]+$`)
	if !re.MatchString(s) {
		t.Errorf("randomAlnum 应全为字母数字,得到 %q", s)
	}
}

func TestUUIDv4_LowerFormat(t *testing.T) {
	rng := random.NewFixedSource(42)
	u := uuidV4(rng, false)
	re := regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$`)
	if !re.MatchString(u) {
		t.Errorf("UUIDv4 lower 格式不符,得到 %q", u)
	}
}

func TestUUIDv4_UpperFormat(t *testing.T) {
	rng := random.NewFixedSource(42)
	u := uuidV4(rng, true)
	re := regexp.MustCompile(`^[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$`)
	if !re.MatchString(u) {
		t.Errorf("UUIDv4 upper 格式不符,得到 %q", u)
	}
}

func TestUUIDv1_Format(t *testing.T) {
	rng := random.NewFixedSource(42)
	u := uuidV1(rng, fixedTime.UnixNano())
	// UUIDv1 格式:xxxxxxxx-xxxx-1xxx-yxxx-xxxxxxxxxxxx
	re := regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-1[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$`)
	if !re.MatchString(u) {
		t.Errorf("UUIDv1 格式不符,得到 %q", u)
	}
}

func TestInt63n(t *testing.T) {
	rng := random.NewFixedSource(42)
	for i := 0; i < 100; i++ {
		v := int63n(rng, 100)
		if v < 0 || v >= 100 {
			t.Errorf("int63n(100) 应在 [0,100),得到 %d", v)
		}
	}
	// 0 边界
	if int63n(rng, 0) != 0 {
		t.Error("int63n(0) 应返回 0")
	}
	if int63n(rng, -1) != 0 {
		t.Error("int63n(-1) 应返回 0")
	}
}

func TestRandomChoice(t *testing.T) {
	rng := random.NewFixedSource(42)
	items := []string{"a", "b", "c"}
	c := randomChoice(rng, items)
	found := false
	for _, item := range items {
		if c == item {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("randomChoice 应返回切片中的一项,得到 %q", c)
	}
	// 空切片
	if randomChoice(rng, nil) != "" {
		t.Error("空切片应返回空串")
	}
}

func TestRawURLEncode(t *testing.T) {
	// 与标准库 base64.RawURLEncoding 对比
	cases := [][]byte{
		[]byte("hello"),
		[]byte("A"),
		[]byte(""),
		{0x00, 0xFF, 0x7E, 0x3D},
		make([]byte, 16), // 全 0
	}
	// 因为没引入 encoding/base64 依赖,我们只做格式校验
	for _, data := range cases {
		encoded := rawURLEncode(data)
		// 无填充 =
		if strings.Contains(encoded, "=") {
			t.Errorf("rawURLEncode 应无填充,得到 %q", encoded)
		}
		// 应只含 URL-safe 字符
		re := regexp.MustCompile(`^[A-Za-z0-9\-_]*$`)
		if !re.MatchString(encoded) {
			t.Errorf("rawURLEncode 应只含 URL-safe 字符,得到 %q", encoded)
		}
	}
}

// ===== 生产场景(uuid_seq)完整验证 =====

func TestBuild_UUIDSeq_ProductionFormat(t *testing.T) {
	// v1 生产用 uuid_seq;完整格式:uuid.seq@domain
	g := newTestGen()
	mid := g.Build("uuid_seq", "office.gogomorocco.com")

	re := regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.\d+@office\.gogomorocco\.com$`)
	if !re.MatchString(mid) {
		t.Errorf("uuid_seq 生产格式不符,得到 %q", mid)
	}
}

// ===== domain 传递验证 =====

func TestBuild_DomainRespected(t *testing.T) {
	g := newTestGen()
	domains := []string{"a.com", "sub.example.co.jp", "office.gogomorocco.com"}
	for _, d := range domains {
		mid := g.Build("hex16", d)
		if !strings.HasSuffix(mid, "@"+d) {
			t.Errorf("domain %q 应体现在 Message-ID 后缀,得到 %q", d, mid)
		}
	}
}
