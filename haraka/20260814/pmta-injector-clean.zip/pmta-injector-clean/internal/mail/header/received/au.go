package received

import (
	"fmt"
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// generateAu 生成"au"风格 Received 头(KDDI au 运营商)
//
// 【契约】v2 与 v1 email/headers.go::generateReceivedAu 完全一致
//
// 【格式】
//
//	Received: from mail.au.com by mta-snd-e{NN}.au.com with ESMTP
//	  id <{17位时间}.{4大写}.{5数字}.mail.au.com@mta-snd-e{NN}.au.com>
//	  for <{收件人}>;
//	  {日期}
//
// 【规则】
//   - e 编号 01-99(两处一致 —— 3 处 mta-snd-e{NN} 用同一 eStr)
//   - 收件人为空时跳过 for 子句(但仍带日期)
//   - 时间戳 17 位 + 4 大写字母 + 5 数字(id 字段的三段随机)
func generateAu(rng random.Source, toAddress string, t time.Time) string {
	eNum := rng.Intn(99) + 1           // 1-99
	eStr := fmt.Sprintf("e%02d", eNum) // e01-e99
	mtaSndDomain := fmt.Sprintf("mta-snd-%s.au.com", eStr)

	timestamp17 := format17Timestamp(t)
	letters4 := random4UpperLetters(rng)
	digits5 := random5Digits(rng)

	idStr := fmt.Sprintf("%s.%s.%s.mail.au.com@%s",
		timestamp17, letters4, digits5, mtaSndDomain)

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Received: from mail.au.com by %s with ESMTP\r\n", mtaSndDomain))
	sb.WriteString(fmt.Sprintf("  id <%s>\r\n", idStr))
	if toAddress != "" {
		sb.WriteString(fmt.Sprintf("  for <%s>;\r\n", toAddress))
	}
	sb.WriteString(fmt.Sprintf("  %s\r\n", formatJSTDate(t)))

	return sb.String()
}
