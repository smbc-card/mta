package received

import (
	"fmt"
	"time"
)

// jstZone 日本时区(固定 +0900,不依赖服务器本地 tzdata)
//
// 【契约】v2 与 v1 email/headers.go::receivedJST 完全一致(time.FixedZone("JST", 9*3600))
//
// 【为何用固定 FixedZone】不依赖 tzdata:
//   - Windows 服务器可能没有 tzdata
//   - LoadLocation("Asia/Tokyo") 在 tzdata 缺失时返回 error,fallback UTC 会打乱日期格式
//   - 直接 FixedZone 永不失败,且名称显示为 "JST"(与 v1 一致)
var jstZone = time.FixedZone("JST", 9*3600)

// format17Timestamp 生成 yyyyMMddHHmmssfff 格式的 17 位时间戳(年4 月2 日2 时2 分2 秒2 + 毫秒3)
//
// 【契约】v2 与 v1 email/headers.go::format17Timestamp 完全一致
//
// 【调用方】au / softbank 的 Received id 字段使用
// 【假设】输入 t 应已转为 JST(调用方负责);函数内部不再做时区转换
func format17Timestamp(t time.Time) string {
	return t.Format("20060102150405") + fmt.Sprintf("%03d", t.Nanosecond()/1000000)
}

// formatJSTDate 生成标准 RFC 2822 日期 "Mon, 02 Jan 2006 15:04:05 +0900"
//
// 【契约】v2 与 v1 email/headers.go::formatReceivedJSTDate 完全一致
//
// 【假设】输入 t 已含 JST 时区(调用方 t.In(jstZone));-0700 会自动格式化为 +0900
func formatJSTDate(t time.Time) string {
	return t.Format("Mon, 02 Jan 2006 15:04:05 -0700")
}

// formatJSTDateWithJST 生成带 (JST) 后缀的日期 "Mon, 02 Jan 2006 15:04:05 +0900 (JST)"
//
// 【契约】v2 与 v1 email/headers.go::formatReceivedJSTDateWithJST 完全一致
// 【调用方】docomo 风格(Postfix 标准)使用
func formatJSTDateWithJST(t time.Time) string {
	return t.Format("Mon, 02 Jan 2006 15:04:05 -0700") + " (JST)"
}
