package received

import (
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
	"__MODULE_PLACEHOLDER__/internal/security"
)

// Composer Received 头链生成器(per-worker 单实例)
//
// 【依赖注入】
//   - rng:随机源(hop 数加权 / hop 时间 delta / IP 池抽样 / EHLO 编号)
//   - clk:时钟(时间链的 tBase = clk.Now().In(JST))
//   - cfg:读 Received / ReceivedYahoo / ReceivedAu / ReceivedSoftbank / ReceivedDocomo /
//     ReceivedMitsui / ReceivedYahooIPMode / ReceivedRandomEnabled / ReceivedRandomTemplates /
//     ReceivedRandomMode
//
// 【线程安全】非线程安全,per-worker 一个实例
//
// 【状态字段】
//   - randomSeqIdx:ReceivedRandomMode=sequential 时的 worker 独立顺序索引
type Composer struct {
	rng random.Source
	clk clock.Clock
	cfg *config.HeadersConfig

	randomSeqIdx int
}

// New 创建 Received Composer
//
// 【参数】
//   - rng:必需
//   - clk:必需
//   - cfg:必需(nil 时 GenerateAll 直接返回空串)
func New(rng random.Source, clk clock.Clock, cfg *config.HeadersConfig) *Composer {
	return &Composer{
		rng:          rng,
		clk:          clk,
		cfg:          cfg,
		randomSeqIdx: 0,
	}
}

// VariableProcessor 抽象接口:避免 received 包直接 import variables/basic|extended
//
// 【设计】v1 里 vp 是 *email.VariableProcessor 具体类型,v2 用接口解耦:
//   - Received 随机模板 需要 vp.Process(tpl, recipient) 渲染 {RFC2822_*} 等变量
//   - variables 子包 basic.Processor / extended.Processor 都实现此接口
//
// 【调用方】Week 5 builder 传入 basic 或 extended 的 Processor 组合(通常是 chained)
type VariableProcessor interface {
	Process(template string, recipient any) string
}

// GenerateAll 生成 Received 头链(6 优先级折叠 + 原 Received)
//
// 【契约】v2 与 v1 email/headers.go::GenerateAllReceived 语义完全一致
//
// 【拼接顺序】(从顶到底,符合 RFC 5321:越靠上越是最新一跳)
//
//	三井 → docomo → au → softbank → 雅虎 → Received(随机)→ 原 Received
//
// 【时间链】
//   - 5 ESP + Received(随机)全部走累积时间链:顶 = clk.Now().In(JST),每往下减 1-30 秒
//   - 原 Received 不参与时间链,独立用自己内部的 clk.Now()(B2/D1 决策)
//
// 【B4 决策】Received(随机)不走 Worker 50-200 寿命池,每封都重新挑模板(最大反指纹熵)
//
// 【参数】
//   - envelopeFrom / envelopeTo / fromDomain:邮件信封信息(用于原 Received)
//   - vp:变量处理器(Received 随机模板里的 {VAR} 占位符渲染需要);可为 nil(仅当用户未启用 Received 随机时)
//   - recipient:当前收件人对象(用于 vp.Process 渲染 {TO_*});vp 非 nil 时必须非 nil
//
// 【返回】拼接的 raw 字符串(每个头以 "\r\n" 结尾);全部未勾选返回空串
// 【空场景】cfg==nil / cfg.Enabled=false → 返回空串
func (c *Composer) GenerateAll(envelopeFrom, envelopeTo, fromDomain string, vp VariableProcessor, recipient any) string {
	if c.cfg == nil || !c.cfg.Enabled {
		return ""
	}

	// 【安全】5 ESP + 原 Received 内的多个 generator 都会把 envelope 字段拼进 `for <%s>` /
	// `by <%s>` 之类;若字段含 CR/LF 会拆头注入伪造 Received 链。上游 reader 已 sanitize,
	// 这里作为 header 生成端的最后防线。
	envelopeFrom = security.SanitizeHeaderValue(envelopeFrom)
	envelopeTo = security.SanitizeHeaderValue(envelopeTo)
	fromDomain = security.SanitizeHeaderValue(fromDomain)

	// JST 基准时间(与 v1 示例 +0900 对齐)
	tBase := c.clk.Now().In(jstZone)

	// 按 D1 方案 A 顺序收集启用的 5 ESP + Received(随机)生成器
	// 每个生成器是 (t time.Time) -> string 闭包
	type receivedFn func(t time.Time) string
	var generators []receivedFn

	if c.cfg.ReceivedMitsui {
		generators = append(generators, func(t time.Time) string {
			return generateMitsui(t)
		})
	}
	if c.cfg.ReceivedDocomo {
		generators = append(generators, func(t time.Time) string {
			return generateDocomo(c.rng, envelopeTo, t)
		})
	}
	if c.cfg.ReceivedAu {
		generators = append(generators, func(t time.Time) string {
			return generateAu(c.rng, envelopeTo, t)
		})
	}
	if c.cfg.ReceivedSoftbank {
		generators = append(generators, func(t time.Time) string {
			return generateSoftbank(c.rng, envelopeTo, t)
		})
	}
	if c.cfg.ReceivedYahoo {
		// 默认 yahoo(含空串、"yahoo"),仅 "random" 走全球随机公网
		useYahooIP := c.cfg.ReceivedYahooIPMode != "random"
		generators = append(generators, func(t time.Time) string {
			return generateYahoo(c.rng, envelopeTo, useYahooIP, t)
		})
	}

	// Received(随机)插在雅虎和原 Received 之间
	// 【注意】闭包接收 t 参数(generators slice 协议要求)但丢弃;
	// Received 随机模板内部由 {RFC2822_*} 等变量自取时间
	if c.cfg.ReceivedRandomEnabled && len(c.cfg.ReceivedRandomTemplates) > 0 && vp != nil && recipient != nil {
		generators = append(generators, func(_ time.Time) string {
			return generateRandomTemplate(c, c.cfg.ReceivedRandomTemplates, c.cfg.ReceivedRandomMode, vp, recipient)
		})
	}

	// 按累积时间链生成(顶 = tBase,每往下减 1-30 秒)
	var sb strings.Builder
	currentTime := tBase
	for i, gen := range generators {
		if i > 0 {
			delta := time.Duration(c.rng.Intn(30)+1) * time.Second
			currentTime = currentTime.Add(-delta)
		}
		sb.WriteString(gen(currentTime))
	}

	// 原 Received 永远在最底,独立用自己内部时间(B2/D1 决策)
	if c.cfg.Received {
		sb.WriteString(generateOriginal(c.rng, c.clk, envelopeFrom, envelopeTo, fromDomain))
	}

	return sb.String()
}
