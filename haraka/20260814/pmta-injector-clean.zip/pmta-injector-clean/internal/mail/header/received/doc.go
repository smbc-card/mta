// Package received 生成 Received 头链(原 Received + 5 ESP 风格 + Received 随机模板)
//
// 【调用入口】GenerateAll(envelopeFrom, envelopeTo, fromDomain, vp, recipient) - 由 Week 5 builder 调用
//
// 【6 优先级折叠】(GenerateAll 输出顺序):
//  1. Mitsui         - 三井 UFJ 风格
//  2. Docomo         - NTT Docomo 运营商风格
//  3. Au             - KDDI au 运营商风格
//  4. Softbank       - Softbank 运营商风格(含 172.16 内部中继私网 IP)
//  5. Yahoo          - Yahoo Japan 风格(122 CIDR 池 + mta 编号 EHLO)
//  6. RandomTemplate - Received 随机模板(用户配置池,含 {RFC2822_*} 等变量占位符)
//  7. Received       - 原 Received(加权 hop 1/2/3,以 20%/50%/30% 分布)
//
// 【时间链单调】顶(index=0)= now,每往下 hop 减 1-30 秒 —— 符合 RFC 5321 §4.4 追加规则
//
// 【时区】所有日期用 JST(+0900)固定(time.FixedZone),不依赖服务器本地 tzdata
//
// 【多 hop 分布】原 Received:1 hop 20% / 2 hop 50% / 3 hop 30%(与 v1 加权一致)
//   - 1 hop:ESMTPSA 客户端提交
//   - 2 hop:top(MX 接收 ESMTPS) + bottom(客户端 ESMTPSA)
//   - 3 hop:top + middle(内部中继 ESMTP) + bottom
//
// 【危险提示】(v1 明确写在文档 §十五):
//   - Received 总数建议 ≤ 2 个,6 个全开反指纹效果反向
//   - 雅虎 + 发件域 docomo 组合容易被反查识破
//   - softbank 含 172.16 私网 IP 是真实特征,不要"修复"
//
// 【依赖】random.Source + clock.Clock + *config.HeadersConfig + data.Pool(Yahoo CIDR 等)
// 【不 import 其他子包】(D16-1 决策)
package received
