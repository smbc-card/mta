package received

import (
	"net"
	"regexp"
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// fixedTestTime 所有测试用的固定时间基准(JST 中午 12:00,含小时/分/秒/毫秒可辨识)
var fixedTestTime = time.Date(2026, 8, 7, 15, 30, 45, 123000000, time.UTC)

// newTestComposer 建一个可复现的 Composer(FixedSource + FixedClock)
func newTestComposer(seed int64, cfg *config.HeadersConfig) *Composer {
	return New(
		random.NewFixedSource(seed),
		clock.NewFixedClock(fixedTestTime),
		cfg,
	)
}

// fakeVP 实现 VariableProcessor 接口的测试替身 —— Process 只做占位符字面替换
type fakeVP struct {
	replacements map[string]string
}

func (v *fakeVP) Process(template string, _ any) string {
	out := template
	for k, val := range v.replacements {
		out = strings.ReplaceAll(out, k, val)
	}
	return out
}

// fakeRecipient 空的 recipient 占位(vp 只关心非 nil)
type fakeRecipient struct{}

// ============================================================================
// time_util —— JST 时区 + 3 格式化函数
// ============================================================================

func TestJSTZone(t *testing.T) {
	_, offset := time.Now().In(jstZone).Zone()
	if offset != 9*3600 {
		t.Errorf("JST offset 秒:got=%d, want=%d", offset, 9*3600)
	}
	// 名称应为 "JST"(与 v1 一致)
	name, _ := time.Date(2026, 8, 7, 0, 0, 0, 0, jstZone).Zone()
	if name != "JST" {
		t.Errorf("JST zone 名称:got=%q, want=%q", name, "JST")
	}
}

func TestFormat17Timestamp(t *testing.T) {
	// 2026-08-07 15:30:45.123 UTC → 17 位:20260807153045123
	got := format17Timestamp(fixedTestTime)
	want := "20260807153045123"
	if got != want {
		t.Errorf("format17Timestamp:got=%q, want=%q", got, want)
	}
}

func TestFormatJSTDate(t *testing.T) {
	// 2026-08-07 15:30:45 UTC → JST = +0900 → 需先 .In(jstZone)
	tJST := fixedTestTime.In(jstZone)
	got := formatJSTDate(tJST)
	// 期望:Sat, 08 Aug 2026 00:30:45 +0900(UTC+9)
	if !strings.HasSuffix(got, " +0900") {
		t.Errorf("formatJSTDate 时区:got=%q, want 尾部 +0900", got)
	}
	if !strings.Contains(got, "2026") {
		t.Errorf("formatJSTDate 年份:got=%q", got)
	}
}

func TestFormatJSTDateWithJST(t *testing.T) {
	tJST := fixedTestTime.In(jstZone)
	got := formatJSTDateWithJST(tJST)
	if !strings.HasSuffix(got, "+0900 (JST)") {
		t.Errorf("formatJSTDateWithJST:got=%q, want 尾部 '+0900 (JST)'", got)
	}
}

// ============================================================================
// random_util —— 各随机 helper
// ============================================================================

func TestRandom4UpperLetters(t *testing.T) {
	rng := random.NewFixedSource(42)
	s := random4UpperLetters(rng)
	if len(s) != 4 {
		t.Fatalf("长度:got=%d, want=4", len(s))
	}
	for i, ch := range s {
		if ch < 'A' || ch > 'Z' {
			t.Errorf("[%d]=%q 不是大写字母", i, ch)
		}
	}
}

func TestRandom5Digits(t *testing.T) {
	rng := random.NewFixedSource(42)
	s := random5Digits(rng)
	if len(s) != 5 {
		t.Fatalf("长度:got=%d, want=5", len(s))
	}
	for i, ch := range s {
		if ch < '0' || ch > '9' {
			t.Errorf("[%d]=%q 不是数字", i, ch)
		}
	}
}

func TestRandom11AlphaNumUpper(t *testing.T) {
	rng := random.NewFixedSource(42)
	s := random11AlphaNumUpper(rng)
	if len(s) != 11 {
		t.Fatalf("长度:got=%d, want=11", len(s))
	}
	for i, ch := range s {
		valid := (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')
		if !valid {
			t.Errorf("[%d]=%q 不是大写字母或数字", i, ch)
		}
	}
}

func TestRandomHex(t *testing.T) {
	rng := random.NewFixedSource(42)
	// n=0 / 负数 → 空
	if s := randomHex(rng, 0); s != "" {
		t.Errorf("n=0:got=%q, want 空", s)
	}
	if s := randomHex(rng, -1); s != "" {
		t.Errorf("n=-1:got=%q, want 空", s)
	}
	// n=16 → 16 字符 hex
	s := randomHex(rng, 16)
	if len(s) != 16 {
		t.Errorf("n=16 长度:got=%d, want=16", len(s))
	}
	if !regexp.MustCompile(`^[0-9a-f]+$`).MatchString(s) {
		t.Errorf("非合法 hex:%q", s)
	}
}

// ============================================================================
// ip.go
// ============================================================================

func TestIPToUint32(t *testing.T) {
	// 192.168.1.1 → 0xC0A80101 = 3232235777
	got := ipToUint32(net.IPv4(192, 168, 1, 1))
	if got != 0xC0A80101 {
		t.Errorf("ipToUint32:got=0x%X, want=0xC0A80101", got)
	}
	// IPv6 → 0
	if ipToUint32(net.ParseIP("::1")) != 0 {
		t.Error("IPv6 应返回 0")
	}
}

func TestUint32ToIPv4(t *testing.T) {
	if got := uint32ToIPv4(0xC0A80101); got != "192.168.1.1" {
		t.Errorf("uint32ToIPv4:got=%q, want=%q", got, "192.168.1.1")
	}
	if got := uint32ToIPv4(0); got != "0.0.0.0" {
		t.Errorf("uint32ToIPv4(0):got=%q", got)
	}
}

func TestRandomIPInCIDR_Slash24(t *testing.T) {
	rng := random.NewFixedSource(42)
	_, n, _ := net.ParseCIDR("192.168.1.0/24")
	// 抽 100 次,都应在 192.168.1.1 ~ 192.168.1.254 之间
	for i := 0; i < 100; i++ {
		ip := randomIPInCIDR(rng, n)
		parts := strings.Split(ip, ".")
		if len(parts) != 4 || parts[0] != "192" || parts[1] != "168" || parts[2] != "1" {
			t.Fatalf("第 %d 次 IP 越界 CIDR:%q", i, ip)
		}
		if parts[3] == "0" || parts[3] == "255" {
			t.Errorf("第 %d 次 IP=%q 未避开网络/广播号", i, ip)
		}
	}
}

func TestRandomIPInCIDR_Slash32(t *testing.T) {
	rng := random.NewFixedSource(42)
	_, n, _ := net.ParseCIDR("203.0.113.1/32")
	// /32 应直接返回基地址
	if got := randomIPInCIDR(rng, n); got != "203.0.113.1" {
		t.Errorf("/32:got=%q, want=%q", got, "203.0.113.1")
	}
}

func TestRandomYahooIP(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 首次 lazy-load 应成功(v2 data 包 YahooCidrsPool 有 122 条)
	ip := randomYahooIP(rng)
	if net.ParseIP(ip) == nil {
		t.Errorf("非合法 IP:%q", ip)
	}
	// 验证 Yahoo IP 在池覆盖的一个大段里(不能是 127.x 或 192.168.x 等私网)
	if strings.HasPrefix(ip, "127.") || strings.HasPrefix(ip, "192.168.") ||
		strings.HasPrefix(ip, "10.") {
		t.Errorf("Yahoo IP 不应在私网:%q", ip)
	}
}

func TestRandomPublicIP(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 抽 50 次,每次都应是合法公网(不在 9 段非公网)
	nonRoutablePrefixes := []string{
		"0.", "10.", "127.", "169.254.", "172.16.", "172.17.", "172.18.",
		"172.19.", "172.20.", "172.21.", "172.22.", "172.23.", "172.24.",
		"172.25.", "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.",
		"192.168.", "224.", "225.", "226.", "227.", "228.", "229.", "230.", "231.",
		"232.", "233.", "234.", "235.", "236.", "237.", "238.", "239.",
		"240.", "255.",
	}
	for i := 0; i < 50; i++ {
		ip := randomPublicIP(rng)
		if net.ParseIP(ip) == nil {
			t.Fatalf("第 %d 次非合法 IP:%q", i, ip)
		}
		for _, prefix := range nonRoutablePrefixes {
			if strings.HasPrefix(ip, prefix) {
				t.Errorf("第 %d 次 IP=%q 在非公网段 %q", i, ip, prefix)
				break
			}
		}
	}
}

func TestRandomSoftbank172IP(t *testing.T) {
	rng := random.NewFixedSource(42)
	ip := randomSoftbank172IP(rng)
	// 必须在 172.16.0.0/12 段(172.16.x.x ~ 172.31.x.x)
	if !strings.HasPrefix(ip, "172.") {
		t.Errorf("softbank IP 应以 172. 开头:%q", ip)
	}
	parts := strings.Split(ip, ".")
	if len(parts) != 4 {
		t.Fatalf("非合法 IP:%q", ip)
	}
	// 第二段 16-31
	if parts[1] < "16" || parts[1] > "31" {
		t.Errorf("softbank 第二段应在 16-31:%q", ip)
	}
}

// ============================================================================
// hostgen —— 域名/IP/用户名/MailID
// ============================================================================

func TestGenerateRandomDomain(t *testing.T) {
	rng := random.NewFixedSource(42)
	d := generateRandomDomain(rng)
	// 应以 mail. 或 smtp. 开头
	if !strings.HasPrefix(d, "mail.") && !strings.HasPrefix(d, "smtp.") {
		t.Errorf("域名应以 mail./smtp. 开头:%q", d)
	}
	// 应含 . 分隔
	if strings.Count(d, ".") < 2 {
		t.Errorf("域名结构异常:%q", d)
	}
}

func TestGenerateRandomIPRealistic(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 抽 50 次,first octet 应在 {1-9, 11-126, 128-169, 171, 173-191, 193-223}
	for i := 0; i < 50; i++ {
		ip := generateRandomIPRealistic(rng)
		parts := strings.Split(ip, ".")
		if len(parts) != 4 {
			t.Fatalf("第 %d 次:%q", i, ip)
		}
		// 尾字节 1-254
		last := parts[3]
		if last == "0" || last == "255" {
			t.Errorf("第 %d 次 IP=%q 尾字节 0/255 未避开", i, ip)
		}
	}
}

func TestGenerateMailID(t *testing.T) {
	rng := random.NewFixedSource(42)
	id := generateMailID(rng)
	// 格式:{8}-{4}-{4}-{4}.{1}
	re := regexp.MustCompile(`^[A-Z0-9]{8}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}\.[1-9]$`)
	if !re.MatchString(id) {
		t.Errorf("MailID 格式不匹配:%q", id)
	}
}

func TestGenerateMailID_Reproducibility(t *testing.T) {
	// v2 与 v1 差异:v2 全用 rng(包括前 8 字符),故 FixedSource 完全复现
	rng1 := random.NewFixedSource(42)
	rng2 := random.NewFixedSource(42)
	if id1, id2 := generateMailID(rng1), generateMailID(rng2); id1 != id2 {
		t.Errorf("复现失败:%q vs %q", id1, id2)
	}
}

func TestGenerateRandomUsername(t *testing.T) {
	rng := random.NewFixedSource(42)
	u := generateRandomUsername(rng)
	// 格式:{name}{3digits} —— name 至少 4 字符 + 3 位数字尾
	re := regexp.MustCompile(`^[a-z]{4,}\d{3}$`)
	if !re.MatchString(u) {
		t.Errorf("username 格式不匹配:%q", u)
	}
}

// ============================================================================
// 5 ESP 各风格
// ============================================================================

func TestGenerateYahoo(t *testing.T) {
	rng := random.NewFixedSource(42)
	tJST := fixedTestTime.In(jstZone)
	got := generateYahoo(rng, "user@example.com", true, tJST)
	// 结构验证:2 行,第 1 行 from + EHLO,第 2 行 by ... with SMTP
	if !strings.Contains(got, "Received: from ") {
		t.Errorf("缺少 'Received: from':\n%s", got)
	}
	if !strings.Contains(got, "  (EHLO ") {
		t.Errorf("缺少 '  (EHLO ':\n%s", got)
	}
	if !strings.Contains(got, "\r\n  by ") {
		t.Errorf("第 2 行缩进 2 空格 + by:\n%s", got)
	}
	if !strings.Contains(got, " with SMTP;") {
		t.Errorf("缺少 ' with SMTP;':\n%s", got)
	}
	if !strings.HasSuffix(got, "\r\n") {
		t.Errorf("尾部应 CRLF:%q", got)
	}
	// EHLO 域应含 .gm.yahoo.co.jp
	if !strings.Contains(got, ".gm.yahoo.co.jp") {
		t.Errorf("EHLO 域应含 .gm.yahoo.co.jp:\n%s", got)
	}
	// by 域应是 6 patterns 之一 —— 关键子串验证
	byPatterns := []string{".mail.otm.ynwp.yahoo.co.jp", ".mail.snz.ynwp.yahoo.co.jp",
		".kks.gm.yahoo.co.jp", ".ssk.gm.yahoo.co.jp"}
	found := false
	for _, p := range byPatterns {
		if strings.Contains(got, "by mta") && strings.Contains(got, p) {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("by 域不在 6 patterns 中:\n%s", got)
	}
}

func TestGenerateAu_WithRecipient(t *testing.T) {
	rng := random.NewFixedSource(42)
	tJST := fixedTestTime.In(jstZone)
	got := generateAu(rng, "user@example.com", tJST)
	// 4 行:Received / id / for / date
	lines := strings.Split(strings.TrimRight(got, "\r\n"), "\r\n")
	if len(lines) != 4 {
		t.Errorf("au 应 4 行(with for),got=%d 行:\n%s", len(lines), got)
	}
	if !strings.HasPrefix(lines[0], "Received: from mail.au.com by mta-snd-e") {
		t.Errorf("第 1 行结构:%q", lines[0])
	}
	// eNum 一致性检查:第 1 行的 e{NN} 应与 id 内 @ 后的 e{NN} 一致
	eRe := regexp.MustCompile(`mta-snd-(e\d{2})`)
	m1 := eRe.FindStringSubmatch(lines[0])
	m2 := eRe.FindStringSubmatch(lines[1])
	if len(m1) < 2 || len(m2) < 2 {
		t.Fatalf("eNum 未匹配:%s / %s", lines[0], lines[1])
	}
	if m1[1] != m2[1] {
		t.Errorf("eNum 两处不一致:第 1 行=%s, 第 2 行=%s", m1[1], m2[1])
	}
}

func TestGenerateAu_NoRecipient(t *testing.T) {
	rng := random.NewFixedSource(42)
	tJST := fixedTestTime.In(jstZone)
	got := generateAu(rng, "", tJST)
	// 收件人空 → 只 3 行(跳过 for)
	if strings.Contains(got, "for <>") {
		t.Errorf("空收件人不应有 for 子句:\n%s", got)
	}
	lines := strings.Split(strings.TrimRight(got, "\r\n"), "\r\n")
	if len(lines) != 3 {
		t.Errorf("au 空收件人应 3 行,got=%d 行:\n%s", len(lines), got)
	}
}

func TestGenerateSoftbank(t *testing.T) {
	rng := random.NewFixedSource(42)
	tJST := fixedTestTime.In(jstZone)
	got := generateSoftbank(rng, "user@example.com", tJST)
	// 10 空格缩进特征
	if !strings.Contains(got, "          by ") {
		t.Errorf("softbank 10 空格 by 缩进缺失:\n%s", got)
	}
	if !strings.Contains(got, "          id <") {
		t.Errorf("softbank 10 空格 id 缩进缺失:\n%s", got)
	}
	// 172.x.x.x IP 特征
	if !strings.Contains(got, "([172.") {
		t.Errorf("softbank 172 私网 IP 缺失:\n%s", got)
	}
	// ebmky / dimky 域名
	if !strings.Contains(got, "ebmky") || !strings.Contains(got, "dimky") {
		t.Errorf("softbank ebmky/dimky 域名缺失:\n%s", got)
	}
	// dimky-sc 两处一致(by 行 和 id @ 前)
	scRe := regexp.MustCompile(`dimky(\d{3})sc`)
	matches := scRe.FindAllStringSubmatch(got, -1)
	if len(matches) < 2 {
		t.Fatalf("dimky-sc 未双次出现:%v", matches)
	}
	if matches[0][1] != matches[1][1] {
		t.Errorf("dimky-sc 两处编号不一致:%s vs %s", matches[0][1], matches[1][1])
	}
}

func TestGenerateDocomo(t *testing.T) {
	rng := random.NewFixedSource(42)
	tJST := fixedTestTime.In(jstZone)
	got := generateDocomo(rng, "user@example.com", tJST)
	// Postfix 特征
	if !strings.Contains(got, "(Postfix) with ESMTP id ") {
		t.Errorf("Postfix 特征缺失:\n%s", got)
	}
	// (JST) 后缀
	if !strings.Contains(got, "(JST)") {
		t.Errorf("(JST) 后缀缺失:\n%s", got)
	}
	// mail{N}.docomo-bill.ne.jp
	if !regexp.MustCompile(`mail\d{1,2}\.docomo-bill\.ne\.jp`).MatchString(got) {
		t.Errorf("docomo-bill 主机名缺失:\n%s", got)
	}
	// 11 位 queue id
	if !regexp.MustCompile(`ESMTP id [A-Z0-9]{11}`).MatchString(got) {
		t.Errorf("11 位 queue id 缺失:\n%s", got)
	}
}

func TestGenerateMitsui(t *testing.T) {
	tJST := fixedTestTime.In(jstZone)
	got := generateMitsui(tJST)
	// vpass → smbc 固定字符串
	if !strings.HasPrefix(got, "Received: from mail.vpass.ne.jp by mail.smbc.co.jp;\r\n") {
		t.Errorf("mitsui 首行结构:\n%s", got)
	}
	// 第 2 行 3 空格缩进
	if !strings.Contains(got, "\r\n   ") {
		t.Errorf("mitsui 3 空格缩进缺失:\n%s", got)
	}
	// 应以 CRLF 结尾
	if !strings.HasSuffix(got, "\r\n") {
		t.Errorf("尾部应 CRLF")
	}
}

// ============================================================================
// original —— 原 Received 加权 hop
// ============================================================================

func TestGenerateOriginal_StructureValid(t *testing.T) {
	rng := random.NewFixedSource(42)
	clk := clock.NewFixedClock(fixedTestTime)
	got := generateOriginal(rng, clk, "from@example.com", "to@example.com", "example.com")
	// 至少含 1 个 "Received: from"
	if !strings.Contains(got, "Received: from ") {
		t.Errorf("缺 'Received: from':\n%s", got)
	}
	// 至少含 " for <to@example.com>"
	if !strings.Contains(got, " for <to@example.com>") {
		t.Errorf("缺 for 子句:\n%s", got)
	}
	// 至少含 "TLS1_" (v1 硬编码 tlsVersion)
	if !strings.Contains(got, "TLS1_") {
		t.Errorf("缺 TLS 版本:\n%s", got)
	}
}

func TestGenerateOriginal_HopDistribution(t *testing.T) {
	// 抽 1000 次,统计 hop 分布(通过 "Received:" 出现次数):
	//   1 hop  20% → count 1 次
	//   2 hop  50% → count 2 次
	//   3 hop  30% → count 3 次
	clk := clock.NewFixedClock(fixedTestTime)
	counts := [4]int{} // counts[1..3]
	for i := 0; i < 1000; i++ {
		rng := random.NewFixedSource(int64(i))
		got := generateOriginal(rng, clk, "f@e.com", "t@e.com", "e.com")
		hops := strings.Count(got, "Received: from ")
		if hops >= 1 && hops <= 3 {
			counts[hops]++
		}
	}
	// 允许 ±5% 相对误差(1000 次采样,期望值 200/500/300)
	if counts[1] < 150 || counts[1] > 250 {
		t.Errorf("1 hop 分布偏 20%%:got=%d, want ≈200", counts[1])
	}
	if counts[2] < 450 || counts[2] > 550 {
		t.Errorf("2 hop 分布偏 50%%:got=%d, want ≈500", counts[2])
	}
	if counts[3] < 250 || counts[3] > 350 {
		t.Errorf("3 hop 分布偏 30%%:got=%d, want ≈300", counts[3])
	}
}

func TestGenerateOriginal_Reproducibility(t *testing.T) {
	clk := clock.NewFixedClock(fixedTestTime)
	rng1 := random.NewFixedSource(42)
	rng2 := random.NewFixedSource(42)
	out1 := generateOriginal(rng1, clk, "f@e.com", "t@e.com", "e.com")
	out2 := generateOriginal(rng2, clk, "f@e.com", "t@e.com", "e.com")
	if out1 != out2 {
		t.Errorf("复现失败:\nout1=%q\nout2=%q", out1, out2)
	}
}

// ============================================================================
// random_template —— Received(随机)
// ============================================================================

func TestGenerateRandomTemplate_Basic(t *testing.T) {
	cfg := &config.HeadersConfig{Enabled: true}
	c := newTestComposer(42, cfg)
	vp := &fakeVP{replacements: map[string]string{"{IP}": "1.2.3.4"}}
	got := generateRandomTemplate(c, []string{"from foo by bar with SMTP; {IP}"}, "random", vp, &fakeRecipient{})
	// 应以 "Received: " 开头,含替换后的 1.2.3.4,以 CRLF 结尾
	if !strings.HasPrefix(got, "Received: ") {
		t.Errorf("前缀:%q", got)
	}
	if !strings.Contains(got, "1.2.3.4") {
		t.Errorf("变量未渲染:%q", got)
	}
	if !strings.HasSuffix(got, "\r\n") {
		t.Errorf("尾部 CRLF:%q", got)
	}
}

func TestGenerateRandomTemplate_EmptyPool(t *testing.T) {
	c := newTestComposer(42, &config.HeadersConfig{Enabled: true})
	vp := &fakeVP{}
	if got := generateRandomTemplate(c, nil, "random", vp, &fakeRecipient{}); got != "" {
		t.Errorf("空池应返回空,got=%q", got)
	}
	if got := generateRandomTemplate(c, []string{"tpl"}, "random", nil, &fakeRecipient{}); got != "" {
		t.Errorf("vp=nil 应返回空,got=%q", got)
	}
	if got := generateRandomTemplate(c, []string{"tpl"}, "random", vp, nil); got != "" {
		t.Errorf("recipient=nil 应返回空,got=%q", got)
	}
}

func TestGenerateRandomTemplate_SequentialMode(t *testing.T) {
	cfg := &config.HeadersConfig{Enabled: true}
	c := newTestComposer(42, cfg)
	vp := &fakeVP{}
	tpls := []string{"tpl_A", "tpl_B", "tpl_C"}
	// sequential 模式下按 seqIdx 顺序循环
	got1 := generateRandomTemplate(c, tpls, "sequential", vp, &fakeRecipient{})
	got2 := generateRandomTemplate(c, tpls, "sequential", vp, &fakeRecipient{})
	got3 := generateRandomTemplate(c, tpls, "sequential", vp, &fakeRecipient{})
	got4 := generateRandomTemplate(c, tpls, "sequential", vp, &fakeRecipient{}) // 循环回 A
	if !strings.Contains(got1, "tpl_A") {
		t.Errorf("第 1 次应 tpl_A:%q", got1)
	}
	if !strings.Contains(got2, "tpl_B") {
		t.Errorf("第 2 次应 tpl_B:%q", got2)
	}
	if !strings.Contains(got3, "tpl_C") {
		t.Errorf("第 3 次应 tpl_C:%q", got3)
	}
	if !strings.Contains(got4, "tpl_A") {
		t.Errorf("第 4 次应回 tpl_A(循环):%q", got4)
	}
}

// ============================================================================
// GenerateAll —— 主入口 6 优先级折叠 + 组合场景
// ============================================================================

func TestGenerateAll_EmptyCfg(t *testing.T) {
	c := newTestComposer(42, nil)
	if got := c.GenerateAll("f", "t", "d", nil, nil); got != "" {
		t.Errorf("cfg=nil 应返回空,got=%q", got)
	}
}

func TestGenerateAll_EnabledFalse(t *testing.T) {
	c := newTestComposer(42, &config.HeadersConfig{Enabled: false})
	if got := c.GenerateAll("f", "t", "d", nil, nil); got != "" {
		t.Errorf("Enabled=false 应返回空,got=%q", got)
	}
}

func TestGenerateAll_AllEspEnabled_Order(t *testing.T) {
	// 5 ESP 全开 → 按 mitsui → docomo → au → softbank → yahoo 顺序输出
	cfg := &config.HeadersConfig{
		Enabled:          true,
		ReceivedMitsui:   true,
		ReceivedDocomo:   true,
		ReceivedAu:       true,
		ReceivedSoftbank: true,
		ReceivedYahoo:    true,
	}
	c := newTestComposer(42, cfg)
	out := c.GenerateAll("f@e.com", "to@e.com", "e.com", nil, nil)

	// 关键子串按 v1 顺序出现
	iMitsui := strings.Index(out, "vpass.ne.jp")
	iDocomo := strings.Index(out, "docomo-bill.ne.jp")
	iAu := strings.Index(out, "mta-snd-e")
	iSoftbank := strings.Index(out, "ebmky")
	iYahoo := strings.Index(out, "yahoo.co.jp")

	if iMitsui < 0 || iDocomo < 0 || iAu < 0 || iSoftbank < 0 || iYahoo < 0 {
		t.Fatalf("5 ESP 都应出现:\n%s", out)
	}
	if !(iMitsui < iDocomo && iDocomo < iAu && iAu < iSoftbank && iSoftbank < iYahoo) {
		t.Errorf("5 ESP 顺序错:mitsui=%d docomo=%d au=%d softbank=%d yahoo=%d",
			iMitsui, iDocomo, iAu, iSoftbank, iYahoo)
	}
}

func TestGenerateAll_TimeChainMonotonic(t *testing.T) {
	// 5 ESP + 原 Received:5 ESP 时间链应严格单调递减
	// mitsui 的日期 > docomo 的日期 > au 的 > softbank 的 > yahoo 的
	cfg := &config.HeadersConfig{
		Enabled:          true,
		ReceivedMitsui:   true,
		ReceivedDocomo:   true,
		ReceivedAu:       true,
		ReceivedSoftbank: true,
		ReceivedYahoo:    true,
	}
	c := newTestComposer(42, cfg)
	out := c.GenerateAll("f@e.com", "to@e.com", "e.com", nil, nil)

	// 提取每个 ESP 段的日期 —— 找 "+0900" 匹配点
	// mitsui 日期在 vpass 段;docomo 日期在 (JST) 前;等等
	// 简单验证:所有 "+0900" 匹配的完整日期串应严格递减
	dateRe := regexp.MustCompile(`\d{2} [A-Z][a-z]{2} 2026 \d{2}:\d{2}:\d{2} \+0900`)
	dates := dateRe.FindAllString(out, -1)
	if len(dates) < 5 {
		t.Fatalf("应至少含 5 个日期(5 ESP),got=%d:\n%s", len(dates), out)
	}
	// 解析每个日期为 time.Time,验证前 5 个严格递减(第 6 个是 docomo 的重复日期,忽略)
	for i := 1; i < 5; i++ {
		if dates[i-1] <= dates[i] {
			t.Errorf("时间链未严格递减:dates[%d]=%q >= dates[%d]=%q(应大于)",
				i-1, dates[i-1], i, dates[i])
		}
	}
}

func TestGenerateAll_OnlyOriginal(t *testing.T) {
	// 只 Received=true,其他全 false → 只输出原 Received
	cfg := &config.HeadersConfig{Enabled: true, Received: true}
	c := newTestComposer(42, cfg)
	out := c.GenerateAll("f@e.com", "to@e.com", "e.com", nil, nil)

	if !strings.Contains(out, "Received: from ") {
		t.Errorf("缺原 Received:\n%s", out)
	}
	// 不含 ESP 特征
	for _, marker := range []string{"vpass", "docomo-bill", "mta-snd-e", "ebmky", "gm.yahoo"} {
		if strings.Contains(out, marker) {
			t.Errorf("不应含 ESP 特征 %q:\n%s", marker, out)
		}
	}
}

func TestGenerateAll_Reproducibility(t *testing.T) {
	cfg := &config.HeadersConfig{
		Enabled:          true,
		ReceivedMitsui:   true,
		ReceivedYahoo:    true,
		Received:         true,
	}
	c1 := newTestComposer(42, cfg)
	c2 := newTestComposer(42, cfg)
	out1 := c1.GenerateAll("f@e.com", "t@e.com", "e.com", nil, nil)
	out2 := c2.GenerateAll("f@e.com", "t@e.com", "e.com", nil, nil)
	if out1 != out2 {
		t.Errorf("复现失败:len(out1)=%d len(out2)=%d", len(out1), len(out2))
	}
}

func TestGenerateAll_RandomTemplateSlot(t *testing.T) {
	// ReceivedRandomEnabled + templates + vp/recipient 都非 nil → 插在 Yahoo 后、原 Received 前
	cfg := &config.HeadersConfig{
		Enabled:                 true,
		ReceivedYahoo:           true,
		Received:                true,
		ReceivedRandomEnabled:   true,
		ReceivedRandomTemplates: []string{"from marker-random by x with SMTP; test"},
		ReceivedRandomMode:      "random",
	}
	c := newTestComposer(42, cfg)
	vp := &fakeVP{}
	out := c.GenerateAll("f@e.com", "t@e.com", "e.com", vp, &fakeRecipient{})

	iYahoo := strings.Index(out, "gm.yahoo.co.jp")
	iRandom := strings.Index(out, "marker-random")
	// 找原 Received 特征:from + Authenticated sender(bottom hop 必然有;单 hop 也用 client submit)
	iOriginal := strings.Index(out, "Authenticated sender:")

	if iYahoo < 0 || iRandom < 0 || iOriginal < 0 {
		t.Fatalf("三段应都出现:yahoo=%d, random=%d, original=%d", iYahoo, iRandom, iOriginal)
	}
	// yahoo < random < 原 Received
	if !(iYahoo < iRandom) {
		t.Errorf("Random 应在 Yahoo 后:yahoo=%d, random=%d", iYahoo, iRandom)
	}
	// 【注意】原 Received 若 hop=1 是 client submit,若 hop=2/3 top 是 mx accept(无 Authenticated sender)
	// 所以只验证 iRandom < iOriginal 或 iRandom < 原 Received 首行位置
	// 用更 robust 的方式:iRandom 应 < 原 Received 中任何一处 "Received:" 之前
	// 简化验证:iRandom 应 < 最后一个 "Received:" 出现的位置
	lastReceived := strings.LastIndex(out, "Received:")
	if !(iRandom < lastReceived) || iRandom == lastReceived {
		// 检查 iRandom 之后还有 Received: 出现
		afterRandom := out[iRandom+len("marker-random"):]
		if !strings.Contains(afterRandom, "Received:") {
			t.Errorf("Random 之后应还有原 Received:iRandom=%d, lastRcvd=%d",
				iRandom, lastReceived)
		}
	}
}
