package received

import (
	"fmt"
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// generateSoftbank 生成"软银"风格 Received 头(Softbank 运营商)
//
// 【契约】v2 与 v1 email/headers.go::generateReceivedSoftbank 完全一致
//
// 【格式】(注意续行缩进 = 10 个空格,是 softbank 真实邮件特征)
//
//	Received: from ebmky{XXX}sc.i.softbank.jp ([{172.X.X.X}])
//	          by dimky{XXX}sc.i.softbank.jp with ESMTP
//	          id <{17位时间}.{4大写}.{5数字}.dimky{XXX}sc.i.softbank.jp@dimky{XXX}sb.mailsv.softbank.jp>
//	          for <{收件人}>; {日期}
//
// 【规则】
//   - ebmky 编号 101-150(3 位)
//   - dimky-sc 编号 101-150(by 行 和 id 内 @ 之前的 dimky 一致)
//   - dimky-sb 编号 101-150(独立于 dimky-sc)
//   - IP 来自 172.16.0.0/12 私网段(真实软银特征 —— 不要"修复")
//   - 收件人为空时跳过 for 子句,但保留日期
func generateSoftbank(rng random.Source, toAddress string, t time.Time) string {
	const indent = "          " // 10 个空格

	ebmkyNum := rng.Intn(50) + 101   // 101-150
	dimkyScNum := rng.Intn(50) + 101 // 101-150
	dimkySbNum := rng.Intn(50) + 101 // 101-150

	ebmkyDomain := fmt.Sprintf("ebmky%03dsc.i.softbank.jp", ebmkyNum)
	dimkyScDomain := fmt.Sprintf("dimky%03dsc.i.softbank.jp", dimkyScNum)
	dimkySbDomain := fmt.Sprintf("dimky%03dsb.mailsv.softbank.jp", dimkySbNum)
	ip := randomSoftbank172IP(rng)

	timestamp17 := format17Timestamp(t)
	letters4 := random4UpperLetters(rng)
	digits5 := random5Digits(rng)

	idStr := fmt.Sprintf("%s.%s.%s.%s@%s",
		timestamp17, letters4, digits5, dimkyScDomain, dimkySbDomain)

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Received: from %s ([%s])\r\n", ebmkyDomain, ip))
	sb.WriteString(fmt.Sprintf("%sby %s with ESMTP\r\n", indent, dimkyScDomain))
	sb.WriteString(fmt.Sprintf("%sid <%s>\r\n", indent, idStr))
	if toAddress != "" {
		sb.WriteString(fmt.Sprintf("%sfor <%s>; %s\r\n", indent, toAddress, formatJSTDate(t)))
	} else {
		sb.WriteString(fmt.Sprintf("%s%s\r\n", indent, formatJSTDate(t)))
	}

	return sb.String()
}
