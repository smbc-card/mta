package received

import (
	"fmt"
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/data"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// tlsVersions 原 Received 用的 TLS 版本(硬编码,与 v1 一致 —— 带尾逗号)
var tlsVersions = []string{"TLS1_2,", "TLS1_3,"}

// generateOriginal 生成"原 Received"头(加权 hop 1/2/3)
//
// 【契约】v2 与 v1 email/headers.go::generateReceived 语义完全一致
//
// 【多 hop 加权】1 hop 20% / 2 hop 50% / 3 hop 30%
//   - 1 hop:客户端 ESMTPSA 提交(与旧 generateReceived 100% 等价,向后兼容)
//   - 2 hop:top(MX ESMTPS) + bottom(客户端 ESMTPSA)
//   - 3 hop:top + middle(内部中继 ESMTP) + bottom
//
// 【时序】times[0]=top=now;每往下 hop 减 1-30 秒(顺序:top → middle → bottom)
//
// 【节点链接】
//   - top.from = 中继节点 = middle.by(3 hop)/ = internal.by(2 hop)
//   - middle.from = internal = bottom.by
//
// 【参数说明】fromAddress 参数保留兼容,内部忽略(v1 也一样 _ = fromAddress)
//
// 【时间源】使用 clk.Now()(v1 用 time.Now();v2 注入 clock 保测试可复现)
// 【B2/D1 决策】原 Received 独立用自己内部时间,不参与 GenerateAll 的累积时间链
func generateOriginal(rng random.Source, clk clock.Clock, fromAddress, toAddress, domain string) string {
	_ = fromAddress // 保留参数兼容 v1 签名

	now := clk.Now()
	tlsVersion := tlsVersions[rng.Intn(len(tlsVersions))]

	cipher := pickCipher(rng)

	// 加权抽样 hop 数
	r := rng.Intn(100)
	var hopCount int
	switch {
	case r < 20:
		hopCount = 1
	case r < 70:
		hopCount = 2
	default:
		hopCount = 3
	}

	// 时序:times[0]=top=now;每往下 hop 减 1-30 秒
	times := make([]time.Time, hopCount)
	times[0] = now
	for i := 1; i < hopCount; i++ {
		delta := time.Duration(rng.Intn(29)+1) * time.Second
		times[i] = times[i-1].Add(-delta)
	}

	// 客户端节点(bottom hop 用,始终生成)
	clientDomain := generateRandomDomain(rng)
	clientIP := generateRandomIPRealistic(rng)
	username := generateRandomUsername(rng)

	// 单 hop:与旧 generateReceived 行为完全一致(向后兼容)
	if hopCount == 1 {
		return formatClientSubmit(
			clientDomain, clientIP, username, domain,
			domain, pickSoftware(rng), generateMailID(rng),
			toAddress, tlsVersion, cipher, now,
		)
	}

	// 多 hop:构造节点链
	internalDomain := generateRandomDomain(rng)
	internalIP := generateRandomIPRealistic(rng)
	var relayDomain, relayIP string
	if hopCount == 3 {
		relayDomain = generateRandomDomain(rng)
		relayIP = generateRandomIPRealistic(rng)
	}

	// 拼装顺序:top → middle → bottom
	var sb strings.Builder

	// top hop:MX 接收 ESMTPS(by 发件方域,from 来自上一个中继)
	topFromDomain := internalDomain
	topFromIP := internalIP
	if hopCount == 3 {
		topFromDomain = relayDomain
		topFromIP = relayIP
	}
	sb.WriteString(formatMxAccept(
		topFromDomain, topFromIP,
		domain, pickSoftware(rng), generateMailID(rng),
		toAddress, tlsVersion, cipher, times[0],
	))

	// middle hop(仅 3 hop):内部中继 ESMTP(不带 AUTH)
	if hopCount == 3 {
		sb.WriteString(formatInternalRelay(
			internalDomain, internalIP,
			relayDomain, relayIP,
			generateMailID(rng),
			toAddress, tlsVersion, cipher, times[1],
		))
	}

	// bottom hop:客户端 ESMTPSA 提交(与单 hop 同款格式)
	sb.WriteString(formatClientSubmit(
		clientDomain, clientIP, username, domain,
		internalDomain, pickSoftware(rng), generateMailID(rng),
		toAddress, tlsVersion, cipher, times[hopCount-1],
	))

	return sb.String()
}

// pickCipher 从 TLSCiphersPool 池抽一个 cipher 字符串
//
// 【契约】v2 走 data.TLSCiphersPool(17 条);v1 用文件级 tlsCiphers 变量
// 【失败兜底】池加载失败 → 返回 v1 池首条(不 panic)
func pickCipher(rng random.Source) string {
	ciphers, err := data.TLSCiphersPool.Get()
	if err != nil || len(ciphers) == 0 {
		return "cipher=TLS_RSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);"
	}
	return ciphers[rng.Intn(len(ciphers))]
}

// pickSoftware 从 MailserverPool 池抽一个"mail server software"标识
//
// 【契约】v2 走 data.MailserverPool;v1 用文件级 mailServerSoftware 变量
// 【失败兜底】池加载失败 → 返回通用兜底
func pickSoftware(rng random.Source) string {
	pool, err := data.MailserverPool.Get()
	if err != nil || len(pool) == 0 {
		return "Postfix"
	}
	return pool[rng.Intn(len(pool))]
}

// formatClientSubmit 生成"客户端 ESMTPSA 提交"风格 Received 头
//
// 【契约】v2 与 v1 email/headers.go::formatReceivedClientSubmit 字节级一致
//
// 与旧 generateReceived 输出格式 100% 一致(确保 1 hop 模式向后兼容)
func formatClientSubmit(fromDomain, fromIP, user, userDomain,
	byDomain, software, mailID, toAddress, tls, cipher string, t time.Time) string {
	return fmt.Sprintf("Received: from %s ([%s])\r\n"+
		" (Authenticated sender: %s@%s)\r\n"+
		" by %s (%s) with ESMTPSA id %s\r\n"+
		" for <%s>;\r\n"+
		" %s %s %s\r\n",
		fromDomain, fromIP,
		user, userDomain,
		byDomain, software, mailID,
		toAddress,
		tls, cipher, t.Format("Mon, 02 Jan 2006 15:04:05 -0700"))
}

// formatInternalRelay 生成"内部中继 ESMTP"风格 Received 头(不带 AUTH)
//
// 【契约】v2 与 v1 email/headers.go::formatReceivedInternalRelay 字节级一致
//
// 真实场景:邮件从客户端进入内部中继后,由内部中继转给下一个外部中继
func formatInternalRelay(fromDomain, fromIP, byDomain, byIP,
	mailID, toAddress, tls, cipher string, t time.Time) string {
	return fmt.Sprintf("Received: from %s (%s [%s])\r\n"+
		" by %s ([%s]) with ESMTP id %s\r\n"+
		" for <%s>;\r\n"+
		" %s %s %s\r\n",
		fromDomain, fromDomain, fromIP,
		byDomain, byIP, mailID,
		toAddress,
		tls, cipher, t.Format("Mon, 02 Jan 2006 15:04:05 -0700"))
}

// formatMxAccept 生成"MX 接收 ESMTPS"风格 Received 头
//
// 【契约】v2 与 v1 email/headers.go::formatReceivedMxAccept 字节级一致
//
// 真实场景:邮件从最后一个中继投递到目标域 MX 时的接收记录
func formatMxAccept(fromDomain, fromIP, byDomain, software, mailID,
	toAddress, tls, cipher string, t time.Time) string {
	return fmt.Sprintf("Received: from %s ([%s])\r\n"+
		" by %s (%s) with ESMTPS id %s\r\n"+
		" for <%s>;\r\n"+
		" %s %s %s\r\n",
		fromDomain, fromIP,
		byDomain, software, mailID,
		toAddress,
		tls, cipher, t.Format("Mon, 02 Jan 2006 15:04:05 -0700"))
}
