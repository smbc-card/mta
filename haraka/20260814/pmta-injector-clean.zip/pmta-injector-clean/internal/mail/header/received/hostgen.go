package received

import (
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/data"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// generateRandomDomain 随机生成一个"看起来真"的域名(用于原 Received 里的 clientDomain 等)
//
// 【契约】v2 与 v1 email/headers.go::generateRandomDomain 语义一致
//
// 【两种格式】50/50 随机:
//   - 格式 1: mail.{7位hex}.{tld}
//   - 格式 2: smtp.{word}-{suffix}.{tld}
//
// 【数据】TLD / Word / Suffix 池走 data 包(v1 硬编码 74/104/89 条,已抽出到 data)
// 【失败兜底】池加载失败时用 fallback "mail.example.com"
func generateRandomDomain(rng random.Source) string {
	tlds, err := data.DomainTLDsPool.Get()
	if err != nil || len(tlds) == 0 {
		return "mail.example.com"
	}
	words, err := data.DomainWordsPool.Get()
	if err != nil || len(words) == 0 {
		return "mail.example.com"
	}
	suffixes, err := data.DomainSuffixesPool.Get()
	if err != nil || len(suffixes) == 0 {
		return "mail.example.com"
	}

	if rng.Intn(2) == 0 {
		// 格式 1: mail.{7hex}.{tld}
		return fmt.Sprintf("mail.%s.%s", randomHex(rng, 7), tlds[rng.Intn(len(tlds))])
	}
	// 格式 2: smtp.{word}-{suffix}.{tld}
	return fmt.Sprintf("smtp.%s-%s.%s",
		words[rng.Intn(len(words))],
		suffixes[rng.Intn(len(suffixes))],
		tlds[rng.Intn(len(tlds))])
}

// generateRandomIPRealistic 生成真实范围的随机 IP(排除 first-octet 里明显非公网范围)
//
// 【契约】v2 与 v1 email/headers.go::generateRandomIPRealistic 语义一致
//
// 【硬编码范围】first octet 只从 6 个区间抽:
//   {1-9} {11-126} {128-169} {171-171} {173-191} {193-223}
// 【尾字节】1-254(避开网络号 0 和广播号 255)
func generateRandomIPRealistic(rng random.Source) string {
	validRanges := [][2]int{
		{1, 9}, {11, 126}, {128, 169}, {171, 171},
		{173, 191}, {193, 223},
	}
	r := validRanges[rng.Intn(len(validRanges))]
	first := rng.Intn(r[1]-r[0]+1) + r[0]
	second := rng.Intn(255)
	third := rng.Intn(255)
	fourth := rng.Intn(254) + 1
	return fmt.Sprintf("%d.%d.%d.%d", first, second, third, fourth)
}

// generateMailID 生成邮件传输 ID(原 Received 的 id 字段)
//
// 【契约】v2 与 v1 email/headers.go::generateMailID **格式一致**(数据字节因 rng 源不同会不同)
//
// 【格式】{8 大写字母数字}-{4 大写 hex}-{4 大写 hex}-{4 大写 hex}.{1-9 位数字}
//
// 【v2 差异】v1 前 8 字符用 crypto/rand,v2 全部用注入 Source —— 为保测试可复现
// (v2 全项目统一策略:所有随机都可通过 FixedSource 精确复现;
//  这与 v1 行为字节不同,但反指纹语义完全等价 —— 输出格式合法且随机)
func generateMailID(rng random.Source) string {
	const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, 8)
	for i := range result {
		result[i] = chars[rng.Intn(len(chars))]
	}
	dash1 := randomHex(rng, 4)
	dash2 := randomHex(rng, 4)
	dash3 := randomHex(rng, 4)
	return fmt.Sprintf("%s-%s-%s-%s.%d",
		strings.ToUpper(string(result)),
		strings.ToUpper(dash1),
		strings.ToUpper(dash2),
		strings.ToUpper(dash3),
		rng.Intn(9)+1)
}

// generateRandomUsername 生成 Authenticated sender 用户名(用户名 + 3 位数字后缀)
//
// 【契约】v2 与 v1 email/headers.go::generateRandomUsername 语义一致
//
// 【池】16 条硬编码用户名(v1 一致)
func generateRandomUsername(rng random.Source) string {
	usernames := []string{
		"username", "user", "mail", "admin", "sender", "client",
		"account", "mailer", "webmaster", "system", "daemon",
		"notification", "postmaster", "mailsystem", "automated", "monitor",
	}
	name := usernames[rng.Intn(len(usernames))]
	number := rng.Intn(1000)
	return fmt.Sprintf("%s%03d", name, number)
}

