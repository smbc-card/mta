package received

import (
	"strings"

	"__MODULE_PLACEHOLDER__/internal/mail/header/fold"
)

// generateRandomTemplate 生成"Received(随机)"头(用户配置模板池)
//
// 【契约】v2 与 v1 email/headers.go::generateReceivedRandom 语义完全一致
//
// 【工作流】
//  1. 从 tpls 池选一条模板(mode = sequential | random)
//  2. 用 vp.Process 渲染变量占位符({RFC2822_*} / {IP_YAHOO_JP} / {JWT_TOKEN} 等)
//  3. RFC 5322 §2.2.3 折叠(长行 > 78 字符断行,续行 "\r\n\t")
//  4. 拼上 "Received: " 前缀和 "\r\n" 收尾
//
// 【B3 决策】顺序模式用 seqIdxPtr 独立计数器(worker 内顺序但 worker 间交错)
// 【B4 决策】每封都重新挑,不走 Worker 50-200 寿命池(最大反指纹熵)
//
// 【返回】空场景(池空 / vp nil / recipient nil / 选中模板为空)→ 返回空串
//
// 【时间源】模板内 {RFC2822_*} 等变量自己取 time.Now(),本函数不接受 t 参数
// (上层 GenerateAll 在 generators 闭包里会丢弃 t 参数)
func generateRandomTemplate(c *Composer, tpls []string, mode string, vp VariableProcessor, recipient any) string {
	if len(tpls) == 0 || vp == nil || recipient == nil {
		return ""
	}

	// 选模板(顺序 vs 随机);大小写不敏感(防御用户手改 config)
	var tpl string
	n := len(tpls)
	if strings.EqualFold(strings.TrimSpace(mode), "sequential") {
		tpl = tpls[c.randomSeqIdx%n]
		c.randomSeqIdx++
	} else {
		// 默认随机(空串、"random" 都走这里)
		tpl = tpls[c.rng.Intn(n)]
	}

	tpl = strings.TrimSpace(tpl)
	if tpl == "" {
		return ""
	}

	// 渲染变量
	rendered := vp.Process(tpl, recipient)

	// 折叠(含 "Received: " 前缀的宽度预留)
	folded := fold.Fold(rendered, len("Received: "))

	return "Received: " + folded + "\r\n"
}
