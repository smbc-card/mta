package received

import (
	"fmt"
	"time"
)

// generateMitsui 生成"三井"风格 Received 头(SMBC / vpass 邮件系统)
//
// 【契约】v2 与 v1 email/headers.go::generateReceivedMitsui 完全一致
//
// 【格式】(vpass→smbc,几乎全固定,仅日期变化)
//
//	Received: from mail.vpass.ne.jp by mail.smbc.co.jp;
//	   {日期}
//
// 【规则】第 2 行 3 空格缩进,没有 for <> 子句,不接收 toAddress
// 【无 rng 依赖】纯格式化,不引 random.Source 参数
func generateMitsui(t time.Time) string {
	return fmt.Sprintf("Received: from mail.vpass.ne.jp by mail.smbc.co.jp;\r\n"+
		"   %s\r\n", formatJSTDate(t))
}
