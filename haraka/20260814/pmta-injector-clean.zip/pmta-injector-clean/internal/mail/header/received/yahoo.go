package received

import (
	"fmt"
	"time"

	"__MODULE_PLACEHOLDER__/internal/data"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// generateYahoo 生成"雅虎"风格 Received 头
//
// 【契约】v2 与 v1 email/headers.go::generateReceivedYahoo 完全一致
//
// 【格式】(缩进严格:from 后 2 个空格,第 2 行前 2 个空格)
//
//	Received: from {IP1}  (EHLO {EHLO域}) ({IP2})
//	  by {BY域} with SMTP; {日期}
//
// 【参数】
//   - toAddress: 收件人地址(雅虎风格没有 for <> 子句,此参数仅为统一签名,内部忽略)
//   - useYahooIP: true=从 122 CIDR 池抽 IP;false=全球随机公网 IP(排 9 段非公网)
//   - t: 该 Received 的时间戳(已含 JST 时区,调用方算好)
//
// 【数据来源】
//   - IP: data.YahooCidrsPool(122 条)或 randomPublicIP
//   - EHLO 子域: data.YahooEhloSubdomainsPool(3 条:kks/kth/ssk)
//   - BY 域: data.YahooByPool(6 个 pattern)
func generateYahoo(rng random.Source, toAddress string, useYahooIP bool, t time.Time) string {
	_ = toAddress // 雅虎示例没有 for <>,保留参数维持签名统一

	var ip1, ip2 string
	if useYahooIP {
		ip1 = randomYahooIP(rng)
		ip2 = randomYahooIP(rng)
	} else {
		ip1 = randomPublicIP(rng)
		ip2 = randomPublicIP(rng)
	}

	// EHLO 内层域:mta{001-600}.{kks|kth|ssk}.gm.yahoo.co.jp
	subs, _ := data.YahooEhloSubdomainsPool.Get()
	if len(subs) == 0 {
		subs = []string{"kks", "kth", "ssk"} // 兜底(理论不到达)
	}
	ehloSub := subs[rng.Intn(len(subs))]
	ehloNum := rng.Intn(600) + 1 // 1-600
	ehloDomain := fmt.Sprintf("mta%03d.%s.gm.yahoo.co.jp", ehloNum, ehloSub)

	// by 外层域:6 种范式之一
	if len(data.YahooByPool) == 0 {
		// 极端兜底
		return fmt.Sprintf("Received: from %s  (EHLO %s) (%s)\r\n"+
			"  by mta0001.mail.otm.ynwp.yahoo.co.jp with SMTP; %s\r\n",
			ip1, ehloDomain, ip2, formatJSTDate(t))
	}
	byPat := data.YahooByPool[rng.Intn(len(data.YahooByPool))]
	byNum := rng.Intn(byPat.EndNum-byPat.StartNum+1) + byPat.StartNum
	byDomain := fmt.Sprintf(byPat.Template, byNum)

	return fmt.Sprintf("Received: from %s  (EHLO %s) (%s)\r\n"+
		"  by %s with SMTP; %s\r\n",
		ip1, ehloDomain, ip2,
		byDomain, formatJSTDate(t))
}
