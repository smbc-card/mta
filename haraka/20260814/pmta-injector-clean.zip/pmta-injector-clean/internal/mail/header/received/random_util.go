package received

import (
	"encoding/hex"
	"fmt"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// random4UpperLetters 4 个大写字母随机(A-Z)
//
// 【契约】v2 与 v1 email/headers.go::random4UpperLetters 语义完全一致
// 【用途】au / softbank Received id 字段
func random4UpperLetters(rng random.Source) string {
	b := make([]byte, 4)
	for i := range b {
		b[i] = byte('A' + rng.Intn(26))
	}
	return string(b)
}

// random5Digits 5 位数字随机(可有前导零)
//
// 【契约】v2 与 v1 email/headers.go::random5Digits 语义完全一致
// 【用途】au / softbank Received id 字段
func random5Digits(rng random.Source) string {
	return fmt.Sprintf("%05d", rng.Intn(100000))
}

// random11AlphaNumUpper 11 位大写字母+数字混合(Postfix queue ID 风格)
//
// 【契约】v2 与 v1 email/headers.go::random11AlphaNumUpper 语义完全一致
// 【用途】docomo Received Postfix queue ID
func random11AlphaNumUpper(rng random.Source) string {
	const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, 11)
	for i := range b {
		b[i] = charset[rng.Intn(len(charset))]
	}
	return string(b)
}

// randomHex 生成 n 位十六进制字符串(小写)—— 与 messageid/dkim 各自定义的 helper 等价
//
// 【实现】按 (n+1)/2 字节从 Source 读取,然后 hex.EncodeToString,取前 n 字符
// 【用途】原 Received 的 mail ID 生成
func randomHex(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	nBytes := (n + 1) / 2
	b := make([]byte, nBytes)
	_, _ = rng.Read(b)
	h := hex.EncodeToString(b)
	if len(h) > n {
		h = h[:n]
	}
	return h
}
