package received

import (
	"fmt"
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// generateDocomo 生成"docomo"风格 Received 头(NTT Docomo 运营商)
//
// 【契约】v2 与 v1 email/headers.go::generateReceivedDocomo 完全一致
//
// 【格式】(Postfix 标准 1 空格缩进,日期后带 (JST))
//
//	Received: from mail{N}.docomo-bill.ne.jp (localhost [127.0.0.1])
//	 by localhost.docomo.ne.jp (Postfix) with ESMTP id {11位大写+数字}
//	 for <{收件人}>; {日期} (JST)
//
// 【规则】
//   - mail{N}:N 是 1-10 整数(无前导零)
//   - 11 位大写字母 + 数字混合(Postfix queue ID 风格)
//   - 收件人为空时跳过 for 子句(仅保留日期行)
func generateDocomo(rng random.Source, toAddress string, t time.Time) string {
	mailNum := rng.Intn(10) + 1 // 1-10
	mailDomain := fmt.Sprintf("mail%d.docomo-bill.ne.jp", mailNum)
	queueID := random11AlphaNumUpper(rng)

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Received: from %s (localhost [127.0.0.1])\r\n", mailDomain))
	sb.WriteString(fmt.Sprintf(" by localhost.docomo.ne.jp (Postfix) with ESMTP id %s\r\n", queueID))
	if toAddress != "" {
		sb.WriteString(fmt.Sprintf(" for <%s>; %s\r\n", toAddress, formatJSTDateWithJST(t)))
	} else {
		sb.WriteString(fmt.Sprintf(" %s\r\n", formatJSTDateWithJST(t)))
	}

	return sb.String()
}
