package received

import (
	"fmt"
	"net"
	"sync"

	"__MODULE_PLACEHOLDER__/internal/data"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// 【IP 池懒加载】v2 与 v1 的差异:
//
//   - v1 用 package init 一次性解析所有 CIDR 到 []*net.IPNet;失败 panic
//   - v2 用 sync.Once 懒加载,首次调用 randomYahooIP/randomPublicIP 时才解析
//     好处:import 顺序无关 + 测试可控 + 单元测试 dry-run 不解析
//     兜底:失败时返回硬编码 fallback IP(与 v1 行为一致)
var (
	yahooNetsOnce sync.Once
	yahooNets     []*net.IPNet
	yahooNetsErr  error

	nonRoutableNetsOnce sync.Once
	nonRoutableNets     []*net.IPNet
	nonRoutableNetsErr  error

	softbank172Net *net.IPNet
	softbank172NetOnce sync.Once
)

// loadYahooNets 从 data.YahooCidrsPool 加载 + 解析所有 CIDR
//
// 【失败处理】任何一条 CIDR 解析失败 → 整个池为空 + 记录 err
// 【调用方】randomYahooIP 检查 err;若失败用 fallback IP 兜底
func loadYahooNets() ([]*net.IPNet, error) {
	yahooNetsOnce.Do(func() {
		strs, err := data.YahooCidrsPool.Get()
		if err != nil {
			yahooNetsErr = fmt.Errorf("received: 加载 Yahoo CIDR 池: %w", err)
			return
		}
		nets := make([]*net.IPNet, 0, len(strs))
		for _, s := range strs {
			_, n, err := net.ParseCIDR(s)
			if err != nil {
				yahooNetsErr = fmt.Errorf("received: 解析 Yahoo CIDR %q: %w", s, err)
				return
			}
			nets = append(nets, n)
		}
		yahooNets = nets
	})
	return yahooNets, yahooNetsErr
}

// loadNonRoutableNets 从 data.NonRoutableCidrsPool 加载 + 解析 9 段非公网
//
// 【失败处理】同 loadYahooNets;失败时 randomPublicIP fallback
func loadNonRoutableNets() ([]*net.IPNet, error) {
	nonRoutableNetsOnce.Do(func() {
		strs, err := data.NonRoutableCidrsPool.Get()
		if err != nil {
			nonRoutableNetsErr = fmt.Errorf("received: 加载 NonRoutable CIDR 池: %w", err)
			return
		}
		nets := make([]*net.IPNet, 0, len(strs))
		for _, s := range strs {
			_, n, err := net.ParseCIDR(s)
			if err != nil {
				nonRoutableNetsErr = fmt.Errorf("received: 解析 NonRoutable CIDR %q: %w", s, err)
				return
			}
			nets = append(nets, n)
		}
		nonRoutableNets = nets
	})
	return nonRoutableNets, nonRoutableNetsErr
}

// loadSoftbank172Net 解析 softbank 内部中继私网段 172.16.0.0/12(硬编码 v1 常量)
func loadSoftbank172Net() *net.IPNet {
	softbank172NetOnce.Do(func() {
		_, n, err := net.ParseCIDR("172.16.0.0/12")
		if err != nil {
			// 硬编码 CIDR 不可能失败 —— 兜底防御性
			return
		}
		softbank172Net = n
	})
	return softbank172Net
}

// ipToUint32 将 net.IP 转为 uint32(IPv4 only)
//
// 【契约】v2 与 v1 email/headers.go::ipToUint32 完全一致
func ipToUint32(ip net.IP) uint32 {
	ip4 := ip.To4()
	if ip4 == nil {
		return 0
	}
	return uint32(ip4[0])<<24 | uint32(ip4[1])<<16 | uint32(ip4[2])<<8 | uint32(ip4[3])
}

// uint32ToIPv4 将 uint32 转为点分十进制 IPv4
//
// 【契约】v2 与 v1 email/headers.go::uint32ToIPv4 完全一致
func uint32ToIPv4(u uint32) string {
	return fmt.Sprintf("%d.%d.%d.%d", (u>>24)&0xFF, (u>>16)&0xFF, (u>>8)&0xFF, u&0xFF)
}

// randomIPInCIDR 在 CIDR 段内随机一个 IP,避开网络号(.0)和广播号(.255 等)
//
// 【契约】v2 与 v1 email/headers.go::randomIPInCIDR 完全一致
//
// 【边界】/31 和 /32 直接返回段基地址(这俩没有"内部地址"概念)
func randomIPInCIDR(rng random.Source, n *net.IPNet) string {
	ones, bits := n.Mask.Size()
	hostBits := uint(bits - ones)
	if hostBits <= 1 {
		// /31 /32:直接返回基地址
		return uint32ToIPv4(ipToUint32(n.IP))
	}
	size := uint32(1) << hostBits
	// 可用偏移 [1, size-2]
	offset := uint32(rng.Intn(int(size)-2)) + 1
	return uint32ToIPv4(ipToUint32(n.IP) + offset)
}

// randomYahooIP 从 122 条雅虎 CIDR 池里均匀随机选一段,再段内随机一个 IP
//
// 【契约】v2 与 v1 email/headers.go::randomYahooIP 语义一致
// 【失败兜底】池加载失败 → 返回硬编码 "183.79.0.1"(Yahoo Japan 一个真实 IP)
func randomYahooIP(rng random.Source) string {
	nets, err := loadYahooNets()
	if err != nil || len(nets) == 0 {
		return "183.79.0.1"
	}
	idx := rng.Intn(len(nets))
	return randomIPInCIDR(rng, nets[idx])
}

// randomPublicIP 全球随机公网可路由 IPv4,排除 9 段非公网
//
// 【契约】v2 与 v1 email/headers.go::randomPublicIP 语义一致
//
// 【算法】拒绝采样:随机 32 位 → 落在排除段就重抽。9 段总覆盖 < 14%,平均 1.16 次命中
// 【上限】100 次仍未成功(概率 < 10^-90)→ 返回一个保证公网的 IP "203.0.114.1"
// 【失败兜底】非公网池加载失败 → 也返回 "203.0.114.1"
func randomPublicIP(rng random.Source) string {
	nets, err := loadNonRoutableNets()
	if err != nil {
		return "203.0.114.1"
	}
	for tries := 0; tries < 100; tries++ {
		u := uint32(rng.Int63() & 0xffffffff)
		ip := net.IPv4(byte(u>>24), byte(u>>16), byte(u>>8), byte(u)).To4()
		excluded := false
		for _, n := range nets {
			if n.Contains(ip) {
				excluded = true
				break
			}
		}
		if !excluded {
			return uint32ToIPv4(u)
		}
	}
	return "203.0.114.1"
}

// randomSoftbank172IP 软银 Received 用的 172.16.0.0/12 内随机 IP(避开网络号/广播号)
//
// 【契约】v2 与 v1 email/headers.go::randomSoftbank172IP 语义一致
// 【失败兜底】硬编码 CIDR 不可能失败;若极端场景失败,返回 "172.16.0.1"
func randomSoftbank172IP(rng random.Source) string {
	n := loadSoftbank172Net()
	if n == nil {
		return "172.16.0.1"
	}
	return randomIPInCIDR(rng, n)
}
