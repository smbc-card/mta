package fold

import (
	"strings"
	"testing"
)

// ===== Fold =====

// TestFold_ShortValue 短值不需折叠,原样返回
func TestFold_ShortValue(t *testing.T) {
	got := Fold("simple value", 10)
	if got != "simple value" {
		t.Errorf("短值应原样返回,得到 %q", got)
	}
}

// TestFold_ExactlyTarget 值 + prefix 恰好等于 TargetLen,不折叠
func TestFold_ExactlyTarget(t *testing.T) {
	// prefix=10, value 长 68 → 78 = TargetLen 不折
	value := strings.Repeat("x", 68)
	got := Fold(value, 10)
	if strings.Contains(got, "\r\n") {
		t.Errorf("值恰好等于 TargetLen 不应折叠,得到 %q", got)
	}
}

// TestFold_LongValueBreakOnSpace 长值在空格处折叠
func TestFold_LongValueBreakOnSpace(t *testing.T) {
	value := strings.Repeat("word ", 30) // 150 字符,超过 TargetLen
	got := Fold(value, 10)
	if !strings.Contains(got, "\r\n\t") {
		t.Errorf("长值应含 \\r\\n\\t 续行符,得到 %q", got)
	}
}

// TestFold_ReceivedTemplate 生产真实 Received 长头,应正确折叠
func TestFold_ReceivedTemplate(t *testing.T) {
	// 模拟一个 Received 长头(> 200 字符)
	value := "from mail.example.com (mail.example.com [1.2.3.4]) by mtaext.otm.ynwp.yahoo.co.jp with ESMTPSA id 20260807-abc123 for <test@example.com>; Wed, 07 Aug 2026 15:52:01 +0900"
	got := Fold(value, len("Received: "))
	lines := strings.Split(got, "\r\n\t")
	if len(lines) < 2 {
		t.Errorf("Received 长头应折叠 ≥ 2 行,得到 %d 行", len(lines))
	}
	// 每一行(除首行 + prefix)应 ≤ TargetLen
	for i, line := range lines {
		lineLen := len(line)
		if i == 0 {
			lineLen += len("Received: ")
		} else {
			lineLen += 1 // \t
		}
		if lineLen > TargetLen && lineLen > HardLimit {
			t.Errorf("第 %d 行超硬上限:%d > %d", i, lineLen, HardLimit)
		}
	}
}

// TestFold_BreakPriority_Semicolon "; " 是最高优先级
func TestFold_BreakPriority_Semicolon(t *testing.T) {
	// 构造:短句 + 分号 + 长句
	value := strings.Repeat("a", 40) + "; " + strings.Repeat("b", 50)
	got := Fold(value, 10)
	// 断行应在 "; " 后(第 1 行含 "; ")
	firstLineEnd := strings.Index(got, "\r\n\t")
	if firstLineEnd < 0 {
		t.Fatal("应产生折叠")
	}
	firstLine := got[:firstLineEnd]
	if !strings.HasSuffix(firstLine, "; ") {
		t.Errorf("第 1 行应以 '; ' 结尾(优先级最高),得到 %q", firstLine)
	}
}

// TestFold_BreakPriority_For " for " 优先级
func TestFold_BreakPriority_For(t *testing.T) {
	value := strings.Repeat("a", 40) + " for " + strings.Repeat("b", 50)
	got := Fold(value, 10)
	// " for " 应触发断行(第 2 行以 "for" 开头)
	if !strings.Contains(got, "\r\n\tfor ") {
		t.Errorf("应在 ' for ' 前断行,得到 %q", got)
	}
}

// TestFold_NoSpaceInLongLine 无空格的超长行,应硬切
func TestFold_NoSpaceInLongLine(t *testing.T) {
	value := strings.Repeat("x", 200) // 无空格
	got := Fold(value, 10)
	// 应含续行符
	if !strings.Contains(got, "\r\n\t") {
		t.Errorf("无空格超长行也应硬切,得到长度 %d", len(got))
	}
}

// TestFold_CRLFInInput 输入含 CRLF 应被替换为空格
func TestFold_CRLFInInput(t *testing.T) {
	value := "line1\r\nline2\r\nline3"
	got := Fold(value, 10)
	// 结果不应含原来的 \r\n(会被替换成 " ")
	if strings.Contains(got, "line1\r\nline2") {
		t.Errorf("原始 CRLF 应被替换,得到 %q", got)
	}
	if !strings.Contains(got, "line1 line2 line3") {
		t.Errorf("原始 CRLF 应替换为空格,得到 %q", got)
	}
}

// TestFold_EmptyValue 空值应返回空
func TestFold_EmptyValue(t *testing.T) {
	got := Fold("", 10)
	if got != "" {
		t.Errorf("空值应返回空,得到 %q", got)
	}
}

// ===== FoldFullHeader =====

// TestFoldFullHeader 完整头折叠
func TestFoldFullHeader(t *testing.T) {
	value := strings.Repeat("word ", 30)
	got := FoldFullHeader("Received", value)

	// 应以 "Received: " 开头
	if !strings.HasPrefix(got, "Received: ") {
		t.Errorf("应以 'Received: ' 开头,得到 %q", got[:20])
	}
	// 应以 \r\n 结尾
	if !strings.HasSuffix(got, "\r\n") {
		t.Errorf("应以 \\r\\n 结尾,得到 %q", got[len(got)-4:])
	}
	// 应含续行符
	if !strings.Contains(got, "\r\n\t") {
		t.Errorf("长值应折叠")
	}
}

// TestFoldFullHeader_Short 短头不折叠(单行 + CRLF)
func TestFoldFullHeader_Short(t *testing.T) {
	got := FoldFullHeader("Subject", "Hello")
	want := "Subject: Hello\r\n"
	if got != want {
		t.Errorf("短头应无折叠,期望 %q, 得到 %q", want, got)
	}
}

// ===== FoldWithLimit =====

// TestFoldWithLimit_Custom 自定义 targetLen
func TestFoldWithLimit_Custom(t *testing.T) {
	value := strings.Repeat("word ", 10) // ~50 字符
	// 用超严 targetLen=30,即使短值也折叠
	got := FoldWithLimit(value, 5, 30, 200)
	if !strings.Contains(got, "\r\n\t") {
		t.Errorf("严格 targetLen=30 应折叠,得到 %q", got)
	}
}

// ===== findBestBreak =====

func TestFindBestBreak_Semicolon(t *testing.T) {
	// "abc; def" softBudget 8
	got := findBestBreak("abc; def", 8, 100)
	// "; " 在 idx=3,返回 idx+2=5(前段 "abc; ")
	if got != 5 {
		t.Errorf("findBestBreak 应返回 5, 得到 %d", got)
	}
}

func TestFindBestBreak_NoBreak(t *testing.T) {
	// 只有 1 字符,不能切
	got := findBestBreak("a", 1, 100)
	if got >= 0 {
		t.Errorf("单字符不应可切, 得到 %d", got)
	}
}

func TestFindBestBreak_HardBudgetFallback(t *testing.T) {
	// softBudget 内无空格,hardBudget 内有 → 应用 hardBudget 找
	// 构造:100 个 a + 空格 + 150 个 b = 251 字符;hardBudget=200 ≤ 251 才进入 fallback
	value := strings.Repeat("a", 100) + " " + strings.Repeat("b", 150)
	got := findBestBreak(value, 50, 200) // soft 50 无空格,hard 200 内的空格 idx=100
	if got != 101 {                       // 空格 idx+1
		t.Errorf("应在 hardBudget 内找到空格 idx=101, 得到 %d", got)
	}
}
