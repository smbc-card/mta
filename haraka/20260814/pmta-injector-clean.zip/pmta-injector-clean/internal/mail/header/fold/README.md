# internal/mail/header/fold

**用途**:RFC 5322 §2.2.3 邮件头折叠 —— 长头(> 78 字符)在语义边界处断行 + `\r\n\t` 续行前缀。

## 快速开始

```go
import "__MODULE_PLACEHOLDER__/internal/mail/header/fold"

// Fold:折叠头值(不含 Name 和冒号)
folded := fold.Fold(longHeaderValue, len("Received: "))
// 返回:含 \r\n\t 续行符,不含 Name 前缀

// FoldFullHeader:完整头
line := fold.FoldFullHeader("Received", longValue)
// 返回:"Received: folded-value\r\n"

// FoldWithLimit:自定义 targetLen / hardLimit
custom := fold.FoldWithLimit(value, prefixLen, 50, 500)
```

## 断点优先级(v1 fold.go 逻辑,一字节不改)

| 优先级 | 边界 | 说明 |
|--------|------|------|
| 1 | `; ` | 分号后断(含分号) |
| 2 | ` for ` | for 前空格 |
| 3 | ` by ` | by 前空格 |
| 4 | ` with ` | with 前空格 |
| 5 | ` (EHLO ` | ( 前空格 |
| 6 | `) ` | ) 后(含) |
| 7 | 任意空格 | 兜底 |

**性能**:单次扫描 O(n),无回溯。

## RFC 5322 §2.2.3 约束

- 每行 ≤ 78 字符(**软上限**)—— 客户端显示不友好
- 每行 ≤ 998 字符(**硬上限**)—— 违反 RFC,MTA 可能拒收
- 续行必须以 CRLF + WSP(SP 或 TAB)开头
- Header-Name 不能被折叠(必须在首行)

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| 位置 | email/fold.go(私有,包内用) | internal/mail/header/fold(独立包,导出) |
| API | foldHeaderValue / foldFullHeader | Fold / FoldFullHeader + FoldWithLimit |
| 单测 | ❌ 无 | ✅ 16 单测覆盖 6 断点优先级 + 边界 case |

## 未来扩展

- `FoldWithIndent(value, prefixLen, indent string)` —— 支持自定义续行前缀(如 2 空格代替 TAB)
- `EstimateLines(value, prefixLen) int` —— 预估折叠后行数(用于 buffer size 优化)

Week 4+ 有需要再加。

## 测试

```bash
go test -cover ./internal/mail/header/fold/...
# 预期覆盖率 ≥ 95%
```
