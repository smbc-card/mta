package dkim

import (
	"fmt"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// recentRingSize 反指纹环形缓冲区容量(每个 Signer 独立)
//
// 8 = 同一 worker 最近 8 次抽样不重复;62 个源池下避免重复几乎不会失败
const recentRingSize = 8

// Signer 伪 DKIM-Signature 头生成器(per-worker 单实例)
//
// 【依赖注入】
//   - rng:随机源(测试用 FixedSource(seed=42) 可复现)
//   - clk:时钟(签名 t= 字段用,测试用 FixedClock 可复现)
//   - cfg:仅读 DkimHFieldsCustomEnabled / DkimHFieldsList(自定义 h= 字段列表)
//
// 【线程安全】非线程安全。生产 = 每个 worker 一个 Signer 实例(与 v1 一致)。
//
// 【状态字段】
//   - recent[recentRingSize]:环形缓冲区,记录最近用过的 dkimExternalSources 索引
//   - recentPos:下一次写入位置(0..recentRingSize-1 循环)
//   - 初始值填 -1(空槽),避免第一次抽样把 idx=0 误判为"最近用过"
type Signer struct {
	rng random.Source
	clk clock.Clock
	cfg *config.HeadersConfig

	recent    []int
	recentPos int
}

// New 创建 DKIM Signer
//
// 【参数】
//   - rng:必需(nil 会在首次 Generate 时 panic)
//   - clk:必需(同上)
//   - cfg:必需(nil 时 Generate 走 default 自适应 h=)
//
// 【初始化】recent 全填 -1 表示"空槽" —— 不能填 0(0 是 dkimExternalSources 的合法索引)
func New(rng random.Source, clk clock.Clock, cfg *config.HeadersConfig) *Signer {
	recent := make([]int, recentRingSize)
	for i := range recent {
		recent[i] = -1
	}
	return &Signer{
		rng:       rng,
		clk:       clk,
		cfg:       cfg,
		recent:    recent,
		recentPos: 0,
	}
}

// Generate 生成一条完整 DKIM-Signature 头(含末尾 CRLF)
//
// 【契约】v2 与 v1 email/headers.go::generateDkimSignature 语义一致
//
// 【返回格式】(多行,含内部折行)
//
//	DKIM-Signature: v=1; a=rsa-sha256; c=<canon>;\r\n
//	 d=<domain>; s=<selector>; t=<unix-ts>;\r\n
//	 h=<hfields>;\r\n
//	 bh=<base64-32>;\r\n
//	 b=<base64-multiline>\r\n
//
// 【参数说明】fromAddress / domain 保留以维持函数签名兼容 —— 伪签名的 d= 指向外部大厂域
// 而非发件方真实域名(设计详见 doc.go),故本实现故意不使用这两个参数
//
// 【字段多样化】c=/h=/b= 长度不再固定:
//   - c= 按 canonicalizations 加权抽样(relaxed/relaxed 70% 等真实分布)
//   - h= 按发件方风格池抽样(gmail 小写 / outlook 大写 / yahoo 含 Received / ses / japan / generic)
//   - b= 长度对应 selector 的 RSA 位数(1024/2048/4096 → 128/256/512 字节 → 172/344/684 字符)
func (s *Signer) Generate(fromAddress, domain string) string {
	_ = fromAddress // 故意不使用,理由见上方注释
	_ = domain

	src := s.pickExternalSource()

	// selector:SES 风格每次动态生成 32 字符 base32 串,其余从该源候选池随机选
	var selector string
	if src.isSESLike {
		selector = s.generateSESLikeSelector()
	} else if len(src.selectors) > 0 {
		selector = src.selectors[s.rng.Intn(len(src.selectors))]
	} else {
		// 兜底:数据池不一致时落到该分支(正常配置不会到达)
		selector = "default"
	}

	canon := s.pickCanonicalization()
	hFields := s.pickHFields(src.domain)
	bByteCount := signatureByteCount(src.rsaBits)

	bh := randomBase64(s.rng, 32)
	sig := randomBase64Multiline(s.rng, bByteCount)
	timestamp := s.clk.Now().Unix()

	return fmt.Sprintf(
		"DKIM-Signature: v=1; a=rsa-sha256; c=%s;\r\n"+
			" d=%s; s=%s; t=%d;\r\n"+
			" h=%s;\r\n"+
			" bh=%s;\r\n"+
			" b=%s\r\n",
		canon,
		src.domain, selector, timestamp,
		hFields,
		bh,
		sig,
	)
}

// pickExternalSource 加权抽样一个外部域源 + 环形去重
//
// 【算法】
//  1. 累计 totalWeight 后用一次 rng.Intn 实现加权抽样(O(n) 扫描)
//  2. 最多重试 recentRingSize+2 = 10 次以躲开最近历史;超过仍未找到就接受重复
//     (62 个源、最近 8 个,理论上必然能找到非重复项;上限是兜底防极端 case)
//
// 【兜底】池空(理论不可能)→ 返回 &fallbackSource
// 【兜底】totalWeight ≤ 0(理论不可能)→ 返回首项
func (s *Signer) pickExternalSource() *externalSource {
	if len(externalSources) == 0 {
		return &fallbackSource
	}

	totalWeight := 0
	for i := range externalSources {
		totalWeight += externalSources[i].weight
	}
	if totalWeight <= 0 {
		return &externalSources[0]
	}

	maxRetry := recentRingSize + 2
	lastIdx := 0
	for retry := 0; retry < maxRetry; retry++ {
		r := s.rng.Intn(totalWeight)
		idx := 0
		for i := range externalSources {
			r -= externalSources[i].weight
			if r < 0 {
				idx = i
				break
			}
		}
		lastIdx = idx
		if !s.isRecent(idx) {
			s.recordRecent(idx)
			return &externalSources[idx]
		}
	}

	// 重试用完仍未避开最近历史 —— 接受重复(极端情况下池子过小或权重过偏)
	s.recordRecent(lastIdx)
	return &externalSources[lastIdx]
}

// isRecent 检查源索引 idx 是否在最近用过的环形缓冲区中
func (s *Signer) isRecent(idx int) bool {
	for _, v := range s.recent {
		if v == idx {
			return true
		}
	}
	return false
}

// recordRecent 把刚使用的源索引写入环形缓冲区(覆盖最旧的一条)
func (s *Signer) recordRecent(idx int) {
	s.recent[s.recentPos] = idx
	s.recentPos = (s.recentPos + 1) % recentRingSize
}
