package dkim

import "strings"

// hFieldsByStyle h= 字段按发件方风格的真实模板池
//
// 【契约】v2 与 v1 email/headers.go::dkimHFieldsByStyle 字节级一致 —— 5 风格池 + 模板顺序不变
//
// 【设计动机】不同 ESP 的 h= 字段在大小写、顺序、长度上差异显著,按风格池模拟真实分布:
//   - gmail   : 一律小写
//   - outlook : 一律首字大写
//   - yahoo   : 含 Received(与 yahoo.co.jp 共用)
//   - ses     : Amazon SES 自己的顺序
//   - japan   : 针对日本运营商 / MVNO / ISP(20 个域)
//   - generic : 其他归此
var hFieldsByStyle = map[string][]string{
	"gmail": {
		"from:to:subject:date:message-id:mime-version:content-type",
		"from:to:subject:date:message-id:mime-version:reply-to",
		"to:cc:from:subject:message-id:date:mime-version",
	},
	"outlook": {
		"From:To:Subject:Date:Message-ID:Content-Type:Content-Transfer-Encoding:MIME-Version",
		"MIME-Version:Date:From:To:Subject:Message-ID:Content-Type:Content-Transfer-Encoding",
	},
	"yahoo": {
		"Received:From:Reply-To:Subject:Date:To:Message-ID:Content-Type:Content-Transfer-Encoding:MIME-Version",
		"Date:From:Reply-To:Subject:To:MIME-Version:Content-Type:Message-ID",
	},
	"ses": {
		"Date:From:Reply-To:To:Message-ID:Subject:MIME-Version:Content-Type:Content-Transfer-Encoding",
		"From:To:Subject:Date:Message-ID:MIME-Version:Content-Type",
	},
	// 【2026-05-18 第二批新增】japan 风格针对日本运营商 / MVNO / ISP 域名
	// 配合 externalSources 中 20 个日本域使用,实现 d= 日本域 + h= 日本风格协调一致
	"japan": {
		// 模板 1:日本 ESP 经典风格(含 Received,长形式,常见于 nifty / biglobe / so-net 等)
		"Received:From:Reply-To:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding",
		// 模板 2:docomo / softbank 运营商风格(首字大写,含 Sender)
		"From:Sender:Reply-To:To:Subject:Date:Message-ID:Content-Type:MIME-Version",
		// 模板 3:楽天 / MVNO 现代风格(全小写)
		"from:to:subject:date:message-id:mime-version:content-type:content-transfer-encoding",
	},
	"generic": {
		"From:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding",
		"from:to:subject:date:message-id:mime-version:content-type",
		"From:Reply-To:To:Subject:Date:Message-ID:Content-Type",
	},
}

// styleForDomain 根据发件方外部域名匹配对应的 h= 风格 key
//
// 【契约】v2 与 v1 email/headers.go::pickDkimHFields 内 switch 完全一致 —— 域名映射不变
//
// 匹配不到的归 "generic"(覆盖所有非主流大厂域)
func styleForDomain(srcDomain string) string {
	switch srcDomain {
	case "gmail.com", "googlemail.com", "google.com":
		return "gmail"
	case "outlook.com", "hotmail.com", "live.com", "microsoft.com", "office365.com":
		return "outlook"
	case "yahoo.com", "yahoo.co.jp", "ymail.com":
		// 注:yahoo.co.jp 保留在 yahoo 风格(真实 Yahoo Japan DKIM 签名跟 yahoo.com 风格非常接近)
		return "yahoo"
	case "amazonses.com":
		return "ses"
	// 【2026-05-18 第二批新增】日本运营商 / MVNO / ISP 共 20 个域 → japan 风格
	// 5 个原运营商 + 5 个原本地 ISP + 10 个新增(含 i.softbank.jp / Y!mobile / UQ / 楽天 / mineo / IIJmio 等)
	case "docomo.ne.jp", "softbank.ne.jp", "au.com", "ezweb.ne.jp", "kddi.com",
		"nifty.com", "biglobe.ne.jp", "so-net.ne.jp", "ocn.ad.jp", "plala.or.jp",
		"i.softbank.jp", "ymobile.ne.jp", "uqmobile.jp", "rakuten-mobile.jp",
		"mineo.jp", "iijmio.jp", "ocn.ne.jp", "dion.ne.jp", "odn.ne.jp", "zaq.ne.jp":
		return "japan"
	default:
		return "generic"
	}
}

// pickHFields 根据发件方域名选择对应风格的 h= 字段(或用户自定义列表覆盖)
//
// 【方案 D + 方案 β 优先级】cfg.DkimHFieldsCustomEnabled=true 且 DkimHFieldsList 非空
// → 优先用自定义列表(保序 + 大小写规范化 + 强制前置 From);否则走域名自适应池
//
// 【兜底】风格池为空(理论不可能;若某天 hFieldsByStyle 被改坏了)→ 返回 default 7 字段
func (s *Signer) pickHFields(srcDomain string) string {
	if s.cfg != nil && s.cfg.DkimHFieldsCustomEnabled && len(s.cfg.DkimHFieldsList) > 0 {
		return buildCustomHFields(s.cfg.DkimHFieldsList)
	}
	pool := hFieldsByStyle[styleForDomain(srcDomain)]
	if len(pool) == 0 {
		return "From:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding"
	}
	return pool[s.rng.Intn(len(pool))]
}

// buildCustomHFields 用用户自定义字段列表生成 h= 值(方案 D + β)
//
// 【契约】v2 与 v1 email/headers.go::buildCustomDkimHFields 语义完全一致
//
// 【规则】
//   - 按传入顺序保留(列表位置 = h= 里的顺序)
//   - 每个字段名做规范化(normalizeHeaderName)
//   - 去重(同一字段只出现一次;已存在的字段忽略后续副本)
//   - 强制包含 From(RFC 6376 规定;若列表里没有会自动前置到最开头)
//   - 空列表兜底:返回默认 7 字段(保证签名永远有合法 h= 值)
//
// 【向后兼容】DkimHFieldsList 只影响扩展 DKIM 方案 B 的 h= 字段,不影响 PMTA 真实 DKIM
func buildCustomHFields(list []string) string {
	seen := make(map[string]bool, len(list))
	out := make([]string, 0, len(list)+1)
	for _, raw := range list {
		name := normalizeHeaderName(raw)
		if name == "" {
			continue
		}
		lower := strings.ToLower(name)
		if seen[lower] {
			continue
		}
		seen[lower] = true
		out = append(out, name)
	}
	// 强制前置 From(RFC 6376)
	if !seen["from"] {
		out = append([]string{"From"}, out...)
	}
	if len(out) == 0 {
		return "From:To:Subject:Date:Message-ID:MIME-Version:Content-Type"
	}
	return strings.Join(out, ":")
}

// normalizeHeaderName 把用户输入的字段名规范化到"大写-小写-连字符"格式
//
// 【契约】v2 与 v1 email/headers.go::normalizeDkimHeaderName 语义完全一致
//
// 【示例】
//
//	"from"                        → "From"
//	"MESSAGE-ID"                  → "Message-ID"
//	"message-id"                  → "Message-ID"
//	"content-transfer-encoding"   → "Content-Transfer-Encoding"
//	"List-Unsubscribe-Post"       → "List-Unsubscribe-Post"
//	"message_id"(下划线)         → "Message_id"(下划线保留,仅按段首大写)
//
// 【规则】
//  1. 按 '-' 分段
//  2. 每段首字母大写、其余小写
//  3. 特殊:9 常见缩写按 RFC 惯例保留(ID / IP / MIME / DKIM / SPF / DMARC / CSA / URL / HTTP / HTTPS)
//  4. 空段/空整串 → 返回空串(调用方跳过)
func normalizeHeaderName(raw string) string {
	s := strings.TrimSpace(raw)
	if s == "" {
		return ""
	}
	segs := strings.Split(s, "-")
	for i, seg := range segs {
		seg = strings.TrimSpace(seg)
		if seg == "" {
			continue
		}
		lower := strings.ToLower(seg)
		switch lower {
		case "id":
			segs[i] = "ID"
		case "ip":
			segs[i] = "IP"
		case "mime":
			segs[i] = "MIME"
		case "dkim":
			segs[i] = "DKIM"
		case "spf":
			segs[i] = "SPF"
		case "dmarc":
			segs[i] = "DMARC"
		case "csa":
			segs[i] = "CSA"
		case "url":
			segs[i] = "URL"
		case "http", "https":
			segs[i] = strings.ToUpper(lower)
		default:
			// 首字母大写,其余小写(TitleCase)
			r := []rune(lower)
			r[0] = []rune(strings.ToUpper(string(r[0])))[0]
			segs[i] = string(r)
		}
	}
	return strings.Join(segs, "-")
}
