package dkim

// externalSource 一个伪签名候选源(外部大厂域 + 该域的合理 selector 池 + 抽样权重)
//
// 【方案 B 移植自 Haraka 2026-05-15 + 2026-05-18 加 rsaBits 字段】
//   - domain     : d= 字段使用的外部域名
//   - selectors  : 候选 selector(每封邮件从中随机一个);isSESLike=true 时忽略
//   - weight     : 加权抽样权重(值越高被抽中概率越大,模拟真实流量分布)
//   - isSESLike  : true 时 selector 每次动态生成 32 字符 base32 随机串(SES 每客户独立)
//   - rsaBits    : RSA 密钥长度(1024/2048/4096),决定 b= base64 长度(172/344/684 字符)
type externalSource struct {
	domain    string
	selectors []string
	weight    int
	isSESLike bool
	rsaBits   int
}

// externalSources 外部大厂域签名池(62 条,按真实邮件流量加权)
//
// 【契约】v2 与 v1 email/headers.go::dkimExternalSources 字节级一致 —— 顺序、权重、
// selector 池、isSESLike、rsaBits 一个都不变。加新条目请追加到末尾。
//
// 【权重分布参考】总和约 176;单源最大 20(gmail.com ~11%),最小 1(长尾企业域)
var externalSources = []externalSource{
	// ===== Google 系(~20%)=====
	{"gmail.com", []string{"20230601", "20221208", "20210112", "20161025"}, 20, false, 2048},
	{"googlemail.com", []string{"20230601", "20221208"}, 4, false, 2048},
	{"google.com", []string{"20221208", "20230601"}, 4, false, 2048},

	// ===== Microsoft 系(~16%)=====
	{"outlook.com", []string{"selector1", "selector2"}, 12, false, 2048},
	{"hotmail.com", []string{"selector1", "selector2"}, 7, false, 2048},
	{"live.com", []string{"selector1", "selector2"}, 4, false, 2048},
	{"microsoft.com", []string{"selector1", "selector2"}, 3, false, 2048},
	{"office365.com", []string{"selector1"}, 2, false, 2048},

	// ===== Yahoo 系(~8%,含日本 Yahoo 针对 docomo 场景加分)=====
	{"yahoo.com", []string{"s2048", "s1024", "s1"}, 6, false, 2048},
	{"yahoo.co.jp", []string{"s2048", "s1024"}, 6, false, 2048},
	{"ymail.com", []string{"s2048"}, 2, false, 2048},

	// ===== Apple 系(~4%)=====
	{"icloud.com", []string{"1a1hai", "sig1"}, 5, false, 2048},
	{"me.com", []string{"1a1hai"}, 2, false, 2048},

	// ===== Amazon SES(~6%,selector 每次动态 32 字符随机生成)=====
	{"amazonses.com", nil, 10, true, 2048},

	// ===== ESP 邮件服务商(~11%)=====
	{"sendgrid.net", []string{"s1", "smtpapi", "m1"}, 5, false, 2048},
	{"sendgrid.me", []string{"s1"}, 1, false, 2048},
	{"mailgun.org", []string{"k1", "mg", "pic"}, 4, false, 2048},
	{"mandrillapp.com", []string{"mandrill", "mte1"}, 3, false, 2048},
	{"mcsv.net", []string{"k2"}, 2, false, 2048},
	{"mtasv.net", []string{"20150623"}, 1, false, 2048},
	{"sparkpostmail.com", []string{"scph1220"}, 1, false, 2048},
	{"hubspotemail.net", []string{"hs1"}, 2, false, 2048},

	// ===== 日本运营商域(~10%,2026-05-18 新增,针对日本市场加权)=====
	{"docomo.ne.jp", []string{"docomo", "mail"}, 5, false, 2048},
	{"softbank.ne.jp", []string{"sb", "softbank"}, 4, false, 2048},
	{"au.com", []string{"au", "default"}, 4, false, 2048},
	{"ezweb.ne.jp", []string{"ezweb"}, 3, false, 2048},
	{"kddi.com", []string{"kddi"}, 2, false, 2048},

	// ===== 日本本地邮件商(~5%)=====
	{"nifty.com", []string{"default"}, 2, false, 2048},
	{"biglobe.ne.jp", []string{"default"}, 2, false, 2048},
	{"so-net.ne.jp", []string{"s1024"}, 2, false, 1024},
	{"ocn.ad.jp", []string{"default"}, 1, false, 2048},
	{"plala.or.jp", []string{"default"}, 1, false, 2048},

	// ===== 韩国(~5%,2026-05-18 新增)=====
	{"naver.com", []string{"s2048", "naver"}, 3, false, 2048},
	{"daum.net", []string{"daum"}, 2, false, 2048},
	{"kakao.com", []string{"kakao"}, 2, false, 2048},
	{"hanmail.net", []string{"hanmail"}, 1, false, 1024},

	// ===== 欧洲(~5%,2026-05-18 新增)=====
	{"gmx.de", []string{"s1", "k1"}, 2, false, 2048},
	{"web.de", []string{"webde", "default"}, 2, false, 2048},
	{"mail.ru", []string{"mailru", "selector"}, 2, false, 2048},
	{"yandex.ru", []string{"mail", "yandex"}, 2, false, 2048},
	{"tutanota.com", []string{"tutanota"}, 1, false, 4096},

	// ===== 国内主流(~7%,2026-05-18 新增,留作未来扩国内市场)=====
	{"163.com", []string{"s2048", "s1024"}, 3, false, 2048},
	{"qq.com", []string{"s201512", "s202004"}, 3, false, 2048},
	{"126.com", []string{"s2048"}, 2, false, 2048},
	{"sina.com", []string{"s1024"}, 1, false, 1024},
	{"sohu.com", []string{"sohu"}, 1, false, 1024},
	{"aliyun.com", []string{"aliyun"}, 2, false, 2048},
	{"foxmail.com", []string{"foxmail"}, 1, false, 1024},

	// ===== 企业 SaaS / 营销邮件(~6%,长尾多样性)=====
	{"salesforce.com", []string{"200608"}, 1, false, 2048},
	{"pardot.com", []string{"pardotdkim"}, 1, false, 2048},
	{"linkedin.com", []string{"proddkim1024"}, 1, false, 1024},
	{"paypal.com", []string{"pp-dkim1"}, 1, false, 2048},
	{"adobe.com", []string{"s2048"}, 1, false, 2048},
	{"zoho.com", []string{"zmail"}, 1, false, 2048},
	{"zendesk.com", []string{"mail"}, 1, false, 2048},
	{"intercom-mail.com", []string{"intercom"}, 1, false, 2048},
	{"protonmail.com", []string{"protonmail"}, 1, false, 4096},
	{"fastmail.com", []string{"fm1"}, 1, false, 2048},

	// ===== 长尾欧美(~3%,2026-05-18 新增)=====
	{"fastmail.fm", []string{"fm1"}, 1, false, 2048},
	{"gmx.com", []string{"k1"}, 1, false, 2048},
	{"mailbox.org", []string{"mbo1"}, 1, false, 2048},
	{"runbox.com", []string{"runbox"}, 1, false, 2048},

	// ===== 日本运营商 / MVNO / ISP 扩展(~12%,2026-05-18 第二批新增)=====
	// 针对日本市场加权:iPhone Softbank / Y!mobile / UQ / 楽天 / mineo / IIJmio / 老牌 ISP
	// 配合 hFieldsByStyle["japan"] 风格池 → d= 日本域 + h= 日本风格,协调一致
	{"i.softbank.jp", []string{"sb-iphone", "softbank"}, 5, false, 2048},
	{"ymobile.ne.jp", []string{"ymobile"}, 3, false, 2048},
	{"uqmobile.jp", []string{"uqmobile"}, 3, false, 2048},
	{"rakuten-mobile.jp", []string{"rakuten-mobile"}, 3, false, 2048},
	{"mineo.jp", []string{"mineo"}, 2, false, 2048},
	{"iijmio.jp", []string{"iijmio"}, 2, false, 2048},
	{"ocn.ne.jp", []string{"ocn", "default"}, 2, false, 2048},
	{"dion.ne.jp", []string{"dion"}, 1, false, 2048},
	{"odn.ne.jp", []string{"odn"}, 1, false, 1024},
	{"zaq.ne.jp", []string{"zaq"}, 1, false, 1024},
}

// fallbackSource 兜底源:极端情况下(池空 —— 理论不可能)返回此值,保证 Generate 永不崩
var fallbackSource = externalSource{
	domain:    "gmail.com",
	selectors: []string{"20230601"},
	weight:    1,
	isSESLike: false,
	rsaBits:   2048,
}
