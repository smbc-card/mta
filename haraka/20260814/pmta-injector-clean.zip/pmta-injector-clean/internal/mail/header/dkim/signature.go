package dkim

import (
	"encoding/base64"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// sesCharset Amazon SES 风格 selector 的字符集(base32 小写字母 + 数字 2-7,共 32 字符)
const sesCharset = "abcdefghijklmnopqrstuvwxyz234567"

// signatureByteCount 根据 RSA 位数计算 b= 字段的字节数
//
// 【契约】v2 与 v1 email/headers.go::dkimSignatureByteCount 完全一致
//
// b= 字节数 = RSA 密钥位数 / 8(base64 后字符数约 byteCount * 4/3 向上取整)
//   - 1024-bit → 128 字节 → 172 字符 base64
//   - 2048-bit → 256 字节 → 344 字符 base64
//   - 4096-bit → 512 字节 → 684 字符 base64
//
// 未知位数兜底 256 字节(与历史行为兼容)
func signatureByteCount(rsaBits int) int {
	switch rsaBits {
	case 1024:
		return 128
	case 4096:
		return 512
	case 2048:
		return 256
	default:
		return 256
	}
}

// generateSESLikeSelector 生成 Amazon SES 风格的 32 字符 base32 随机 selector
//
// 【契约】v2 与 v1 email/headers.go::generateSESLikeSelector 语义一致
//
// 真实 SES 中每个客户独立分配此类 selector,因此动态生成不会暴露指纹
func (s *Signer) generateSESLikeSelector() string {
	b := make([]byte, 32)
	for i := range b {
		b[i] = sesCharset[s.rng.Intn(len(sesCharset))]
	}
	return string(b)
}

// randomBase64 生成 n 字节随机数据的 base64 编码(单行,无换行)
//
// 【与 v1 generateRandomBase64 等价】用注入 Source 替代 crypto/rand,可复现
func randomBase64(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	b := make([]byte, n)
	_, _ = rng.Read(b)
	return base64.StdEncoding.EncodeToString(b)
}

// randomBase64Multiline 生成 n 字节随机数据的 base64 编码 + 72 字符/行折行
//
// 【与 v1 generateRandomBase64Multiline 等价】折行分隔符 "\r\n   "(3 空格 continuation)
//
// 【用途】DKIM b= 字段长内容折行(RFC 5322 §2.2.3 允许 header 值折行)
func randomBase64Multiline(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	b := make([]byte, n)
	_, _ = rng.Read(b)
	encoded := base64.StdEncoding.EncodeToString(b)

	const lineLen = 72
	if len(encoded) <= lineLen {
		return encoded
	}
	var lines []string
	for i := 0; i < len(encoded); i += lineLen {
		end := i + lineLen
		if end > len(encoded) {
			end = len(encoded)
		}
		lines = append(lines, encoded[i:end])
	}
	return strings.Join(lines, "\r\n   ")
}
