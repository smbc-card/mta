// Package dkim 生成伪 DKIM-Signature 头(方案 B,移植自 Haraka 2026-05-15)
//
// 【设计思路】伪签名的 d= 故意设为外部大厂域名(而非发件方真实域名),让接收方反垃圾
// 系统将"DKIM 校验失败"归因于"邮件经过外部中转链路时签名损坏"—— 这是邮件世界常态
// (邮件列表 / 转发 / 反垃圾扫描都会破坏原始签名),反垃圾系统对此宽容。
// 而非"发件方自家签名都对不上"—— 后者被视为伪造,扣分严重。
//
// 【核心机制】
//   - 外部域池:~62 条(gmail/outlook/yahoo/icloud/SES/日本运营商/欧洲/国内主流等)
//   - 加权抽样:模拟真实邮件流量比例(gmail ~11% / outlook ~7% / 长尾 ~1%)
//   - 环形去重:每个 Signer(= per-worker)内记忆最近 8 次用过的源索引,避免短期重复
//   - c= 加权:relaxed/relaxed 70% / relaxed/simple 15% / simple/simple 10% / simple/relaxed 5%
//   - h= 按域名风格池:gmail(全小写)/ outlook(首字大写)/ yahoo(含 Received)/ ses / japan / generic
//   - b= 长度按 rsaBits(1024/2048/4096)决定字节数(128/256/512),对应 base64 172/344/684 字符
//   - custom 优先:HeadersConfig.DkimHFieldsCustomEnabled=true 时用 DkimHFieldsList 覆盖自适应
//
// 【契约】v2 与 v1 字节级一致(仅重构结构,不改任何语义)。所有常量池原样从 v1 headers.go 搬。
//
// 【依赖】random.Source + clock.Clock + *config.HeadersConfig(读 DkimHFieldsCustomEnabled/List)
// 【不 import 其他子包】(D16-1 决策:扁平 + 顶层协调)
package dkim
