package dkim

// canonicalizationEntry DKIM c= 字段加权池条目
type canonicalizationEntry struct {
	value  string
	weight int
}

// canonicalizations DKIM 规范化算法加权池(c= 字段)
//
// 【契约】v2 与 v1 email/headers.go::dkimCanonicalizations 字节级一致 —— 值、权重、顺序不变
//
// 【真实分布】(避免 c= 永远是 relaxed/relaxed 形成指纹)
//   - relaxed/relaxed  70%
//   - relaxed/simple   15%
//   - simple/simple    10%
//   - simple/relaxed    5%
var canonicalizations = []canonicalizationEntry{
	{"relaxed/relaxed", 70},
	{"relaxed/simple", 15},
	{"simple/simple", 10},
	{"simple/relaxed", 5},
}

// pickCanonicalization 按权重抽样 c= 字段值
//
// 【算法】累计 totalWeight 后用一次 rng.Intn 实现加权抽样(O(n) 扫描)
// 【兜底】totalWeight ≤ 0(理论不可能)→ 返回 "relaxed/relaxed"
// 【兜底】r 意外未落入任何区间(理论上 r < totalWeight 不会到)→ 返回最后一项
func (s *Signer) pickCanonicalization() string {
	total := 0
	for i := range canonicalizations {
		total += canonicalizations[i].weight
	}
	if total <= 0 {
		return "relaxed/relaxed"
	}
	r := s.rng.Intn(total)
	for i := range canonicalizations {
		r -= canonicalizations[i].weight
		if r < 0 {
			return canonicalizations[i].value
		}
	}
	return canonicalizations[len(canonicalizations)-1].value
}
