package dkim

import (
	"regexp"
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// fixedTime 所有测试用的固定时间基准
var fixedTime = time.Date(2026, 8, 7, 12, 0, 0, 0, time.UTC)

// newTestSigner 建一个可复现的 Signer(FixedSource + FixedClock)
func newTestSigner(seed int64, cfg *config.HeadersConfig) *Signer {
	return New(
		random.NewFixedSource(seed),
		clock.NewFixedClock(fixedTime),
		cfg,
	)
}

// ============================================================================
// 契约锁定 —— v2 常量池条数与 v1 严格一致
// ============================================================================

func TestExternalSourcesCount(t *testing.T) {
	// v1 headers.go::dkimExternalSources 经 2 批扩容后共 72 条
	if got := len(externalSources); got != 72 {
		t.Fatalf("externalSources 条数偏离契约:got=%d, want=72", got)
	}
}

func TestCanonicalizationsCount(t *testing.T) {
	// v1:relaxed/relaxed + relaxed/simple + simple/simple + simple/relaxed
	if got := len(canonicalizations); got != 4 {
		t.Fatalf("canonicalizations 条数偏离契约:got=%d, want=4", got)
	}
	// 权重总和 = 70+15+10+5 = 100
	total := 0
	for _, c := range canonicalizations {
		total += c.weight
	}
	if total != 100 {
		t.Fatalf("canonicalizations 权重总和偏离:got=%d, want=100", total)
	}
}

func TestHFieldsByStyleKeys(t *testing.T) {
	wantKeys := []string{"gmail", "outlook", "yahoo", "ses", "japan", "generic"}
	if got := len(hFieldsByStyle); got != len(wantKeys) {
		t.Fatalf("hFieldsByStyle 风格数偏离:got=%d, want=%d", got, len(wantKeys))
	}
	for _, k := range wantKeys {
		if _, ok := hFieldsByStyle[k]; !ok {
			t.Errorf("hFieldsByStyle 缺少风格 key: %q", k)
		}
	}
}

// ============================================================================
// New —— 初始状态
// ============================================================================

func TestNew_InitialState(t *testing.T) {
	s := newTestSigner(42, nil)
	if len(s.recent) != recentRingSize {
		t.Fatalf("recent 长度:got=%d, want=%d", len(s.recent), recentRingSize)
	}
	for i, v := range s.recent {
		if v != -1 {
			t.Errorf("recent[%d] 初始值:got=%d, want=-1(不能是 0,0 是合法索引)", i, v)
		}
	}
	if s.recentPos != 0 {
		t.Errorf("recentPos 初始值:got=%d, want=0", s.recentPos)
	}
}

// ============================================================================
// normalizeHeaderName —— 9 特殊缩写 + 常规 + 边界
// ============================================================================

func TestNormalizeHeaderName(t *testing.T) {
	cases := []struct {
		name, in, want string
	}{
		// 常规:全小写、全大写、混合大小写 → TitleCase
		{"lower_from", "from", "From"},
		{"upper_to", "TO", "To"},
		{"mixed_reply_to", "reply-to", "Reply-To"},
		{"content_type", "content-type", "Content-Type"},
		{"multi_seg", "content-transfer-encoding", "Content-Transfer-Encoding"},
		{"listunsub_post", "List-Unsubscribe-Post", "List-Unsubscribe-Post"},

		// 特殊缩写:ID/IP/MIME/DKIM/SPF/DMARC/CSA/URL/HTTP/HTTPS 按 RFC 惯例保留
		{"id_upper", "message-id", "Message-ID"},
		{"id_mixed", "Message-Id", "Message-ID"},
		{"ip_orig", "x-originating-ip", "X-Originating-IP"},
		{"mime_version", "mime-version", "MIME-Version"},
		{"dkim", "DKIM-Signature", "DKIM-Signature"},
		{"spf", "received-spf", "Received-SPF"},
		{"dmarc", "arc-authentication-dmarc", "Arc-Authentication-DMARC"},
		{"csa", "x-csa-complaints", "X-CSA-Complaints"},
		{"url", "x-report-url", "X-Report-URL"},
		{"http", "x-http-source", "X-HTTP-Source"},
		{"https", "https-forwarded", "HTTPS-Forwarded"},

		// 边界:空串 / 纯空格 / 前后空格 trim
		{"empty", "", ""},
		{"whitespace", "   ", ""},
		{"trim", "  from  ", "From"},

		// 下划线(非 header 合法字符)—— 保留原样,只按段首大写
		{"underscore", "message_id", "Message_id"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := normalizeHeaderName(tc.in)
			if got != tc.want {
				t.Errorf("normalizeHeaderName(%q):got=%q, want=%q", tc.in, got, tc.want)
			}
		})
	}
}

// ============================================================================
// buildCustomHFields —— 空/去重/强制前置 From/normalize 集成
// ============================================================================

func TestBuildCustomHFields(t *testing.T) {
	t.Run("nil_list_returns_from_only", func(t *testing.T) {
		// 【v1 行为】list=nil → 循环不执行 → seen 里没 from → 强制前置 → out=["From"]
		// 返回 "From"(fallback 7 字段是死代码,永不到达,因为强制前置总能让 out 非空)
		got := buildCustomHFields(nil)
		if got != "From" {
			t.Errorf("nil 列表:got=%q, want=%q", got, "From")
		}
	})

	t.Run("all_empty_strings_fallback", func(t *testing.T) {
		got := buildCustomHFields([]string{"", "  ", "\t"})
		// 全部规范化后为空 → 只剩 From(强制前置)
		if got != "From" {
			t.Errorf("全空串:got=%q, want=%q", got, "From")
		}
	})

	t.Run("preserves_order", func(t *testing.T) {
		got := buildCustomHFields([]string{"To", "From", "Subject"})
		// From 已在列表中,不重复前置;保序
		want := "To:From:Subject"
		if got != want {
			t.Errorf("保序:got=%q, want=%q", got, want)
		}
	})

	t.Run("force_prepend_from", func(t *testing.T) {
		got := buildCustomHFields([]string{"To", "Subject", "Date"})
		// From 不在列表 → 强制前置到最开头
		want := "From:To:Subject:Date"
		if got != want {
			t.Errorf("强制前置:got=%q, want=%q", got, want)
		}
	})

	t.Run("dedup_case_insensitive", func(t *testing.T) {
		got := buildCustomHFields([]string{"From", "TO", "to", "Subject", "SUBJECT"})
		// 去重:大小写不敏感 —— To 只出现一次(第一次),Subject 只出现一次(第一次)
		want := "From:To:Subject"
		if got != want {
			t.Errorf("去重:got=%q, want=%q", got, want)
		}
	})

	t.Run("normalize_integration", func(t *testing.T) {
		got := buildCustomHFields([]string{"MESSAGE-ID", "mime-version", "reply-to"})
		// 每个字段先 normalize 再去重 + 强制前置 From
		want := "From:Message-ID:MIME-Version:Reply-To"
		if got != want {
			t.Errorf("normalize 集成:got=%q, want=%q", got, want)
		}
	})
}

// ============================================================================
// signatureByteCount —— RSA 位数映射
// ============================================================================

func TestSignatureByteCount(t *testing.T) {
	cases := []struct {
		bits int
		want int
	}{
		{1024, 128},
		{2048, 256},
		{4096, 512},
		{0, 256},   // 未知位数兜底 256
		{-1, 256},  // 负数兜底
		{999, 256}, // 非标准位数兜底
	}
	for _, tc := range cases {
		if got := signatureByteCount(tc.bits); got != tc.want {
			t.Errorf("signatureByteCount(%d):got=%d, want=%d", tc.bits, got, tc.want)
		}
	}
}

// ============================================================================
// styleForDomain —— 域名 → 风格映射
// ============================================================================

func TestStyleForDomain(t *testing.T) {
	cases := []struct {
		domain, want string
	}{
		// 5 风格各抽 1 个代表
		{"gmail.com", "gmail"},
		{"googlemail.com", "gmail"},
		{"outlook.com", "outlook"},
		{"hotmail.com", "outlook"},
		{"yahoo.com", "yahoo"},
		{"yahoo.co.jp", "yahoo"},
		{"amazonses.com", "ses"},

		// japan 风格(20 域全测)
		{"docomo.ne.jp", "japan"},
		{"softbank.ne.jp", "japan"},
		{"au.com", "japan"},
		{"i.softbank.jp", "japan"},
		{"ymobile.ne.jp", "japan"},
		{"uqmobile.jp", "japan"},
		{"rakuten-mobile.jp", "japan"},
		{"mineo.jp", "japan"},
		{"iijmio.jp", "japan"},

		// 未匹配 → generic
		{"163.com", "generic"},
		{"protonmail.com", "generic"},
		{"unknown-domain.example", "generic"},
		{"", "generic"},
	}
	for _, tc := range cases {
		if got := styleForDomain(tc.domain); got != tc.want {
			t.Errorf("styleForDomain(%q):got=%q, want=%q", tc.domain, got, tc.want)
		}
	}
}

// ============================================================================
// pickHFields —— 域名自适应 + custom 覆盖
// ============================================================================

func TestPickHFields_ByDomain(t *testing.T) {
	// FixedSource 抽样,输出必须来自对应风格池
	s := newTestSigner(42, nil)
	got := s.pickHFields("gmail.com")

	found := false
	for _, tpl := range hFieldsByStyle["gmail"] {
		if got == tpl {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("pickHFields(gmail.com) 结果不在 gmail 池中:got=%q", got)
	}
}

func TestPickHFields_CustomOverride(t *testing.T) {
	cfg := &config.HeadersConfig{
		DkimHFieldsCustomEnabled: true,
		DkimHFieldsList:          []string{"To", "Subject", "Date"},
	}
	s := newTestSigner(42, cfg)
	got := s.pickHFields("gmail.com") // 域名应被 custom 覆盖
	want := "From:To:Subject:Date"    // 强制前置 From
	if got != want {
		t.Errorf("custom 覆盖:got=%q, want=%q", got, want)
	}
}

func TestPickHFields_CustomDisabled(t *testing.T) {
	// custom_enabled=false → 走域名自适应,即使 list 非空
	cfg := &config.HeadersConfig{
		DkimHFieldsCustomEnabled: false,
		DkimHFieldsList:          []string{"To", "Subject"},
	}
	s := newTestSigner(42, cfg)
	got := s.pickHFields("gmail.com")
	for _, tpl := range hFieldsByStyle["gmail"] {
		if got == tpl {
			return // OK
		}
	}
	t.Errorf("custom_enabled=false 时应走 gmail 池:got=%q", got)
}

func TestPickHFields_CustomEmptyList(t *testing.T) {
	// custom_enabled=true 但 list 为空 → 走域名自适应
	cfg := &config.HeadersConfig{
		DkimHFieldsCustomEnabled: true,
		DkimHFieldsList:          nil,
	}
	s := newTestSigner(42, cfg)
	got := s.pickHFields("outlook.com")
	for _, tpl := range hFieldsByStyle["outlook"] {
		if got == tpl {
			return // OK
		}
	}
	t.Errorf("custom_enabled=true 但 list 空 → 应走 outlook 池:got=%q", got)
}

// ============================================================================
// pickCanonicalization —— 加权分布
// ============================================================================

func TestPickCanonicalization_ValidValues(t *testing.T) {
	s := newTestSigner(42, nil)
	valid := map[string]bool{
		"relaxed/relaxed": true,
		"relaxed/simple":  true,
		"simple/simple":   true,
		"simple/relaxed":  true,
	}
	// 抽 200 次,每次结果都必须在合法集合内
	for i := 0; i < 200; i++ {
		got := s.pickCanonicalization()
		if !valid[got] {
			t.Fatalf("第 %d 次抽样返回非法值:%q", i, got)
		}
	}
}

func TestPickCanonicalization_Distribution(t *testing.T) {
	// 大数定律:10000 次抽样,relaxed/relaxed 应约占 70%(允许 ±5%)
	s := newTestSigner(1234, nil)
	count := make(map[string]int, 4)
	const total = 10000
	for i := 0; i < total; i++ {
		count[s.pickCanonicalization()]++
	}
	// relaxed/relaxed 期望 7000,允许 [6500, 7500]
	if count["relaxed/relaxed"] < 6500 || count["relaxed/relaxed"] > 7500 {
		t.Errorf("relaxed/relaxed 分布偏离 70%%:got=%d/%d", count["relaxed/relaxed"], total)
	}
	// simple/relaxed 期望 500,允许 [350, 700]
	if count["simple/relaxed"] < 350 || count["simple/relaxed"] > 700 {
		t.Errorf("simple/relaxed 分布偏离 5%%:got=%d/%d", count["simple/relaxed"], total)
	}
}

// ============================================================================
// generateSESLikeSelector —— 32 字符 base32(a-z2-7)
// ============================================================================

func TestGenerateSESLikeSelector(t *testing.T) {
	s := newTestSigner(42, nil)
	sel := s.generateSESLikeSelector()
	if len(sel) != 32 {
		t.Fatalf("SES selector 长度:got=%d, want=32", len(sel))
	}
	// 所有字符必须在 base32 (a-z2-7) 字符集
	for i, ch := range sel {
		valid := (ch >= 'a' && ch <= 'z') || (ch >= '2' && ch <= '7')
		if !valid {
			t.Errorf("SES selector[%d]=%q 不在字符集(a-z2-7)", i, ch)
		}
	}
}

// ============================================================================
// randomBase64 / randomBase64Multiline
// ============================================================================

func TestRandomBase64(t *testing.T) {
	rng := random.NewFixedSource(42)
	// n=0 / 负数 → 空串
	if got := randomBase64(rng, 0); got != "" {
		t.Errorf("randomBase64(0):got=%q, want=空", got)
	}
	if got := randomBase64(rng, -1); got != "" {
		t.Errorf("randomBase64(-1):got=%q, want=空", got)
	}
	// n=32 → 44 字符 base64(32*4/3 向上取整,含 padding)
	if got := randomBase64(rng, 32); len(got) != 44 {
		t.Errorf("randomBase64(32) 长度:got=%d, want=44", len(got))
	}
}

func TestRandomBase64Multiline_Short(t *testing.T) {
	// 短内容(≤72 字符)不折行
	rng := random.NewFixedSource(42)
	got := randomBase64Multiline(rng, 32) // 32 字节 → 44 字符 base64,不折行
	if strings.Contains(got, "\r\n") {
		t.Errorf("短 base64 不应折行:got=%q", got)
	}
	if len(got) != 44 {
		t.Errorf("短 base64 长度:got=%d, want=44", len(got))
	}
}

func TestRandomBase64Multiline_Long(t *testing.T) {
	// 长内容(>72 字符)按 72 字符/行折,分隔符 "\r\n   "
	rng := random.NewFixedSource(42)
	got := randomBase64Multiline(rng, 256) // 256 字节 → 344 字符 base64,应折成 5 行
	if !strings.Contains(got, "\r\n   ") {
		t.Errorf("长 base64 应含折行分隔符 '\\r\\n   ':got 前 100 字符=%q", got[:min(100, len(got))])
	}
	// 分割后每行 ≤72 字符
	lines := strings.Split(got, "\r\n   ")
	if len(lines) != 5 { // ceil(344/72) = 5
		t.Errorf("折行数:got=%d, want=5", len(lines))
	}
	for i, line := range lines {
		if len(line) > 72 {
			t.Errorf("第 %d 行长度 %d > 72", i, len(line))
		}
	}
}

func TestRandomBase64Multiline_ZeroAndNegative(t *testing.T) {
	rng := random.NewFixedSource(42)
	if got := randomBase64Multiline(rng, 0); got != "" {
		t.Errorf("n=0:got=%q, want=空", got)
	}
	if got := randomBase64Multiline(rng, -1); got != "" {
		t.Errorf("n=-1:got=%q, want=空", got)
	}
}

// ============================================================================
// pickExternalSource —— 环形去重(最关键的反指纹保证)
// ============================================================================

func TestPickExternalSource_ValidResult(t *testing.T) {
	s := newTestSigner(42, nil)
	src := s.pickExternalSource()
	if src == nil {
		t.Fatal("pickExternalSource 返回 nil")
	}
	if src.domain == "" {
		t.Errorf("domain 为空")
	}
}

func TestPickExternalSource_RingDedup(t *testing.T) {
	// 硬约束:连续抽 20 次,任一时刻 recent[8] 内不应出现返回的 idx(除非重试用完 fallback)
	// 由于池有 72 条,理论上重试永远能找到非重复项 → 20 次全部无重复
	s := newTestSigner(42, nil)

	seen := make([]int, 0, 20)
	for i := 0; i < 20; i++ {
		// 记录抽样前的 recent 快照
		snapshot := make([]int, len(s.recent))
		copy(snapshot, s.recent)

		src := s.pickExternalSource()

		// 反查:src 对应的 idx
		idx := -1
		for j := range externalSources {
			if externalSources[j].domain == src.domain {
				idx = j
				break
			}
		}
		if idx < 0 {
			t.Fatalf("第 %d 次:找不到 %q 的索引", i, src.domain)
		}

		// 检查:snapshot(抽样前的 recent)不应包含 idx
		for _, v := range snapshot {
			if v == idx {
				t.Errorf("第 %d 次抽样 idx=%d(domain=%q),但它在 snapshot 中重复:%v",
					i, idx, src.domain, snapshot)
				break
			}
		}
		seen = append(seen, idx)
	}
}

func TestPickExternalSource_Distribution(t *testing.T) {
	// 加权抽样:大量采样后 gmail.com(权重 20)应比 sina.com(权重 1)频繁得多
	// 用大 seed 避免 fixed pattern 干扰;不测精确比例(环形去重会扰动)
	s := newTestSigner(9999, nil)
	count := make(map[string]int)
	const total = 5000
	for i := 0; i < total; i++ {
		src := s.pickExternalSource()
		count[src.domain]++
	}
	// gmail.com 至少应比 sina.com 多 3 倍(权重差 20:1,但环形去重会平均化)
	if count["gmail.com"] < count["sina.com"]*3 {
		t.Errorf("gmail.com 应远多于 sina.com:gmail=%d, sina=%d",
			count["gmail.com"], count["sina.com"])
	}
	// 每个域都应至少被抽中过(72 域,5000 次,期望每域约 70 次)
	unseen := 0
	for _, src := range externalSources {
		if count[src.domain] == 0 {
			unseen++
		}
	}
	if unseen > 5 {
		t.Errorf("有 %d 个域从未被抽中(>5),说明加权 + 环形去重协同异常", unseen)
	}
}

// ============================================================================
// Generate —— 完整输出格式 + 复现性
// ============================================================================

func TestGenerate_Format(t *testing.T) {
	s := newTestSigner(42, nil)
	out := s.Generate("user@example.com", "example.com")

	// 首行:DKIM-Signature: v=1; a=rsa-sha256; c=<canon>;
	if !strings.HasPrefix(out, "DKIM-Signature: v=1; a=rsa-sha256; c=") {
		t.Errorf("首行前缀不对:got 前 50=%q", out[:min(50, len(out))])
	}
	// 末字符:\n(整个头以 CRLF 结尾)
	if !strings.HasSuffix(out, "\r\n") {
		t.Error("末尾应以 \\r\\n 结尾")
	}
	// 必须包含 5 个关键字段
	for _, marker := range []string{" d=", " s=", " t=", " h=", " bh=", " b="} {
		if !strings.Contains(out, marker) {
			t.Errorf("缺少字段 %q", marker)
		}
	}
	// 整体正则:严格匹配 5 行结构(b= 可能多行,允许 \r\n   续行)
	re := regexp.MustCompile(
		`^DKIM-Signature: v=1; a=rsa-sha256; c=(relaxed|simple)/(relaxed|simple);\r\n` +
			` d=[a-zA-Z0-9.\-]+; s=[a-zA-Z0-9.\-+/=]+; t=\d+;\r\n` +
			` h=[^;]+;\r\n` +
			` bh=[A-Za-z0-9+/=]+;\r\n` +
			` b=[A-Za-z0-9+/= \r\n]+\r\n$`)
	if !re.MatchString(out) {
		t.Errorf("完整格式正则不匹配:\n%s", out)
	}
}

func TestGenerate_Reproducibility(t *testing.T) {
	// 相同 seed + 相同 clock → 两次调用完全一致
	s1 := newTestSigner(42, nil)
	s2 := newTestSigner(42, nil)
	out1 := s1.Generate("a@b.com", "b.com")
	out2 := s2.Generate("a@b.com", "b.com")
	if out1 != out2 {
		t.Errorf("复现失败:\nout1=%q\nout2=%q", out1, out2)
	}
}

func TestGenerate_Continuous(t *testing.T) {
	// 连续 100 次调用不 panic,每次输出都符合结构
	s := newTestSigner(42, nil)
	for i := 0; i < 100; i++ {
		out := s.Generate("user@example.com", "example.com")
		if !strings.HasPrefix(out, "DKIM-Signature: v=1;") {
			t.Fatalf("第 %d 次输出结构异常:%q", i, out[:min(60, len(out))])
		}
		if !strings.HasSuffix(out, "\r\n") {
			t.Fatalf("第 %d 次末尾非 CRLF", i)
		}
	}
}

func TestGenerate_Timestamp(t *testing.T) {
	// t= 字段应等于 FixedClock 的 Unix 时间戳
	s := newTestSigner(42, nil)
	out := s.Generate("a@b.com", "b.com")

	wantTS := fixedTime.Unix()
	// 从 " t=<num>;" 里抽出时间戳
	tsRe := regexp.MustCompile(` t=(\d+);`)
	m := tsRe.FindStringSubmatch(out)
	if len(m) != 2 {
		t.Fatalf("t= 字段未找到:%q", out)
	}
	if m[1] != "1786464000" && wantTS == 1786464000 {
		// 校验 wantTS 计算无误
	}
	// 直接比较:t= 值应等于 fixedTime.Unix()
	if got := m[1]; got != formatInt64(wantTS) {
		t.Errorf("t= 值:got=%q, want=%d", got, wantTS)
	}
}

func TestGenerate_CustomHFieldsAppearInOutput(t *testing.T) {
	// custom_enabled + list → 输出的 h= 字段应完全按 list 顺序
	cfg := &config.HeadersConfig{
		DkimHFieldsCustomEnabled: true,
		DkimHFieldsList:          []string{"To", "Subject", "Date"},
	}
	s := newTestSigner(42, cfg)
	out := s.Generate("a@b.com", "b.com")
	// 期望 h= 后跟 "From:To:Subject:Date"
	if !strings.Contains(out, " h=From:To:Subject:Date;") {
		t.Errorf("custom h= 未按预期出现:\n%s", out)
	}
}

// ============================================================================
// 辅助
// ============================================================================

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func formatInt64(v int64) string {
	// 避免 import "strconv" 单独就为一个 helper —— 用 fmt.Sprintf 也可,但 strconv.FormatInt 更快
	// 这里只在测试用,可读性优先
	if v == 0 {
		return "0"
	}
	neg := v < 0
	if neg {
		v = -v
	}
	var buf [20]byte
	i := len(buf)
	for v > 0 {
		i--
		buf[i] = byte('0' + v%10)
		v /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
