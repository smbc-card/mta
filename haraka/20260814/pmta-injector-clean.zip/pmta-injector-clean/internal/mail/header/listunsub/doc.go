// Package listunsub 生成 List-Unsubscribe 头(4 模式 + List-Unsubscribe-Post 联动)
//
// 【4 模式】(cfg.ListUnsubMode 决定):
//   - "" / "default"  → <mailto:unsubscribe-{16hex}@{domain}>(老行为)
//   - "real"          → 从 ListUnsubRealTemplates 抽(配合 HTTP server 真实退订)
//   - "custom"        → 从 ListUnsubCustomTemplates 抽
//   - "random"        → 从 ListUnsubRandomTemplates 抽
//
// 【联动头】List-Unsubscribe-Post(RFC 8058 One-Click):
//   - cfg.ListUnsubscribePost=true 或 (mode=real) → 强制加 "List-Unsubscribe-Post: List-Unsubscribe=One-Click"
//   - real 模式下"自动加"是不可关闭的(Gmail/Yahoo 2024 One-Click 新规)
//   - 由调用方(Week 5 builder)决定是否 emit,本包只提供是否需要 Post 的判断
//
// 【池模式工作流】(real/custom/random):
//  1. 按对应 Mode 字段(sequential | random)选模板
//  2. 用 VariableProcessor 渲染变量占位符({FROM_DOMAIN} / {ID_HEX:N} / {JWT_TOKEN} 等)
//  3. RFC 5322 §2.2.3 折叠长 URL
//  4. 拼上 "List-Unsubscribe: " 前缀和 "\r\n" 收尾
//
// 【B3 决策】顺序模式 real/custom/random 各自 worker 独立索引,互不影响
// 【B4 决策】每封都重新挑,不走 Worker 50-200 寿命池
//
// 【依赖】random.Source + *config.HeadersConfig + mail/header/fold(RFC 5322 折叠)
// 【不 import 其他子包】(D16-1 决策;fold 是基础工具包非子包,可 import)
package listunsub
