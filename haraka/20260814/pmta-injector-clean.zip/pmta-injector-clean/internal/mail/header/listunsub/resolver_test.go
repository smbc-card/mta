package listunsub

import (
	"regexp"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// newTestResolver 建可复现的 Resolver
func newTestResolver(seed int64, cfg *config.HeadersConfig) *Resolver {
	return New(random.NewFixedSource(seed), cfg)
}

// fakeVP 测试替身:占位符字面替换
type fakeVP struct {
	replacements map[string]string
}

func (v *fakeVP) Process(template string, _ any) string {
	out := template
	for k, val := range v.replacements {
		out = strings.ReplaceAll(out, k, val)
	}
	return out
}

type fakeRecipient struct{}

// ============================================================================
// 空场景 —— 全返回 ("", false)
// ============================================================================

func TestResolve_NilCfg(t *testing.T) {
	r := newTestResolver(42, nil)
	h, needsPost := r.Resolve("example.com", nil, nil)
	if h != "" || needsPost {
		t.Errorf("cfg=nil 应返回 ('', false),got=(%q, %v)", h, needsPost)
	}
}

func TestResolve_ListUnsubscribeDisabled(t *testing.T) {
	cfg := &config.HeadersConfig{ListUnsubscribe: false}
	r := newTestResolver(42, cfg)
	h, needsPost := r.Resolve("example.com", nil, nil)
	if h != "" || needsPost {
		t.Errorf("ListUnsubscribe=false 应返回 ('', false),got=(%q, %v)", h, needsPost)
	}
}

// ============================================================================
// default 模式(空 mode / "default" / 未知 mode / 池空 fallback)
// ============================================================================

func TestResolve_DefaultMode_EmptyMode(t *testing.T) {
	cfg := &config.HeadersConfig{ListUnsubscribe: true}
	r := newTestResolver(42, cfg)
	h, needsPost := r.Resolve("example.com", nil, nil)

	// 格式:List-Unsubscribe: <mailto:unsubscribe-{16hex}@example.com>\r\n
	re := regexp.MustCompile(`^List-Unsubscribe: <mailto:unsubscribe-[0-9a-f]{16}@example\.com>\r\n$`)
	if !re.MatchString(h) {
		t.Errorf("default 格式不匹配:%q", h)
	}
	if needsPost {
		t.Errorf("default 模式默认不需要 Post,got=true")
	}
}

func TestResolve_DefaultMode_ExplicitDefault(t *testing.T) {
	cfg := &config.HeadersConfig{ListUnsubscribe: true, ListUnsubMode: "default"}
	r := newTestResolver(42, cfg)
	h, _ := r.Resolve("example.com", nil, nil)
	if !strings.HasPrefix(h, "List-Unsubscribe: <mailto:unsubscribe-") {
		t.Errorf("显式 default 格式:%q", h)
	}
}

func TestResolve_DefaultMode_UnknownMode(t *testing.T) {
	// 未知 mode → default 兜底
	cfg := &config.HeadersConfig{ListUnsubscribe: true, ListUnsubMode: "unknown"}
	r := newTestResolver(42, cfg)
	h, _ := r.Resolve("example.com", nil, nil)
	if !strings.HasPrefix(h, "List-Unsubscribe: <mailto:unsubscribe-") {
		t.Errorf("未知 mode 应 fallback default:%q", h)
	}
}

func TestResolve_DefaultMode_CaseInsensitive(t *testing.T) {
	// mode 大小写 + 前后空格容错
	for _, mode := range []string{"DEFAULT", " Default ", "\tdefault\r\n"} {
		cfg := &config.HeadersConfig{ListUnsubscribe: true, ListUnsubMode: mode}
		r := newTestResolver(42, cfg)
		h, _ := r.Resolve("example.com", nil, nil)
		if !strings.HasPrefix(h, "List-Unsubscribe: <mailto:unsubscribe-") {
			t.Errorf("mode=%q 应 fallback default:%q", mode, h)
		}
	}
}

// ============================================================================
// real 模式 + Post 联动
// ============================================================================

func TestResolve_RealMode_WithTemplates(t *testing.T) {
	cfg := &config.HeadersConfig{
		ListUnsubscribe:        true,
		ListUnsubMode:          "real",
		ListUnsubRealTemplates: []string{"<https://real-marker.com/u/{TOKEN}>"},
		ListUnsubRealMode:      "random",
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{replacements: map[string]string{"{TOKEN}": "abc123"}}
	h, needsPost := r.Resolve("example.com", vp, &fakeRecipient{})

	if !strings.Contains(h, "real-marker.com/u/abc123") {
		t.Errorf("real 模式渲染失败:%q", h)
	}
	if !strings.HasPrefix(h, "List-Unsubscribe: ") {
		t.Errorf("real 头前缀:%q", h)
	}
	if !strings.HasSuffix(h, "\r\n") {
		t.Errorf("real 头结尾:%q", h)
	}
	// C6 决策:real 模式**强制** needsPost=true
	if !needsPost {
		t.Errorf("real 模式 needsPost 应=true(C6 决策),got=false")
	}
}

func TestResolve_RealMode_EmptyPool_FallbackDefault(t *testing.T) {
	// real 模式但 templates 为空 → fallback default
	cfg := &config.HeadersConfig{
		ListUnsubscribe:        true,
		ListUnsubMode:          "real",
		ListUnsubRealTemplates: nil,
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{}
	h, needsPost := r.Resolve("example.com", vp, &fakeRecipient{})
	// fallback default
	if !strings.HasPrefix(h, "List-Unsubscribe: <mailto:unsubscribe-") {
		t.Errorf("real 池空应 fallback default:%q", h)
	}
	// 但 needsPost 仍为 true(mode=real 强制,即使 fallback)
	if !needsPost {
		t.Errorf("real 模式即使 fallback,needsPost 仍应=true,got=false")
	}
}

func TestResolve_RealMode_NilVP_FallbackDefault(t *testing.T) {
	cfg := &config.HeadersConfig{
		ListUnsubscribe:        true,
		ListUnsubMode:          "real",
		ListUnsubRealTemplates: []string{"<https://x/u>"},
	}
	r := newTestResolver(42, cfg)
	h, needsPost := r.Resolve("example.com", nil, &fakeRecipient{})
	if !strings.HasPrefix(h, "List-Unsubscribe: <mailto:unsubscribe-") {
		t.Errorf("vp=nil 应 fallback:%q", h)
	}
	if !needsPost {
		t.Errorf("needsPost 仍应=true")
	}
}

// ============================================================================
// custom 模式
// ============================================================================

func TestResolve_CustomMode(t *testing.T) {
	cfg := &config.HeadersConfig{
		ListUnsubscribe:          true,
		ListUnsubMode:            "custom",
		ListUnsubCustomTemplates: []string{"<mailto:custom-{HEX}@example.com>"},
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{replacements: map[string]string{"{HEX}": "deadbeef"}}
	h, needsPost := r.Resolve("example.com", vp, &fakeRecipient{})

	if !strings.Contains(h, "custom-deadbeef@example.com") {
		t.Errorf("custom 模式渲染:%q", h)
	}
	// C6 决策:custom 模式 needsPost 只看 cfg.ListUnsubscribePost(不像 real 强制)
	if needsPost {
		t.Errorf("custom 模式 needsPost 应=false(ListUnsubscribePost 未设),got=true")
	}
}

func TestResolve_CustomMode_WithExplicitPost(t *testing.T) {
	// custom + ListUnsubscribePost=true → needsPost=true
	cfg := &config.HeadersConfig{
		ListUnsubscribe:          true,
		ListUnsubscribePost:      true,
		ListUnsubMode:            "custom",
		ListUnsubCustomTemplates: []string{"<mailto:x@y.com>"},
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{}
	_, needsPost := r.Resolve("example.com", vp, &fakeRecipient{})
	if !needsPost {
		t.Errorf("显式 ListUnsubscribePost=true 应触发 needsPost")
	}
}

// ============================================================================
// random 模式
// ============================================================================

func TestResolve_RandomMode(t *testing.T) {
	cfg := &config.HeadersConfig{
		ListUnsubscribe:          true,
		ListUnsubMode:            "random",
		ListUnsubRandomTemplates: []string{"<https://random-x.com/u/{HEX}>"},
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{replacements: map[string]string{"{HEX}": "cafe"}}
	h, needsPost := r.Resolve("example.com", vp, &fakeRecipient{})
	if !strings.Contains(h, "random-x.com/u/cafe") {
		t.Errorf("random 模式渲染:%q", h)
	}
	if needsPost {
		t.Errorf("random 模式 needsPost 默认 false,got=true")
	}
}

// ============================================================================
// sequential vs random 模式(池内选择)
// ============================================================================

func TestResolve_SequentialMode_Cycles(t *testing.T) {
	cfg := &config.HeadersConfig{
		ListUnsubscribe:        true,
		ListUnsubMode:          "real",
		ListUnsubRealTemplates: []string{"<A>", "<B>", "<C>"},
		ListUnsubRealMode:      "sequential",
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{}

	got := make([]string, 4)
	for i := 0; i < 4; i++ {
		h, _ := r.Resolve("e.com", vp, &fakeRecipient{})
		got[i] = h
	}
	// 期望 A, B, C, A(循环)
	if !strings.Contains(got[0], "<A>") {
		t.Errorf("第 1 次应含 <A>:%q", got[0])
	}
	if !strings.Contains(got[1], "<B>") {
		t.Errorf("第 2 次应含 <B>:%q", got[1])
	}
	if !strings.Contains(got[2], "<C>") {
		t.Errorf("第 3 次应含 <C>:%q", got[2])
	}
	if !strings.Contains(got[3], "<A>") {
		t.Errorf("第 4 次循环回 <A>:%q", got[3])
	}
}

func TestResolve_SequentialMode_IndependentPerMode(t *testing.T) {
	// B3 决策:real / custom / random 3 套 seqIdx 独立
	cfg := &config.HeadersConfig{
		ListUnsubscribe:          true,
		ListUnsubMode:            "real",
		ListUnsubRealTemplates:   []string{"<REAL_A>", "<REAL_B>"},
		ListUnsubRealMode:        "sequential",
		ListUnsubCustomTemplates: []string{"<CUSTOM_X>", "<CUSTOM_Y>"},
		ListUnsubCustomMode:      "sequential",
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{}

	// 抽 real 2 次(推进 realSeqIdx 到 2)
	r.Resolve("e.com", vp, &fakeRecipient{})
	r.Resolve("e.com", vp, &fakeRecipient{})

	// 切到 custom 模式(customSeqIdx 应仍从 0 开始)
	cfg.ListUnsubMode = "custom"
	h, _ := r.Resolve("e.com", vp, &fakeRecipient{})
	if !strings.Contains(h, "<CUSTOM_X>") {
		t.Errorf("custom seqIdx 应独立(从 0 开始),got=%q", h)
	}
}

func TestResolve_SequentialMode_CaseInsensitive(t *testing.T) {
	// mode="Sequential" / "SEQUENTIAL" / " sequential " 都应触发顺序模式
	for _, seqMode := range []string{"Sequential", "SEQUENTIAL", " sequential ", "sequential"} {
		cfg := &config.HeadersConfig{
			ListUnsubscribe:        true,
			ListUnsubMode:          "real",
			ListUnsubRealTemplates: []string{"<A>", "<B>"},
			ListUnsubRealMode:      seqMode,
		}
		r := newTestResolver(42, cfg)
		vp := &fakeVP{}
		h1, _ := r.Resolve("e.com", vp, &fakeRecipient{})
		h2, _ := r.Resolve("e.com", vp, &fakeRecipient{})
		if !(strings.Contains(h1, "<A>") && strings.Contains(h2, "<B>")) {
			t.Errorf("mode=%q sequential 未生效:h1=%q h2=%q", seqMode, h1, h2)
		}
	}
}

// ============================================================================
// 边界:模板 TrimSpace 后为空 → fallback default
// ============================================================================

func TestResolve_EmptyTemplateInPool_FallsBack(t *testing.T) {
	// 模板池首条是空白字符串 → 选中后 TrimSpace 变空 → renderFromPool 返回 ""
	// → Resolve 应 fallback default
	cfg := &config.HeadersConfig{
		ListUnsubscribe:        true,
		ListUnsubMode:          "real",
		ListUnsubRealTemplates: []string{"   \t\n  "}, // 只有空白
		ListUnsubRealMode:      "sequential",
	}
	r := newTestResolver(42, cfg)
	vp := &fakeVP{}
	h, needsPost := r.Resolve("example.com", vp, &fakeRecipient{})
	// fallback default
	if !strings.HasPrefix(h, "List-Unsubscribe: <mailto:unsubscribe-") {
		t.Errorf("空模板池应 fallback default:%q", h)
	}
	// 仍是 real 模式 → needsPost 应=true
	if !needsPost {
		t.Errorf("needsPost 应=true(real 模式)")
	}
}

// ============================================================================
// 复现性
// ============================================================================

func TestResolve_Reproducibility(t *testing.T) {
	// 相同 seed + cfg → 两个 Resolver 输出完全一致
	makeCfg := func() *config.HeadersConfig {
		return &config.HeadersConfig{ListUnsubscribe: true}
	}
	r1 := newTestResolver(42, makeCfg())
	r2 := newTestResolver(42, makeCfg())
	h1, _ := r1.Resolve("example.com", nil, nil)
	h2, _ := r2.Resolve("example.com", nil, nil)
	if h1 != h2 {
		t.Errorf("复现失败:%q vs %q", h1, h2)
	}
}

// ============================================================================
// randomHex helper
// ============================================================================

func TestRandomHex(t *testing.T) {
	rng := random.NewFixedSource(42)
	if s := randomHex(rng, 0); s != "" {
		t.Errorf("n=0:%q", s)
	}
	if s := randomHex(rng, -1); s != "" {
		t.Errorf("n=-1:%q", s)
	}
	s16 := randomHex(rng, 16)
	if len(s16) != 16 {
		t.Errorf("n=16 长度:%d", len(s16))
	}
	if !regexp.MustCompile(`^[0-9a-f]{16}$`).MatchString(s16) {
		t.Errorf("非合法 hex:%q", s16)
	}
	// 奇数长度也支持
	s7 := randomHex(rng, 7)
	if len(s7) != 7 {
		t.Errorf("n=7 长度:%d", len(s7))
	}
}
