package listunsub

import (
	"encoding/hex"
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/mail/header/fold"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// Resolver List-Unsubscribe 头生成器(per-worker 单实例)
//
// 【依赖注入】
//   - rng:随机模式下从池抽样 / default 模式生成 16 hex token
//   - cfg:读 ListUnsubscribe / ListUnsubMode / ListUnsub{Real,Custom,Random}Templates
//     + ListUnsub{Real,Custom,Random}Mode(sequential/random)+ ListUnsubscribePost
//
// 【线程安全】非线程安全,per-worker 一个实例
//
// 【状态字段】3 套独立顺序索引(B3 决策)
//   - realSeqIdx / customSeqIdx / randomSeqIdx:sequential 模式下 worker 独立计数器
type Resolver struct {
	rng random.Source
	cfg *config.HeadersConfig

	realSeqIdx   int
	customSeqIdx int
	randomSeqIdx int
}

// New 创建 List-Unsubscribe Resolver
//
// 【参数】
//   - rng:必需
//   - cfg:必需(nil 时 Resolve 返回空串)
func New(rng random.Source, cfg *config.HeadersConfig) *Resolver {
	return &Resolver{
		rng:          rng,
		cfg:          cfg,
		realSeqIdx:   0,
		customSeqIdx: 0,
		randomSeqIdx: 0,
	}
}

// VariableProcessor 与 received.VariableProcessor 同义(避免跨包 import,各包各定义)
type VariableProcessor interface {
	Process(template string, recipient any) string
}

// Resolve 生成 List-Unsubscribe 头(含末尾 CRLF),返回是否需要额外 Post 头
//
// 【契约】v2 与 v1 email/headers.go::getListUnsubscribe 语义完全一致
//
// 【返回】
//   - header:"List-Unsubscribe: <...>\r\n"(含末尾 CRLF),空场景返回空串
//   - needsPost:是否需要额外加 "List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n"
//     真值场景:cfg.ListUnsubscribePost=true 或 mode=real(C6 决策强制加,不可关闭)
//
// 【空场景】(全返回 "", false —— 调用方不 emit)
//   - cfg == nil
//   - cfg.ListUnsubscribe == false(未启用)—— v2 差异:v1 由上层判断;v2 内部检查更 robust
//
// 【4 模式】(cfg.ListUnsubMode 大小写 + trim 规范化后)
//   - "real"          → 从 ListUnsubRealTemplates 抽 + vp 渲染 + fold
//   - "custom"        → 从 ListUnsubCustomTemplates 抽
//   - "random"        → 从 ListUnsubRandomTemplates 抽
//   - "" / "default" / 其他 / 池空 / vp 或 recipient 为 nil → 兜底 default
//
// 【default 兜底格式】<mailto:unsubscribe-{16hex}@{domain}>(v1 一致)
//
// 【B3 决策】sequential 模式下,3 套 seqIdx 独立(real/custom/random 各自 worker 独立计数)
func (r *Resolver) Resolve(domain string, vp VariableProcessor, recipient any) (header string, needsPost bool) {
	if r.cfg == nil {
		return "", false
	}
	if !r.cfg.ListUnsubscribe {
		return "", false
	}

	// 模式规范化(防御用户手改 config.yaml 写成 "Real"/"REAL"/带空格等)
	mode := strings.ToLower(strings.TrimSpace(r.cfg.ListUnsubMode))

	// Post 头判断(C6 决策 —— real 强制加,不可关闭)
	// 【前提】已通过 !r.cfg.ListUnsubscribe 检查,此处 ListUnsubscribe=true 是隐含条件
	needsPost = r.cfg.ListUnsubscribePost || mode == "real"

	// 池模式:成功即返回;否则 fallback default
	switch mode {
	case "real":
		if s := r.renderFromPool(r.cfg.ListUnsubRealTemplates, r.cfg.ListUnsubRealMode, &r.realSeqIdx, vp, recipient); s != "" {
			return s, needsPost
		}
	case "custom":
		if s := r.renderFromPool(r.cfg.ListUnsubCustomTemplates, r.cfg.ListUnsubCustomMode, &r.customSeqIdx, vp, recipient); s != "" {
			return s, needsPost
		}
	case "random":
		if s := r.renderFromPool(r.cfg.ListUnsubRandomTemplates, r.cfg.ListUnsubRandomMode, &r.randomSeqIdx, vp, recipient); s != "" {
			return s, needsPost
		}
	}

	// default 模式 / 任何模式池为空时的兜底:保留原 mailto 占位行为(P0 头永远存在)
	token := randomHex(r.rng, 16)
	return fmt.Sprintf("List-Unsubscribe: <mailto:unsubscribe-%s@%s>\r\n", token, domain), needsPost
}

// renderFromPool 从模板池选一条 → 渲染变量 → 折叠 → 包装为 "List-Unsubscribe: ...\r\n"
//
// 【契约】v2 与 v1 email/headers.go::renderListUnsubFromPool 语义一致
//
// 【返回空串场景】(调用方 fallback 到 default)
//   - 池空(tpls == nil 或 len==0)
//   - vp == nil / recipient == nil(用户仅启用 default 时的调用形态)
//   - 选中模板 TrimSpace 后为空(用户可能粘了空行)
//
// 【模式】mode 大小写不敏感 + trim
//   - "sequential" → 用 *seqIdxPtr 循环(worker 独立计数)
//   - 其他(含 "", "random")→ 随机 rng.Intn
func (r *Resolver) renderFromPool(tpls []string, mode string, seqIdxPtr *int, vp VariableProcessor, recipient any) string {
	if len(tpls) == 0 || vp == nil || recipient == nil {
		return ""
	}

	var tpl string
	n := len(tpls)
	if strings.EqualFold(strings.TrimSpace(mode), "sequential") {
		tpl = tpls[*seqIdxPtr%n]
		*seqIdxPtr++
	} else {
		tpl = tpls[r.rng.Intn(n)]
	}

	tpl = strings.TrimSpace(tpl)
	if tpl == "" {
		return ""
	}

	rendered := vp.Process(tpl, recipient)
	folded := fold.Fold(rendered, len("List-Unsubscribe: "))

	return "List-Unsubscribe: " + folded + "\r\n"
}

// randomHex 生成 n 位十六进制字符串(小写)—— 与 messageid/dkim/received 各自定义的 helper 等价
//
// 【实现】按 (n+1)/2 字节从 Source 读取,然后 hex.EncodeToString,取前 n 字符
// 【D16-1 决策】每包各写一份,不 import 子包(基础包 fold 除外)
func randomHex(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	nBytes := (n + 1) / 2
	b := make([]byte, nBytes)
	_, _ = rng.Read(b)
	h := hex.EncodeToString(b)
	if len(h) > n {
		h = h[:n]
	}
	return h
}
