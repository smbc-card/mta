# internal/mail/encoding

**用途**:v2 里所有邮件编码工具的集中所在(charset 转换 + RFC 2047 encoded-word + body 编码)。

## 文件组织

| 文件 | 内容 |
|------|------|
| `charset.go` | UTF-8 → 目标编码(Shift_JIS / EUC-JP / ISO-2022-JP / GBK 等) |
| `encoded_word.go` | RFC 2047 encoded-word(邮件头 `=?charset?B?...?=` / `=?charset?Q?...?=`) |
| `body.go` | 邮件主体编码(base64 每 76 字符换行 / quoted-printable / 7bit) |

## 快速开始

```go
import "__MODULE_PLACEHOLDER__/internal/mail/encoding"

// 邮件头(含非 ASCII)编码
subject := encoding.EncodeHeaderBase64("你好世界", "utf-8")
// → "=?UTF-8?B?5L2g5aW95LiW55WM?="

// 或用 QP(对 ASCII-heavy 内容更紧凑)
from := encoding.EncodeHeaderQP("John Doe 中文", "utf-8")
// → "=?UTF-8?Q?John_Doe_=E4=B8=AD=E6=96=87?="

// 邮件主体(base64,每 76 字符换行)
body := encoding.EncodeBodyBase64([]byte(longMailBody))

// charset 转换(UTF-8 → Shift_JIS,给日本邮件用)
sjisBytes := encoding.ConvertFromUTF8([]byte("こんにちは"), "shift_jis")
```

## API 一览

### charset.go

| API | 语义 |
|-----|------|
| `IsUTF8Charset(charset string) bool` | 判断 charset 是否为 UTF-8 兼容 |
| `ConvertFromUTF8(b []byte, charset string) []byte` | UTF-8 → 目标编码字节 |
| `ConvertStringFromUTF8(s string, charset string) []byte` | 上面的 string 版本 |

**支持的 charset**(大小写不敏感):

- **日文**:Shift_JIS / ISO-2022-JP / EUC-JP / windows-31j / cp932
- **中文**:GB2312 / GBK / GB18030 / cp936 / HZ-GB-2312
- **UTF-8 兼容**:utf-8 / utf8 / us-ascii / ascii / (空串)

**容错策略**(v1 Haraka25 修复):

- 整段转换失败时,**逐字符检测**,不支持的字符替换为 `?`
- 保护 ISO-2022-JP 等有状态编码的转义序列连续性

### encoded_word.go

| API | 返回格式 |
|-----|----------|
| `EncodeHeaderBase64(s, charset) string` | `=?charset?B?base64?=`(或原字符串,纯 ASCII 时) |
| `EncodeHeaderQP(s, charset) string` | `=?charset?Q?quoted-printable?=`(或原字符串) |

**优化**:纯 ASCII + UTF-8 charset 时**直接返回原字符串**,不做 encoded-word 包装。

### body.go

| API | 语义 |
|-----|------|
| `EncodeBodyBase64(body []byte) string` | Base64 每 76 字符换行(\r\n) |
| `EncodeBodyQP(body []byte) string` | Quoted-Printable(Go 标准库 mime/quotedprintable) |
| `EncodeBody7bit(body []byte) string` | 7bit(骨架期:直接返回原字节;未来加严格校验) |

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| charset 转换 | email/charset.go 92 行(仅 charset) | encoding/charset.go(独立包,导出 IsUTF8Charset) |
| base64 header | builder.go / headers.go 里散落 base64.StdEncoding.EncodeToString | 集中 `EncodeHeaderBase64(s, charset)` |
| QP header | 无统一 API | 集中 `EncodeHeaderQP(s, charset)` |
| base64 body(76 换行)| builder.go 里手工分 | 集中 `EncodeBodyBase64(body)` |
| QP body | mime/quotedprintable.NewWriter 每处重复 | 集中 `EncodeBodyQP(body)` |
| 单测 | ❌ 无 | ✅ 22+ 单测覆盖所有 charset + encoded-word 格式 + body |

## 依赖

- **Go 标准库**:`encoding/base64` / `mime/quotedprintable` / `strings`
- **vendor**:`golang.org/x/text/encoding/japanese` / `simplifiedchinese` / `transform`(已 vendor,Week 1 Day 1)
- **不依赖**:config / telemetry / random / clock —— 纯字符串/字节处理

## 测试

```bash
go test -cover ./internal/mail/encoding/...
# 预期覆盖率 ≥ 90%
```
