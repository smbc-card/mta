package encoding

import (
	"encoding/base64"
	"strings"
	"unicode/utf8"
)

// EncodeHeaderBase64 用 RFC 2047 encoded-word 格式对 header 值做 base64 编码
//
// 【返回格式】=?charset?B?base64-encoded-content?=
//
// 【处理步骤】
//  1. 若 charset 是 UTF-8 兼容 & s 是纯 ASCII → 直接返回 s(无需编码)
//  2. 否则 ConvertFromUTF8 转成目标编码字节
//  3. base64.StdEncoding.EncodeToString
//  4. 拼装 =?charset?B?...?=
//
// 【用途】邮件头 From / To / Subject 里含非 ASCII 时,必须用 encoded-word 包起来。
func EncodeHeaderBase64(s string, charset string) string {
	if s == "" {
		return ""
	}
	if IsUTF8Charset(charset) && isASCII(s) {
		return s
	}
	targetBytes := ConvertFromUTF8([]byte(s), charset)
	b64 := base64.StdEncoding.EncodeToString(targetBytes)
	normCharset := normalizedCharsetName(charset)

	// 【H1 修 2026-08-13】RFC 2047 §2 要求单个 encoded-word ≤ 75 字符;超长时按 UTF-8
	// 字符边界分段(仅 UTF-8 —— 有状态编码 ISO-2022-JP/Shift_JIS/EUC-JP 分段会破坏 escape
	// 序列导致乱码)。多段之间用空格连接(fold 包会在长度超限时插 CRLF+space)。
	// 与 v1 encodeRFC2047B 分段逻辑等价。
	//
	// 【R5(c) 修 2026-08-14】singleThreshold 从 65 收紧到 63:
	//   总长 = "=?" + charset + "?B?" + b64 + "?=" = 2 + len(charset) + 3 + b64 + 2
	//   UTF-8 charset=5,固定开销 12;b64 = 63 → 总长 75 (=RFC 硬上限)
	//   之前 65 → 总长最多 77,某些严格 header_check 会警告
	const singleThreshold = 63 // base64 段长门槛(=?UTF-8?B?..?= 固定 12 字节开销,63+12=75 = RFC 上限)
	const chunkSize = 45       // 每段 UTF-8 字符字节数(base64 后约 60,+12 头 ≈ 72 < 75)
	if len(b64) <= singleThreshold || !IsUTF8Charset(charset) {
		return "=?" + normCharset + "?B?" + b64 + "?="
	}

	var out strings.Builder
	for i := 0; i < len(targetBytes); {
		end := i + chunkSize
		if end >= len(targetBytes) {
			end = len(targetBytes)
		} else {
			// UTF-8 边界对齐:不在多字节字符中间截断
			for end > i && !utf8.RuneStart(targetBytes[end]) {
				end--
			}
		}
		chunk := targetBytes[i:end]
		if out.Len() > 0 {
			out.WriteString(" ")
		}
		out.WriteString("=?")
		out.WriteString(normCharset)
		out.WriteString("?B?")
		out.WriteString(base64.StdEncoding.EncodeToString(chunk))
		out.WriteString("?=")
		i = end
	}
	return out.String()
}

// EncodeHeaderQP 用 RFC 2047 encoded-word 格式对 header 值做 Quoted-Printable 编码
//
// 【返回格式】=?charset?Q?quoted-printable-encoded-content?=
//
// 【与 Base64 的对比】QP 对 ASCII-heavy 内容更紧凑(base64 固定 4/3 膨胀,QP 只对非 ASCII 字节膨胀)
//
// 【实现说明】RFC 2047 §5 里的 Q-encoding 与 RFC 2045 §6.7 略有差异:
//   - 空格必须编码为 "_" 或 "=20"(不能保留原空格,否则解析器会拆分)
//   - "?" "_" "=" 必须编码
func EncodeHeaderQP(s string, charset string) string {
	if s == "" {
		return ""
	}
	if IsUTF8Charset(charset) && isASCII(s) {
		return s
	}
	targetBytes := ConvertFromUTF8([]byte(s), charset)
	return "=?" + normalizedCharsetName(charset) + "?Q?" + qEncode(targetBytes) + "?="
}

// isASCII 判断字符串是否纯 ASCII(< 128)
func isASCII(s string) bool {
	for i := 0; i < len(s); i++ {
		if s[i] >= 128 {
			return false
		}
	}
	return true
}

// normalizedCharsetName 返回 RFC 2047 encoded-word 里用的 charset 名(通常大写)
//
// 常见约定:
//   - UTF-8:"UTF-8"
//   - Shift_JIS:"Shift_JIS"
//   - ISO-2022-JP:"ISO-2022-JP"
//   - EUC-JP:"EUC-JP"
//   - GBK / GB18030:"GB18030"(优先规范名)
func normalizedCharsetName(charset string) string {
	switch strings.ToLower(strings.TrimSpace(charset)) {
	case "shift_jis", "shift-jis", "sjis", "windows-31j", "cp932":
		return "Shift_JIS"
	case "iso-2022-jp", "iso2022jp":
		return "ISO-2022-JP"
	case "euc-jp", "eucjp":
		return "EUC-JP"
	case "gb2312", "gbk", "gb18030", "cp936", "windows-936":
		return "GB18030"
	case "hz-gb-2312", "hz-gb2312":
		return "HZ-GB-2312"
	case "", "utf-8", "utf8":
		return "UTF-8"
	case "us-ascii", "ascii":
		return "US-ASCII"
	default:
		return strings.ToUpper(charset)
	}
}

// qEncode RFC 2047 §5 Q-encoding
//
// 规则:
//   - 空格 → "_"(不是 "=20";=20 是 RFC 2045 §6.7 的做法,不适用于 header)
//   - "?" "_" "=" → =xx 三字节
//   - 非 ASCII 字节(>= 128) → =xx 三字节
//   - 控制字符(0-31, 127) → =xx 三字节
//   - 其他 ASCII → 原样
//
// 【为什么手写而不用 mime.QEncoding.Encode】
//   - Go 标准库 mime.QEncoding 会自动包 "=?charset?Q?...?=" 前缀 + 折叠长行
//   - 我们要自己控制 charset 名(与 v1 一致) + 不做长度折叠(交给 fold 包)
func qEncode(data []byte) string {
	var b strings.Builder
	b.Grow(len(data) * 2) // 预估:平均每字节 1-3 字符
	for _, c := range data {
		switch {
		case c == ' ':
			b.WriteByte('_')
		case c == '?' || c == '_' || c == '=':
			b.WriteString(qHex(c))
		case c < 32 || c == 127 || c >= 128:
			b.WriteString(qHex(c))
		default:
			b.WriteByte(c)
		}
	}
	return b.String()
}

// qHex 返回一个字节的 "=xx" 十六进制表示(大写)
func qHex(c byte) string {
	const hexChars = "0123456789ABCDEF"
	return string([]byte{'=', hexChars[c>>4], hexChars[c&0x0F]})
}
