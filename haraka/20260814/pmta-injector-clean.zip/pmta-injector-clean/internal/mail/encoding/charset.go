// Package encoding 提供 v2 里所有邮件编码相关工具
//
// 【包含】
//   - charset.go        —— UTF-8 → 目标编码(Shift_JIS/EUC-JP/ISO-2022-JP/GBK 等)
//   - encoded_word.go   —— RFC 2047 encoded-word(=?charset?B?...?= / =?charset?Q?...?=)
//   - body.go           —— 邮件主体编码(base64 / quoted-printable / 7bit)
//
// 【依赖】
//   - Go 标准库 mime / mime/quotedprintable / encoding/base64
//   - vendor 的 golang.org/x/text/encoding(charset 转换)
//
// 【与 v1 的对比】
//   - v1 charset.go 单文件 92 行(仅 charset 转换)
//   - v1 base64/QP 分散在 builder.go / headers.go / variables_ext.go 里,重复调用
//   - v2 集中到 encoding 包,3 个子文件按功能分,统一 API
package encoding

import (
	"strings"

	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/japanese"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
)

// getEncoder 根据 charset 名称获取对应的编码器
//
// 返回 nil 表示 UTF-8 或不支持的编码(不做转换)
//
// 支持的 charset(大小写不敏感):
//   - Shift_JIS 系:"shift_jis" / "shift-jis" / "sjis" / "windows-31j" / "cp932"
//   - ISO-2022-JP 系:"iso-2022-jp" / "iso2022jp"
//   - EUC-JP 系:"euc-jp" / "eucjp"
//   - GBK 系(简体中文):"gb2312" / "gbk" / "gb18030" / "cp936" / "windows-936"
//   - HZ-GB-2312:"hz-gb-2312" / "hz-gb2312"
func getEncoder(charset string) *encoding.Encoder {
	switch strings.ToLower(strings.TrimSpace(charset)) {
	case "shift_jis", "shift-jis", "sjis", "windows-31j", "cp932":
		return japanese.ShiftJIS.NewEncoder()
	case "iso-2022-jp", "iso2022jp":
		return japanese.ISO2022JP.NewEncoder()
	case "euc-jp", "eucjp":
		return japanese.EUCJP.NewEncoder()
	case "gb2312", "gbk", "gb18030", "cp936", "windows-936":
		return simplifiedchinese.GBK.NewEncoder()
	case "hz-gb-2312", "hz-gb2312":
		return simplifiedchinese.HZGB2312.NewEncoder()
	default:
		return nil
	}
}

// IsUTF8Charset 判断 charset 是否为 UTF-8(不需要转换)
//
// UTF-8 兼容取值(大小写不敏感):
//   - ""(空串,默认视为 UTF-8)
//   - "utf-8" / "utf8"
//   - "us-ascii" / "ascii"(ASCII 是 UTF-8 子集)
func IsUTF8Charset(charset string) bool {
	lower := strings.ToLower(strings.TrimSpace(charset))
	return lower == "" || lower == "utf-8" || lower == "utf8" || lower == "us-ascii" || lower == "ascii"
}

// ConvertFromUTF8 将 UTF-8 字节转换为目标编码的字节
//
// 【行为】
//   - charset 是 UTF-8 兼容 → 直接返回原字节
//   - charset 不支持 → 直接返回原字节
//   - 转换成功 → 返回目标编码字节
//   - 转换失败 → 逐字符检测,将不支持的字符替换为 '?',用替换后的安全字符串重转
//     (v1 里的 Haraka25 修复:避免 ━▶♪ 等特殊字符导致全文乱码)
//
// 【ISO-2022-JP 特殊】有状态编码,需要保证转义序列连续正确,故用"先构建安全字符串再整段转换"策略。
func ConvertFromUTF8(utf8Bytes []byte, charset string) []byte {
	if IsUTF8Charset(charset) {
		return utf8Bytes
	}

	encoder := getEncoder(charset)
	if encoder == nil {
		return utf8Bytes
	}

	// 先尝试整段转换(大部分情况下会成功,性能最优)
	result, _, err := transform.Bytes(encoder, utf8Bytes)
	if err == nil {
		return result
	}

	// 整段转换失败 → 逐字符检测,将不支持的字符替换为 '?'
	s := string(utf8Bytes)
	var safeBuilder strings.Builder
	for _, r := range s {
		testEncoder := getEncoder(charset)
		_, _, testErr := transform.Bytes(testEncoder, []byte(string(r)))
		if testErr != nil {
			safeBuilder.WriteByte('?')
		} else {
			safeBuilder.WriteRune(r)
		}
	}

	// 用安全字符串重新做一次完整转换
	safeEncoder := getEncoder(charset)
	safeResult, _, safeErr := transform.Bytes(safeEncoder, []byte(safeBuilder.String()))
	if safeErr != nil {
		return []byte(safeBuilder.String())
	}
	return safeResult
}

// ConvertStringFromUTF8 将 UTF-8 字符串转换为目标编码的字节
func ConvertStringFromUTF8(s string, charset string) []byte {
	return ConvertFromUTF8([]byte(s), charset)
}
