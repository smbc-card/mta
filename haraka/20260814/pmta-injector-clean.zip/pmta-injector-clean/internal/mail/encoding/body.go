package encoding

import (
	"bytes"
	"encoding/base64"
	"mime/quotedprintable"
	"strings"
)

// EncodeBodyBase64 邮件主体 base64 编码
//
// 【格式】RFC 2045 §6.8 —— base64 输出每 76 字符换行(\r\n)
//
// 【与 base64.StdEncoding.EncodeToString 的差异】
//   - 标准库输出单行;此函数按 76 字符/行分块(邮件传输规范)
//   - 每行末尾 \r\n
//
// 【为什么手写而不用 mime.NewEncoded】mime 里没有直接的 body base64 API,
// 只有 mime.WordEncoder(仅用于 header encoded-word)
func EncodeBodyBase64(body []byte) string {
	encoded := base64.StdEncoding.EncodeToString(body)
	if len(encoded) <= 76 {
		return encoded
	}

	var b strings.Builder
	b.Grow(len(encoded) + (len(encoded)/76)*2) // 每 76 字符插 \r\n

	for i := 0; i < len(encoded); i += 76 {
		end := i + 76
		if end > len(encoded) {
			end = len(encoded)
		}
		b.WriteString(encoded[i:end])
		if end < len(encoded) {
			b.WriteString("\r\n")
		}
	}
	return b.String()
}

// EncodeBodyQP 邮件主体 Quoted-Printable 编码(RFC 2045 §6.7)
//
// 【用 Go 标准库 mime/quotedprintable.NewWriter】
//   - 自动处理行长(每行 ≤ 76)
//   - 自动处理软换行 "=\r\n"
//   - 空格/tab 出现在行尾时自动 =20/=09
func EncodeBodyQP(body []byte) string {
	var buf bytes.Buffer
	w := quotedprintable.NewWriter(&buf)
	_, _ = w.Write(body)
	_ = w.Close()
	return buf.String()
}

// EncodeBody7bit 邮件主体 7bit 编码(RFC 2045 §2.7)
//
// 【定义】7bit 意味着:
//   - 每行 ≤ 998 字节(硬上限)
//   - 每字节 ≤ 127(纯 ASCII)
//   - 不含 NUL(0x00)
//
// 【本函数】不做任何转换,只做 sanity check:
//   - 若 body 已经 7bit 兼容 → 返回原字符串
//   - 若含非 ASCII(>= 128)→ 打印警告日志(未来 slog 集成),但仍返回原内容
//
// 【生产用法】只在 charset=US-ASCII 时使用;对 UTF-8 应用 base64 或 QP
func EncodeBody7bit(body []byte) string {
	// v2 骨架期:直接返回原字节;未来若需要严格 7bit 校验,加参数控制
	return string(body)
}
