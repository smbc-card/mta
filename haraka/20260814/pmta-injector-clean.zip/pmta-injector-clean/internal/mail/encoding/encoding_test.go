package encoding

import (
	"encoding/base64"
	"strings"
	"testing"
)

// ===== charset =====

func TestIsUTF8Charset(t *testing.T) {
	cases := map[string]bool{
		"":            true, // 空串默认 UTF-8
		"utf-8":       true,
		"UTF-8":       true,
		"utf8":        true,
		"UTF8":        true,
		"us-ascii":    true,
		"ascii":       true,
		"shift_jis":   false,
		"iso-2022-jp": false,
		"gbk":         false,
		"unknown":     false,
	}
	for input, want := range cases {
		got := IsUTF8Charset(input)
		if got != want {
			t.Errorf("IsUTF8Charset(%q) = %v, 期望 %v", input, got, want)
		}
	}
}

func TestConvertFromUTF8_UTF8Passthrough(t *testing.T) {
	input := []byte("hello 世界")
	got := ConvertFromUTF8(input, "utf-8")
	if string(got) != string(input) {
		t.Errorf("UTF-8 charset 应原样返回,得到 %q", got)
	}
}

func TestConvertFromUTF8_UnknownPassthrough(t *testing.T) {
	input := []byte("hello 世界")
	got := ConvertFromUTF8(input, "unknown-charset")
	if string(got) != string(input) {
		t.Errorf("未知 charset 应原样返回,得到 %q", got)
	}
}

func TestConvertFromUTF8_ShiftJIS(t *testing.T) {
	// "こんにちは" UTF-8 → Shift_JIS
	utf8 := []byte("こんにちは")
	sjis := ConvertFromUTF8(utf8, "shift_jis")
	// Shift_JIS 编码后字节数应与 UTF-8 不同(Shift_JIS 2 字节/汉字,UTF-8 3 字节/汉字)
	if len(sjis) == len(utf8) {
		t.Errorf("Shift_JIS 转换后字节数应变化,原 %d, 得 %d", len(utf8), len(sjis))
	}
	// Shift_JIS 应比 UTF-8 短(2 字节 vs 3 字节)
	if len(sjis) >= len(utf8) {
		t.Errorf("Shift_JIS 应比 UTF-8 短(2 字节/汉字 vs 3 字节),原 %d, 得 %d", len(utf8), len(sjis))
	}
}

func TestConvertFromUTF8_UnsupportedChars(t *testing.T) {
	// Shift_JIS 不支持某些 emoji;转换应用 ? 替换,不 panic
	utf8 := []byte("test 🎉 end")
	result := ConvertFromUTF8(utf8, "shift_jis")
	if len(result) == 0 {
		t.Error("含 unsupported char 也应有输出")
	}
	// 结果应含 "test" 和 "end"(不确定 emoji 处理后的字节,但英文部分应保留)
	if !strings.Contains(string(result), "test") {
		t.Errorf("应保留 ASCII 部分,得到 %q", result)
	}
}

func TestConvertStringFromUTF8(t *testing.T) {
	// 应等价 ConvertFromUTF8([]byte(s), ...)
	s := "hello"
	got1 := ConvertStringFromUTF8(s, "utf-8")
	got2 := ConvertFromUTF8([]byte(s), "utf-8")
	if string(got1) != string(got2) {
		t.Errorf("string 与 []byte 版本应等价")
	}
}

// ===== encoded-word (RFC 2047) =====

func TestEncodeHeaderBase64_ASCII_NoEncode(t *testing.T) {
	// 纯 ASCII + UTF-8 → 无需编码,原样返回
	got := EncodeHeaderBase64("hello", "utf-8")
	if got != "hello" {
		t.Errorf("纯 ASCII 不应编码,得到 %q", got)
	}
}

func TestEncodeHeaderBase64_NonASCII_Encoded(t *testing.T) {
	got := EncodeHeaderBase64("你好", "utf-8")
	if !strings.HasPrefix(got, "=?UTF-8?B?") {
		t.Errorf("应以 =?UTF-8?B? 开头,得到 %q", got)
	}
	if !strings.HasSuffix(got, "?=") {
		t.Errorf("应以 ?= 结尾,得到 %q", got)
	}
	// 中间应是合法 base64
	middle := got[len("=?UTF-8?B?") : len(got)-2]
	decoded, err := base64.StdEncoding.DecodeString(middle)
	if err != nil {
		t.Errorf("中间应是合法 base64,得到 %q, err: %v", middle, err)
	}
	if string(decoded) != "你好" {
		t.Errorf("解码后应是原字符串,得到 %q", decoded)
	}
}

func TestEncodeHeaderBase64_ShiftJIS(t *testing.T) {
	got := EncodeHeaderBase64("こんにちは", "shift_jis")
	if !strings.HasPrefix(got, "=?Shift_JIS?B?") {
		t.Errorf("应以 =?Shift_JIS?B? 开头,得到 %q", got)
	}
}

func TestEncodeHeaderBase64_Empty(t *testing.T) {
	got := EncodeHeaderBase64("", "utf-8")
	if got != "" {
		t.Errorf("空串应返回空,得到 %q", got)
	}
}

func TestEncodeHeaderQP_ASCII_NoEncode(t *testing.T) {
	got := EncodeHeaderQP("hello", "utf-8")
	if got != "hello" {
		t.Errorf("纯 ASCII 不应编码,得到 %q", got)
	}
}

func TestEncodeHeaderQP_NonASCII(t *testing.T) {
	got := EncodeHeaderQP("你好", "utf-8")
	if !strings.HasPrefix(got, "=?UTF-8?Q?") {
		t.Errorf("应以 =?UTF-8?Q? 开头,得到 %q", got)
	}
	// "你" UTF-8 是 E4 BD A0,编码为 =E4=BD=A0
	if !strings.Contains(got, "=E4=BD=A0") {
		t.Errorf("应含 =E4=BD=A0(你 UTF-8 编码),得到 %q", got)
	}
}

func TestEncodeHeaderQP_SpaceHandling(t *testing.T) {
	// 空格应编码为 "_"
	got := EncodeHeaderQP("你 好", "utf-8")
	if !strings.Contains(got, "_") {
		t.Errorf("空格应编码为 _, 得到 %q", got)
	}
}

func TestQEncode_SpecialChars(t *testing.T) {
	// "?" "_" "=" 都应编码
	got := qEncode([]byte("a?b_c=d"))
	if !strings.Contains(got, "=3F") { // ?
		t.Errorf("? 应编码为 =3F, 得到 %q", got)
	}
	if !strings.Contains(got, "=5F") { // _
		t.Errorf("_ 应编码为 =5F, 得到 %q", got)
	}
	if !strings.Contains(got, "=3D") { // =
		t.Errorf("= 应编码为 =3D, 得到 %q", got)
	}
}

func TestIsASCII(t *testing.T) {
	if !isASCII("hello") {
		t.Error("hello 应是 ASCII")
	}
	if isASCII("你好") {
		t.Error("你好 不是 ASCII")
	}
	if !isASCII("") {
		t.Error("空串应视为 ASCII")
	}
}

func TestNormalizedCharsetName(t *testing.T) {
	cases := map[string]string{
		"":            "UTF-8",
		"utf-8":       "UTF-8",
		"utf8":        "UTF-8",
		"UTF-8":       "UTF-8",
		"shift_jis":   "Shift_JIS",
		"SJIS":        "Shift_JIS",
		"iso-2022-jp": "ISO-2022-JP",
		"euc-jp":      "EUC-JP",
		"gbk":         "GB18030",
		"gb18030":     "GB18030",
	}
	for input, want := range cases {
		got := normalizedCharsetName(input)
		if got != want {
			t.Errorf("normalizedCharsetName(%q) = %q, 期望 %q", input, got, want)
		}
	}
}

// ===== body =====

func TestEncodeBodyBase64_Short(t *testing.T) {
	// 短 body:不换行
	got := EncodeBodyBase64([]byte("hello"))
	if strings.Contains(got, "\r\n") {
		t.Errorf("短 body 不应换行,得到 %q", got)
	}
	// 应能解码回原
	decoded, _ := base64.StdEncoding.DecodeString(got)
	if string(decoded) != "hello" {
		t.Errorf("解码应回原,得到 %q", decoded)
	}
}

func TestEncodeBodyBase64_Long_Line76(t *testing.T) {
	// 长 body:应每 76 字符换行
	body := strings.Repeat("A", 300) // 300 字节 → base64 400 字符 → 应换 5+ 行
	got := EncodeBodyBase64([]byte(body))
	lines := strings.Split(got, "\r\n")
	if len(lines) < 4 {
		t.Errorf("应换 ≥ 4 行,得到 %d 行", len(lines))
	}
	// 每行(除最后)应恰好 76 字符
	for i, line := range lines {
		if i == len(lines)-1 {
			// 最后一行可能 < 76
			if len(line) > 76 {
				t.Errorf("最后一行超 76 字符,得到 %d", len(line))
			}
		} else {
			if len(line) != 76 {
				t.Errorf("第 %d 行应恰好 76 字符,得到 %d", i, len(line))
			}
		}
	}
}

func TestEncodeBodyQP(t *testing.T) {
	// QP 编码
	got := EncodeBodyQP([]byte("hello 世界"))
	// 中文应编码为 =XX
	if !strings.Contains(got, "=") {
		t.Errorf("含中文应含 =XX 编码,得到 %q", got)
	}
	// ASCII 部分应保留
	if !strings.Contains(got, "hello") {
		t.Errorf("ASCII 部分应保留,得到 %q", got)
	}
}

func TestEncodeBodyQP_ASCIIPassthrough(t *testing.T) {
	got := EncodeBodyQP([]byte("plain ASCII text"))
	// 纯 ASCII 应基本原样(可能 QP 有换行)
	if !strings.Contains(got, "plain ASCII text") {
		t.Errorf("纯 ASCII 应保留,得到 %q", got)
	}
}

func TestEncodeBody7bit(t *testing.T) {
	// 骨架期:直接返回原字符串
	got := EncodeBody7bit([]byte("hello"))
	if got != "hello" {
		t.Errorf("7bit 应原样返回,得到 %q", got)
	}
}
