package render

// 【csharp H3 修 2026-08-13】自定义随机附件生成 —— 从 v1 email/builder.go:1029-1096 移植
//
// 【功能】cfg.Attachments.Custom.Enabled=true 时每封邮件生成 1 个逐封不同的随机附件:
//   - filename:{NameMode: random 生成 / fixed 用 FixedName} + . + {SuffixMode: random / fixed}
//   - content:多行随机 ASCII 字母数字(与内容自洽用 text/plain; charset=us-ascii)
//
// 【与上传附件叠加】用户上传的 Files 挑 1 (A5)之后,再 append 1 个 custom → 每封实际最多 2 个附件
// 【契约】v1 email/builder.go::generateCustomAttachment / genAttachName / genAttachSuffix / genAttachContent

import (
	"strings"

	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/mail/mime"
	"__MODULE_PLACEHOLDER__/internal/random"
)

const (
	attachAlnum       = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
	attachSuffixAlpha = "abcdefghijklmnopqrstuvwxyz"
)

// generateCustomAttachment 每封生成 1 个自定义附件(per-worker rng → 每封不同)
//
// 【返回】mime.Attachment;Data 是 ASCII 字节,MIMEType text/plain;charset=us-ascii
// 【与 v1 行为一致】随机长度 clamp 在 [Min, Max] 之间,若 Min<1 或 Min>Max 兜底
func generateCustomAttachment(c *config.CustomAttachmentConfig, rng random.Source) mime.Attachment {
	name := genAttachName(c, rng)
	suffix := genAttachSuffix(c, rng)
	filename := name + "." + suffix
	return mime.Attachment{
		FileName: filename,
		MIMEType: "text/plain; charset=us-ascii",
		Data:     genAttachContent(c, rng),
		// ContentID/IsInline 留空 → 普通附件走 multipart/mixed
	}
}

// sanitizeAttachPart 文件名/后缀消毒:剥离控制字符 + 文件系统/MIME 危险字符
// 防止固定名/后缀里的 CRLF 造成 MIME 头注入
func sanitizeAttachPart(s string) string {
	var sb strings.Builder
	for _, r := range s {
		if r < 0x20 || r == 0x7f {
			continue // 控制字符(含 \r \n \t)
		}
		switch r {
		case '/', '\\', ':', '*', '?', '"', '<', '>', '|':
			continue // 文件系统/MIME 危险字符
		default:
			sb.WriteRune(r)
		}
	}
	return strings.TrimSpace(sb.String())
}

func genAttachName(c *config.CustomAttachmentConfig, rng random.Source) string {
	if strings.EqualFold(c.NameMode, "fixed") {
		if s := sanitizeAttachPart(c.FixedName); s != "" {
			return s
		}
		// 固定名消毒后为空 → 兜底随机(防止生成无名的 ".suffix")
	}
	n := randIntRange(rng, c.NameMin, c.NameMax, 1, 64)
	return randStringFrom(rng, n, attachAlnum)
}

func genAttachSuffix(c *config.CustomAttachmentConfig, rng random.Source) string {
	if strings.EqualFold(c.SuffixMode, "fixed") {
		// 固定后缀:消毒 + 去掉用户可能误带的点(不带点,拼接时统一加)
		if s := strings.Trim(sanitizeAttachPart(c.FixedSuffix), "."); s != "" {
			return s
		}
	}
	n := randIntRange(rng, c.SuffixMin, c.SuffixMax, 1, 16)
	return randStringFrom(rng, n, attachSuffixAlpha)
}

func genAttachContent(c *config.CustomAttachmentConfig, rng random.Source) []byte {
	lines := randIntRange(rng, c.ContentLinesMin, c.ContentLinesMax, 1, 10000)
	var sb strings.Builder
	for i := 0; i < lines; i++ {
		if i > 0 {
			sb.WriteString("\r\n")
		}
		chars := randIntRange(rng, c.ContentCharsMin, c.ContentCharsMax, 1, 100000)
		sb.WriteString(randStringFrom(rng, chars, attachAlnum))
	}
	return []byte(sb.String())
}

// randIntRange 从 [min, max] 均匀抽 int;若 min < absMin 用 absMin;若 min > max 用 min
//
// 【契约】v1 randIntRange 语义 —— 边界保护 + 均匀分布
func randIntRange(rng random.Source, min, max, absMin, absMax int) int {
	if min < absMin {
		min = absMin
	}
	if max < min {
		max = min
	}
	if max > absMax {
		max = absMax
	}
	if min >= max {
		return min
	}
	return rng.Intn(max-min+1) + min
}

// randStringFrom 从字符集 alphabet 里抽 n 个字符组成字符串
func randStringFrom(rng random.Source, n int, alphabet string) string {
	if n <= 0 || len(alphabet) == 0 {
		return ""
	}
	b := make([]byte, n)
	for i := 0; i < n; i++ {
		b[i] = alphabet[rng.Intn(len(alphabet))]
	}
	return string(b)
}
