// Package render 顶层邮件渲染器 —— 集成 5 header 子包 + variables + mime + obfuscate + compose
//
// 【调用入口】Builder.Build(recipient) → (*Email, error)
//
// 【集成拓扑】(Day 26 实现)
//
//	1. 变量渲染:variables.basic + variables.extended 处理模板占位符
//	2. 混淆:obfuscate.Noiser 注入 zero-width / bidi / 图像 noise
//	3. MIME 拼装:mime.Builder 决定 3 分支矩阵(text/html/multipart)+ 附件
//	4. Header 生成:5 header 子包各自生成对应 header 段
//	   - dkim.Signer.Generate() → DKIM-Signature 头
//	   - received.Composer.GenerateAll() → 6 优先级折叠 + 原 Received
//	   - listunsub.Resolver.Resolve() → List-Unsubscribe + Post 联动
//	   - extended.Selector.EmitP0AndPool() + 7 定值 method(ReplyTo/Return-Path/X-Mailer 等)
//	   - messageid.Generator.Build() → Message-ID
//	5. Header 后处理:compose.Postprocessor.Assemble()
//	   - 若 cfg.DkimHFieldsList 非空 → reorderByDkimList(跳过 shuffle)
//	   - 否则若 cfg.ShuffleOrder → shuffleHeadersWithAnchors
//	   - 若 cfg.RandomCase → applyCaseRandomization
//	6. 最终拼装:headers + "\r\n" + MIME body → raw email 字符串
//
// 【P18 硬约束】dkim.Signer 和 compose.Postprocessor 必须收到**同一份** cfg.DkimHFieldsList
// (确保邮件 header 顺序 = PMTA 生成的 h= 顺序)
//
// 【D22-3 race 修复 —— 全 6 处已解决】v1 里 6 处 race,v2 全消除:
//   1. 全局 rand → per-worker random.Source(依赖注入)
//   2. 全局 clock → per-worker clock.Clock(依赖注入)
//   3. header slot 全局 map → per-worker headerCurrentSet(状态私有)
//   4. dkim cache → per-worker signer(状态私有)
//   5. received 时间链 → per-worker composer(状态私有)
//   6. TemplateEngine stringCache/fileCache → **v2 架构消除**:
//      - bootstrap 单点读盘 htmlBody(sync.Once 语义,只读共享 string)
//      - render.Builder / basic.Processor / extended.Processor 全部 per-worker(factory 模式)
//      - 所有 regex 是 top-level regexp.MustCompile(Go 保证线程安全)
//      - 所有变量池是 top-level 只读切片
//      - 无 stringCache/fileCache 结构体字段(v2 不再有 html/template 引擎)
//   验证:race_test.go 中 50 workers × 100 iter × 5 count = 25000 次并发 Build 无 panic
// 【CHK-2 完成 2026-08-08】
//
// 【依赖】几乎所有 mail 子包 + variables + config
package render
