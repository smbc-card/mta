package render

import (
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/mail/header/compose"
	"__MODULE_PLACEHOLDER__/internal/mail/header/dkim"
	hdrExt "__MODULE_PLACEHOLDER__/internal/mail/header/extended"
	"__MODULE_PLACEHOLDER__/internal/mail/header/listunsub"
	"__MODULE_PLACEHOLDER__/internal/mail/header/messageid"
	"__MODULE_PLACEHOLDER__/internal/mail/header/received"
	"__MODULE_PLACEHOLDER__/internal/mail/mime"
	"__MODULE_PLACEHOLDER__/internal/mail/obfuscate"
	"__MODULE_PLACEHOLDER__/internal/random"
	"__MODULE_PLACEHOLDER__/internal/security"
	"__MODULE_PLACEHOLDER__/internal/variables/basic"
	varExt "__MODULE_PLACEHOLDER__/internal/variables/extended"
)

// Email 渲染后的完整邮件(顶层输出)
//
// 【契约】v2 字段与 v1 email.Email struct 对齐(核心字段;CC/BCC 由 Week 6 dispatcher 补)
type Email struct {
	RawContent   string // 完整 raw email(headers + "\r\n" + body,以 CRLF 分隔)
	EnvelopeFrom string // SMTP MAIL FROM(不含 <>)
	EnvelopeTo   string // SMTP RCPT TO(单个;CC/BCC 独立邮件由 dispatcher 分配)
	MessageID    string // 生成的 Message-ID(不含 <>,用于日志)
	Subject      string // 渲染后的 Subject(用于日志)
}

// Recipient 单个收件人上下文
//
// 【设计】render 定义自己的 Recipient(依赖倒置,不 import types)
// 【dispatcher 适配】Week 6 dispatcher 从 CSV/文件加载后适配到本 struct
type Recipient struct {
	Email        string
	Name         string
	FirstName    string
	LastName     string
	CustomFields map[string]string

	// Subject / HTMLBody / TextBody 由 dispatcher 提供(通常来自 cfg.Email 或模板文件渲染)
	// render 层不做模板文件加载,只做变量渲染 + 混淆 + MIME 组装
	Subject  string
	HTMLBody string
	TextBody string

	// 【D-014】主邮件 Cc 头列表(CC/BCC 独立邮件传 nil;主邮件才填,让主收件人看到抄送)
	// v1 email/builder.go::BuildOptions.CcHeaderList 语义
	CcHeaderList []string

	// 【D-011】PMTA 控制头(仅 MtaType="pmta" 时写入 raw email 顶部)
	// 通常 == cfg.PMTA.VirtualMTA / cfg.Job.ID;dispatcher 可 per-recipient 覆盖
	VirtualMTA string
	JobID      string

	// 【A1 override】显示名(覆盖 cfg.Sender.FromName;来自 sender.display_names 池化选择)
	// 空 → 走 cfg.Sender.FromName(默认)
	DisplayName string

	// 【A4 override】From 邮箱(覆盖 cfg.Sender.FromAddress;来自 headers.custom_from_emails 池化选择)
	// 空 → 走 cfg.Sender.FromAddress(默认)。仅覆盖 From 头,EnvelopeFrom 不动
	FromAddress string

	// 【D-012】附件(bootstrap 层预读盘;render 直接透传给 mime)
	Attachments []mime.Attachment

	// 【D-013】内嵌图(ContentID 非空 + IsInline=true;走 multipart/related 分支)
	EmbeddedImgs []mime.Attachment
}

// Builder 顶层邮件渲染器(per-worker 单实例)
//
// 【wire up】内部创建所有子包 Builder(D22-3 全部注入 rng/clk,消除 v1 包级 rand race)
//
// 【线程安全】非线程安全;per-worker 一个 Builder 实例
type Builder struct {
	cfg *config.Config
	rng random.Source
	clk clock.Clock

	// 5 header 子包
	signer   *dkim.Signer
	composer *received.Composer
	resolver *listunsub.Resolver
	selector *hdrExt.Selector
	postproc *compose.Postprocessor

	// Message-ID 生成器
	midGen *messageid.Generator

	// 混淆 + MIME
	noiser *obfuscate.Noiser
	mimer  *mime.Builder

	// 变量渲染(basic + extended,通过 varAdapter 桥接)
	varBasic *basic.Processor
	varExt   *varExt.Processor
}

// New 创建顶层 Builder
//
// 【参数】
//   - cfg:全局配置(读所有 header/mime/attachment/sender 相关)
//   - rng:per-worker 随机源(所有子包共享此源;D22-3 race 修复)
//   - clk:时钟(dkim t= / received 时间链 / 定值头 timestamp 等)
//   - cache:附件 SHA256 缓存(D22-4;可选,nil = 不缓存)
//   - customVars:自定义变量池(由 bootstrap 从 cfg.Variables.CustomVariableFiles 读盘构造;
//     nil 表示无自定义变量,{CUSTOM:name} 返回空串)
//
// 【wire up】内部创建 10 个子包 Builder 实例
func New(cfg *config.Config, rng random.Source, clk clock.Clock, cache mime.AttachmentCache, customVars map[string][]string) *Builder {
	// 构造 basic.Config(从 cfg 里挑出 basic 需要的字段)
	// 【A6/A7 修复 2026-08-13】Amount 4 字段 + Custom 池必须接入,否则
	// {AMOUNT} 出 0、{CUSTOM:name} 出空串,C# UI 里的 variables.amount_* 和
	// variables.custom_variable_files 静默失效
	basicCfg := &basic.Config{
		Sender: basic.SenderVars{
			FromAddress: cfg.Sender.FromAddress,
			FromName:    cfg.Sender.FromName,
		},
		Amount: basic.AmountCfg{
			Min:          cfg.Variables.AmountMin,
			Max:          cfg.Variables.AmountMax,
			Decimals:     cfg.Variables.AmountDecimals,
			UseSeparator: cfg.Variables.AmountUseSeparator,
		},
		Custom: customVars,
	}

	return &Builder{
		cfg:      cfg,
		rng:      rng,
		clk:      clk,
		signer:   dkim.New(rng, clk, &cfg.Headers),
		composer: received.New(rng, clk, &cfg.Headers),
		resolver: listunsub.New(rng, &cfg.Headers),
		selector: hdrExt.New(rng, clk, &cfg.Headers),
		postproc: compose.New(rng),
		midGen:   messageid.New(rng, clk),
		noiser:   obfuscate.New(rng),
		mimer:    mime.New(rng, cache),
		varBasic: basic.New(rng, clk, basicCfg),
		varExt:   varExt.New(rng, clk),
	}
}

// applyImageNoise csharp H4:image/* 附件 per-email 加噪(pixel 微调 + 尾追随机字节)
//
// 【行为】遍历 slice,MIMEType 前缀 "image/" 才调 AddImageNoise;非图透传;
// 每张图 copy Data(pre-loaded 共享 slice,不能就地改)
func applyImageNoise(atts []mime.Attachment, noiser *obfuscate.Noiser) []mime.Attachment {
	if len(atts) == 0 || noiser == nil {
		return atts
	}
	out := make([]mime.Attachment, len(atts))
	for i, a := range atts {
		out[i] = a
		if strings.HasPrefix(strings.ToLower(a.MIMEType), "image/") {
			cp := make([]byte, len(a.Data))
			copy(cp, a.Data)
			out[i].Data = noiser.AddImageNoise(cp, a.FileName)
		}
	}
	return out
}

// textToHTML M4:纯文本 → 基础 HTML 包装(与 v1 email/template.go::TextToHTML 语义等价)
//
// 【行为】
//   - 空 → 空
//   - HTML 转义:& → &amp;, < → &lt;, > → &gt;, " → &quot;
//   - \r\n 或 \n → <br>
//   - 外层包 <!DOCTYPE html><html><head>...</head><body style="...">...</body></html>
//
// 【契约】v1 输出含 DOCTYPE + meta charset + body style="font-family:Arial..." + <br> 分隔
func textToHTML(text string) string {
	if text == "" {
		return ""
	}
	// HTML escape(顺序敏感:& 必须先)
	escaped := strings.ReplaceAll(text, `&`, `&amp;`)
	escaped = strings.ReplaceAll(escaped, `<`, `&lt;`)
	escaped = strings.ReplaceAll(escaped, `>`, `&gt;`)
	escaped = strings.ReplaceAll(escaped, `"`, `&quot;`)
	// \r\n / \n → <br>
	escaped = strings.ReplaceAll(escaped, "\r\n", "<br>\n")
	escaped = strings.ReplaceAll(escaped, "\n", "<br>\n")

	return `<!DOCTYPE html>` + "\n" +
		`<html>` + "\n" +
		`<head><meta charset="UTF-8"></head>` + "\n" +
		`<body style="font-family:Arial,sans-serif;">` + "\n" +
		escaped + "\n" +
		`</body>` + "\n" +
		`</html>`
}

// varAdapter 把 basic + extended 两个 Processor 桥接到子包 VariableProcessor 接口
//
// 【P18 相关】mime/received/listunsub 各自定义 VariableProcessor 接口
// (2 参数 Process(template, recipient any));basic.Process 是 (content, *basic.Recipient),
// extended.Process 是 (content) —— 两者签名不同,需 adapter 统一
//
// 【处理顺序】basic 先,extended 后(与 v1 一致)
type varAdapter struct {
	basic *basic.Processor
	ext   *varExt.Processor
	rcpt  *basic.Recipient
}

// Process 实现 VariableProcessor 接口:先 basic 再 extended
//
// 【recipient 参数忽略】adapter 内部持有 basic.Recipient(rcpt 字段);
// 外部 recipient any 参数是接口签名要求,内部实际用持有的 rcpt
func (a *varAdapter) Process(template string, _ any) string {
	s := a.basic.Process(template, a.rcpt)
	return a.ext.Process(s)
}

// Build 渲染单个收件人的完整邮件
//
// 【核心 flow】v1 email/builder.go::Build + buildRawEmail 精简整合版
//
//  1. 渲染 subject / body(basic + extended 变量渲染)
//  2. 混淆(obfuscate.Noiser:zero-width + bidi)
//  3. MIME 组装(mime.Builder,3 分支矩阵)
//  4. 5 header 子包 + messageid + 定值 8 method 生成所有邮件头
//  5. compose.Postprocessor 后处理(shuffle / DKIM 排序 / case 混淆)
//  6. 拼装 raw email(headers + "\r\n" + MIME body)
//
// 【Day 26 简化】以下由 Week 6 dispatcher 补(不在 render 内做):
//   - 模板文件加载(dispatcher 读盘后传 recipient.HTMLBody)
//   - 附件文件读盘(dispatcher 传 mime.Attachment.Data)
//   - 内嵌图文件读盘
//   - CC/BCC 分配(dispatcher 决定 envelopeTo 和 CcHeader)
//   - 自定义 From 邮箱轮选
func (b *Builder) Build(recipient *Recipient) (*Email, error) {
	if recipient == nil {
		return nil, fmt.Errorf("render: recipient is nil")
	}

	// 【1】构造 basic.Recipient(变量渲染用)+ varAdapter
	basicRcpt := &basic.Recipient{
		Email:        recipient.Email,
		Name:         recipient.Name,
		FirstName:    recipient.FirstName,
		LastName:     recipient.LastName,
		CustomFields: recipient.CustomFields,
	}
	vp := &varAdapter{basic: b.varBasic, ext: b.varExt, rcpt: basicRcpt}

	charset := b.effectiveCharset()

	// 【2】渲染 subject / body
	subject := vp.Process(recipient.Subject, basicRcpt)
	htmlBody := vp.Process(recipient.HTMLBody, basicRcpt)
	textBody := ""
	if recipient.TextBody != "" {
		textBody = vp.Process(recipient.TextBody, basicRcpt)
	}

	// 【3】混淆(zero-width + bidi)
	if b.cfg.ZeroWidth.Enabled && b.cfg.ZeroWidth.Subject {
		subject = b.noiser.InsertZeroWidth(subject, false)
	}
	if b.cfg.Email.SubjectBidiReverse && obfuscate.BidiCharsetSupported(charset) {
		subject = b.noiser.BidiReverseHide(subject)
	}
	// 【M4 修 2026-08-13】纯文本模板 → HTML wrap(cfg.Email.ConvertTxtToHtml)
	// v1 email/builder.go:232-237:非 HTML 内容 + ConvertTxtToHtml=true 时包 <html><body>
	// 注意:必须在 zero-width 混淆之前做,否则插入的零宽字符会破坏 <p> 分段判断
	if b.cfg.Email.ConvertTxtToHtml && !mime.IsHTMLContent(htmlBody) && htmlBody != "" {
		htmlBody = textToHTML(htmlBody)
	}
	if b.cfg.ZeroWidth.Enabled && b.cfg.ZeroWidth.TemplateContent {
		htmlBody = b.noiser.InsertZeroWidth(htmlBody, mime.IsHTMLContent(htmlBody))
	}

	// 【4】MIME 组装(D-012/D-013:附件 + 内嵌图从 recipient 透传)
	// 【csharp H3 修 2026-08-13】attachments.custom.enabled=true 时每封 append 1 个逐封不同的随机附件
	// 【csharp H4 修 2026-08-13】image_noise.enabled=true 时 image/* 附件 per-email 加噪
	// 防同图 SHA256 被 ESP 一次命中所有;必须 copy Data(pre-loaded slice 是共享的)
	attList := recipient.Attachments
	embedList := recipient.EmbeddedImgs
	if b.cfg.Attachments.Custom.Enabled {
		// 每封生成 1 个;与 recipient.Attachments 里挑出的 1 个静态附件叠加
		customAtt := generateCustomAttachment(&b.cfg.Attachments.Custom, b.rng)
		// 拷贝一份新 slice,避免污染 recipient.Attachments(shared 状态)
		newList := make([]mime.Attachment, 0, len(attList)+1)
		newList = append(newList, attList...)
		newList = append(newList, customAtt)
		attList = newList
	}
	if b.cfg.ImageNoise.Enabled {
		attList = applyImageNoise(attList, b.noiser)
		embedList = applyImageNoise(embedList, b.noiser)
	}
	mimeParams := mime.BuildParams{
		TextBody:       textBody,
		HTMLBody:       htmlBody,
		Charset:        charset,
		Encoding:       b.effectiveBodyEncoding(),
		HeaderEncoding: b.cfg.Encoding.HeaderEncoding, // H3:附件 filename RFC2047 编码用
		MimeMode:       b.cfg.Email.MimeMode,
		Attachments:    attList,
		EmbeddedImgs:   embedList,
	}
	mimeRes, err := b.mimer.BuildMIME(mimeParams)
	if err != nil {
		return nil, fmt.Errorf("render: mime build: %w", err)
	}

	// 【5】Header 生成
	mainHeaders := make([]string, 0, 32)
	// 【A4】From 邮箱:recipient.FromAddress 覆盖 cfg.Sender.FromAddress(池化选择结果)
	fromAddress := b.cfg.Sender.FromAddress
	if recipient.FromAddress != "" {
		fromAddress = recipient.FromAddress
	}
	envelopeFrom := b.cfg.Sender.EnvelopeFrom
	if envelopeFrom == "" {
		envelopeFrom = fromAddress
	}
	fromDomain := extractDomain(envelopeFrom)

	// 【D-011】PMTA 控制头(仅 mta_type="pmta" 且非 Haraka 路径)
	// v1 email/builder.go:462-471 语义:Haraka 不识别,会原样残留 → 必须跳过
	if strings.EqualFold(b.cfg.MtaType, "pmta") {
		virtualMTA := recipient.VirtualMTA
		if virtualMTA == "" {
			virtualMTA = b.cfg.PMTA.VirtualMTA
		}
		jobID := recipient.JobID
		if jobID == "" {
			jobID = b.cfg.Job.ID
		}
		if virtualMTA != "" {
			mainHeaders = append(mainHeaders, fmt.Sprintf("x-virtual-mta: %s\r\n", virtualMTA))
		}
		if jobID != "" {
			mainHeaders = append(mainHeaders, fmt.Sprintf("x-job: %s\r\n", jobID))
		}
	}

	// 5.1 Received 段
	if rcvdBlock := b.composer.GenerateAll(envelopeFrom, recipient.Email, fromDomain, vp, basicRcpt); rcvdBlock != "" {
		mainHeaders = append(mainHeaders, compose.SplitHeaderBlock(rcvdBlock)...)
	}

	// 5.2 DKIM(方案 B 伪签)
	if b.cfg.Headers.Enabled && b.cfg.Headers.DkimSignature {
		if dkimLine := b.signer.Generate(fromAddress, fromDomain); dkimLine != "" {
			mainHeaders = append(mainHeaders, dkimLine)
		}
	}

	// 5.3 标准头
	// 【D-016】From 头 display name 走 RFC2047 编码(cfg.Encoding.HeaderEncoding);若 BidiReverse=true 先反转
	// 【D-018】To 头同样:若 recipient.Name 非空,用 "Name" <email> + 编码
	// 【A1】displayName:recipient.DisplayName 覆盖 cfg.Sender.FromName(池化选择结果)
	// 【M3 修 2026-08-13】DisplayNameNewline(字面 \r\n → 真 CRLF)+ ZeroWidth.DisplayName
	headerEnc := b.cfg.Encoding.HeaderEncoding
	displayName := b.cfg.Sender.FromName
	if recipient.DisplayName != "" {
		displayName = recipient.DisplayName
	}
	// M3-a:字面 `\r\n` 字符串 → 真 CRLF(仅当 Headers.DisplayNameNewline=true)
	if displayName != "" && b.cfg.Headers.DisplayNameNewline {
		displayName = strings.ReplaceAll(displayName, `\r\n`, "\r\n")
	}
	// M3-b:零宽字符插入(仅当 ZeroWidth.Enabled + ZeroWidth.DisplayName)
	if displayName != "" && b.cfg.ZeroWidth.Enabled && b.cfg.ZeroWidth.DisplayName {
		displayName = b.noiser.InsertZeroWidth(displayName, false)
	}
	if displayName != "" && b.cfg.Sender.DisplayNameBidiReverse && obfuscate.BidiCharsetSupported(charset) {
		displayName = b.noiser.BidiReverseHide(displayName)
	}
	mainHeaders = append(mainHeaders,
		fmt.Sprintf("From: %s\r\n", formatAddressWithName(displayName, fromAddress, headerEnc, charset)))
	mainHeaders = append(mainHeaders,
		fmt.Sprintf("To: %s\r\n", formatAddressWithName(recipient.Name, recipient.Email, headerEnc, charset)))

	// 【D-014】主邮件 Cc 头(仅主邮件有,CC/BCC 独立邮件不含)
	// v1 email/builder.go:280-311 语义:每地址过滤 CR/LF 防头注入 + 逗号连 + fold
	if ccHeader := buildCcHeader(recipient.CcHeaderList); ccHeader != "" {
		mainHeaders = append(mainHeaders, ccHeader)
	}

	// 【D-017】Subject 头走 RFC2047 编码(subject 已含 zero-width + bidi 反指纹,编码时会 base64 全部包住)
	mainHeaders = append(mainHeaders,
		fmt.Sprintf("Subject: %s\r\n", encodeHeaderValue(subject, headerEnc, charset)))

	// 【D-019】Date 头:优先 cfg.Sender.Timezone(IANA 名),非法/空 → time.Local(生产 Linux JST 自动)
	mainHeaders = append(mainHeaders,
		fmt.Sprintf("Date: %s\r\n", b.clk.Now().In(effectiveTimezone(b.cfg.Sender.Timezone)).Format("Mon, 02 Jan 2006 15:04:05 -0700")))

	// Message-ID
	// 【D-020】style 选择:MessageIDRandomAll=true → data.MessageIDStyleKeysPool 25 风格全选;
	// 否则 cfg.Headers.MessageIDStyles 抽 1;都空 → fallback "uuid_v4_lower"
	var msgIDText string
	if b.cfg.Headers.Enabled && b.cfg.Headers.MessageID {
		msgIDDomain := fromDomain
		if b.cfg.Headers.MessageIDUseOrgDomain && b.cfg.Sender.OrgDomain != "" {
			msgIDDomain = b.cfg.Sender.OrgDomain
		}
		styleKey := pickMessageIDStyle(b.cfg.Headers.MessageIDRandomAll, b.cfg.Headers.MessageIDStyles, b.rng)
		msgIDText = b.midGen.Build(styleKey, msgIDDomain)
	} else {
		msgIDText = fmt.Sprintf("%d@%s", b.clk.Now().UnixNano(), fromDomain)
	}
	mainHeaders = append(mainHeaders, fmt.Sprintf("Message-ID: <%s>\r\n", msgIDText))

	// MIME-Version + Content-Type + Content-Transfer-Encoding
	mainHeaders = append(mainHeaders, "MIME-Version: 1.0\r\n")

	// 5.4 定值 8 method(Reply-To / Return-Path / X-Mailer / X-Priority / Importance / Accept-Lang / Content-Lang)
	if b.cfg.Headers.Enabled {
		headersCfg := &b.cfg.Headers
		if headersCfg.ReplyTo {
			mainHeaders = append(mainHeaders, fmt.Sprintf("Reply-To: %s\r\n", b.selector.ReplyTo(fromAddress, fromDomain)))
		}
		if headersCfg.ReturnPath {
			mainHeaders = append(mainHeaders, fmt.Sprintf("Return-Path: <%s>\r\n", b.selector.ReturnPath(fromAddress, fromDomain)))
		}
		if headersCfg.XMailer {
			mainHeaders = append(mainHeaders, fmt.Sprintf("X-Mailer: %s\r\n", b.selector.XMailer()))
		}
		if headersCfg.XPriority {
			mainHeaders = append(mainHeaders, fmt.Sprintf("X-Priority: %s\r\n", b.selector.XPriority()))
		}
		if headersCfg.Importance {
			mainHeaders = append(mainHeaders, fmt.Sprintf("Importance: %s\r\n", b.selector.Importance()))
		}
		if headersCfg.AcceptLanguage {
			mainHeaders = append(mainHeaders, fmt.Sprintf("Accept-Language: %s\r\n", b.selector.AcceptLanguage()))
		}
		if headersCfg.ContentLanguage {
			mainHeaders = append(mainHeaders, fmt.Sprintf("Content-Language: %s\r\n", b.selector.ContentLanguage()))
		}

		// 5.5 List-Unsubscribe + Post 联动
		if listunsubHdr, needsPost := b.resolver.Resolve(fromDomain, vp, basicRcpt); listunsubHdr != "" {
			mainHeaders = append(mainHeaders, listunsubHdr)
			if needsPost {
				mainHeaders = append(mainHeaders, "List-Unsubscribe-Post: List-Unsubscribe=One-Click\r\n")
			}
		}

		// 5.6 P0 + P1/P2/P3 随机池(29 slot)
		if p0AndPool := b.selector.EmitP0AndPool(fromDomain); p0AndPool != "" {
			mainHeaders = append(mainHeaders, compose.SplitHeaderBlock(p0AndPool)...)
		}
	}

	// 【csharp H2 修 2026-08-13】用户自定义头文本(cfg.Headers.CustomHeadersText)
	// 每行 "Name: Value" 格式;跳空行 + '#' 注释;name/value 各自过 SanitizeHeaderValue
	// value 走变量渲染(允许模板变量如 {DATE_TIME});非法行(缺 ':')跳过不报错
	if b.cfg.Headers.Enabled && b.cfg.Headers.CustomHeadersText != "" {
		for _, line := range strings.Split(b.cfg.Headers.CustomHeadersText, "\n") {
			line = strings.TrimRight(line, "\r")
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			colonIdx := strings.Index(line, ":")
			if colonIdx <= 0 || colonIdx == len(line)-1 {
				continue // 缺 name 或缺 value
			}
			name := strings.TrimSpace(line[:colonIdx])
			value := strings.TrimSpace(line[colonIdx+1:])
			// 变量渲染(允许 {DATE_TIME} 等)
			value = vp.Process(value, basicRcpt)
			// 编码 + sanitize(encodeHeaderValue 内部已 sanitize)
			encoded := encodeHeaderValue(value, headerEnc, charset)
			// name 必须纯 ASCII 且无 CRLF(不做 RFC2047 编码)
			cleanName := strings.TrimSpace(security.SanitizeHeaderValue(name))
			if cleanName == "" {
				continue
			}
			mainHeaders = append(mainHeaders, fmt.Sprintf("%s: %s\r\n", cleanName, encoded))
		}
	}

	// 5.7 MIME Content-Type + Encoding(mime.BuildMIME 返回的两个 header)
	if mimeRes.ContentTypeHeader != "" {
		mainHeaders = append(mainHeaders, mimeRes.ContentTypeHeader)
	}
	if mimeRes.EncodingHeader != "" {
		mainHeaders = append(mainHeaders, mimeRes.EncodingHeader)
	}

	// 【6】compose 后处理(shuffle / DKIM 排序 / case 混淆)
	// P18:dkim.Signer 和 compose.Postprocessor 必须收到**同一份** DkimHFieldsList
	var dkimList []string
	if b.cfg.Headers.DkimHFieldsMasterEnabled && len(b.cfg.Headers.DkimHFieldsList) > 0 {
		dkimList = b.cfg.Headers.DkimHFieldsList
	}
	mainHeaders = b.postproc.Assemble(
		mainHeaders,
		b.cfg.Headers.ShuffleOrder,
		b.cfg.Headers.RandomCase,
		b.cfg.Headers.CaseMode,
		dkimList,
	)

	// 【7】拼装 raw email(headers + "\r\n" + body)
	var raw strings.Builder
	for _, h := range mainHeaders {
		raw.WriteString(h)
	}
	// header/body 分隔空行(v1 一致:MIME body 前有一行空行)
	raw.WriteString("\r\n")
	raw.WriteString(mimeRes.Body)

	return &Email{
		RawContent:   raw.String(),
		EnvelopeFrom: envelopeFrom,
		EnvelopeTo:   recipient.Email,
		MessageID:    msgIDText,
		Subject:      subject,
	}, nil
}

// effectiveCharset 决定实际字符集(优先级:Encoding.Charset > Email.Charset > "UTF-8")
//
// 【契约】v2 与 v1 email/builder.go::(*Builder).getCharset 语义一致(简化版)
func (b *Builder) effectiveCharset() string {
	if b.cfg.Encoding.Charset != "" {
		return b.cfg.Encoding.Charset
	}
	if b.cfg.Email.Charset != "" {
		return b.cfg.Email.Charset
	}
	return "UTF-8"
}

// effectiveBodyEncoding 决定 body 传输编码
//
// 【H5 修 2026-08-13】接入 cfg.Encoding.RandomEncoding:
//   - RandomEncoding=true → per-email 在 [base64, quoted-printable] 二元随机(v1 一致)
//   - 否则 → cfg.Encoding.BodyEncoding(默认 "7bit")
//
// 【为什么 2 元】v1 builder.go:448 就是这个池 —— 与"随机"配对的合理选择。
// 7bit/8bit 不与 QP/base64 混用,避免 body 内容表征差异被反垃圾聚类。
func (b *Builder) effectiveBodyEncoding() string {
	if b.cfg.Encoding.RandomEncoding {
		if b.rng.Intn(2) == 0 {
			return "base64"
		}
		return "quoted-printable"
	}
	if b.cfg.Encoding.BodyEncoding != "" {
		return b.cfg.Encoding.BodyEncoding
	}
	return "7bit"
}

// extractDomain 从 email address 里提取域名(@ 右侧)
//
// 【空/无 @】返回原字符串(与 v1 一致的宽容行为)
func extractDomain(addr string) string {
	if idx := strings.LastIndex(addr, "@"); idx > 0 && idx < len(addr)-1 {
		return addr[idx+1:]
	}
	return addr
}
