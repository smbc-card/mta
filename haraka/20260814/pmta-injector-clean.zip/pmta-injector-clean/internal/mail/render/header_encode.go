package render

// Header 值编码 + 时区 + Message-ID style 辅助 —— D-016..D-020
//
// 【v1 语义】email/builder.go 里 From / To / Subject / 自定义头都走 encodeRFC2047WithCharset
// v2 拆到独立函数,便于 render.Build 里各头统一调用

import (
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/internal/data"
	"__MODULE_PLACEHOLDER__/internal/mail/encoding"
	"__MODULE_PLACEHOLDER__/internal/random"
	"__MODULE_PLACEHOLDER__/internal/security"
)

// encodeHeaderValue RFC2047 encoded-word 编码
//
// 【参数】
//   - s        —— 要编码的字符串(可含中日文 / bidi / zero-width)
//   - headerEnc —— cfg.Encoding.HeaderEncoding("base64" / "quoted-printable" / "qp" / 空)
//   - charset  —— 目标字符集("UTF-8" / "ISO-2022-JP" / "Shift_JIS" / ...)
//
// 【行为】
//   - 空 s → 空
//   - 纯 ASCII → 直接返回(RFC2047 无需编码)—— 内部 encoding.EncodeHeaderBase64 已做此优化
//   - 空 headerEnc → 兼容 v1 default 行为,用 base64
//   - "base64" / "b" → EncodeHeaderBase64
//   - "quoted-printable" / "qp" / "q" → EncodeHeaderQP
//   - 其他值 → 兜底走 base64(与 v1 一致)
func encodeHeaderValue(s, headerEnc, charset string) string {
	if s == "" {
		return ""
	}
	// 【安全】ASCII pass-through 分支会原样返回,若 s 含 CR/LF 则头会被拆成多行→注入
	// SanitizeHeaderValue 剥离 CRLF,是所有头值输出前的最后统一防线
	s = security.SanitizeHeaderValue(s)
	if s == "" {
		return ""
	}
	if charset == "" {
		charset = "UTF-8"
	}
	switch strings.ToLower(strings.TrimSpace(headerEnc)) {
	case "quoted-printable", "qp", "q":
		return encoding.EncodeHeaderQP(s, charset)
	default:
		// 空或 "base64" / "b" / 其他 → 走 base64(v1 default)
		return encoding.EncodeHeaderBase64(s, charset)
	}
}

// formatAddressWithName 构造 name-addr 格式:name 是 encoded-word 时不加 quotes(与 v1 对齐)
//
// 【用途】From / To 头带 display name 时的标准 RFC 5322 §3.4 name-addr 格式
//
// 【行为】
//   - name == "" → 直接返回 addr
//   - encoded 是 encoded-word(`=?..?=`)→ `encoded <addr>`(RFC5322 phrase = 1*encoded-word)
//   - 否则(ASCII 或未编码)→ `"encoded" <addr>`(quoted-string 保护含特殊字符的 ASCII)
//
// 【为什么区分】v1 email/builder.go 里用 encodeRFC2047WithCharset 后直接 %s <addr>,不加 quotes;
// v2 若统一加 quotes 会让 encoded-word 被双引号包,虽然合法但与 v1 字节不一致
func formatAddressWithName(name, addr, headerEnc, charset string) string {
	// 【安全】addr 直接进头(不走 encoding),必须 sanitize;name 走 encodeHeaderValue 已被 sanitize
	addr = security.SanitizeHeaderValue(addr)
	if name == "" {
		return addr
	}
	encoded := encodeHeaderValue(name, headerEnc, charset)
	if encoded == "" {
		return addr
	}
	// encoded-word(=?..?=)直接跟 <addr>(v1 phrase 惯例;RFC5322 encoded-word 本身是 atom)
	if strings.HasPrefix(encoded, "=?") && strings.HasSuffix(encoded, "?=") {
		return encoded + " <" + addr + ">"
	}
	// 【M1 修 2026-08-13】纯 ASCII name:对齐 v1 needsQuoting 语义
	//   - 无特殊字符(specialChars ∪ 空格 ∪ tab)→ 不加 quotes(与 v1 字节等价)
	//   - 含特殊字符 → 加 quotes,内部 \\ → \\\\ 和 " → \" 转义(RFC5322 quoted-string)
	if needsQuoting(encoded) {
		escaped := strings.ReplaceAll(encoded, `\`, `\\`)
		escaped = strings.ReplaceAll(escaped, `"`, `\"`)
		return `"` + escaped + `" <` + addr + ">"
	}
	return encoded + " <" + addr + ">"
}

// needsQuoting v1 encodeEmailAddressWithCharset 里对 ASCII display name 是否加 quotes 的判定
//
// 【契约】RFC5322 §3.2.3 specials + 空格 + tab 必须走 quoted-string
//   specials = ( "(" / ")" / "<" / ">" / "[" / "]" / ":" / ";" / "@" / "\" / "," / "." / <"> )
func needsQuoting(s string) bool {
	const specials = `()<>[]:;@\,."` + " \t"
	return strings.ContainsAny(s, specials)
}

// effectiveTimezone D-019:cfg.Sender.Timezone → *time.Location
//
// 【行为】
//   - 空 tz → time.Local(生产 Linux JST 自动匹配)
//   - 合法 IANA(如 "Asia/Tokyo") → LoadLocation
//   - 非法值 → 静默降级 time.Local(不 err;避免破坏启动)
func effectiveTimezone(tz string) *time.Location {
	tz = strings.TrimSpace(tz)
	if tz == "" {
		return time.Local
	}
	loc, err := time.LoadLocation(tz)
	if err != nil {
		return time.Local
	}
	return loc
}

// pickMessageIDStyle D-020:从 25 风格池或用户 cfg 抽一个 style key
//
// 【行为】
//   - randomAll=true → 从 data.MessageIDStyleKeysPool(25 个)全池随机
//   - cfg.MessageIDStyles 非空 → 从用户勾选列表随机(先过滤有效 key,过滤后为空则走全池)
//   - 两者都空 → **兜底走全池随机**(v1 GenerateCustomMessageID 默认行为)
//   - 仅当全池加载失败(几乎不可能)才最终 fallback "uuid_v4_lower"
//
// 【M2 修 2026-08-13】之前"两者都空"时 hardcode "uuid_v4_lower",反指纹归零;
// 应与 v1 一致 —— 未 cfg 时用全池 25 风格随机
func pickMessageIDStyle(randomAll bool, cfgStyles []string, rng random.Source) string {
	const fallback = "uuid_v4_lower"

	pool, poolErr := data.MessageIDStyleKeysPool.Get()

	if randomAll && poolErr == nil && len(pool) > 0 {
		return pool[rng.Intn(len(pool))]
	}

	// 用户 cfgStyles 先过滤到 pool 交集(避免 typo/无效 key)
	if len(cfgStyles) > 0 && poolErr == nil && len(pool) > 0 {
		validSet := make(map[string]bool, len(pool))
		for _, k := range pool {
			validSet[k] = true
		}
		valid := make([]string, 0, len(cfgStyles))
		for _, k := range cfgStyles {
			if validSet[k] {
				valid = append(valid, k)
			}
		}
		if len(valid) > 0 {
			return valid[rng.Intn(len(valid))]
		}
		// 过滤后为空 → 落到全池兜底
	}

	// 两者都空 或 cfg 全 typo:走全池随机(v1 兜底行为)
	if poolErr == nil && len(pool) > 0 {
		return pool[rng.Intn(len(pool))]
	}

	// 极端:pool 加载失败,最终 fallback
	return fallback
}
