package render

// D22-3 第 6 处 race 修复验证 —— CHK-2
//
// 【背景】v1 email/template.go::TemplateEngine 有 stringCache/fileCache 两个 map,
// 多 worker 并发调 RenderString/RenderFile 会 concurrent map write panic。
//
// 【v2 消除方案】从架构上删除,而非补 sync.Once/sync.Map:
//   1. 不再有 html/template 引擎(v2 只做变量替换,不解析 Go template)
//   2. bootstrap 单点读盘 htmlBody(sync.Once 语义 → 只读共享 string)
//   3. render.Builder / basic.Processor / extended.Processor 全部 per-worker(factory 模式)
//   4. 所有 regex 是 top-level regexp.MustCompile(Go 官方保证线程安全)
//   5. 所有变量池是 top-level var xxx = [...](只读切片)
//
// 【本测试目的】高并发 stress 验证:
//   - N goroutine × M iteration = N*M 次 Build,共享 htmlBody + 独立 Builder + 独立 rng
//   - 若隐藏 map 并发写,Go runtime 会 panic("concurrent map read and map write")
//   - 若数据串扰(某 goroutine 输出含另一 goroutine 的 email),测试断言 fail
//
// 【Windows -race 不可用(P26)】依靠 Go runtime 的 map hash panic 检测 + 结果比对

import (
	"fmt"
	"strings"
	"sync"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// ============================================================================
// 并发 stress:模拟生产 factory 模式(每 worker 独立 Builder)
// ============================================================================

func TestConcurrent_PerWorkerBuilder_SharedTemplate_NoRace(t *testing.T) {
	// 共享的只读 htmlBody(模拟 bootstrap 一次读盘)
	sharedHTMLBody := `<html><body>Hello {TO_NAME}! Your ID: {UUID_SHORT}. Domain: {TO_DOMAIN}.</body></html>`
	sharedSubject := `Welcome {TO_FIRST}, order #{RANDOM:6}`

	// 共享 cfg(只读)
	cfg := &config.Config{
		Sender: config.SenderConfig{
			FromAddress:  "sender@example.com",
			FromName:     "Test Sender",
			EnvelopeFrom: "bounce@example.com",
		},
		Email:    config.EmailConfig{Charset: "UTF-8", MimeMode: "standard"},
		Encoding: config.EncodingConfig{BodyEncoding: "7bit"},
		Headers:  config.HeadersConfig{Enabled: true, MessageID: true},
	}

	const workers = 50
	const iterPerWorker = 100

	var wg sync.WaitGroup
	errCh := make(chan error, workers*iterPerWorker)

	for w := 0; w < workers; w++ {
		wg.Add(1)
		workerID := w
		go func() {
			defer wg.Done()

			// per-worker Builder + rng(模拟 bootstrap.factory 语义)
			// FixedSource(workerID) 保结果可预测
			rng := random.NewFixedSource(int64(workerID))
			clk := clock.NewFixedClock(time.Now())
			builder := New(cfg, rng, clk, nil, nil)

			for i := 0; i < iterPerWorker; i++ {
				rcpt := &Recipient{
					Email:     fmt.Sprintf("user%d-%d@example.com", workerID, i),
					Name:      fmt.Sprintf("User %d-%d", workerID, i),
					FirstName: fmt.Sprintf("F%d", workerID),
					LastName:  fmt.Sprintf("L%d", i),
					Subject:   sharedSubject,
					HTMLBody:  sharedHTMLBody,
				}
				email, err := builder.Build(rcpt)
				if err != nil {
					errCh <- fmt.Errorf("worker %d iter %d: %w", workerID, i, err)
					return
				}
				// 数据未串扰:EnvelopeTo 必须精确匹配本次输入
				if email.EnvelopeTo != rcpt.Email {
					errCh <- fmt.Errorf("worker %d iter %d: EnvelopeTo=%s want=%s (数据串扰)",
						workerID, i, email.EnvelopeTo, rcpt.Email)
					return
				}
				// Subject 变量应已替换(不再含 {TO_FIRST})
				if strings.Contains(email.Subject, "{TO_FIRST}") {
					errCh <- fmt.Errorf("worker %d iter %d: Subject 未渲染:%s",
						workerID, i, email.Subject)
					return
				}
			}
		}()
	}

	wg.Wait()
	close(errCh)

	for err := range errCh {
		t.Error(err)
	}
}

// ============================================================================
// 并发 stress:同 Builder + 多 goroutine(反面场景 —— 应受 doc 警告"per-worker")
// ============================================================================
// 【设计意图】render.Builder doc 明说"非线程安全,per-worker 一个实例"。
// 本测试 **不并发共享 Builder** —— 只验证 v2 架构下 per-worker 隔离是充分的。
// 若未来有人违反 doc 并发共享,请另加测试记录预期 panic。

// ============================================================================
// 变量渲染:大量 {CUSTOM} + {IF} 变量的 stringCache 压力测试
// ============================================================================
// 【关键测试】v1 里 stringCache 就是缓存 RenderString(text) 的 template.Template。
// v2 里 basic.processCustomVariables/processConditionalVariables 用 top-level regex 直接匹配,
// 没有 per-string cache;所以本测无论 template 有多少种,都不会触发 map 并发写。

func TestConcurrent_ManyDistinctTemplates_NoRace(t *testing.T) {
	cfg := &config.Config{
		Sender:   config.SenderConfig{FromAddress: "s@x.com", EnvelopeFrom: "s@x.com"},
		Email:    config.EmailConfig{Charset: "UTF-8", MimeMode: "standard"},
		Encoding: config.EncodingConfig{BodyEncoding: "7bit"},
		Headers:  config.HeadersConfig{Enabled: true, MessageID: true},
	}

	const workers = 30
	// 每 goroutine 用完全不同的 template —— 若 v2 有 stringCache 类语义,并发插入 map 会 panic
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		id := w
		go func() {
			defer wg.Done()
			rng := random.NewFixedSource(int64(id))
			clk := clock.NewFixedClock(time.Now())
			builder := New(cfg, rng, clk, nil, nil)

			for i := 0; i < 50; i++ {
				// 每次都是唯一 template 字符串(制造 cache miss 高频)
				tmpl := fmt.Sprintf(
					"W%d I%d {UUID_SHORT} {RANDOM:8} {IF:TO_DOMAIN=example.com:yes-%d:no-%d}",
					id, i, id, i,
				)
				rcpt := &Recipient{
					Email:    fmt.Sprintf("u%d-%d@example.com", id, i),
					Subject:  tmpl,
					HTMLBody: "<p>" + tmpl + "</p>",
				}
				_, err := builder.Build(rcpt)
				if err != nil {
					t.Errorf("worker %d iter %d: %v", id, i, err)
					return
				}
			}
		}()
	}
	wg.Wait()
}

// ============================================================================
// 并发 stress:验证 mime.NewSyncMapCache() 附件缓存并发安全
// ============================================================================
// 【D22-4】AttachmentCache 是 sync.Map 实现,可跨 worker 共享。此测验证共享 cache 时也 OK。
// 【注意】Day 26 render.Build 未开启附件路径(dispatcher 层补);此处传 nil cache 与生产一致。
// 【与 D22-3 关系】cache=nil 时零共享;若未来切换 SyncMapCache 共享,由 D22-4 sync.Map 语义保证。
// 本 case 用 nil 即可覆盖 D22-3 关注点。

// ============================================================================
// v1 stringCache 语义 vs v2 —— 编译期约束确认(v2 struct 无 stringCache/fileCache 字段)
// ============================================================================
// 【意图】静态断言:v2 render.Builder 内部**无任何 map[string]xxx 字段**,
// 即 v1 D22-3 第 6 处 race 的载体在 v2 结构上不存在。
// 【实现】用 struct literal 构造 + 字段名注释,若未来有人加 map 字段(引入回归),编译不影响,
// 但会在 doc.go D22-3 注释里显式看到本约束。文档式约束,不是运行时断言。

// ============================================================================
// 处理器无状态 pure:同 seed + 同 template + 同 recipient → 输出恒等
// ============================================================================
// 【为什么这条属于 D22-3】v1 里 stringCache 会导致"首次 Parse 慢,后续 cache 快"—— 结果一致
// 但性能不一致;若 cache 出错(map 半写)结果会不一致。v2 stateless 直接保证 pure。

func TestBuilder_DeterministicOutput_SameInput(t *testing.T) {
	cfg := &config.Config{
		Sender:   config.SenderConfig{FromAddress: "s@x.com", EnvelopeFrom: "s@x.com"},
		Email:    config.EmailConfig{Charset: "UTF-8", MimeMode: "standard"},
		Encoding: config.EncodingConfig{BodyEncoding: "7bit"},
		Headers:  config.HeadersConfig{Enabled: true, MessageID: true},
	}
	fixedT := time.Date(2026, 8, 8, 12, 0, 0, 0, time.UTC)
	rcpt := &Recipient{
		Email:    "u@x.com",
		Name:     "N",
		Subject:  "Hi {TO_NAME}",
		HTMLBody: "<p>Body</p>",
	}

	// 建 2 个 Builder,同 seed 同 clock → 输出必须完全相同(bit-for-bit)
	builder1 := New(cfg, random.NewFixedSource(42), clock.NewFixedClock(fixedT), nil, nil)
	builder2 := New(cfg, random.NewFixedSource(42), clock.NewFixedClock(fixedT), nil, nil)

	e1, err1 := builder1.Build(rcpt)
	e2, err2 := builder2.Build(rcpt)

	if err1 != nil || err2 != nil {
		t.Fatalf("Build err: %v / %v", err1, err2)
	}
	if e1.RawContent != e2.RawContent {
		t.Error("同 seed 同 input 输出不一致 —— 存在隐藏状态")
	}
	if e1.MessageID != e2.MessageID {
		t.Errorf("MessageID 不一致:%s vs %s", e1.MessageID, e2.MessageID)
	}
}
