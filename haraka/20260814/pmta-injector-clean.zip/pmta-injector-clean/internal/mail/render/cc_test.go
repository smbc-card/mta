package render

import (
	"strings"
	"testing"
)

// ============================================================================
// buildCcHeader —— D-014 边界
// ============================================================================

func TestBuildCcHeader_Empty(t *testing.T) {
	if got := buildCcHeader(nil); got != "" {
		t.Errorf("nil 应返回空,got=%q", got)
	}
	if got := buildCcHeader([]string{}); got != "" {
		t.Errorf("空 slice 应返回空,got=%q", got)
	}
}

func TestBuildCcHeader_AllBlank(t *testing.T) {
	got := buildCcHeader([]string{"", "  ", "\t"})
	if got != "" {
		t.Errorf("全空白应返回空,got=%q", got)
	}
}

func TestBuildCcHeader_SingleAddr(t *testing.T) {
	got := buildCcHeader([]string{"a@example.com"})
	want := "Cc: a@example.com\r\n"
	if got != want {
		t.Errorf("got=%q want=%q", got, want)
	}
}

func TestBuildCcHeader_MultipleAddrs(t *testing.T) {
	got := buildCcHeader([]string{"a@x.com", "b@y.com", "c@z.com"})
	want := "Cc: a@x.com, b@y.com, c@z.com\r\n"
	if got != want {
		t.Errorf("got=%q want=%q", got, want)
	}
}

func TestBuildCcHeader_TrimWhitespace(t *testing.T) {
	got := buildCcHeader([]string{"  a@x.com  ", "\tb@y.com\t"})
	want := "Cc: a@x.com, b@y.com\r\n"
	if got != want {
		t.Errorf("got=%q want=%q", got, want)
	}
}

func TestBuildCcHeader_FiltersCRLFInjection(t *testing.T) {
	// v1 v8.1.3 #22 纵深防御:防头注入
	got := buildCcHeader([]string{
		"a@x.com",
		"b@y.com\r\nBcc: attacker@evil.com", // 注入尝试
		"c@z.com",
	})
	want := "Cc: a@x.com, c@z.com\r\n"
	if got != want {
		t.Errorf("含 CRLF 应被过滤,got=%q want=%q", got, want)
	}
	// 输出绝不能含 attacker
	if strings.Contains(got, "attacker") {
		t.Fatal("CRLF 注入未被过滤!")
	}
}

func TestBuildCcHeader_FiltersLoneCRAndLF(t *testing.T) {
	got := buildCcHeader([]string{
		"only-cr@x.com\rextra",
		"only-lf@y.com\nextra",
		"clean@z.com",
	})
	// 只 clean@z.com 保留
	want := "Cc: clean@z.com\r\n"
	if got != want {
		t.Errorf("got=%q want=%q", got, want)
	}
}

func TestBuildCcHeader_LongList_Folds(t *testing.T) {
	// 构造超长列表触发 fold(prefixLen=4 "Cc: ")
	addrs := make([]string, 20)
	for i := range addrs {
		addrs[i] = "user0000@example-domain.com"
	}
	got := buildCcHeader(addrs)

	if !strings.HasPrefix(got, "Cc: ") {
		t.Errorf("应以 'Cc: ' 开头,got 前 8 字符=%q", got[:8])
	}
	if !strings.HasSuffix(got, "\r\n") {
		t.Errorf("应以 CRLF 结尾")
	}
	// 折叠应含至少一个 CRLF+space/tab(fold 标志)
	inner := strings.TrimSuffix(got, "\r\n")
	if !strings.Contains(inner, "\r\n") {
		t.Errorf("长列表应触发 fold,含内部 CRLF")
	}
}

func TestBuildCcHeader_MixedValidInvalid(t *testing.T) {
	got := buildCcHeader([]string{
		"",                    // 空
		"good@x.com",          // 有效
		"  ",                  // 空白
		"bad@y.com\rinjected", // 中间 CR(真正的注入攻击)
		"nice@z.com",          // 有效
	})
	want := "Cc: good@x.com, nice@z.com\r\n"
	if got != want {
		t.Errorf("got=%q want=%q", got, want)
	}
}
