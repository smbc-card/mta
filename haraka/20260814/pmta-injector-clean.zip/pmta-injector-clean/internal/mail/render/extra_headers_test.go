package render

import (
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/mail/mime"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// D-011..D-014 集成测试(Build 完整流程)

// newBuilderWithMta 建可复现的 Builder,可指定 mta_type
func newBuilderWithMta(seed int64, mtaType, virtualMTA, jobID string) *Builder {
	cfg := &config.Config{
		MtaType: mtaType,
		Sender: config.SenderConfig{
			FromAddress:  "sender@example.com",
			FromName:     "Test Sender",
			EnvelopeFrom: "bounce@example.com",
		},
		PMTA: config.PMTAConfig{VirtualMTA: virtualMTA},
		Job:  config.JobConfig{ID: jobID},
		Email: config.EmailConfig{
			Charset:  "UTF-8",
			MimeMode: "standard",
		},
		Encoding: config.EncodingConfig{
			BodyEncoding: "7bit",
		},
		Headers: config.HeadersConfig{
			Enabled:   true,
			MessageID: true,
		},
	}
	fixedT := time.Date(2026, 8, 8, 12, 0, 0, 0, time.UTC)
	return New(cfg, random.NewFixedSource(seed), clock.NewFixedClock(fixedT), nil, nil)
}

// ============================================================================
// D-011: PMTA 控制头
// ============================================================================

func TestBuild_PMTAHeaders_WrittenWhenPMTA(t *testing.T) {
	b := newBuilderWithMta(42, "pmta", "pmta-vmta1", "job-20260808-001")
	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, err := b.Build(rcpt)
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	if !strings.Contains(email.RawContent, "x-virtual-mta: pmta-vmta1\r\n") {
		t.Error("PMTA 模式应含 x-virtual-mta 头")
	}
	if !strings.Contains(email.RawContent, "x-job: job-20260808-001\r\n") {
		t.Error("PMTA 模式应含 x-job 头")
	}
}

func TestBuild_PMTAHeaders_SkippedWhenHaraka(t *testing.T) {
	b := newBuilderWithMta(42, "haraka", "pmta-vmta1", "job-x")
	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	if strings.Contains(email.RawContent, "x-virtual-mta") {
		t.Error("Haraka 模式不应含 x-virtual-mta 头")
	}
	if strings.Contains(email.RawContent, "x-job") {
		t.Error("Haraka 模式不应含 x-job 头")
	}
}

func TestBuild_PMTAHeaders_SkippedWhenNoMtaType(t *testing.T) {
	b := newBuilderWithMta(42, "", "vmta", "jid")
	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	if strings.Contains(email.RawContent, "x-virtual-mta") {
		t.Error("MtaType 空不应含 PMTA 头")
	}
}

func TestBuild_PMTAHeaders_CaseInsensitiveMtaType(t *testing.T) {
	b := newBuilderWithMta(42, "PMTA", "v1", "j1") // 大写
	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	if !strings.Contains(email.RawContent, "x-virtual-mta: v1") {
		t.Error("大写 PMTA 应等价 pmta,含 x-virtual-mta")
	}
}

func TestBuild_PMTAHeaders_RecipientOverrideCfg(t *testing.T) {
	b := newBuilderWithMta(42, "pmta", "cfg-vmta", "cfg-job")
	rcpt := &Recipient{
		Email: "u@x.com", Subject: "s", HTMLBody: "b",
		VirtualMTA: "custom-vmta", JobID: "custom-job",
	}
	email, _ := b.Build(rcpt)
	if !strings.Contains(email.RawContent, "x-virtual-mta: custom-vmta") {
		t.Error("recipient 覆盖应生效")
	}
	if strings.Contains(email.RawContent, "cfg-vmta") {
		t.Error("cfg 值不应出现(被 recipient 覆盖)")
	}
	if !strings.Contains(email.RawContent, "x-job: custom-job") {
		t.Error("recipient jobID 覆盖应生效")
	}
}

func TestBuild_PMTAHeaders_EmptyCfgAndRecipient(t *testing.T) {
	b := newBuilderWithMta(42, "pmta", "", "")
	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	if strings.Contains(email.RawContent, "x-virtual-mta") {
		t.Error("VirtualMTA 空不应写空头")
	}
	if strings.Contains(email.RawContent, "x-job") {
		t.Error("JobID 空不应写空头")
	}
}

// ============================================================================
// D-014: Cc 头集成
// ============================================================================

func TestBuild_CcHeader_WhenListNonEmpty(t *testing.T) {
	b := newBuilderWithMta(42, "haraka", "", "")
	rcpt := &Recipient{
		Email: "main@x.com", Subject: "s", HTMLBody: "b",
		CcHeaderList: []string{"cc1@x.com", "cc2@y.com"},
	}
	email, _ := b.Build(rcpt)
	if !strings.Contains(email.RawContent, "Cc: cc1@x.com, cc2@y.com\r\n") {
		t.Errorf("应含 Cc 头,raw:\n%s", email.RawContent)
	}
	// Cc 头应在 To 之后 Subject 之前
	toIdx := strings.Index(email.RawContent, "To: main@x.com")
	ccIdx := strings.Index(email.RawContent, "Cc: cc1@x.com")
	subjIdx := strings.Index(email.RawContent, "Subject: s")
	if !(toIdx < ccIdx && ccIdx < subjIdx) {
		t.Errorf("Cc 头位置错(应在 To 后 Subject 前);to=%d cc=%d subj=%d", toIdx, ccIdx, subjIdx)
	}
}

func TestBuild_CcHeader_EmptyList_NoHeader(t *testing.T) {
	b := newBuilderWithMta(42, "haraka", "", "")
	rcpt := &Recipient{
		Email: "u@x.com", Subject: "s", HTMLBody: "b",
		// CcHeaderList 为 nil
	}
	email, _ := b.Build(rcpt)
	if strings.Contains(email.RawContent, "Cc:") {
		t.Error("空 CcHeaderList 不应有 Cc 头")
	}
}

// ============================================================================
// D-012: 附件
// ============================================================================

func TestBuild_WithAttachments_WalksMixedPath(t *testing.T) {
	b := newBuilderWithMta(42, "haraka", "", "")
	rcpt := &Recipient{
		Email: "u@x.com", Subject: "s", HTMLBody: "<p>b</p>",
		Attachments: []mime.Attachment{
			{FileName: "test.txt", MIMEType: "text/plain", Data: []byte("hello attach")},
		},
	}
	email, err := b.Build(rcpt)
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// 附件走 multipart/mixed
	if !strings.Contains(email.RawContent, "multipart/mixed") {
		t.Error("有附件应走 multipart/mixed")
	}
	if !strings.Contains(email.RawContent, "test.txt") {
		t.Error("附件文件名应出现在 Content-Disposition")
	}
	if !strings.Contains(email.RawContent, "Content-Disposition: attachment") {
		t.Error("附件应有 Content-Disposition: attachment")
	}
}

// ============================================================================
// D-013: 内嵌图
// ============================================================================

func TestBuild_WithEmbeddedImages_WalksRelatedPath(t *testing.T) {
	b := newBuilderWithMta(42, "haraka", "", "")
	pngData := []byte{0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A} // PNG header
	rcpt := &Recipient{
		Email: "u@x.com", Subject: "s",
		HTMLBody: `<img src="cid:img1">`,
		EmbeddedImgs: []mime.Attachment{
			{FileName: "img1.png", MIMEType: "image/png", Data: pngData, ContentID: "img1", IsInline: true},
		},
	}
	email, err := b.Build(rcpt)
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// 内嵌图(无附件)走 multipart/related
	if !strings.Contains(email.RawContent, "multipart/related") {
		t.Error("有内嵌图应走 multipart/related")
	}
	if !strings.Contains(email.RawContent, "Content-ID: <img1>") {
		t.Errorf("内嵌图应有 Content-ID 头,raw:\n%s", email.RawContent)
	}
}

func TestBuild_WithBothAttachmentsAndEmbeddedImages(t *testing.T) {
	// 附件 + 内嵌图 → multipart/mixed 里嵌套 multipart/related
	b := newBuilderWithMta(42, "haraka", "", "")
	rcpt := &Recipient{
		Email: "u@x.com", Subject: "s", HTMLBody: `<img src="cid:img1">`,
		Attachments: []mime.Attachment{
			{FileName: "doc.pdf", MIMEType: "application/pdf", Data: []byte("PDF-1.4")},
		},
		EmbeddedImgs: []mime.Attachment{
			{FileName: "img1.png", MIMEType: "image/png", Data: []byte{0x89, 0x50}, ContentID: "img1", IsInline: true},
		},
	}
	email, err := b.Build(rcpt)
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	if !strings.Contains(email.RawContent, "multipart/mixed") {
		t.Error("附件+内嵌图应外层 multipart/mixed")
	}
	if !strings.Contains(email.RawContent, "doc.pdf") {
		t.Error("附件文件名应出现")
	}
	if !strings.Contains(email.RawContent, "img1") {
		t.Error("内嵌图 CID 应出现")
	}
}
