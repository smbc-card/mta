package render

import (
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/config"
	"__MODULE_PLACEHOLDER__/internal/random"
	"__MODULE_PLACEHOLDER__/internal/variables/basic"
)

var fixedTestTime = time.Date(2026, 8, 7, 15, 30, 45, 0, time.UTC)

// newTestBuilder 建可复现的 Builder + 最小合理 config
func newTestBuilder(seed int64) *Builder {
	cfg := &config.Config{
		Sender: config.SenderConfig{
			FromAddress:  "sender@example.com",
			FromName:     "Test Sender",
			EnvelopeFrom: "bounce@example.com",
		},
		Email: config.EmailConfig{
			Charset:  "UTF-8",
			MimeMode: "standard",
		},
		Encoding: config.EncodingConfig{
			BodyEncoding: "7bit",
		},
		Headers: config.HeadersConfig{
			Enabled:   true,
			MessageID: true,
		},
	}
	return New(cfg, random.NewFixedSource(seed), clock.NewFixedClock(fixedTestTime), nil, nil)
}

// makeRecipient 构造标准测试用 recipient
func makeRecipient(email, subject, body string) *Recipient {
	return &Recipient{
		Email:    email,
		Name:     "Recipient Name",
		Subject:  subject,
		HTMLBody: body,
	}
}

// ============================================================================
// New wire up
// ============================================================================

func TestNew_Wireup(t *testing.T) {
	b := newTestBuilder(42)
	if b == nil {
		t.Fatal("New 返回 nil")
	}
	// 所有 10 个子包依赖必须已注入
	if b.signer == nil {
		t.Error("signer 未注入")
	}
	if b.composer == nil {
		t.Error("composer 未注入")
	}
	if b.resolver == nil {
		t.Error("resolver 未注入")
	}
	if b.selector == nil {
		t.Error("selector 未注入")
	}
	if b.postproc == nil {
		t.Error("postproc 未注入")
	}
	if b.midGen == nil {
		t.Error("midGen 未注入")
	}
	if b.noiser == nil {
		t.Error("noiser 未注入")
	}
	if b.mimer == nil {
		t.Error("mimer 未注入")
	}
	if b.varBasic == nil {
		t.Error("varBasic 未注入")
	}
	if b.varExt == nil {
		t.Error("varExt 未注入")
	}
}

// ============================================================================
// Build 边界
// ============================================================================

func TestBuild_NilRecipient(t *testing.T) {
	b := newTestBuilder(42)
	_, err := b.Build(nil)
	if err == nil {
		t.Error("nil recipient 应返回 err")
	}
}

// ============================================================================
// Build 核心 flow
// ============================================================================

func TestBuild_MinimalFlow(t *testing.T) {
	b := newTestBuilder(42)
	rcpt := makeRecipient("user@example.com", "Test Subject", "Hello World")
	email, err := b.Build(rcpt)
	if err != nil {
		t.Fatalf("Build:%v", err)
	}
	if email == nil {
		t.Fatal("Build 返回 nil")
	}
	if email.RawContent == "" {
		t.Fatal("RawContent 空")
	}

	// EnvelopeFrom / EnvelopeTo / Subject 正确
	if email.EnvelopeFrom != "bounce@example.com" {
		t.Errorf("EnvelopeFrom:%q, want=bounce@example.com", email.EnvelopeFrom)
	}
	if email.EnvelopeTo != "user@example.com" {
		t.Errorf("EnvelopeTo:%q", email.EnvelopeTo)
	}
	if email.Subject != "Test Subject" {
		t.Errorf("Subject:%q", email.Subject)
	}
	if email.MessageID == "" {
		t.Error("MessageID 空")
	}

	// raw 应含核心 headers
	// 【D-016】From display name 若纯 ASCII 无需 base64 编码(encoding 包 ASCII 短路)
	// 【D-018】To 头带 Name → "\"Name\" <email>"(makeRecipient 传 "Recipient Name")
	must := []string{
		"From: \"Test Sender\" <sender@example.com>\r\n",
		"To: \"Recipient Name\" <user@example.com>\r\n",
		"Subject: Test Subject\r\n",
		"MIME-Version: 1.0\r\n",
		"Message-ID: <",
		"Date: ",
	}
	for _, h := range must {
		if !strings.Contains(email.RawContent, h) {
			t.Errorf("缺 header:%q", h)
		}
	}

	// 应含 header/body 分隔的 \r\n\r\n(至少一处 —— MIME body 前)
	if !strings.Contains(email.RawContent, "\r\n\r\n") {
		t.Error("缺 header/body 分隔空行")
	}

	// body 应含 "Hello World"(text/plain 单体 + 7bit → 原样)
	if !strings.Contains(email.RawContent, "Hello World") {
		t.Errorf("缺 body 内容:\n%s", email.RawContent)
	}
}

func TestBuild_EnvelopeFromFallbackToFromAddress(t *testing.T) {
	// EnvelopeFrom 空 → fallback FromAddress
	cfg := &config.Config{
		Sender: config.SenderConfig{FromAddress: "sender@x.com"},
		Email:  config.EmailConfig{Charset: "UTF-8", MimeMode: "standard"},
		Encoding: config.EncodingConfig{BodyEncoding: "7bit"},
	}
	b := New(cfg, random.NewFixedSource(42), clock.NewFixedClock(fixedTestTime), nil, nil)
	email, err := b.Build(makeRecipient("u@x.com", "s", "b"))
	if err != nil {
		t.Fatalf("Build:%v", err)
	}
	if email.EnvelopeFrom != "sender@x.com" {
		t.Errorf("EnvelopeFrom fallback:%q, want=sender@x.com", email.EnvelopeFrom)
	}
}

func TestBuild_HTMLBody_ContentTypeIsHTML(t *testing.T) {
	b := newTestBuilder(42)
	rcpt := makeRecipient("u@x.com", "s", "<html><body>hi</body></html>")
	email, _ := b.Build(rcpt)
	if !strings.Contains(email.RawContent, "Content-Type: text/html") {
		t.Errorf("HTML body 应含 text/html:\n%s", email.RawContent)
	}
}

func TestBuild_AlternativeMode(t *testing.T) {
	cfg := &config.Config{
		Sender: config.SenderConfig{FromAddress: "s@x.com"},
		Email: config.EmailConfig{
			Charset:  "UTF-8",
			MimeMode: "alternative",
		},
		Encoding: config.EncodingConfig{BodyEncoding: "7bit"},
	}
	b := New(cfg, random.NewFixedSource(42), clock.NewFixedClock(fixedTestTime), nil, nil)
	rcpt := makeRecipient("u@x.com", "s", "<p>html</p>")
	rcpt.TextBody = "text ver"
	email, err := b.Build(rcpt)
	if err != nil {
		t.Fatalf("Build:%v", err)
	}
	if !strings.Contains(email.RawContent, "multipart/alternative") {
		t.Errorf("应含 multipart/alternative:\n%s", email.RawContent[:400])
	}
}

// ============================================================================
// Header 生成集成
// ============================================================================

func TestBuild_WithReplyToXMailer(t *testing.T) {
	cfg := &config.Config{
		Sender: config.SenderConfig{FromAddress: "s@x.com", FromName: "S"},
		Email:  config.EmailConfig{Charset: "UTF-8", MimeMode: "standard"},
		Encoding: config.EncodingConfig{BodyEncoding: "7bit"},
		Headers: config.HeadersConfig{
			Enabled:   true,
			ReplyTo:   true,
			XMailer:   true,
			XPriority: true, XPriorityValue: "3 (Normal)",
		},
	}
	b := New(cfg, random.NewFixedSource(42), clock.NewFixedClock(fixedTestTime), nil, nil)
	email, _ := b.Build(makeRecipient("u@x.com", "s", "b"))
	// 应含 Reply-To / X-Mailer / X-Priority(可能被 shuffle 但仍在 raw 里)
	for _, h := range []string{"Reply-To: ", "X-Mailer: ", "X-Priority: 3"} {
		if !strings.Contains(email.RawContent, h) {
			t.Errorf("缺 %q:\n%s", h, email.RawContent)
		}
	}
}

func TestBuild_WithListUnsubscribe_RealMode(t *testing.T) {
	cfg := &config.Config{
		Sender: config.SenderConfig{FromAddress: "s@x.com"},
		Email:  config.EmailConfig{Charset: "UTF-8", MimeMode: "standard"},
		Encoding: config.EncodingConfig{BodyEncoding: "7bit"},
		Headers: config.HeadersConfig{
			Enabled:                true,
			ListUnsubscribe:        true,
			ListUnsubMode:          "real",
			ListUnsubRealTemplates: []string{"<https://example.com/u/{HEX}>"},
		},
	}
	b := New(cfg, random.NewFixedSource(42), clock.NewFixedClock(fixedTestTime), nil, nil)
	email, _ := b.Build(makeRecipient("u@x.com", "s", "b"))
	// real 模式应含 List-Unsubscribe + Post
	if !strings.Contains(email.RawContent, "List-Unsubscribe:") {
		t.Error("缺 List-Unsubscribe")
	}
	if !strings.Contains(email.RawContent, "List-Unsubscribe-Post: List-Unsubscribe=One-Click") {
		t.Error("缺 List-Unsubscribe-Post(real 模式 C6 决策强制)")
	}
}

// ============================================================================
// Reproducibility
// ============================================================================

func TestBuild_Reproducibility(t *testing.T) {
	// 相同 seed + config → raw 完全一致
	b1 := newTestBuilder(42)
	b2 := newTestBuilder(42)
	e1, err1 := b1.Build(makeRecipient("u@x.com", "test", "hello"))
	e2, err2 := b2.Build(makeRecipient("u@x.com", "test", "hello"))
	if err1 != nil || err2 != nil {
		t.Fatalf("err1=%v err2=%v", err1, err2)
	}
	if e1.RawContent != e2.RawContent {
		t.Errorf("复现失败:len1=%d len2=%d", len(e1.RawContent), len(e2.RawContent))
	}
	if e1.MessageID != e2.MessageID {
		t.Errorf("MessageID 复现:%q vs %q", e1.MessageID, e2.MessageID)
	}
}

// ============================================================================
// extractDomain helper
// ============================================================================

func TestExtractDomain(t *testing.T) {
	cases := []struct{ in, want string }{
		{"user@example.com", "example.com"},
		{"a@sub.domain.jp", "sub.domain.jp"},
		{"noaddress", "noaddress"},           // 无 @ → 原样
		{"", ""},                             // 空 → 空
		{"@example.com", "@example.com"},     // @ 在开头(idx=0)→ 原样(v1 一致的宽容行为)
		{"user@", "user@"},                   // @ 在尾 → 原样
	}
	for _, c := range cases {
		if got := extractDomain(c.in); got != c.want {
			t.Errorf("extractDomain(%q):got=%q, want=%q", c.in, got, c.want)
		}
	}
}

// ============================================================================
// varAdapter
// ============================================================================

func TestVarAdapter_Process(t *testing.T) {
	// varAdapter 应能处理 basic + extended 两种变量
	b := newTestBuilder(42)
	basicRcpt := makeBasicRcpt()
	vp := &varAdapter{basic: b.varBasic, ext: b.varExt, rcpt: basicRcpt}

	// {FROM_ADDRESS} 是 basic 变量
	got := vp.Process("From is {FROM_ADDRESS}", basicRcpt)
	if !strings.Contains(got, "From is ") {
		t.Errorf("varAdapter:%q", got)
	}
	// 空模板返回空(或原样)
	if got := vp.Process("no variables here", basicRcpt); got != "no variables here" {
		t.Errorf("无变量应原样:%q", got)
	}
}

// makeBasicRcpt 构造 basic.Recipient(为 varAdapter 测试用)
func makeBasicRcpt() *basic.Recipient {
	return &basic.Recipient{
		Email: "u@x.com",
		Name:  "U",
	}
}
