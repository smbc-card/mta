package render

// Cc 头构造 —— D-014(主邮件 Cc 头 v1 对齐)
//
// 【v1 语义】email/builder.go:280-311
//   - 每个 CC 地址过滤 CR/LF(纵深防御,防头注入)
//   - 逗号 + 空格连接
//   - 若拼接后总长 > 78 字符 → RFC 5322 §2.2.3 fold(用现有 fold 包)

import (
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/mail/header/fold"
)

// buildCcHeader 从地址列表构造 "Cc: addr1, addr2, ...\r\n"
//
// 【返回】
//   - 空列表 / 全空 / 全含非法字符 → ""(调用方跳过 Cc 头输出)
//   - 有效 → "Cc: a@x.com, b@y.com\r\n"(短)
//   - 长 → "Cc: a@x.com,\r\n\tb@y.com, ...\r\n"(fold)
func buildCcHeader(list []string) string {
	if len(list) == 0 {
		return ""
	}

	parts := make([]string, 0, len(list))
	for _, addr := range list {
		trimmed := strings.TrimSpace(addr)
		if trimmed == "" {
			continue
		}
		// 过滤 CR/LF(v1 v8.1.3 #22 纵深防御:防头注入)
		if strings.ContainsAny(trimmed, "\r\n") {
			continue
		}
		parts = append(parts, trimmed)
	}
	if len(parts) == 0 {
		return ""
	}

	raw := strings.Join(parts, ", ")

	// v1 v8.1.3 #23:RFC 5322 §2.2.3 fold,超长自动折成多行
	// fold 包 Fold(value, prefixLen);prefixLen=4("Cc: ")
	folded := fold.Fold(raw, len("Cc: "))
	return fmt.Sprintf("Cc: %s\r\n", folded)
}
