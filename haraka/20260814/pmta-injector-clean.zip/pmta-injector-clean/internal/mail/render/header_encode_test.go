package render

import (
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/data"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// ============================================================================
// D-016 / D-017:encodeHeaderValue
// ============================================================================

func TestEncodeHeaderValue_ASCII_NoEncoding(t *testing.T) {
	// 纯 ASCII + UTF-8 → 不编码(encoding 包内部短路)
	got := encodeHeaderValue("Hello World", "base64", "UTF-8")
	if got != "Hello World" {
		t.Errorf("ASCII 不应编码,got=%q", got)
	}
}

func TestEncodeHeaderValue_NonASCII_Base64(t *testing.T) {
	got := encodeHeaderValue("【Test】", "base64", "UTF-8")
	if !strings.HasPrefix(got, "=?UTF-8?B?") {
		t.Errorf("含中日文应 base64 编码,got=%q", got)
	}
	if !strings.HasSuffix(got, "?=") {
		t.Errorf("RFC2047 应以 ?= 结尾,got=%q", got)
	}
}

func TestEncodeHeaderValue_NonASCII_QP(t *testing.T) {
	got := encodeHeaderValue("café", "qp", "UTF-8")
	if !strings.HasPrefix(got, "=?UTF-8?Q?") {
		t.Errorf("QP 编码,got=%q", got)
	}
}

func TestEncodeHeaderValue_EmptyEncoding_DefaultsToBase64(t *testing.T) {
	got := encodeHeaderValue("【x】", "", "UTF-8")
	if !strings.HasPrefix(got, "=?UTF-8?B?") {
		t.Errorf("空 encoding 应 default base64,got=%q", got)
	}
}

func TestEncodeHeaderValue_EmptyCharset_DefaultsToUTF8(t *testing.T) {
	got := encodeHeaderValue("【x】", "base64", "")
	if !strings.Contains(got, "UTF-8") {
		t.Errorf("空 charset 应 default UTF-8,got=%q", got)
	}
}

func TestEncodeHeaderValue_EmptyString(t *testing.T) {
	if got := encodeHeaderValue("", "base64", "UTF-8"); got != "" {
		t.Errorf("空 s 应返回空,got=%q", got)
	}
}

func TestEncodeHeaderValue_UnknownEncoding_FallsBackBase64(t *testing.T) {
	got := encodeHeaderValue("【x】", "unknown-value", "UTF-8")
	if !strings.HasPrefix(got, "=?UTF-8?B?") {
		t.Errorf("未知 encoding 应 fallback base64,got=%q", got)
	}
}

// ============================================================================
// D-018:formatAddressWithName
// ============================================================================

func TestFormatAddressWithName_EmptyName(t *testing.T) {
	got := formatAddressWithName("", "a@b.com", "base64", "UTF-8")
	if got != "a@b.com" {
		t.Errorf("空 name 应只返回 addr,got=%q", got)
	}
}

func TestFormatAddressWithName_ASCIIName(t *testing.T) {
	got := formatAddressWithName("John Doe", "a@b.com", "base64", "UTF-8")
	want := `"John Doe" <a@b.com>`
	if got != want {
		t.Errorf("got=%q want=%q", got, want)
	}
}

func TestFormatAddressWithName_NonASCIIName_Encoded(t *testing.T) {
	got := formatAddressWithName("山田太郎", "a@b.com", "base64", "UTF-8")
	if !strings.Contains(got, "=?UTF-8?B?") {
		t.Errorf("非 ASCII name 应 base64 编码,got=%q", got)
	}
	if !strings.HasSuffix(got, "<a@b.com>") {
		t.Errorf("应以 <addr> 结尾,got=%q", got)
	}
}

// ============================================================================
// D-019:effectiveTimezone
// ============================================================================

func TestEffectiveTimezone_Empty_ReturnsLocal(t *testing.T) {
	if got := effectiveTimezone(""); got != time.Local {
		t.Errorf("空 tz 应 time.Local,got=%v", got)
	}
}

func TestEffectiveTimezone_ValidIANA(t *testing.T) {
	got := effectiveTimezone("Asia/Tokyo")
	if got.String() != "Asia/Tokyo" {
		t.Errorf("got=%v want=Asia/Tokyo", got)
	}
}

func TestEffectiveTimezone_UTC(t *testing.T) {
	got := effectiveTimezone("UTC")
	if got.String() != "UTC" {
		t.Errorf("got=%v want=UTC", got)
	}
}

func TestEffectiveTimezone_Invalid_FallsBackLocal(t *testing.T) {
	got := effectiveTimezone("Invalid/Zone/Name")
	if got != time.Local {
		t.Errorf("非法 tz 应 fallback Local,got=%v", got)
	}
}

// ============================================================================
// D-020:pickMessageIDStyle
// ============================================================================

func TestPickMessageIDStyle_RandomAll(t *testing.T) {
	rng := random.NewFixedSource(42)
	// randomAll=true 应从 25 池抽
	got := pickMessageIDStyle(true, nil, rng)
	if got == "" {
		t.Error("空 style key")
	}
	// 应在 25 风格之一(用 messageid.keys 里的池校验)
}

func TestPickMessageIDStyle_UserStyles(t *testing.T) {
	rng := random.NewFixedSource(42)
	styles := []string{"uuid_seq", "uuid_v4_lower"}
	got := pickMessageIDStyle(false, styles, rng)
	if got != "uuid_seq" && got != "uuid_v4_lower" {
		t.Errorf("应在用户 list 内,got=%q", got)
	}
}

func TestPickMessageIDStyle_UserStyles_SingleItem(t *testing.T) {
	rng := random.NewFixedSource(42)
	got := pickMessageIDStyle(false, []string{"uuid_seq"}, rng)
	if got != "uuid_seq" {
		t.Errorf("got=%q", got)
	}
}

func TestPickMessageIDStyle_BothEmpty_Fallback(t *testing.T) {
	// 【M2 修 2026-08-13】两者都空 → 走全池随机(v1 兜底行为),而非 hardcode uuid_v4_lower
	// 只有 pool 加载失败(几乎不可能)才最终 fallback。
	rng := random.NewFixedSource(42)
	got := pickMessageIDStyle(false, nil, rng)
	if got == "" {
		t.Fatal("got 空串")
	}
	// 应该是 pool 里的合法 key(any 25 种之一)
	pool, err := data.MessageIDStyleKeysPool.Get()
	if err != nil {
		t.Fatalf("pool.Get: %v", err)
	}
	valid := make(map[string]bool, len(pool))
	for _, k := range pool {
		valid[k] = true
	}
	if !valid[got] {
		t.Errorf("got=%q 不在 25 风格池", got)
	}
}

// ============================================================================
// D-019 集成:Date 头带时区
// ============================================================================

func TestBuild_Date_UsesConfigTimezone(t *testing.T) {
	// 建 Builder 用 UTC clock,cfg.Sender.Timezone=Asia/Tokyo → Date 头应 +0900
	b := newTestBuilder(42) // fixedTestTime = 2026-08-07 15:30:45 UTC
	b.cfg.Sender.Timezone = "Asia/Tokyo"

	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, err := b.Build(rcpt)
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	// UTC 15:30:45 + 9h = JST 00:30:45 next day → 期望 "Sat, 08 Aug 2026 00:30:45 +0900"
	if !strings.Contains(email.RawContent, "+0900") {
		t.Errorf("Date 头应含 +0900 时区,raw:\n%s", email.RawContent)
	}
}

func TestBuild_Date_DefaultLocal(t *testing.T) {
	b := newTestBuilder(42)
	// 不设 Timezone → time.Local(测试机时区)
	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	// 只验证有 Date 头且有时区标记(±HHMM),不断言具体值(依赖运行机时区)
	if !strings.Contains(email.RawContent, "Date: ") {
		t.Error("缺 Date 头")
	}
}

// ============================================================================
// D-016 集成:From 头非 ASCII 编码 + BidiReverse
// ============================================================================

func TestBuild_From_NonASCIIName_EncodedBase64(t *testing.T) {
	b := newTestBuilder(42)
	b.cfg.Sender.FromName = "山田太郎"
	b.cfg.Encoding.HeaderEncoding = "base64"

	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	// encoded-word 不加 quotes(v1 email/builder.go 一致的 name-addr 格式)
	if !strings.Contains(email.RawContent, "From: =?UTF-8?B?") {
		t.Errorf("From 名应 base64 编码(不带 quotes,v1 一致),raw:\n%s", email.RawContent)
	}
	if !strings.Contains(email.RawContent, "?= <sender@example.com>") {
		t.Errorf("From 结构应 encoded <addr>(v1 一致,encoded-word 后直接 <addr>)")
	}
}

// ============================================================================
// D-017 集成:Subject 编码
// ============================================================================

func TestBuild_Subject_NonASCII_EncodedBase64(t *testing.T) {
	b := newTestBuilder(42)
	b.cfg.Encoding.HeaderEncoding = "base64"

	rcpt := &Recipient{Email: "u@x.com", Subject: "【重要】通知", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	if !strings.Contains(email.RawContent, "Subject: =?UTF-8?B?") {
		t.Errorf("Subject 应 base64 编码,raw:\n%s", email.RawContent)
	}
}

// ============================================================================
// D-020 集成:Message-ID style 来自 cfg
// ============================================================================

func TestBuild_MessageID_UsesCfgStyle(t *testing.T) {
	b := newTestBuilder(42)
	b.cfg.Headers.MessageIDStyles = []string{"uuid_seq"}
	b.cfg.Headers.MessageIDRandomAll = false

	rcpt := &Recipient{Email: "u@x.com", Subject: "s", HTMLBody: "b"}
	email, _ := b.Build(rcpt)
	// uuid_seq 格式:20YYMMDDTHHMMSS-uuid-000001@domain 类
	// 只验证 MessageID 非空且不是 uuid_v4_lower 格式(uuid_v4 是 8-4-4-4-12 hex)
	if email.MessageID == "" {
		t.Fatal("MessageID 空")
	}
	// uuid_v4_lower 全 hex + 4 段短横 8-4-4-4-12,uuid_seq 会包含 timestamp 结构
	// 简易判断:uuid_seq 通常长度 > 40,uuid_v4 是 36
	if len(email.MessageID) < 20 {
		t.Errorf("MessageID 太短:%q", email.MessageID)
	}
}
