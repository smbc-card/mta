package mime

import "sync"

// ============================================================================
// AttachmentCache 具体实现(D22-4 附件 SHA256 缓存)
// ============================================================================
//
// 【接口 vs 实现】接口 AttachmentCache 在 builder.go 定义;此处提供两个实现:
//   - syncMapCache(生产用):sync.Map 并发安全 KV 存储
//   - 【测试】直接传 nil,或用 syncMapCache;不额外提供 noop 类型(nil 即 noop)

// syncMapCache 基于 sync.Map 的线程安全实现
//
// 【D22-3 race 修复】v1 用 `map[string]*Attachment` + 无锁访问 → 并发写 panic;
// v2 用 sync.Map 保证线程安全(生产多 worker 共享)
//
// 【适用场景】多 worker 共享附件(同一批次内多封邮件用同一批附件文件)
// 【非适用场景】per-worker 独立缓存 —— 每 worker 直接 new syncMapCache 也行,与 nil 相当
type syncMapCache struct {
	m sync.Map
}

// NewSyncMapCache 创建基于 sync.Map 的线程安全 AttachmentCache 实现
//
// 【生产用】多 worker 共享此 cache,可跨 worker 复用附件字节(避免重复读盘)
// 【测试用】直接传 nil 到 New(rng, nil)—— 效果等价"不缓存"
func NewSyncMapCache() AttachmentCache {
	return &syncMapCache{}
}

// Get 查缓存(命中返回 data 和 true;未命中返回 nil 和 false)
func (c *syncMapCache) Get(key string) ([]byte, bool) {
	v, ok := c.m.Load(key)
	if !ok {
		return nil, false
	}
	data, ok := v.([]byte)
	if !ok {
		// 类型异常(理论不到达 —— Set 严格控制类型)
		return nil, false
	}
	return data, true
}

// Set 写缓存(线程安全,多 worker 可同时调用)
func (c *syncMapCache) Set(key string, data []byte) {
	c.m.Store(key, data)
}
