package mime

import (
	"encoding/base64"
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/mail/encoding"
)

// encodeFilename H3:附件 filename 若含非 ASCII 走 RFC 2047 encoded-word,防 8-bit header
//
// 【行为】
//   - 纯 ASCII → 原样(与 v1 encodeRFC2047 needsEncoding=false 分支一致)
//   - 含非 ASCII + headerEnc="quoted-printable"/"qp"/"q" → =?charset?Q?..?=
//   - 其他(默认 base64) → =?charset?B?..?=
//
// 【charset 兜底】空 → "UTF-8"
func encodeFilename(name, headerEnc, charset string) string {
	if name == "" {
		return ""
	}
	if charset == "" {
		charset = "UTF-8"
	}
	switch strings.ToLower(strings.TrimSpace(headerEnc)) {
	case "quoted-printable", "qp", "q":
		return encoding.EncodeHeaderQP(name, charset)
	default:
		return encoding.EncodeHeaderBase64(name, charset)
	}
}

// ============================================================================
// 附件 part 生成(普通附件 + CID 内嵌图)
// v1 email/builder.go::writeAttachments 闭包(625-647 行)
// v1 email/builder.go::writeEmbeddedImages 闭包(689-712 行)
// ============================================================================

// buildAttachmentPart 生成单个普通附件 part(base64 编码 + Content-Disposition: attachment)
//
// 【契约】v2 与 v1 writeAttachments 单条循环体语义一致
//
// 【结构】
//
//	--{boundary}
//	Content-Type: {mimeType}; name="{filename}"
//	Content-Transfer-Encoding: base64
//	Content-Disposition: attachment; filename="{filename}"
//	<空行>
//	{base64 编码内容,76 字符/行折}
//
// 【返回】不含末尾结束边界(结束边界 --{boundary}-- 由调用方追加)
//
// 【注意】图像噪声不在此包处理(D16-1 不 import obfuscate);
// 调用方 render.Builder 在传 Attachment 前先做 AddImageNoise,再传入本函数
//
// 【H3 修 2026-08-13】filename 若含非 ASCII 走 RFC 2047 encoded-word;不再原样 8-bit 输出
func buildAttachmentPart(boundary string, att Attachment, headerEnc, charset string) string {
	var sb strings.Builder

	encodedName := encodeFilename(att.FileName, headerEnc, charset)

	sb.WriteString(fmt.Sprintf("--%s\r\n", boundary))
	sb.WriteString(fmt.Sprintf("Content-Type: %s; name=\"%s\"\r\n", att.MIMEType, encodedName))
	sb.WriteString("Content-Transfer-Encoding: base64\r\n")
	sb.WriteString(fmt.Sprintf("Content-Disposition: attachment; filename=\"%s\"\r\n", encodedName))
	sb.WriteString("\r\n")

	// base64 编码 + 76 字符/行折(与 v1 一致)
	encoded := base64.StdEncoding.EncodeToString(att.Data)
	for i := 0; i < len(encoded); i += 76 {
		end := i + 76
		if end > len(encoded) {
			end = len(encoded)
		}
		sb.WriteString(encoded[i:end])
		sb.WriteString("\r\n")
	}

	return sb.String()
}

// buildEmbeddedImagePart 生成单个 CID 内嵌图 part
//
// 【契约】v2 与 v1 writeEmbeddedImages 单条循环体语义一致
//
// 【结构】
//
//	--{boundary}
//	Content-Type: {mimeType}; name="{filename}"
//	Content-ID: <{cid}>
//	Content-Transfer-Encoding: base64
//	Content-Disposition: inline; filename="{filename}"
//	<空行>
//	{base64 编码内容,76 字符/行折}
//
// 【差异 vs buildAttachmentPart】
//   - 多一行 Content-ID: <cid>
//   - Content-Disposition 是 inline 而非 attachment
//
// 【CID 引用】HTML body 里 <img src="cid:{cid}"> 引用
//
// 【R4 修 2026-08-14】filename 若含非 ASCII 走 RFC 2047 encoded-word 编码(与
// buildAttachmentPart 一致 —— H3 修当时漏了本函数)
func buildEmbeddedImagePart(boundary string, img Attachment, headerEnc, charset string) string {
	var sb strings.Builder

	encodedName := encodeFilename(img.FileName, headerEnc, charset)

	sb.WriteString(fmt.Sprintf("--%s\r\n", boundary))
	sb.WriteString(fmt.Sprintf("Content-Type: %s; name=\"%s\"\r\n", img.MIMEType, encodedName))
	sb.WriteString(fmt.Sprintf("Content-ID: <%s>\r\n", img.ContentID))
	sb.WriteString("Content-Transfer-Encoding: base64\r\n")
	sb.WriteString(fmt.Sprintf("Content-Disposition: inline; filename=\"%s\"\r\n", encodedName))
	sb.WriteString("\r\n")

	encoded := base64.StdEncoding.EncodeToString(img.Data)
	for i := 0; i < len(encoded); i += 76 {
		end := i + 76
		if end > len(encoded) {
			end = len(encoded)
		}
		sb.WriteString(encoded[i:end])
		sb.WriteString("\r\n")
	}

	return sb.String()
}
