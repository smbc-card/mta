package mime

import (
	"encoding/hex"
	"fmt"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// ============================================================================
// boundary 生成 —— 6 种真实客户端风格 + 冲突兜底检测(D22-5)
// v1 email/builder.go::boundaryStyles + generateBoundary
// ============================================================================

// boundaryStyles 6 种客户端风格 boundary 生成器
//
// 【契约】v2 与 v1 email/builder.go::boundaryStyles 语义一致
// (v1 用包级 rand + closure,v2 改注入 rng 参数)
//
// 【设计动机】不同邮件客户端的 boundary 格式差异显著,反垃圾 ML 模型对 boundary 敏感
// 【6 风格】Outlook / Apple Mail / Gmail / Postfix / Thunderbird / PHPMailer
// 【独立选择】同封邮件的 Alt/Rel/Mixed 三个 boundary 各自独立调用 —— 风格可能不同
// (与真实邮件经过多 MTA 重打包时各用自己风格的现象一致)
var boundaryStyles = []func(rng random.Source) string{
	// Outlook: ----=_NextPart_000_{4-hex}_01D{5-hex}.{8-hex} 全大写
	func(rng random.Source) string {
		return fmt.Sprintf("----=_NextPart_000_%s_01D%s.%s",
			strings.ToUpper(randomHex(rng, 4)),
			strings.ToUpper(randomHex(rng, 5)),
			strings.ToUpper(randomHex(rng, 8)))
	},
	// Apple Mail: Apple-Mail=_{UUID 大写 v4}
	func(rng random.Source) string {
		return fmt.Sprintf("Apple-Mail=_%s", strings.ToUpper(uuidV4(rng)))
	},
	// Gmail: 30 位 hex(前 14 位 0,后 16 位随机)
	func(rng random.Source) string {
		return fmt.Sprintf("00000000000000%s", randomHex(rng, 16))
	},
	// Postfix: {8-hex}.{8-hex}(紧凑形式)
	func(rng random.Source) string {
		return fmt.Sprintf("%s.%s", randomHex(rng, 8), randomHex(rng, 8))
	},
	// Thunderbird: ------------{24-hex 小写}
	func(rng random.Source) string {
		return fmt.Sprintf("------------%s", randomHex(rng, 24))
	},
	// PHPMailer: b1_{32-hex}
	func(rng random.Source) string {
		return fmt.Sprintf("b1_%s", randomHex(rng, 32))
	},
}

// GenerateBoundary 生成 MIME boundary(6 风格随机选一,含冲突兜底检测)
//
// 【契约】v2 与 v1 email/builder.go::generateBoundary 语义一致(风格池不变)
//
// 【D22-5 冲突兜底】body 中若出现 "\n--<candidate>",MIME 解析会错误分段;
// 最多重试 10 次;超过则接受最后一次(实际不会到达 —— 6 风格 × rng 组合冲突概率 ≈ 0)
//
// 【prefix 参数】v1 有 prefix 参数但内部忽略(`_ = prefix`),v2 沿用 —— 保签名兼容
func (b *Builder) GenerateBoundary(prefix string, bodyForConflictCheck string) string {
	_ = prefix // v1 一致:参数保留但不使用

	for retry := 0; retry < 10; retry++ {
		candidate := boundaryStyles[b.rng.Intn(len(boundaryStyles))](b.rng)
		// D22-5:检查 body 中是否已存在 "\n--<candidate>"(MIME 解析边界的完整前缀)
		if !strings.Contains(bodyForConflictCheck, "\n--"+candidate) {
			return candidate
		}
	}
	// 极端:10 次都冲突 → 接受最后一次(几乎不可能;若发生则由外层排查)
	return boundaryStyles[0](b.rng)
}

// ============================================================================
// helper —— 与其他子包各自维护一份(D16-1 决策:不 import 其他子包)
// ============================================================================

// randomHex 生成 n 位十六进制字符串(小写)
func randomHex(rng random.Source, n int) string {
	if n <= 0 {
		return ""
	}
	nBytes := (n + 1) / 2
	b := make([]byte, nBytes)
	_, _ = rng.Read(b)
	h := hex.EncodeToString(b)
	if len(h) > n {
		h = h[:n]
	}
	return h
}

// uuidV4 生成 RFC 4122 v4 UUID(小写);v1 用 utils.GenerateUUID(),v2 各包各写一份
func uuidV4(rng random.Source) string {
	var b [16]byte
	_, _ = rng.Read(b[:])
	b[6] = (b[6] & 0x0f) | 0x40 // version 4
	b[8] = (b[8] & 0x3f) | 0x80 // variant 10xx
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x",
		b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}
