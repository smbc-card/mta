// Package mime 邮件 MIME 编码器(3 分支矩阵:纯文本 / HTML / multipart)
//
// 【3 分支矩阵】(v1 email/builder.go::buildRawEmail 内散在的 MIME 逻辑抽出)
//   - 纯文本(text_plain.go):Content-Type: text/plain;charset=... + 单 body
//   - HTML(html.go):Content-Type: text/html;charset=... + 可选 alternative text
//   - multipart(multipart.go):multipart/mixed + multipart/alternative + 附件
//
// 【分支决策】(builder.go::BuildMIME 主入口)
//   - 无附件 + 仅 text → text_plain 分支
//   - 无附件 + 仅 html(可选 alt text)→ html 分支(html-only 或 multipart/alternative)
//   - 有附件 → multipart/mixed 分支(内含 multipart/alternative + 附件)
//
// 【boundary 生成】(boundary.go)
//   - 8 字节随机 hex(v1 一致)
//   - **D22-5 兜底冲突检测**:极端概率下 boundary 在 body 中出现 → 重生成一次
//
// 【D22-6 body 编码规则】
//   - 纯 ASCII body(所有字节 <128 且无独立 CR/LF)→ 7bit
//   - 含非 ASCII 且短行(平均 <70 字符)→ QP(quoted-printable)
//   - 含非 ASCII 且长行或大量 binary → base64
//   - 编码走 mail/encoding 包(Day 13 已实现)
//
// 【D22-3 race 修复】v1 boundary 生成用 crypto/rand(线程安全,但每次新分配);
// v2 走注入 rng.Source(可复现 + 无重复分配)
//
// 【D22-4 附件 cache】(multipart.go)
//   - 可选注入 sync.Map cache(New 时传;nil 表示不缓存)
//   - 生产用:每 worker 一个 cache 或全局共享(builder 决定)
//   - 测试用:传 nil 保测试隔离
//
// 【依赖】random.Source + mail/encoding 包(Day 13 完成)
package mime
