package mime

import (
	"fmt"
	"strings"
)

// ============================================================================
// multipart/mixed(顶层附件外壳)+ multipart/related(内嵌图外壳)
// v1 email/builder.go::752-767(mixed 分支)+ 715-742(writeContentBlock)
// ============================================================================

// buildMultipartMixed 生成 multipart/mixed(有附件或 full 模式)
//
// 【契约】v2 与 v1 email/builder.go::buildRawEmail 分支 1(752-767 行)语义一致
//
// 【结构】
//
//	Content-Type: multipart/mixed; boundary="{Mixed}"
//	<空行>
//	--{Mixed}
//	{contentBlock}(可能是 related/alternative/单体)
//	{attachment 1}
//	{attachment 2}
//	...
//	--{Mixed}--
//
// 【嵌套】contentBlock 由 buildContentBlock 生成(内部按 hasEmbeddedImages / useAlternative 决策)
func (b *Builder) buildMultipartMixed(params BuildParams) (BuildResult, error) {
	// 先生成 contentBlock(可能是 related 包 body,或直接 alternative/单体)
	contentBlock, err := b.buildContentBlock(params)
	if err != nil {
		return BuildResult{}, err
	}

	// 拼接所有附件字节用于 boundary 冲突检测
	var conflictCheck strings.Builder
	conflictCheck.WriteString(params.HTMLBody)
	conflictCheck.WriteString(params.TextBody)
	conflictCheck.WriteString(contentBlock)
	for _, att := range params.Attachments {
		conflictCheck.Write(att.Data)
	}
	mixedBoundary := b.GenerateBoundary("Mixed", conflictCheck.String())

	var body strings.Builder

	// 【H4 修 2026-08-13】不再写"首行空行":header/body 分隔由 render/builder.go:401
	// 独家负责("\r\n" 一次);mime 层只负责 body(以 --boundary 起头)
	//
	// 内容块开头边界
	body.WriteString(fmt.Sprintf("--%s\r\n", mixedBoundary))
	body.WriteString(contentBlock)
	// contentBlock 末尾无 \r\n 时补一个(为下一个边界预留)
	if !strings.HasSuffix(contentBlock, "\r\n") {
		body.WriteString("\r\n")
	}

	// 附件们(H3:filename 走 RFC2047 编码)
	for _, att := range params.Attachments {
		body.WriteString(buildAttachmentPart(mixedBoundary, att, params.HeaderEncoding, params.Charset))
	}

	// 结束边界
	body.WriteString(fmt.Sprintf("--%s--\r\n", mixedBoundary))

	return BuildResult{
		ContentTypeHeader: fmt.Sprintf("Content-Type: multipart/mixed; boundary=\"%s\"\r\n", mixedBoundary),
		EncodingHeader:    "", // multipart 无顶层 encoding
		Body:              body.String(),
	}, nil
}

// buildMultipartRelated 生成 multipart/related(有内嵌图,无附件,非 full 模式)
//
// 【契约】v2 与 v1 email/builder.go::writeContentBlock 有内嵌图分支(717-734 行)语义一致
//
// 【结构】
//
//	Content-Type: multipart/related; boundary="{Rel}"
//	<空行>
//	--{Rel}
//	{innerBody}(alternative 或单体)
//	{cid image 1}
//	{cid image 2}
//	...
//	--{Rel}--
//
// 【innerBody 决策】useAlternative → alternative;否则单体
func (b *Builder) buildMultipartRelated(params BuildParams) (BuildResult, error) {
	// 生成内部 body(alternative 或单体)
	var innerContentType, innerEncoding, innerBody string
	if params.MimeMode == "alternative" || params.MimeMode == "full" {
		alt, err := b.buildAlternative(params)
		if err != nil {
			return BuildResult{}, err
		}
		innerContentType = alt.ContentTypeHeader
		innerEncoding = alt.EncodingHeader // 空(multipart 无顶层 encoding)
		innerBody = alt.Body
	} else {
		single, err := b.buildSingleBody(params)
		if err != nil {
			return BuildResult{}, err
		}
		innerContentType = single.ContentTypeHeader
		innerEncoding = single.EncodingHeader
		innerBody = single.Body
	}

	// boundary 冲突检测
	var conflictCheck strings.Builder
	conflictCheck.WriteString(params.HTMLBody)
	conflictCheck.WriteString(params.TextBody)
	conflictCheck.WriteString(innerBody)
	for _, img := range params.EmbeddedImgs {
		conflictCheck.Write(img.Data)
	}
	relBoundary := b.GenerateBoundary("Rel", conflictCheck.String())

	var body strings.Builder

	// 【H4 修 2026-08-13】不再写"首行空行"(同 buildMultipartMixed 注释)
	//
	// 内部 body 部分
	// 【R1 修 2026-08-14】innerContentType/innerEncoding 与 innerBody 之间必须空行
	// (同 buildContentBlock 修复原因;RFC 2046 §5.1.1)
	body.WriteString(fmt.Sprintf("--%s\r\n", relBoundary))
	body.WriteString(innerContentType)
	if innerEncoding != "" {
		body.WriteString(innerEncoding)
	}
	body.WriteString("\r\n") // header/body 分隔
	body.WriteString(innerBody)
	if !strings.HasSuffix(innerBody, "\r\n") {
		body.WriteString("\r\n")
	}

	// CID 图片们
	for _, img := range params.EmbeddedImgs {
		body.WriteString(buildEmbeddedImagePart(relBoundary, img, params.HeaderEncoding, params.Charset))
	}

	// 结束边界
	body.WriteString(fmt.Sprintf("--%s--\r\n", relBoundary))

	return BuildResult{
		ContentTypeHeader: fmt.Sprintf("Content-Type: multipart/related; boundary=\"%s\"\r\n", relBoundary),
		EncodingHeader:    "",
		Body:              body.String(),
	}, nil
}

// buildContentBlock 生成"内容块"—— 供 buildMultipartMixed 内部调用
//
// 【契约】v2 与 v1 email/builder.go::writeContentBlock 闭包(717-742 行)语义一致
//
// 【决策】
//   - hasEmbeddedImages → 走 buildMultipartRelated(内部再决策 alternative/单体)
//   - 否则 → 直接 alternative 或单体
//
// 【返回】拼装好的字符串(Content-Type header + encoding header + body 一体)
//
// 【用途】buildMultipartMixed 需要"完整的内容块串"塞进 --{Mixed} 之后;
// 而 BuildMIME 顶层调用时,ContentType/Encoding 是独立返回的 —— 所以 buildContentBlock
// 内部把三段拼成一串,与 BuildResult 分开
func (b *Builder) buildContentBlock(params BuildParams) (string, error) {
	// 【R1 修 2026-08-14】嵌套部件 header/body 之间必须空行(RFC 2046 §5.1.1);
	// H4 修(2026-08-13)误把这一行 CRLF 也删了,导致 mixed → nested multipart 被
	// Go stdlib mime/multipart 判 "malformed MIME header: missing colon"。
	// top-level 分隔由 render/builder.go:401 独家负责,不影响此处

	// 有内嵌图 → related 包裹(内部再走 alternative/单体)
	if len(params.EmbeddedImgs) > 0 {
		rel, err := b.buildMultipartRelated(paramsWithoutAttachments(params))
		if err != nil {
			return "", err
		}
		return rel.ContentTypeHeader + rel.EncodingHeader + "\r\n" + rel.Body, nil
	}

	// 无内嵌图 → alternative 或单体
	useAlternative := params.MimeMode == "alternative" || params.MimeMode == "full"
	if useAlternative {
		alt, err := b.buildAlternative(params)
		if err != nil {
			return "", err
		}
		return alt.ContentTypeHeader + alt.EncodingHeader + "\r\n" + alt.Body, nil
	}
	single, err := b.buildSingleBody(params)
	if err != nil {
		return "", err
	}
	return single.ContentTypeHeader + single.EncodingHeader + "\r\n" + single.Body, nil
}

// paramsWithoutAttachments 返回一个新 params(移除 Attachments,保留其他字段)
//
// 【用途】buildContentBlock 调 buildMultipartRelated 时,要防止 related 再走 mixed 分支
// (递归归属需要区分层次:mixed 外层管附件,related 内层管内嵌图)
func paramsWithoutAttachments(p BuildParams) BuildParams {
	p.Attachments = nil
	return p
}
