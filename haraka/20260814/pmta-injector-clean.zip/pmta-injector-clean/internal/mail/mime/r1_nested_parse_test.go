package mime

// R1【CRITICAL】回归测试 —— H4 修 (2026-08-13) 误删嵌套 multipart 分隔空行
// (2026-08-14 R1 修复) 用 Go stdlib mime/multipart.NewReader 反解 BuildMIME 输出,
// 确保生成的 raw body 严格 RFC 2046 §5.1.1 合规

import (
	"io"
	"mime"
	"mime/multipart"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// stdlibParse 用 Go stdlib 反解 BuildMIME 输出 —— 只要底层 MIME 结构非法这里就 fail
//
// 【为什么用 stdlib】mime/multipart.NewReader 严格按 RFC 2046 判定:
//   - 部件 header/body 之间必须有空行(§5.1.1)
//   - boundary 前必须换行
//   - 每部件的 header 必须 name: value 格式
// 这些是 SpamAssassin/Postfix strict 会同等严格检查的
func stdlibParse(t *testing.T, ctHeader, body string) []string {
	t.Helper()
	// 直接用 multipart.NewReader,ContentType 里挖 boundary
	// (ctHeader 形如 "Content-Type: multipart/mixed; boundary=\"XX\"\r\n")
	// 去掉 header 名前缀
	value := strings.TrimSuffix(strings.TrimPrefix(ctHeader, "Content-Type: "), "\r\n")
	mediaType, params, err := mime.ParseMediaType(value)
	if err != nil {
		t.Fatalf("mime.ParseMediaType: %v; ctHeader=%q", err, ctHeader)
	}
	if !strings.HasPrefix(mediaType, "multipart/") {
		t.Fatalf("expect multipart/*, got %q", mediaType)
	}
	boundary := params["boundary"]
	if boundary == "" {
		t.Fatalf("missing boundary in %q", value)
	}

	// body 里去掉前导 raw header 部分 —— 我们 ctHeader 只有一个头,已 concat 到 body
	// 实际 body 从 --boundary 开始
	mr := multipart.NewReader(strings.NewReader(body), boundary)
	var parts []string
	for i := 0; ; i++ {
		p, err := mr.NextPart()
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatalf("outer NextPart[%d]: %v\n--- body head ---\n%s\n---", i, err, headSnippet(body, 500))
		}
		payload, _ := io.ReadAll(p)
		partsInner := []string{p.Header.Get("Content-Type")}
		if strings.HasPrefix(p.Header.Get("Content-Type"), "multipart/") {
			// 嵌套 —— 递归
			innerMt, innerParams, err := mime.ParseMediaType(p.Header.Get("Content-Type"))
			if err != nil {
				t.Fatalf("inner ParseMediaType: %v", err)
			}
			_ = innerMt
			mr2 := multipart.NewReader(strings.NewReader(string(payload)), innerParams["boundary"])
			for j := 0; ; j++ {
				p2, err := mr2.NextPart()
				if err == io.EOF {
					break
				}
				if err != nil {
					t.Fatalf("inner NextPart[%d.%d]: %v", i, j, err)
				}
				partsInner = append(partsInner, "→"+p2.Header.Get("Content-Type"))
				_, _ = io.ReadAll(p2)
			}
		}
		parts = append(parts, strings.Join(partsInner, "|"))
	}
	return parts
}

func headSnippet(s string, n int) string {
	if len(s) > n {
		return s[:n] + "...(truncated)"
	}
	return s
}

// TestR1_MixedAlternative_ParsesWithStdlib —— mime_mode=alternative + 附件
// 触发 buildMultipartMixed → buildContentBlock → buildAlternative 嵌套
// H4 修破坏了 inner header/body 分隔,R1 修复;此 test 防未来回归
func TestR1_MixedAlternative_ParsesWithStdlib(t *testing.T) {
	b := New(random.NewFixedSource(42), nil)
	params := BuildParams{
		TextBody:       "plain fallback",
		HTMLBody:       "<p>html body</p>",
		Charset:        "UTF-8",
		Encoding:       "7bit",
		HeaderEncoding: "base64",
		MimeMode:       "alternative",
		Attachments: []Attachment{
			{FileName: "a.bin", MIMEType: "application/octet-stream", Data: []byte("data")},
		},
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("BuildMIME: %v", err)
	}
	parts := stdlibParse(t, res.ContentTypeHeader, res.Body)
	// 期望:2 个 outer part —— alternative(内含 plain + html) + attachment
	if len(parts) != 2 {
		t.Fatalf("expect 2 outer parts, got %d: %v", len(parts), parts)
	}
	if !strings.HasPrefix(parts[0], "multipart/alternative") {
		t.Errorf("part[0] expect multipart/alternative, got %q", parts[0])
	}
	if !strings.Contains(parts[0], "→text/plain") || !strings.Contains(parts[0], "→text/html") {
		t.Errorf("part[0] expect text/plain + text/html children, got %q", parts[0])
	}
	if !strings.HasPrefix(parts[1], "application/octet-stream") {
		t.Errorf("part[1] expect application/octet-stream, got %q", parts[1])
	}
}

// TestR1_MixedRelated_ParsesWithStdlib —— 内嵌图 + 附件 = mixed → related → single/alt
func TestR1_MixedRelated_ParsesWithStdlib(t *testing.T) {
	b := New(random.NewFixedSource(42), nil)
	params := BuildParams{
		HTMLBody:       `<p><img src="cid:img1"></p>`,
		Charset:        "UTF-8",
		Encoding:       "7bit",
		HeaderEncoding: "base64",
		MimeMode:       "standard",
		Attachments: []Attachment{
			{FileName: "a.bin", MIMEType: "application/octet-stream", Data: []byte("data")},
		},
		EmbeddedImgs: []Attachment{
			{FileName: "logo.png", MIMEType: "image/png", ContentID: "img1", IsInline: true, Data: []byte("fakepng")},
		},
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("BuildMIME: %v", err)
	}
	parts := stdlibParse(t, res.ContentTypeHeader, res.Body)
	if len(parts) != 2 {
		t.Fatalf("expect 2 outer parts (related + attachment), got %d: %v", len(parts), parts)
	}
	if !strings.HasPrefix(parts[0], "multipart/related") {
		t.Errorf("part[0] expect multipart/related, got %q", parts[0])
	}
}

// TestR1_TopLevelAlternative_ParsesWithStdlib —— alternative 顶层(无附件)
func TestR1_TopLevelAlternative_ParsesWithStdlib(t *testing.T) {
	b := New(random.NewFixedSource(42), nil)
	params := BuildParams{
		TextBody: "plain",
		HTMLBody: "<p>html</p>",
		Charset:  "UTF-8",
		Encoding: "7bit",
		MimeMode: "alternative",
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("BuildMIME: %v", err)
	}
	parts := stdlibParse(t, res.ContentTypeHeader, res.Body)
	// 顶层 alternative:2 个 part(plain + html)
	if len(parts) != 2 {
		t.Fatalf("expect 2 parts, got %d: %v", len(parts), parts)
	}
	if !strings.HasPrefix(parts[0], "text/plain") {
		t.Errorf("part[0] expect text/plain, got %q", parts[0])
	}
	if !strings.HasPrefix(parts[1], "text/html") {
		t.Errorf("part[1] expect text/html, got %q", parts[1])
	}
}

// TestR1_MixedSingle_ParsesWithStdlib —— mixed + single body(无 alt/related)
func TestR1_MixedSingle_ParsesWithStdlib(t *testing.T) {
	b := New(random.NewFixedSource(42), nil)
	params := BuildParams{
		HTMLBody: "<p>hi</p>",
		Charset:  "UTF-8",
		Encoding: "7bit",
		MimeMode: "standard",
		Attachments: []Attachment{
			{FileName: "a.bin", MIMEType: "application/octet-stream", Data: []byte("data")},
		},
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("BuildMIME: %v", err)
	}
	parts := stdlibParse(t, res.ContentTypeHeader, res.Body)
	if len(parts) != 2 {
		t.Fatalf("expect 2 parts (html + attachment), got %d: %v", len(parts), parts)
	}
}
