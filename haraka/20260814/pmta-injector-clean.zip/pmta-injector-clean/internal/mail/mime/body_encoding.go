package mime

import (
	"encoding/base64"
	"mime/quotedprintable"
	"strings"

	"__MODULE_PLACEHOLDER__/internal/mail/encoding"
)

// ============================================================================
// body 传输编码 —— base64 / quoted-printable / 7bit / 8bit
// v1 email/builder.go::writeEncodedBody(797-836 行)
// ============================================================================

// writeEncodedBody 按指定编码写入 body
//
// 【契约】v2 与 v1 email/builder.go::writeEncodedBody 语义完全一致
//
// 【A8 修 2026-08-13】body 从 UTF-8 → charset 的字符集转换现在在 writeEncodedBody 内部做
// (之前版本注释说"由 mail/encoding 处理"但 render/mime 全流程都没调,导致
// Content-Type 声明 Shift_JIS 但 body 里塞 UTF-8 字节 → 收件人乱码)
//
// 【4 分支】
//   - "base64"           → charset 转换 → base64 编码 + 76 字符/行折
//   - "quoted-printable" → charset 转换 → QP 编码
//   - "7bit" / "8bit"    → charset 转换 → 原样写入 + NormalizeLineEndings + 末尾 \r\n
//   - 其他              → 兜底走 base64
//
// 【末尾 CRLF】body 末尾若无 \r\n,7bit/8bit 分支会补一个;base64/QP 分支不补(编码结果本身已含)
func writeEncodedBody(sb *strings.Builder, body string, encodingName string, charset string) {
	// 【A8】先做字符集转换(charset 空/UTF-8 → 原样;非 UTF-8 → 转成目标编码字节)
	bodyBytes := encoding.ConvertFromUTF8([]byte(body), charset)

	switch strings.ToLower(encodingName) {
	case "base64":
		encoded := base64.StdEncoding.EncodeToString(bodyBytes)
		for i := 0; i < len(encoded); i += 76 {
			end := i + 76
			if end > len(encoded) {
				end = len(encoded)
			}
			sb.WriteString(encoded[i:end])
			sb.WriteString("\r\n")
		}
	case "quoted-printable":
		var qpBuilder strings.Builder
		writer := quotedprintable.NewWriter(&qpBuilder)
		_, _ = writer.Write(bodyBytes)
		_ = writer.Close()
		sb.WriteString(qpBuilder.String())
	case "7bit", "8bit":
		bodyStr := normalizeLineEndings(string(bodyBytes))
		sb.WriteString(bodyStr)
		if !strings.HasSuffix(bodyStr, "\r\n") {
			sb.WriteString("\r\n")
		}
	default:
		// 兜底走 base64(与 v1 一致)
		encoded := base64.StdEncoding.EncodeToString(bodyBytes)
		for i := 0; i < len(encoded); i += 76 {
			end := i + 76
			if end > len(encoded) {
				end = len(encoded)
			}
			sb.WriteString(encoded[i:end])
			sb.WriteString("\r\n")
		}
	}
}

// normalizeLineEndings 把 \r\n / \r / \n 统一成 \r\n
//
// 【契约】v2 与 v1 email/charset.go::NormalizeLineEndings 语义一致
//
// 【算法】先 \r\n → \n(消除现有 \r\n),再 \r → \n(单 \r 情况),最后 \n → \r\n
func normalizeLineEndings(s string) string {
	s = strings.ReplaceAll(s, "\r\n", "\n")
	s = strings.ReplaceAll(s, "\r", "\n")
	s = strings.ReplaceAll(s, "\n", "\r\n")
	return s
}
