package mime

import (
	"encoding/base64"
	"regexp"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/random"
)

func newTestBuilder(seed int64) *Builder {
	return New(random.NewFixedSource(seed), nil)
}

// ============================================================================
// 契约锁 —— 6 种 boundary 风格
// ============================================================================

func TestBoundaryStylesCount(t *testing.T) {
	if got := len(boundaryStyles); got != 6 {
		t.Fatalf("boundaryStyles 数量偏离契约:got=%d, want=6", got)
	}
}

// ============================================================================
// boundary 生成
// ============================================================================

func TestGenerateBoundary_FormatValid(t *testing.T) {
	b := newTestBuilder(42)
	// 抽 30 次,每次都应匹配至少一种风格
	patterns := []*regexp.Regexp{
		regexp.MustCompile(`^----=_NextPart_000_[0-9A-F]{4}_01D[0-9A-F]{5}\.[0-9A-F]{8}$`),
		regexp.MustCompile(`^Apple-Mail=_[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$`),
		regexp.MustCompile(`^00000000000000[0-9a-f]{16}$`),
		regexp.MustCompile(`^[0-9a-f]{8}\.[0-9a-f]{8}$`),
		regexp.MustCompile(`^------------[0-9a-f]{24}$`),
		regexp.MustCompile(`^b1_[0-9a-f]{32}$`),
	}
	for i := 0; i < 30; i++ {
		bnd := b.GenerateBoundary("", "")
		matched := false
		for _, re := range patterns {
			if re.MatchString(bnd) {
				matched = true
				break
			}
		}
		if !matched {
			t.Errorf("第 %d 次 boundary 不匹配 6 风格之一:%q", i, bnd)
		}
	}
}

func TestGenerateBoundary_ConflictAvoidance(t *testing.T) {
	// 若 body 中已含 "\n--<candidate>",应触发重试
	// 构造一个必然冲突的场景:先生成一个 boundary,再把它塞进 body,再生成一次 → 应不同
	b := newTestBuilder(42)
	first := b.GenerateBoundary("", "")

	// body 里含 "\n--" + first(MIME 边界的完整前缀)
	conflictBody := "some content\n--" + first + "\nmore content"

	// 用新的 rng seed 重新生成,应避开 first(测试 30 次至少大部分不冲突)
	// 注意:因 rng 会推进,所以此测试主要验证冲突检测机制而非严格避开
	// 简化验证:调用不 panic + 返回非空 boundary
	for i := 0; i < 5; i++ {
		bnd := b.GenerateBoundary("", conflictBody)
		if bnd == "" {
			t.Error("boundary 空")
		}
	}
}

// ============================================================================
// body_encoding
// ============================================================================

func TestWriteEncodedBody_Base64(t *testing.T) {
	var sb strings.Builder
	writeEncodedBody(&sb, "Hello World", "base64", "UTF-8")
	got := sb.String()
	// 应是 base64 编码 + 尾部 CRLF
	if !strings.HasSuffix(got, "\r\n") {
		t.Errorf("base64 尾部 CRLF:%q", got)
	}
	// 去掉 CRLF 后应可解码回 "Hello World"
	stripped := strings.TrimRight(got, "\r\n")
	// 可能多行(76 字符/行)
	stripped = strings.ReplaceAll(stripped, "\r\n", "")
	decoded, err := base64.StdEncoding.DecodeString(stripped)
	if err != nil {
		t.Fatalf("base64 解码:%v", err)
	}
	if string(decoded) != "Hello World" {
		t.Errorf("解码结果:%q", decoded)
	}
}

func TestWriteEncodedBody_Base64_LineFolding(t *testing.T) {
	// 长 body 应折成 76 字符/行
	longBody := strings.Repeat("a", 200) // 200 字符 → base64 ~268 字符 → 4 行
	var sb strings.Builder
	writeEncodedBody(&sb, longBody, "base64", "UTF-8")
	got := sb.String()
	// 每行(去尾部 \r\n 后)≤ 76 字符
	lines := strings.Split(strings.TrimRight(got, "\r\n"), "\r\n")
	for i, line := range lines {
		if len(line) > 76 {
			t.Errorf("第 %d 行 %d > 76", i, len(line))
		}
	}
}

func TestWriteEncodedBody_QuotedPrintable(t *testing.T) {
	var sb strings.Builder
	writeEncodedBody(&sb, "Hello=World", "quoted-printable", "UTF-8")
	got := sb.String()
	// = 应被 QP 编码为 =3D
	if !strings.Contains(got, "=3D") {
		t.Errorf("QP 编码 = 应为 =3D:%q", got)
	}
}

func TestWriteEncodedBody_7Bit(t *testing.T) {
	var sb strings.Builder
	writeEncodedBody(&sb, "Hello\nWorld", "7bit", "UTF-8")
	got := sb.String()
	// \n 应变 \r\n
	if !strings.Contains(got, "Hello\r\nWorld") {
		t.Errorf("7bit 换行归一化:%q", got)
	}
	// 尾部 CRLF
	if !strings.HasSuffix(got, "\r\n") {
		t.Errorf("7bit 尾部 CRLF")
	}
}

func TestWriteEncodedBody_DefaultToBase64(t *testing.T) {
	// 未知 encoding 应兜底走 base64
	var sb strings.Builder
	writeEncodedBody(&sb, "Hello", "unknown-encoding", "UTF-8")
	got := sb.String()
	// 应可 base64 解码
	stripped := strings.ReplaceAll(strings.TrimRight(got, "\r\n"), "\r\n", "")
	if _, err := base64.StdEncoding.DecodeString(stripped); err != nil {
		t.Errorf("未知 encoding 应 fallback base64:%v", err)
	}
}

func TestNormalizeLineEndings(t *testing.T) {
	cases := []struct{ in, want string }{
		{"a\r\nb", "a\r\nb"},
		{"a\nb", "a\r\nb"},
		{"a\rb", "a\r\nb"},        // 单 \r
		{"a\r\n\nb", "a\r\n\r\nb"}, // 混合
	}
	for _, c := range cases {
		if got := normalizeLineEndings(c.in); got != c.want {
			t.Errorf("normalizeLineEndings(%q):got=%q, want=%q", c.in, got, c.want)
		}
	}
}

// ============================================================================
// IsHTMLContent
// ============================================================================

func TestIsHTMLContent(t *testing.T) {
	cases := []struct {
		in   string
		want bool
	}{
		{"<html><body>x</body></html>", true},
		{"<HTML><BODY>x</BODY></HTML>", true},
		{"<div>x</div>", true},
		{"<p>x</p>", true},
		{"line1<br>line2", true},
		{"plain text no tag", false},
		{"", false},
		{"< incomplete", false},
	}
	for _, c := range cases {
		if got := IsHTMLContent(c.in); got != c.want {
			t.Errorf("IsHTMLContent(%q):got=%v, want=%v", c.in, got, c.want)
		}
	}
}

// ============================================================================
// HTMLToPlainText
// ============================================================================

func TestHTMLToPlainText_Basic(t *testing.T) {
	html := "<p>Hello <b>World</b></p><br>Second line"
	got := HTMLToPlainText(html)
	if !strings.Contains(got, "Hello") || !strings.Contains(got, "World") {
		t.Errorf("转换缺失关键词:%q", got)
	}
	// 无 HTML 标签
	if strings.Contains(got, "<") || strings.Contains(got, ">") {
		t.Errorf("残留 HTML:%q", got)
	}
}

func TestHTMLToPlainText_Link(t *testing.T) {
	got := HTMLToPlainText(`<a href="https://example.com">Click here</a>`)
	if !strings.Contains(got, "Click here (https://example.com)") {
		t.Errorf("链接:%q", got)
	}
}

func TestHTMLToPlainText_Entities(t *testing.T) {
	got := HTMLToPlainText(`&amp; &lt; &gt; &nbsp;end`)
	if !strings.Contains(got, "&") || !strings.Contains(got, "<") || !strings.Contains(got, ">") {
		t.Errorf("实体解码:%q", got)
	}
}

func TestHTMLToPlainText_StyleScriptStripped(t *testing.T) {
	html := `<style>body{color:red}</style>content<script>alert()</script>end`
	got := HTMLToPlainText(html)
	if strings.Contains(got, "color:red") || strings.Contains(got, "alert") {
		t.Errorf("style/script 未清除:%q", got)
	}
	if !strings.Contains(got, "content") || !strings.Contains(got, "end") {
		t.Errorf("正文丢失:%q", got)
	}
}

func TestHTMLToPlainText_ImageAlt(t *testing.T) {
	got := HTMLToPlainText(`<img src="x.jpg" alt="示例图">`)
	if !strings.Contains(got, "[画像: 示例图]") {
		t.Errorf("img alt:%q", got)
	}
}

func TestHTMLToPlainText_MultiNewline(t *testing.T) {
	// 3+ 连续换行 → 最多 2 个
	got := HTMLToPlainText("<p>A</p><p>B</p><p>C</p>")
	// </p> → \n\n × 3 → 应压到 \n\n
	if strings.Contains(got, "\n\n\n") {
		t.Errorf("多余空行未清:%q", got)
	}
}

// ============================================================================
// BuildMIME —— 单体分支(标准模式)
// ============================================================================

func TestBuildMIME_SingleBody_TextPlain(t *testing.T) {
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: "plain text no HTML tag",
		Charset:  "utf-8",
		Encoding: "7bit",
		MimeMode: "standard",
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	// Content-Type text/plain
	if !strings.HasPrefix(res.ContentTypeHeader, "Content-Type: text/plain; charset=\"utf-8\"\r\n") {
		t.Errorf("ContentTypeHeader:%q", res.ContentTypeHeader)
	}
	// Encoding header
	if res.EncodingHeader != "Content-Transfer-Encoding: 7bit\r\n" {
		t.Errorf("EncodingHeader:%q", res.EncodingHeader)
	}
	// Body 应含原文 + CRLF
	if !strings.Contains(res.Body, "plain text no HTML tag") {
		t.Errorf("Body:%q", res.Body)
	}
}

func TestBuildMIME_SingleBody_HTML(t *testing.T) {
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: "<html><body>hello</body></html>",
		Charset:  "utf-8",
		Encoding: "base64",
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	if !strings.Contains(res.ContentTypeHeader, "text/html") {
		t.Errorf("应为 text/html:%q", res.ContentTypeHeader)
	}
}

func TestBuildMIME_SingleBody_EmptyMimeMode_DefaultStandard(t *testing.T) {
	// MimeMode 空 → 视为 standard → 单体分支
	b := newTestBuilder(42)
	params := BuildParams{HTMLBody: "hi", Charset: "utf-8", Encoding: "7bit"}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	if strings.Contains(res.ContentTypeHeader, "multipart") {
		t.Errorf("空 MimeMode 不应走 multipart:%q", res.ContentTypeHeader)
	}
}

// ============================================================================
// BuildMIME —— multipart/alternative 分支
// ============================================================================

func TestBuildMIME_Alternative_Structure(t *testing.T) {
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: "<p>Hello <b>World</b></p>",
		Charset:  "utf-8",
		Encoding: "7bit",
		MimeMode: "alternative",
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	// Content-Type multipart/alternative
	if !strings.HasPrefix(res.ContentTypeHeader, "Content-Type: multipart/alternative; boundary=\"") {
		t.Errorf("ContentTypeHeader:%q", res.ContentTypeHeader)
	}
	// EncodingHeader 应为空(multipart 场景)
	if res.EncodingHeader != "" {
		t.Errorf("multipart EncodingHeader 应空:%q", res.EncodingHeader)
	}
	// Body 应含 text/plain + text/html 两部分
	textPlainCount := strings.Count(res.Body, "Content-Type: text/plain")
	textHtmlCount := strings.Count(res.Body, "Content-Type: text/html")
	if textPlainCount != 1 {
		t.Errorf("text/plain 应恰好 1 次:got=%d", textPlainCount)
	}
	if textHtmlCount != 1 {
		t.Errorf("text/html 应恰好 1 次:got=%d", textHtmlCount)
	}
	// 应含结束边界 (--boundary--)
	if !strings.Contains(res.Body, "--\r\n") {
		t.Errorf("缺结束边界")
	}
}

func TestBuildMIME_Alternative_UsesProvidedTextBody(t *testing.T) {
	// 若 TextBody 非空 → 直接用(不走 HTMLToPlainText)
	b := newTestBuilder(42)
	params := BuildParams{
		TextBody: "CUSTOM-TEXT-FALLBACK",
		HTMLBody: "<html><body>HTML VER</body></html>",
		Charset:  "utf-8",
		Encoding: "7bit",
		MimeMode: "alternative",
	}
	res, _ := b.BuildMIME(params)
	if !strings.Contains(res.Body, "CUSTOM-TEXT-FALLBACK") {
		t.Errorf("应用 params.TextBody:%q", res.Body)
	}
	if !strings.Contains(res.Body, "HTML VER") {
		t.Errorf("应含 HTML:%q", res.Body)
	}
}

func TestBuildMIME_Alternative_AutoConvertToPlainWhenTextBodyEmpty(t *testing.T) {
	// TextBody 空 → HTMLToPlainText 转换
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: "<p>Auto Convert Test</p>",
		Charset:  "utf-8",
		Encoding: "7bit",
		MimeMode: "alternative",
	}
	res, _ := b.BuildMIME(params)
	// text/plain part 应含转换后的文本(去 HTML 标签)
	if !strings.Contains(res.Body, "Auto Convert Test") {
		t.Errorf("plain fallback 未生成:%q", res.Body)
	}
}

// ============================================================================
// BuildMIME —— multipart/mixed 分支(附件)
// ============================================================================

func TestBuildMIME_MultipartMixed_WithAttachment(t *testing.T) {
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: "hello",
		Charset:  "utf-8",
		Encoding: "7bit",
		Attachments: []Attachment{
			{FileName: "a.txt", MIMEType: "text/plain", Data: []byte("attachment content")},
		},
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	// Content-Type multipart/mixed
	if !strings.HasPrefix(res.ContentTypeHeader, "Content-Type: multipart/mixed; boundary=\"") {
		t.Errorf("ContentTypeHeader:%q", res.ContentTypeHeader)
	}
	// Body 应含附件的 Content-Disposition: attachment
	if !strings.Contains(res.Body, "Content-Disposition: attachment; filename=\"a.txt\"") {
		t.Errorf("附件 disposition:\n%s", res.Body)
	}
	// 应含 base64 编码的附件内容
	if !strings.Contains(res.Body, base64.StdEncoding.EncodeToString([]byte("attachment content"))) {
		t.Errorf("附件 base64 内容缺失")
	}
	// 应含结束边界
	if !strings.HasSuffix(res.Body, "--\r\n") {
		t.Errorf("结束边界:%q", res.Body[len(res.Body)-30:])
	}
}

func TestBuildMIME_MultipartMixed_FullMode(t *testing.T) {
	// full 模式即使无附件也强制 multipart/mixed
	b := newTestBuilder(42)
	params := BuildParams{HTMLBody: "hi", Charset: "utf-8", Encoding: "7bit", MimeMode: "full"}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	if !strings.Contains(res.ContentTypeHeader, "multipart/mixed") {
		t.Errorf("full 模式应 mixed:%q", res.ContentTypeHeader)
	}
}

func TestBuildMIME_MultipartMixed_WithAlternative(t *testing.T) {
	// full 模式(强制 mixed)+ alternative 内部(text+html)
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: "<p>html ver</p>",
		TextBody: "text ver",
		Charset:  "utf-8",
		Encoding: "7bit",
		MimeMode: "full",
	}
	res, _ := b.BuildMIME(params)
	// mixed 外层
	if !strings.Contains(res.ContentTypeHeader, "multipart/mixed") {
		t.Errorf("外层 mixed:%q", res.ContentTypeHeader)
	}
	// 内部应含 multipart/alternative
	if !strings.Contains(res.Body, "Content-Type: multipart/alternative") {
		t.Errorf("内部应 alternative:\n%s", res.Body)
	}
	// 应含 text/plain 和 text/html 两 part
	if strings.Count(res.Body, "Content-Type: text/plain") != 1 {
		t.Errorf("text/plain part count")
	}
	if strings.Count(res.Body, "Content-Type: text/html") != 1 {
		t.Errorf("text/html part count")
	}
}

// ============================================================================
// BuildMIME —— multipart/related 分支(内嵌图)
// ============================================================================

func TestBuildMIME_MultipartRelated_WithEmbeddedImage(t *testing.T) {
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: `<html><body><img src="cid:logo"></body></html>`,
		Charset:  "utf-8",
		Encoding: "7bit",
		EmbeddedImgs: []Attachment{
			{FileName: "logo.png", MIMEType: "image/png", ContentID: "logo", Data: []byte("fake png data")},
		},
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	// Content-Type multipart/related
	if !strings.HasPrefix(res.ContentTypeHeader, "Content-Type: multipart/related; boundary=\"") {
		t.Errorf("ContentTypeHeader:%q", res.ContentTypeHeader)
	}
	// 应含 Content-ID: <logo>
	if !strings.Contains(res.Body, "Content-ID: <logo>") {
		t.Errorf("Content-ID 缺失:\n%s", res.Body)
	}
	// 应含 Content-Disposition: inline
	if !strings.Contains(res.Body, "Content-Disposition: inline; filename=\"logo.png\"") {
		t.Errorf("inline disposition:\n%s", res.Body)
	}
	// 应含内部 body(text/html 单体)
	if !strings.Contains(res.Body, "Content-Type: text/html") {
		t.Errorf("内部 body 缺失")
	}
}

func TestBuildMIME_MultipartRelated_WithAlternativeInside(t *testing.T) {
	// alternative + 内嵌图 → related 包 alternative
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: `<p>html <img src="cid:x"></p>`,
		TextBody: "text version",
		Charset:  "utf-8",
		Encoding: "7bit",
		MimeMode: "alternative",
		EmbeddedImgs: []Attachment{
			{FileName: "x.png", MIMEType: "image/png", ContentID: "x", Data: []byte("d")},
		},
	}
	res, _ := b.BuildMIME(params)
	// 外层 related
	if !strings.Contains(res.ContentTypeHeader, "multipart/related") {
		t.Errorf("外层 related:%q", res.ContentTypeHeader)
	}
	// 内部 alternative
	if !strings.Contains(res.Body, "Content-Type: multipart/alternative") {
		t.Errorf("内部 alternative 缺失")
	}
}

// ============================================================================
// BuildMIME —— multipart/mixed + related(附件 + 内嵌图 3 层嵌套)
// ============================================================================

func TestBuildMIME_MixedWithRelatedInside(t *testing.T) {
	// 附件 + 内嵌图 → mixed 外层 + related 内层 + body
	b := newTestBuilder(42)
	params := BuildParams{
		HTMLBody: `<p><img src="cid:x"></p>`,
		Charset:  "utf-8",
		Encoding: "7bit",
		Attachments: []Attachment{
			{FileName: "a.pdf", MIMEType: "application/pdf", Data: []byte("pdf data")},
		},
		EmbeddedImgs: []Attachment{
			{FileName: "x.png", MIMEType: "image/png", ContentID: "x", Data: []byte("png data")},
		},
	}
	res, err := b.BuildMIME(params)
	if err != nil {
		t.Fatalf("err:%v", err)
	}
	// 外层 mixed
	if !strings.Contains(res.ContentTypeHeader, "multipart/mixed") {
		t.Errorf("外层 mixed")
	}
	// 内部 related(内容块被 related 包裹)
	if !strings.Contains(res.Body, "Content-Type: multipart/related") {
		t.Errorf("内层 related 缺失")
	}
	// 附件 disposition
	if !strings.Contains(res.Body, "Content-Disposition: attachment; filename=\"a.pdf\"") {
		t.Errorf("附件 缺失")
	}
	// 内嵌图 disposition
	if !strings.Contains(res.Body, "Content-Disposition: inline; filename=\"x.png\"") {
		t.Errorf("内嵌图 缺失")
	}
}

// ============================================================================
// attachment / embedded image part 单元
// ============================================================================

func TestBuildAttachmentPart_Structure(t *testing.T) {
	att := Attachment{FileName: "doc.pdf", MIMEType: "application/pdf", Data: []byte("PDF")}
	got := buildAttachmentPart("BOUNDARY", att, "base64", "UTF-8")
	// 5 关键子串
	for _, s := range []string{
		"--BOUNDARY\r\n",
		"Content-Type: application/pdf; name=\"doc.pdf\"\r\n",
		"Content-Transfer-Encoding: base64\r\n",
		"Content-Disposition: attachment; filename=\"doc.pdf\"\r\n",
		base64.StdEncoding.EncodeToString([]byte("PDF")),
	} {
		if !strings.Contains(got, s) {
			t.Errorf("缺 %q\n%s", s, got)
		}
	}
}

func TestBuildEmbeddedImagePart_Structure(t *testing.T) {
	img := Attachment{FileName: "img.png", MIMEType: "image/png", ContentID: "cid42", Data: []byte("PNG")}
	got := buildEmbeddedImagePart("BOUNDARY", img, "base64", "UTF-8")
	for _, s := range []string{
		"--BOUNDARY\r\n",
		"Content-Type: image/png; name=\"img.png\"\r\n",
		"Content-ID: <cid42>\r\n",
		"Content-Disposition: inline; filename=\"img.png\"\r\n",
	} {
		if !strings.Contains(got, s) {
			t.Errorf("缺 %q\n%s", s, got)
		}
	}
}

func TestBuildAttachmentPart_LargeData_76CharLines(t *testing.T) {
	// 大 data → base64 折成 76 字符/行
	data := make([]byte, 200)
	for i := range data {
		data[i] = byte(i)
	}
	att := Attachment{FileName: "big.bin", MIMEType: "application/octet-stream", Data: data}
	got := buildAttachmentPart("B", att, "base64", "UTF-8")
	// 找 base64 部分,检查每行 ≤ 76
	lines := strings.Split(got, "\r\n")
	for i, line := range lines {
		if len(line) > 76 {
			t.Errorf("第 %d 行 %d > 76:%q", i, len(line), line)
		}
	}
}

// ============================================================================
// AttachmentCache
// ============================================================================

func TestSyncMapCache_GetSet(t *testing.T) {
	c := NewSyncMapCache()
	// 未命中
	if _, ok := c.Get("k1"); ok {
		t.Error("未命中 应 false")
	}
	// Set + Get
	c.Set("k1", []byte("value1"))
	got, ok := c.Get("k1")
	if !ok || string(got) != "value1" {
		t.Errorf("Set/Get 失败:got=%q, ok=%v", got, ok)
	}
	// 覆盖
	c.Set("k1", []byte("value2"))
	got, _ = c.Get("k1")
	if string(got) != "value2" {
		t.Errorf("覆盖失败:%q", got)
	}
}

func TestNew_WithCache(t *testing.T) {
	// 传入 cache
	c := NewSyncMapCache()
	b := New(random.NewFixedSource(42), c)
	if b.cache == nil {
		t.Error("cache 未注入")
	}
}

func TestNew_WithNilCache(t *testing.T) {
	// 传 nil(测试模式)
	b := New(random.NewFixedSource(42), nil)
	if b.cache != nil {
		t.Error("nil cache 应保留 nil")
	}
}

// ============================================================================
// 复现性
// ============================================================================

func TestBuildMIME_Reproducibility(t *testing.T) {
	makeParams := func() BuildParams {
		return BuildParams{
			HTMLBody: "<p>test</p>",
			Charset:  "utf-8",
			Encoding: "7bit",
			MimeMode: "alternative",
		}
	}
	b1 := newTestBuilder(42)
	b2 := newTestBuilder(42)
	r1, _ := b1.BuildMIME(makeParams())
	r2, _ := b2.BuildMIME(makeParams())
	if r1.ContentTypeHeader != r2.ContentTypeHeader {
		t.Errorf("ContentType 复现:\n%q\n%q", r1.ContentTypeHeader, r2.ContentTypeHeader)
	}
	if r1.Body != r2.Body {
		t.Errorf("Body 复现失败:len1=%d len2=%d", len(r1.Body), len(r2.Body))
	}
}
