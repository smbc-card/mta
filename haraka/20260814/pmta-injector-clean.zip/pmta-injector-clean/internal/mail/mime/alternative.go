package mime

import (
	"fmt"
	"strings"
)

// ============================================================================
// multipart/alternative(text/plain fallback + text/html)
// v1 email/builder.go::writeAlternative 闭包(649-673 行)
// ============================================================================

// buildAlternative 生成 multipart/alternative(text/plain fallback + text/html)
//
// 【契约】v2 与 v1 writeAlternative 语义一致
//
// 【结构】
//
//	Content-Type: multipart/alternative; boundary="{Alt}"
//	<空行>
//	--{Alt}
//	Content-Type: text/plain; charset="..."
//	Content-Transfer-Encoding: ...
//	<空行>
//	{plainText}(HTMLToPlainText 转出)
//	<空行>
//	--{Alt}
//	Content-Type: text/html; charset="..."
//	Content-Transfer-Encoding: ...
//	<空行>
//	{HTMLBody}
//	<空行>
//	--{Alt}--
//
// 【plainText 来源】
//   - 若 params.TextBody 非空 → 直接用(允许调用方提供优质纯文本 fallback)
//   - 否则 → HTMLToPlainText(HTMLBody)自动转
//
// 【boundary 冲突检测】用 GenerateBoundary(prefix, HTMLBody+plainText) 检测冲突
func (b *Builder) buildAlternative(params BuildParams) (BuildResult, error) {
	plainText := params.TextBody
	if plainText == "" {
		plainText = HTMLToPlainText(params.HTMLBody)
	}

	// D22-5:boundary 冲突检测输入 = 拼接所有 body 内容
	conflictCheckStr := params.HTMLBody + plainText
	altBoundary := b.GenerateBoundary("Alt", conflictCheckStr)

	var body strings.Builder

	// 【H4 修 2026-08-13】不再写"首行空行":header/body 分隔由 render/builder.go 独家负责
	// (multipart 3 处历史都会多一个 \r\n → header\r\n\r\n\r\n--boundary,与 v1 不等价)
	//
	// text/plain 部分(邮件客户端的 fallback)
	body.WriteString(fmt.Sprintf("--%s\r\n", altBoundary))
	body.WriteString(fmt.Sprintf("Content-Type: text/plain; charset=\"%s\"\r\n", params.Charset))
	body.WriteString(fmt.Sprintf("Content-Transfer-Encoding: %s\r\n", params.Encoding))
	body.WriteString("\r\n")
	writeEncodedBody(&body, plainText, params.Encoding, params.Charset)
	body.WriteString("\r\n")

	// text/html 部分(Gmail/Outlook 优先显示)
	body.WriteString(fmt.Sprintf("--%s\r\n", altBoundary))
	body.WriteString(fmt.Sprintf("Content-Type: text/html; charset=\"%s\"\r\n", params.Charset))
	body.WriteString(fmt.Sprintf("Content-Transfer-Encoding: %s\r\n", params.Encoding))
	body.WriteString("\r\n")
	writeEncodedBody(&body, params.HTMLBody, params.Encoding, params.Charset)
	body.WriteString("\r\n")

	// 结束边界
	body.WriteString(fmt.Sprintf("--%s--\r\n", altBoundary))

	return BuildResult{
		ContentTypeHeader: fmt.Sprintf("Content-Type: multipart/alternative; boundary=\"%s\"\r\n", altBoundary),
		EncodingHeader:    "", // multipart 场景无顶层 encoding(每 part 各自标注)
		Body:              body.String(),
	}, nil
}
