package mime

import (
	"regexp"
	"strings"
	"sync"
)

// ============================================================================
// HTML 判断 + HTML → 纯文本转换
// v1 email/builder.go::isHTMLContent + htmlToPlainText
// ============================================================================

// isHTMLPatterns 判断"内容像 HTML"的关键子串(v1 一致)
//
// 【判定】只要含任一以下子串即视为 HTML —— 与 v1 完全一致
var isHTMLPatterns = []string{"<html", "<HTML", "<body", "<BODY", "<div", "<DIV", "<p>", "<P>", "<br", "<BR"}

// IsHTMLContent 判断内容是否为 HTML
//
// 【契约】v2 与 v1 email/builder.go::isHTMLContent 语义一致
func IsHTMLContent(content string) bool {
	for _, pat := range isHTMLPatterns {
		if strings.Contains(content, pat) {
			return true
		}
	}
	return false
}

// ============================================================================
// htmlToPlainText —— HTML 转纯文本(alternative 模式 fallback 用)
// v1 email/builder.go::htmlToPlainText(329-389 行)
// ============================================================================

// 【D22-3 race 修复 6/6】v1 里 htmlToPlainText 每次调用都 regexp.Compile —— 性能坑 + 全局
// regexp cache 若加也是竞态。v2 用 sync.Once 一次性编译所有 regex,后续无锁复用。
var (
	htmlRegexOnce    sync.Once
	reBreak          *regexp.Regexp
	rePara           *regexp.Regexp
	reDiv            *regexp.Regexp
	reTr             *regexp.Regexp
	reLi             *regexp.Regexp
	reHr             *regexp.Regexp
	reLink           *regexp.Regexp
	reImg            *regexp.Regexp
	reStyle          *regexp.Regexp
	reScript         *regexp.Regexp
	reTags           *regexp.Regexp
	reMultiNewline   *regexp.Regexp
)

func initHTMLRegex() {
	reBreak = regexp.MustCompile(`(?i)<br\s*/?>`)
	rePara = regexp.MustCompile(`(?i)</p>`)
	reDiv = regexp.MustCompile(`(?i)</div>`)
	reTr = regexp.MustCompile(`(?i)</tr>`)
	reLi = regexp.MustCompile(`(?i)<li[^>]*>`)
	reHr = regexp.MustCompile(`(?i)<hr\s*/?>`)
	reLink = regexp.MustCompile(`(?i)<a[^>]+href=["']([^"']*)["'][^>]*>(.*?)</a>`)
	reImg = regexp.MustCompile(`(?i)<img[^>]+alt=["']([^"']*)["'][^>]*/?>`)
	reStyle = regexp.MustCompile(`(?is)<style[^>]*>.*?</style>`)
	reScript = regexp.MustCompile(`(?is)<script[^>]*>.*?</script>`)
	reTags = regexp.MustCompile(`<[^>]+>`)
	reMultiNewline = regexp.MustCompile(`\n{3,}`)
}

// HTMLToPlainText 把 HTML 内容转成纯文本(用于 multipart/alternative fallback)
//
// 【契约】v2 与 v1 email/builder.go::htmlToPlainText 语义完全一致
//
// 【D22-3 race 修复】regexp 一次性编译(sync.Once),v1 里每次调用都 Compile 是性能坑
//
// 【转换规则】
//   - <br> / </p> / </div> / </tr> → \n
//   - <li> → "- "
//   - <hr> → "━━━━━━━━━━━━" 分隔
//   - <a href="...">text</a> → "text (URL)"
//   - <img alt="..."> → "[画像: alt]"
//   - <style>...</style> + <script>...</script> → 完全删除
//   - 其他标签 → 删除
//   - HTML 实体解码(&nbsp; / &amp; / &lt; / &gt; / &quot; / &#39; / &#x27; / &yen; / &copy; / &reg;)
//   - 3+ 连续换行 → 最多 2 个
//   - 每行首尾 trim
func HTMLToPlainText(html string) string {
	htmlRegexOnce.Do(initHTMLRegex)

	text := html
	text = reBreak.ReplaceAllString(text, "\n")
	text = rePara.ReplaceAllString(text, "\n\n")
	text = reDiv.ReplaceAllString(text, "\n")
	text = reTr.ReplaceAllString(text, "\n")
	text = reLi.ReplaceAllString(text, "- ")
	text = reHr.ReplaceAllString(text, "\n━━━━━━━━━━━━\n")
	text = reLink.ReplaceAllString(text, "$2 ($1)")
	text = reImg.ReplaceAllString(text, "[画像: $1]")
	text = reStyle.ReplaceAllString(text, "")
	text = reScript.ReplaceAllString(text, "")
	text = reTags.ReplaceAllString(text, "")

	// HTML 实体解码(与 v1 逐个 ReplaceAll 一致)
	text = strings.ReplaceAll(text, "&nbsp;", " ")
	text = strings.ReplaceAll(text, "&amp;", "&")
	text = strings.ReplaceAll(text, "&lt;", "<")
	text = strings.ReplaceAll(text, "&gt;", ">")
	text = strings.ReplaceAll(text, "&quot;", "\"")
	text = strings.ReplaceAll(text, "&#39;", "'")
	text = strings.ReplaceAll(text, "&#x27;", "'")
	text = strings.ReplaceAll(text, "&yen;", "¥")
	text = strings.ReplaceAll(text, "&copy;", "©")
	text = strings.ReplaceAll(text, "&reg;", "®")

	// 清理多余空行
	text = reMultiNewline.ReplaceAllString(text, "\n\n")

	// 清理行首行尾空格
	lines := strings.Split(text, "\n")
	cleaned := make([]string, len(lines))
	for i, line := range lines {
		cleaned[i] = strings.TrimSpace(line)
	}
	text = strings.Join(cleaned, "\n")

	return strings.TrimSpace(text)
}
