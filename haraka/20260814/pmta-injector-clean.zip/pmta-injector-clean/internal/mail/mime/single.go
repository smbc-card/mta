package mime

import (
	"fmt"
	"strings"
)

// ============================================================================
// 单体 body(text/plain 或 text/html)
// v1 email/builder.go::writeSingleBody 闭包(676-686 行)
// + 主入口分支里的 default 分支单体(773-789 行)
// ============================================================================

// buildSingleBody 生成单体 body(text/plain 或 text/html)
//
// 【契约】v2 与 v1 writeSingleBody + default 分支单体 语义一致
//
// 【自动判定】isHTMLContent(params.HTMLBody) 决定 Content-Type:
//   - HTMLBody 含 HTML 标签(<html/<body/<div/<p>/<br 等)→ text/html
//   - 否则 → text/plain
//
// 【返回 BuildResult】
//   - ContentTypeHeader = "Content-Type: text/xxx; charset=\"...\"\r\n"
//   - EncodingHeader    = "Content-Transfer-Encoding: xxx\r\n"
//   - Body              = writeEncodedBody(HTMLBody, encoding) 输出
//
// 【body 选择】v1 单体分支永远用 email.HTMLBody(即使不含 HTML 标签也用它),
// TextBody 只在 alternative 分支的 text/plain fallback 里用 —— v2 保持同语义:
// 单体 body 就是 params.HTMLBody(可能是纯文本 / 可能是 HTML,由 IsHTMLContent 判定 Content-Type)
func (b *Builder) buildSingleBody(params BuildParams) (BuildResult, error) {
	contentType := "text/plain"
	if IsHTMLContent(params.HTMLBody) {
		contentType = "text/html"
	}

	var body strings.Builder
	writeEncodedBody(&body, params.HTMLBody, params.Encoding, params.Charset)

	return BuildResult{
		ContentTypeHeader: fmt.Sprintf("Content-Type: %s; charset=\"%s\"\r\n", contentType, params.Charset),
		EncodingHeader:    fmt.Sprintf("Content-Transfer-Encoding: %s\r\n", params.Encoding),
		Body:              body.String(),
	}, nil
}
