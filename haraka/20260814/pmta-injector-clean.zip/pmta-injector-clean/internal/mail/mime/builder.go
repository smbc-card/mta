package mime

import (
	"__MODULE_PLACEHOLDER__/internal/random"
)

// Attachment 单个附件
//
// 【契约】v2 与 v1 email.Attachment struct 字段等价(FileName / MIMEType / Data / ContentID)
type Attachment struct {
	FileName    string
	MIMEType    string
	Data        []byte
	ContentID   string // 若非空 → 内嵌图(cid: 引用)
	IsInline    bool
}

// BuildParams MIME 组装输入参数
//
// 【D16-3 决策】每包独立 Params struct —— 避免顶层大 struct,保接口小
//
// 【body 传入约定】v2 假设 TextBody / HTMLBody 已由调用方(render.Builder)完成:
//   - 变量渲染(variables.basic + extended)
//   - 混淆(obfuscate.Noiser InsertZeroWidth / BidiReverseHide)
//   - 字符集转换(UTF-8 → charset 目标编码)—— 由 mail/encoding 处理
//
// 本包只做:传输编码(7bit/QP/base64)+ MIME 结构组装
type BuildParams struct {
	TextBody        string       // 纯文本正文(alternative 的 text/plain fallback 用)
	HTMLBody        string       // 主 body(单体或 alternative 的 text/html;可能是纯文本内容)
	Charset         string       // "utf-8" / "iso-2022-jp" / "gbk" / ...(已完成转换)
	Encoding        string       // "7bit" / "quoted-printable" / "base64"
	HeaderEncoding  string       // "base64" / "quoted-printable" —— 用于附件 filename RFC2047 编码(H3)
	MimeMode        string       // "standard"(默认) / "alternative" / "full"(v1 一致)
	Attachments     []Attachment // Day 25 支持
	EmbeddedImgs    []Attachment // ContentID 非空;Day 25 支持
}

// BuildResult MIME 组装输出
type BuildResult struct {
	// ContentTypeHeader:完整 "Content-Type: ..." 行(含末尾 CRLF)
	// 例如 "Content-Type: multipart/mixed; boundary=\"----=_XXXXXXXX\"\r\n"
	ContentTypeHeader string
	// EncodingHeader:"Content-Transfer-Encoding: ..." 行(含 CRLF);单 body 场景才有;
	// multipart 场景为空(每 part 各自的 encoding 在 part 内标注)
	EncodingHeader string
	// Body:MIME body 文本(不含 header,首行不含空行)
	// 单 body 场景 = 编码后的 body 内容;multipart = 完整 multipart 结构(含 boundary 分隔)
	Body string
}

// AttachmentCache 附件 SHA256 缓存接口(D22-4)
//
// 【设计】接口而非具体 struct,便于:
//   - 生产用:sync.Map 或 lru cache
//   - 测试用:nil 或简单 map
//
// 【返回】Get 返回缓存内容;Set 存入;第 2 返回值表示是否命中
type AttachmentCache interface {
	Get(key string) ([]byte, bool)
	Set(key string, data []byte)
}

// Builder MIME 编码器(per-worker 单实例)
//
// 【依赖注入】
//   - rng:boundary 生成 + 编码抉择的随机源
//   - cache:附件 SHA256 缓存(可选,nil = 不缓存)
//
// 【线程安全】非线程安全(rng 非并发安全),per-worker 一个实例
// 【cache 线程安全】由 cache 实现方保证(sync.Map / lru.Cache 都是线程安全的)
type Builder struct {
	rng   random.Source
	cache AttachmentCache
}

// New 创建 MIME Builder
//
// 【参数】
//   - rng:必需
//   - cache:可选(nil 表示不缓存,每次读原始数据)
func New(rng random.Source, cache AttachmentCache) *Builder {
	return &Builder{rng: rng, cache: cache}
}

// BuildMIME 3 分支矩阵主入口
//
// 【契约】v2 与 v1 email/builder.go::buildRawEmail 里 MIME 分支决策等价
//
// 【分支矩阵】
//   1. 有附件 / MimeMode="full" → multipart/mixed(**Day 25 实现**)
//   2. 有内嵌图 → multipart/related(**Day 25 实现**)
//   3. MimeMode="alternative" / "full" → multipart/alternative(**Day 24 已实现**)
//   4. 默认(无附件 / 无内嵌图 / MimeMode="standard")→ 单体 text/plain 或 text/html
//
// 【Day 24 支持】分支 3 + 4;分支 1/2 返回 ErrMultipartNotImplemented(Day 25 补)
//
// 【返回】(BuildResult, error);error 场景:附件读盘失败 / 编码失败 / 未支持分支
func (b *Builder) BuildMIME(params BuildParams) (BuildResult, error) {
	mimeMode := params.MimeMode
	if mimeMode == "" {
		mimeMode = "standard"
	}
	useAlternative := mimeMode == "alternative" || mimeMode == "full"
	hasAttachments := len(params.Attachments) > 0
	hasEmbeddedImages := len(params.EmbeddedImgs) > 0

	// 分支 1:multipart/mixed(附件 / full 模式)
	if mimeMode == "full" || hasAttachments {
		return b.buildMultipartMixed(params)
	}

	// 分支 2:multipart/related(内嵌图,无附件,非 full 模式)
	if hasEmbeddedImages {
		return b.buildMultipartRelated(params)
	}

	// 分支 3:multipart/alternative
	if useAlternative {
		return b.buildAlternative(params)
	}

	// 分支 4:单体 body
	return b.buildSingleBody(params)
}

// mimeError 简单 error 类型(避免 import "errors" 只为一个 error 值)
type mimeError struct{ msg string }

func (e *mimeError) Error() string { return e.msg }
