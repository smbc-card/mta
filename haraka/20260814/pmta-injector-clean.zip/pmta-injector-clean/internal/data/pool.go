// Package data 提供 v2 里所有静态数据池的加载与访问
//
// 【Week 3 Day 11 骨架】11 个字符串池外置到 files/*.txt + go:embed 加载。
// struct 池(dkim/extended_slots/yahooBy 等)推到 Day 12 用 JSON schema 处理。
//
// 【设计原则】
//   - 泛型 Pool[T]:同一套加载/缓存逻辑复用给所有池
//   - sync.Once 懒加载:启动时不占内存,首次 Get() 才 parse embed 字节
//   - 数据文件放 files/ 子目录:方便 go:embed 模式匹配 + 未来扩展 struct 池
//
// 【与 v1 的对比】
//   - v1 里池硬编码在 email/xmailer.go(500+ 字符串)/ email/headers.go(500+ 行的 mailServerSoftware 等)
//     → 单文件几千行难 review,改一条要重编译整个包
//   - v2 抽到 .txt 文件 → git diff 只显示变更的池,go:embed 自动跟随编译,零运行时依赖
package data

import (
	_ "embed"
	"strings"
	"sync"
)

// Pool 泛型池加载器
//
// 【使用模式】
//
//	var XMailerPool = NewPool(func() ([]string, error) {
//	    return parseLines(xmailerRaw)
//	})
//	items, err := XMailerPool.Get()  // 首次调用触发 loadFn,后续用缓存
//
// 【并发安全】sync.Once 保证 loadFn 只被调用一次(即使跨 goroutine)。
// 首次 Get 结束后,items 只读,后续 Get 无锁竞争 —— 生产热路径无性能损失。
type Pool[T any] struct {
	once    sync.Once
	items   []T
	loadFn  func() ([]T, error)
	loadErr error
}

// NewPool 创建一个池,loadFn 只在首次 Get 时被调用
func NewPool[T any](loadFn func() ([]T, error)) *Pool[T] {
	return &Pool[T]{loadFn: loadFn}
}

// Get 获取池的所有 items(懒加载:首次调用触发 loadFn)
//
// 【返回值】
//   - items:池内容(非 nil,即使 loadFn 报错也返回 nil slice)
//   - err:loadFn 的报错,后续 Get 返回同一 err(sync.Once 语义)
func (p *Pool[T]) Get() ([]T, error) {
	p.once.Do(func() {
		p.items, p.loadErr = p.loadFn()
	})
	return p.items, p.loadErr
}

// Len 返回池大小 —— 若 loadFn 报错则返回 0
// 【用途】测试与诊断;生产热路径应直接用 len(Get()) 避免多次调用
func (p *Pool[T]) Len() int {
	items, err := p.Get()
	if err != nil {
		return 0
	}
	return len(items)
}

// parseLines 解析文本行 —— 每行一个字符串;跳过空行和 "#" 开头的注释
//
// 【处理步骤】
//  1. 按 "\n" split
//  2. 每行 TrimRight("\r") + TrimSpace(容忍 CRLF 混合 + 首尾空白)
//  3. 空行跳过 + "#" 注释行跳过
//
// 【格式约定】数据文件用 UTF-8 编码,LF 或 CRLF 行结束符都支持。
func parseLines(raw string) ([]string, error) {
	lines := strings.Split(raw, "\n")
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		line = strings.TrimRight(line, "\r")
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "#") {
			continue
		}
		out = append(out, line)
	}
	return out, nil
}

// ===================================================================
// 【11 个字符串池】(Week 3 Day 11 Batch 1)
// 来源:v1 email/xmailer.go + email/headers.go + email/templates_listunsub.go 硬编码抽出
// ===================================================================

//go:embed files/xmailer_pool.txt
var xmailerPoolRaw string

// XMailerPool X-Mailer 头值池(v1 xMailerList,526 项)
var XMailerPool = NewPool(func() ([]string, error) { return parseLines(xmailerPoolRaw) })

//go:embed files/mailserver_pool.txt
var mailserverPoolRaw string

// MailserverPool 邮件服务器软件版本池(v1 mailServerSoftware,486 项)
var MailserverPool = NewPool(func() ([]string, error) { return parseLines(mailserverPoolRaw) })

//go:embed files/listunsub_default_pool.txt
var listunsubDefaultPoolRaw string

// ListUnsubDefaultPool List-Unsubscribe 默认模板池(v1 listUnsubTemplatePool,50 项)
// 【用途】ListUnsubMode="custom"/"random" 时的内置基础池(用户配置池优先)
var ListUnsubDefaultPool = NewPool(func() ([]string, error) { return parseLines(listunsubDefaultPoolRaw) })

//go:embed files/yahoo_cidrs.txt
var yahooCidrsRaw string

// YahooCidrsPool 雅虎 CIDR 段池(v1 yahooCidrStrings,122 项)
// 【用途】ReceivedYahooIPMode="yahoo" 时从此池随机抽 IP
// 【B2 修复 2026-08-13】v2 之前只有 36 条,IP 熵下降 70%;补齐到 v1 122 条(含重叠段权重)
var YahooCidrsPool = NewPool(func() ([]string, error) { return parseLines(yahooCidrsRaw) })

//go:embed files/messageid_style_keys.txt
var messageIDStyleKeysRaw string

// MessageIDStyleKeysPool 25 种 Message-ID 风格 key(v1 messageIDStyleKeys,25 项)
// 【契约】§1.15.8 里 message_id_styles 字段的合法取值集合
var MessageIDStyleKeysPool = NewPool(func() ([]string, error) { return parseLines(messageIDStyleKeysRaw) })

//go:embed files/tls_ciphers.txt
var tlsCiphersRaw string

// TLSCiphersPool TLS 密码套件池(v1 tlsCiphers,17 项)
// 【用途】Received 头里的 tls cipher 字段随机来源
var TLSCiphersPool = NewPool(func() ([]string, error) { return parseLines(tlsCiphersRaw) })

//go:embed files/domain_tlds.txt
var domainTLDsRaw string

// DomainTLDsPool 随机域名生成 TLD 池(v1 domainTLDs,109 项)
// 【B3 修复 2026-08-13】v2 之前只有 19 条,组合数下降 293x;补齐到 v1 109 条
var DomainTLDsPool = NewPool(func() ([]string, error) { return parseLines(domainTLDsRaw) })

//go:embed files/domain_words.txt
var domainWordsRaw string

// DomainWordsPool 随机域名生成词根池(v1 domainWords,111 项)
// 【B3 修复 2026-08-13】v2 之前只有 14 条;补齐到 v1 111 条
var DomainWordsPool = NewPool(func() ([]string, error) { return parseLines(domainWordsRaw) })

//go:embed files/domain_suffixes.txt
var domainSuffixesRaw string

// DomainSuffixesPool 随机域名生成后缀池(v1 domainSuffixes,90 项)
// 【B3 修复 2026-08-13】v2 之前只有 14 条;补齐到 v1 90 条
var DomainSuffixesPool = NewPool(func() ([]string, error) { return parseLines(domainSuffixesRaw) })

//go:embed files/nonroutable_cidrs.txt
var nonRoutableCidrsRaw string

// NonRoutableCidrsPool 非公网 CIDR 排除池(v1 nonRoutableCidrs,9 项)
// 【用途】ReceivedYahooIPMode="random" 时排除私网/保留段
var NonRoutableCidrsPool = NewPool(func() ([]string, error) { return parseLines(nonRoutableCidrsRaw) })

//go:embed files/yahoo_ehlo_subdomains.txt
var yahooEhloSubdomainsRaw string

// YahooEhloSubdomainsPool 雅虎 EHLO subdomain 池(v1 yahooEhloSubdomains,3 项)
var YahooEhloSubdomainsPool = NewPool(func() ([]string, error) { return parseLines(yahooEhloSubdomainsRaw) })
