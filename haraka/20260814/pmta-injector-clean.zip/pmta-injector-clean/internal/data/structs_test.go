package data

import (
	"strings"
	"testing"
)

// TestDkimExternalSources_Count 项数应与 v1 精确一致(72 项 —— grep 精确数出)
func TestDkimExternalSources_Count(t *testing.T) {
	if len(DkimExternalSources) != 72 {
		t.Errorf("DkimExternalSources 项数期望 72, 得到 %d", len(DkimExternalSources))
	}
}

// TestDkimExternalSources_KeyDomains 关键域应存在(抽样验证)
func TestDkimExternalSources_KeyDomains(t *testing.T) {
	found := map[string]DkimExternalSource{}
	for _, s := range DkimExternalSources {
		found[s.Domain] = s
	}

	// gmail.com 应存在,权重 20(v1 最高权重)
	if gmail, ok := found["gmail.com"]; !ok {
		t.Error("应包含 gmail.com")
	} else {
		if gmail.Weight != 20 {
			t.Errorf("gmail.com weight 期望 20, 得到 %d", gmail.Weight)
		}
		if len(gmail.Selectors) != 4 {
			t.Errorf("gmail.com 应有 4 个 selector, 得到 %d", len(gmail.Selectors))
		}
	}

	// amazonses.com 应是 IsSESLike=true(nil selectors 特殊 case)
	if ses, ok := found["amazonses.com"]; !ok {
		t.Error("应包含 amazonses.com")
	} else {
		if !ses.IsSESLike {
			t.Error("amazonses.com IsSESLike 应为 true")
		}
		if ses.Selectors != nil {
			t.Errorf("amazonses.com Selectors 应为 nil(SES 动态生成), 得到 %v", ses.Selectors)
		}
	}

	// 日本运营商域(应存在)
	for _, domain := range []string{"docomo.ne.jp", "softbank.ne.jp", "au.com", "ezweb.ne.jp", "i.softbank.jp"} {
		if _, ok := found[domain]; !ok {
			t.Errorf("应包含日本域名 %s", domain)
		}
	}
}

// TestDkimExternalSources_RSABits_Range RSA 位数应在合法范围
func TestDkimExternalSources_RSABits_Range(t *testing.T) {
	validBits := map[int]bool{1024: true, 2048: true, 4096: true}
	for _, s := range DkimExternalSources {
		if !validBits[s.RSABits] {
			t.Errorf("%s RSABits=%d 非合法(应为 1024/2048/4096)", s.Domain, s.RSABits)
		}
	}
}

// TestDkimExternalSources_WeightPositive Weight 都应 > 0
func TestDkimExternalSources_WeightPositive(t *testing.T) {
	for _, s := range DkimExternalSources {
		if s.Weight <= 0 {
			t.Errorf("%s Weight=%d 应 > 0", s.Domain, s.Weight)
		}
	}
}

// TestDkimCanonicalizations 4 项 + 权重合计 100
func TestDkimCanonicalizations(t *testing.T) {
	if len(DkimCanonicalizations) != 4 {
		t.Fatalf("DkimCanonicalizations 期望 4 项, 得到 %d", len(DkimCanonicalizations))
	}
	sum := 0
	for _, c := range DkimCanonicalizations {
		sum += c.Weight
	}
	if sum != 100 {
		t.Errorf("DkimCanonicalizations 权重合计期望 100, 得到 %d", sum)
	}
	// relaxed/relaxed 应是最高权重
	if DkimCanonicalizations[0].Value != "relaxed/relaxed" || DkimCanonicalizations[0].Weight != 70 {
		t.Errorf("第 1 项应是 {relaxed/relaxed, 70}, 得到 %v", DkimCanonicalizations[0])
	}
}

// TestDkimHFieldsByStyle 6 种风格 + 每种风格模板数
func TestDkimHFieldsByStyle_Count(t *testing.T) {
	if len(DkimHFieldsByStyle) != 6 {
		t.Errorf("DkimHFieldsByStyle keys 期望 6, 得到 %d", len(DkimHFieldsByStyle))
	}
	for _, style := range []string{"gmail", "outlook", "yahoo", "ses", "japan", "generic"} {
		if _, ok := DkimHFieldsByStyle[style]; !ok {
			t.Errorf("应包含风格 %q", style)
		}
	}
}

// TestDkimHFieldsByStyle_TemplatesNonEmpty 每种风格至少 1 个模板
func TestDkimHFieldsByStyle_TemplatesNonEmpty(t *testing.T) {
	for style, templates := range DkimHFieldsByStyle {
		if len(templates) == 0 {
			t.Errorf("风格 %q 应至少有 1 个模板", style)
		}
		for i, tmpl := range templates {
			if tmpl == "" {
				t.Errorf("%q[%d] 模板空", style, i)
			}
			// 模板里都应含 From(每份 DKIM 签名的必备字段)
			if !strings.Contains(strings.ToLower(tmpl), "from") {
				t.Errorf("%q[%d] 应含 from 字段: %q", style, i, tmpl)
			}
		}
	}
}

// TestYahooByPool 6 项 + StartNum <= EndNum
func TestYahooByPool(t *testing.T) {
	if len(YahooByPool) != 6 {
		t.Errorf("YahooByPool 项数期望 6, 得到 %d", len(YahooByPool))
	}
	for i, p := range YahooByPool {
		if p.StartNum > p.EndNum {
			t.Errorf("YahooByPool[%d] StartNum(%d) > EndNum(%d)", i, p.StartNum, p.EndNum)
		}
		if !strings.Contains(p.Template, "%") {
			t.Errorf("YahooByPool[%d] Template 应含格式占位符 %%, 得到 %q", i, p.Template)
		}
		if !strings.Contains(p.Template, "yahoo.co.jp") {
			t.Errorf("YahooByPool[%d] Template 应含 yahoo.co.jp, 得到 %q", i, p.Template)
		}
	}
}
