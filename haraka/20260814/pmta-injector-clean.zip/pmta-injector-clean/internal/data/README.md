# internal/data

**用途**:v2 里所有静态数据池的加载与访问(go:embed + 泛型 Pool[T] + 懒加载)。

## 【Week 3 Day 11 骨架】11 个字符串池 + struct 池推到 Day 12

**当前状态**:11 个纯字符串池已外置到 `files/*.txt`。struct 池(dkim 系列 / extended_slots / yahooBy)推到 **Day 12** 用 JSON schema 处理。

## 快速开始

```go
import "__MODULE_PLACEHOLDER__/internal/data"

// 获取 X-Mailer 池(懒加载:首次调用才 parse embed 字节)
items, err := data.XMailerPool.Get()
if err != nil { ... }
for _, x := range items {
    fmt.Println(x)  // 500+ X-Mailer 字符串
}

// 池大小
n := data.XMailerPool.Len()  // 526
```

## 11 个字符串池清单

| Pool 变量 | 文件 | 项数 | v1 来源 | 用途 |
|-----------|------|------|---------|------|
| `XMailerPool` | xmailer_pool.txt | 526 | xmailer.go:11 xMailerList | X-Mailer 头值 |
| `MailserverPool` | mailserver_pool.txt | 486 | headers.go:1853 mailServerSoftware | 邮件服务器软件版本(Received by) |
| `ListUnsubDefaultPool` | listunsub_default_pool.txt | 50 | templates_listunsub.go:43 listUnsubTemplatePool | List-Unsubscribe 内置基础池 |
| `YahooCidrsPool` | yahoo_cidrs.txt | 36 | headers.go:2378 yahooCidrStrings | 雅虎 CIDR 段(ReceivedYahooIPMode="yahoo") |
| `MessageIDStyleKeysPool` | messageid_style_keys.txt | 25 | headers.go:1409 messageIDStyleKeys | 25 种 Message-ID 风格 key(契约 §1.15.8) |
| `TLSCiphersPool` | tls_ciphers.txt | 17 | headers.go:1773 tlsCiphers | Received 头里的 TLS cipher 池 |
| `DomainTLDsPool` | domain_tlds.txt | 19 | headers.go:1795 domainTLDs | 随机域名 TLD 池 |
| `DomainWordsPool` | domain_words.txt | 14 | headers.go:1817 domainWords | 随机域名词根池 |
| `DomainSuffixesPool` | domain_suffixes.txt | 14 | headers.go:1834 domainSuffixes | 随机域名后缀池 |
| `NonRoutableCidrsPool` | nonroutable_cidrs.txt | 9 | headers.go:2425 nonRoutableCidrs | 排除的非公网 CIDR |
| `YahooEhloSubdomainsPool` | yahoo_ehlo_subdomains.txt | 3 | headers.go:2577 yahooEhloSubdomains | 雅虎 EHLO subdomain |
| **合计** | | **1199** | | |

**未外置(Day 12 处理)**:

- `dkimExternalSources`(headers.go:47,~100 项)struct 池
- `dkimHFieldsByStyle`(headers.go:167)map[string][]string
- `dkimCanonicalizations`(headers.go:153)struct 池
- `extendedHeaderSlots`(headers.go:788)struct 池
- `yahooByPool`(headers.go:2587)struct 池

## Pool[T] 泛型 API

```go
type Pool[T any] struct { ... }

func NewPool[T any](loadFn func() ([]T, error)) *Pool[T]
func (p *Pool[T]) Get() ([]T, error)
func (p *Pool[T]) Len() int
```

**特性**:

- **懒加载**:`NewPool` 创建时**不**调用 loadFn;首次 `Get()` 才真正 parse embed 字节
- **只加载一次**:sync.Once 保证,即使跨 goroutine
- **并发安全**:首次加载后 items 只读,后续 Get 无锁竞争 —— 生产热路径零性能损失
- **错误缓存**:loadFn 报错也缓存,后续 Get 返回同一 err

## 数据文件格式

**约定**:每行一个字符串;空行跳过;`#` 开头注释跳过。

```
# 这是注释
value1
value2

value3  # 注释在末尾会被完整保留,不切分(与 v1 里 // 行内注释不同,parseLines 不处理)
```

**编码**:UTF-8;LF 或 CRLF 都支持。

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| X-Mailer 500+ 字符串 | 硬编码在 email/xmailer.go 里(527 行) | files/xmailer_pool.txt(纯数据) |
| headers.go 里 500+ 邮件服务器 | mailServerSoftware slice(500 行) | files/mailserver_pool.txt |
| 数据更改需重编译? | 是 —— 改一行要编 8000+ 行 email 包 | 是(go:embed 编译时嵌入)—— 但**pool_test 会立即发现数量变化** |
| 数据 diff 便利? | git diff 混在 Go 代码里,难过滤 | git diff 只显示 .txt 变更,清晰 |

## 测试

```bash
go test -cover ./internal/data/...
# 预期覆盖率 ≥ 90%
```

## 未来扩展(Day 12)

添加 JSON struct 池:

```go
//go:embed files/dkim_external_sources.json
var dkimSourcesRaw string

var DkimExternalSourcesPool = NewPool(func() ([]DkimExternalSource, error) {
    var out []DkimExternalSource
    err := json.Unmarshal([]byte(dkimSourcesRaw), &out)
    return out, err
})
```
