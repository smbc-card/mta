package data

import (
	"strings"
	"testing"
)

// ===== Pool[T] 泛型基础设施 =====

// TestPool_LazyLoad 首次 Get 才调用 loadFn
func TestPool_LazyLoad(t *testing.T) {
	callCount := 0
	pool := NewPool(func() ([]string, error) {
		callCount++
		return []string{"a", "b", "c"}, nil
	})

	// 未 Get 前 loadFn 不应被调用
	if callCount != 0 {
		t.Errorf("NewPool 不应立即调用 loadFn,callCount=%d", callCount)
	}

	// 首次 Get 触发 loadFn
	items, err := pool.Get()
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 3 || callCount != 1 {
		t.Errorf("首次 Get:items=%v callCount=%d", items, callCount)
	}

	// 二次 Get 复用缓存,loadFn 不再调用
	items2, _ := pool.Get()
	if callCount != 1 {
		t.Errorf("二次 Get 后 loadFn 应仍只调用 1 次,callCount=%d", callCount)
	}
	if len(items2) != 3 {
		t.Errorf("二次 Get items 应一致")
	}
}

// TestPool_LoadError loadFn 报错应被缓存
func TestPool_LoadError(t *testing.T) {
	pool := NewPool(func() ([]string, error) {
		return nil, testErr("加载失败")
	})

	_, err1 := pool.Get()
	_, err2 := pool.Get()
	if err1 == nil || err2 == nil {
		t.Fatal("应返回 error")
	}
	// sync.Once 保证 loadErr 稳定
	if err1.Error() != err2.Error() {
		t.Errorf("Get 应缓存 err,得到 %v vs %v", err1, err2)
	}
}

// TestPool_Len_OK Len 返回正确大小
func TestPool_Len_OK(t *testing.T) {
	pool := NewPool(func() ([]string, error) {
		return []string{"a", "b", "c", "d", "e"}, nil
	})
	if pool.Len() != 5 {
		t.Errorf("Len 应为 5, 得到 %d", pool.Len())
	}
}

// TestPool_Len_Error 加载报错时 Len 返回 0
func TestPool_Len_Error(t *testing.T) {
	pool := NewPool(func() ([]string, error) {
		return nil, testErr("failed")
	})
	if pool.Len() != 0 {
		t.Errorf("加载报错时 Len 应为 0, 得到 %d", pool.Len())
	}
}

// ===== parseLines =====

func TestParseLines_Simple(t *testing.T) {
	items, err := parseLines("a\nb\nc\n")
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"a", "b", "c"}
	assertStringSlice(t, "simple", items, want)
}

func TestParseLines_SkipEmpty(t *testing.T) {
	items, _ := parseLines("a\n\n\nb\n")
	assertStringSlice(t, "skip empty", items, []string{"a", "b"})
}

func TestParseLines_SkipComment(t *testing.T) {
	items, _ := parseLines("# comment\na\n# another\nb\n")
	assertStringSlice(t, "skip comment", items, []string{"a", "b"})
}

func TestParseLines_TrimCRLF(t *testing.T) {
	items, _ := parseLines("a\r\nb\r\nc")
	assertStringSlice(t, "crlf", items, []string{"a", "b", "c"})
}

func TestParseLines_TrimSpace(t *testing.T) {
	items, _ := parseLines("  a  \n\tb\t\n  c\n")
	assertStringSlice(t, "trim space", items, []string{"a", "b", "c"})
}

func TestParseLines_EmptyInput(t *testing.T) {
	items, _ := parseLines("")
	if len(items) != 0 {
		t.Errorf("空输入应返回空 slice, 得到 %v", items)
	}
}

// ===== 11 个具体池 =====

// TestPool_ExpectedCounts 验证每个池的项数与 v1 精确一致
// 这是"防漏抽/多抽"的最强兜底 —— 若某天有人改 files/*.txt 会立即被发现
func TestPool_ExpectedCounts(t *testing.T) {
	cases := []struct {
		name string
		pool interface{ Len() int }
		want int
	}{
		{"XMailerPool", XMailerPool, 526},
		{"MailserverPool", MailserverPool, 486},
		{"ListUnsubDefaultPool", ListUnsubDefaultPool, 50},
		{"YahooCidrsPool", YahooCidrsPool, 122},
		{"MessageIDStyleKeysPool", MessageIDStyleKeysPool, 25},
		{"TLSCiphersPool", TLSCiphersPool, 17},
		{"DomainTLDsPool", DomainTLDsPool, 109},
		{"DomainWordsPool", DomainWordsPool, 111},
		{"DomainSuffixesPool", DomainSuffixesPool, 90},
		{"NonRoutableCidrsPool", NonRoutableCidrsPool, 9},
		{"YahooEhloSubdomainsPool", YahooEhloSubdomainsPool, 3},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got := c.pool.Len()
			if got != c.want {
				t.Errorf("%s 项数期望 %d, 得到 %d", c.name, c.want, got)
			}
		})
	}
}

// TestPool_NoEmptyItems 每个池内不应有空字符串(说明 parseLines 逻辑正确)
func TestPool_NoEmptyItems(t *testing.T) {
	pools := map[string]*Pool[string]{
		"XMailerPool":             XMailerPool,
		"MailserverPool":          MailserverPool,
		"ListUnsubDefaultPool":    ListUnsubDefaultPool,
		"YahooCidrsPool":          YahooCidrsPool,
		"MessageIDStyleKeysPool":  MessageIDStyleKeysPool,
		"TLSCiphersPool":          TLSCiphersPool,
		"DomainTLDsPool":          DomainTLDsPool,
		"DomainWordsPool":         DomainWordsPool,
		"DomainSuffixesPool":      DomainSuffixesPool,
		"NonRoutableCidrsPool":    NonRoutableCidrsPool,
		"YahooEhloSubdomainsPool": YahooEhloSubdomainsPool,
	}
	for name, p := range pools {
		t.Run(name, func(t *testing.T) {
			items, err := p.Get()
			if err != nil {
				t.Fatal(err)
			}
			for i, item := range items {
				if item == "" {
					t.Errorf("%s[%d] 是空字符串", name, i)
				}
			}
		})
	}
}

// TestPool_SampleValueChecks 抽样验证具体池的样本值(防 sed 抽错内容)
func TestPool_SampleValueChecks(t *testing.T) {
	// MessageIDStyleKeysPool 第 1 个应该是 "uuid_v4_lower"(v1 headers.go:1410)
	styles, _ := MessageIDStyleKeysPool.Get()
	if styles[0] != "uuid_v4_lower" {
		t.Errorf("MessageIDStyleKeysPool[0] 应为 uuid_v4_lower, 得到 %q", styles[0])
	}
	if styles[7] != "uuid_seq" { // 第 8 个,索引 7
		t.Errorf("MessageIDStyleKeysPool[7] 应为 uuid_seq(生产实际用), 得到 %q", styles[7])
	}

	// YahooEhloSubdomainsPool 应包含 kks/kth/ssk
	subs, _ := YahooEhloSubdomainsPool.Get()
	wantSubs := map[string]bool{"kks": true, "kth": true, "ssk": true}
	for _, sub := range subs {
		if !wantSubs[sub] {
			t.Errorf("YahooEhloSubdomainsPool 出现意外值 %q", sub)
		}
	}

	// ListUnsubDefaultPool 每一项都应该以 "<" 开头(RFC 2369 要求)
	tmpls, _ := ListUnsubDefaultPool.Get()
	for i, tmpl := range tmpls {
		if !strings.HasPrefix(tmpl, "<") {
			t.Errorf("ListUnsubDefaultPool[%d] 应以 < 开头(RFC 2369), 得到 %q", i, tmpl)
		}
	}
}

// ===== 测试工具 =====

type testErr string

func (e testErr) Error() string { return string(e) }

func assertStringSlice(t *testing.T, name string, got, want []string) {
	t.Helper()
	if len(got) != len(want) {
		t.Fatalf("%s 长度期望 %d, 得到 %d(got=%v)", name, len(want), len(got), got)
	}
	for i, v := range want {
		if got[i] != v {
			t.Errorf("%s[%d] 期望 %q, 得到 %q", name, i, v, got[i])
		}
	}
}
