package data

// ============================================================================
// 【Week 3 Day 12 前半 —— struct 池】
//
// 【设计原则】小-中等规模的 struct 池保留 Go 字面量(不外置 JSON):
//   - JSON 外置反而增加复杂度(Unmarshal + json tag 维护)
//   - Go 字面量编译时保证类型正确,一行一项紧凑
//   - 值 review 时看代码与看 JSON 一样清晰
//
// 【当前包含 4 个池】
//   - DkimExternalSources(62 项) — 伪 DKIM 外部签名域名池(方案 B)
//   - DkimCanonicalizations(4 项) — DKIM canonicalization 加权池
//   - DkimHFieldsByStyle(6 keys map) — DKIM h= 字段按 ESP 风格分组
//   - YahooByPool(6 项) — 雅虎 by mtaXXX.yahoo.co.jp 命名模式池
//
// 【不含 extendedHeaderSlots】— 因含函数指针,Week 4 建 header 生成器包时在那里定义
//
// 【契约来源】v1 email/headers.go:47/153/167/2587
// ============================================================================

// ===================================================================
// 1. DkimExternalSources — 伪 DKIM 外部签名域名池
// ===================================================================

// DkimExternalSource 伪 DKIM 外部签名源
//
// v2 字段名首字母大写(导出),对应 v1 私有字段:
//   - Domain    ← domain
//   - Selectors ← selectors
//   - Weight    ← weight
//   - IsSESLike ← isSESLike
//   - RSABits   ← rsaBits
type DkimExternalSource struct {
	Domain    string   // d= 字段使用的外部域名
	Selectors []string // 候选 selector(每封邮件从中随机一个);IsSESLike=true 时忽略
	Weight    int      // 加权抽样权重(值越高被抽中概率越大)
	IsSESLike bool     // true 时 selector 每次动态生成 32 字符 base32 随机串
	RSABits   int      // RSA 密钥长度(1024/2048/4096),决定 b= base64 长度
}

// DkimExternalSources 62 项外部签名源(v1 dkimExternalSources 精确对齐)
//
// 【设计】伪签名故意将 d= 设为外部大厂域名(而非发件方真实域名),让接收方反垃圾系统
// 将"DKIM 校验失败"归因于"邮件经过外部中转链路时签名损坏"—— 这是邮件世界常态,
// 反垃圾系统对此宽容。
var DkimExternalSources = []DkimExternalSource{
	// ===== Google 系(~20%)=====
	{"gmail.com", []string{"20230601", "20221208", "20210112", "20161025"}, 20, false, 2048},
	{"googlemail.com", []string{"20230601", "20221208"}, 4, false, 2048},
	{"google.com", []string{"20221208", "20230601"}, 4, false, 2048},

	// ===== Microsoft 系(~16%)=====
	{"outlook.com", []string{"selector1", "selector2"}, 12, false, 2048},
	{"hotmail.com", []string{"selector1", "selector2"}, 7, false, 2048},
	{"live.com", []string{"selector1", "selector2"}, 4, false, 2048},
	{"microsoft.com", []string{"selector1", "selector2"}, 3, false, 2048},
	{"office365.com", []string{"selector1"}, 2, false, 2048},

	// ===== Yahoo 系(~8%,含日本 Yahoo 针对 docomo 场景加分)=====
	{"yahoo.com", []string{"s2048", "s1024", "s1"}, 6, false, 2048},
	{"yahoo.co.jp", []string{"s2048", "s1024"}, 6, false, 2048},
	{"ymail.com", []string{"s2048"}, 2, false, 2048},

	// ===== Apple 系(~4%)=====
	{"icloud.com", []string{"1a1hai", "sig1"}, 5, false, 2048},
	{"me.com", []string{"1a1hai"}, 2, false, 2048},

	// ===== Amazon SES(~6%,selector 每次动态 32 字符随机生成)=====
	{"amazonses.com", nil, 10, true, 2048},

	// ===== ESP 邮件服务商(~11%)=====
	{"sendgrid.net", []string{"s1", "smtpapi", "m1"}, 5, false, 2048},
	{"sendgrid.me", []string{"s1"}, 1, false, 2048},
	{"mailgun.org", []string{"k1", "mg", "pic"}, 4, false, 2048},
	{"mandrillapp.com", []string{"mandrill", "mte1"}, 3, false, 2048},
	{"mcsv.net", []string{"k2"}, 2, false, 2048},
	{"mtasv.net", []string{"20150623"}, 1, false, 2048},
	{"sparkpostmail.com", []string{"scph1220"}, 1, false, 2048},
	{"hubspotemail.net", []string{"hs1"}, 2, false, 2048},

	// ===== 日本运营商域(~10%)=====
	{"docomo.ne.jp", []string{"docomo", "mail"}, 5, false, 2048},
	{"softbank.ne.jp", []string{"sb", "softbank"}, 4, false, 2048},
	{"au.com", []string{"au", "default"}, 4, false, 2048},
	{"ezweb.ne.jp", []string{"ezweb"}, 3, false, 2048},
	{"kddi.com", []string{"kddi"}, 2, false, 2048},

	// ===== 日本本地邮件商(~5%)=====
	{"nifty.com", []string{"default"}, 2, false, 2048},
	{"biglobe.ne.jp", []string{"default"}, 2, false, 2048},
	{"so-net.ne.jp", []string{"s1024"}, 2, false, 1024},
	{"ocn.ad.jp", []string{"default"}, 1, false, 2048},
	{"plala.or.jp", []string{"default"}, 1, false, 2048},

	// ===== 韩国(~5%)=====
	{"naver.com", []string{"s2048", "naver"}, 3, false, 2048},
	{"daum.net", []string{"daum"}, 2, false, 2048},
	{"kakao.com", []string{"kakao"}, 2, false, 2048},
	{"hanmail.net", []string{"hanmail"}, 1, false, 1024},

	// ===== 欧洲(~5%)=====
	{"gmx.de", []string{"s1", "k1"}, 2, false, 2048},
	{"web.de", []string{"webde", "default"}, 2, false, 2048},
	{"mail.ru", []string{"mailru", "selector"}, 2, false, 2048},
	{"yandex.ru", []string{"mail", "yandex"}, 2, false, 2048},
	{"tutanota.com", []string{"tutanota"}, 1, false, 4096},

	// ===== 国内主流(~7%)=====
	{"163.com", []string{"s2048", "s1024"}, 3, false, 2048},
	{"qq.com", []string{"s201512", "s202004"}, 3, false, 2048},
	{"126.com", []string{"s2048"}, 2, false, 2048},
	{"sina.com", []string{"s1024"}, 1, false, 1024},
	{"sohu.com", []string{"sohu"}, 1, false, 1024},
	{"aliyun.com", []string{"aliyun"}, 2, false, 2048},
	{"foxmail.com", []string{"foxmail"}, 1, false, 1024},

	// ===== 企业 SaaS / 营销邮件(~6%)=====
	{"salesforce.com", []string{"200608"}, 1, false, 2048},
	{"pardot.com", []string{"pardotdkim"}, 1, false, 2048},
	{"linkedin.com", []string{"proddkim1024"}, 1, false, 1024},
	{"paypal.com", []string{"pp-dkim1"}, 1, false, 2048},
	{"adobe.com", []string{"s2048"}, 1, false, 2048},
	{"zoho.com", []string{"zmail"}, 1, false, 2048},
	{"zendesk.com", []string{"mail"}, 1, false, 2048},
	{"intercom-mail.com", []string{"intercom"}, 1, false, 2048},
	{"protonmail.com", []string{"protonmail"}, 1, false, 4096},
	{"fastmail.com", []string{"fm1"}, 1, false, 2048},

	// ===== 长尾欧美(~3%)=====
	{"fastmail.fm", []string{"fm1"}, 1, false, 2048},
	{"gmx.com", []string{"k1"}, 1, false, 2048},
	{"mailbox.org", []string{"mbo1"}, 1, false, 2048},
	{"runbox.com", []string{"runbox"}, 1, false, 2048},

	// ===== 日本运营商 / MVNO / ISP 扩展(~12%)=====
	{"i.softbank.jp", []string{"sb-iphone", "softbank"}, 5, false, 2048},
	{"ymobile.ne.jp", []string{"ymobile"}, 3, false, 2048},
	{"uqmobile.jp", []string{"uqmobile"}, 3, false, 2048},
	{"rakuten-mobile.jp", []string{"rakuten-mobile"}, 3, false, 2048},
	{"mineo.jp", []string{"mineo"}, 2, false, 2048},
	{"iijmio.jp", []string{"iijmio"}, 2, false, 2048},
	{"ocn.ne.jp", []string{"ocn", "default"}, 2, false, 2048},
	{"dion.ne.jp", []string{"dion"}, 1, false, 2048},
	{"odn.ne.jp", []string{"odn"}, 1, false, 1024},
	{"zaq.ne.jp", []string{"zaq"}, 1, false, 1024},
}

// ===================================================================
// 2. DkimCanonicalizations — DKIM 规范化算法加权池(c= 字段)
// ===================================================================

// DkimCanonicalization DKIM canonicalization 加权项
type DkimCanonicalization struct {
	Value  string
	Weight int
}

// DkimCanonicalizations 4 项(v1 dkimCanonicalizations 精确对齐)
//
// 【设计】按真实邮件世界的实际分布加权,避免 c= 永远是 relaxed/relaxed 形成指纹。
var DkimCanonicalizations = []DkimCanonicalization{
	{"relaxed/relaxed", 70},
	{"relaxed/simple", 15},
	{"simple/simple", 10},
	{"simple/relaxed", 5},
}

// ===================================================================
// 3. DkimHFieldsByStyle — DKIM h= 字段按 ESP 风格分组
// ===================================================================

// DkimHFieldsByStyle 6 种 ESP 风格 → h= 模板列表(v1 dkimHFieldsByStyle 精确对齐)
//
// 【设计】不同 ESP 的 h= 字段在大小写、顺序、长度上差异显著,按风格池模拟真实分布。
var DkimHFieldsByStyle = map[string][]string{
	"gmail": {
		"from:to:subject:date:message-id:mime-version:content-type",
		"from:to:subject:date:message-id:mime-version:reply-to",
		"to:cc:from:subject:message-id:date:mime-version",
	},
	"outlook": {
		"From:To:Subject:Date:Message-ID:Content-Type:Content-Transfer-Encoding:MIME-Version",
		"MIME-Version:Date:From:To:Subject:Message-ID:Content-Type:Content-Transfer-Encoding",
	},
	"yahoo": {
		"Received:From:Reply-To:Subject:Date:To:Message-ID:Content-Type:Content-Transfer-Encoding:MIME-Version",
		"Date:From:Reply-To:Subject:To:MIME-Version:Content-Type:Message-ID",
	},
	"ses": {
		"Date:From:Reply-To:To:Message-ID:Subject:MIME-Version:Content-Type:Content-Transfer-Encoding",
		"From:To:Subject:Date:Message-ID:MIME-Version:Content-Type",
	},
	// japan 风格:针对日本运营商 / MVNO / ISP 域名
	"japan": {
		"Received:From:Reply-To:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding",
		"From:Sender:Reply-To:To:Subject:Date:Message-ID:Content-Type:MIME-Version",
		"from:to:subject:date:message-id:mime-version:content-type:content-transfer-encoding",
	},
	"generic": {
		"From:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding",
		"from:to:subject:date:message-id:mime-version:content-type",
		"From:Reply-To:To:Subject:Date:Message-ID:Content-Type",
	},
}

// ===================================================================
// 4. YahooByPool — 雅虎 by mtaXXX.yahoo.co.jp 命名模式池
// ===================================================================

// YahooByPattern 雅虎 by 主机名生成模式
type YahooByPattern struct {
	Template string // 前缀如 "mta%04d.mail.otm.ynwp.yahoo.co.jp"
	StartNum int    // 起始编号(含)
	EndNum   int    // 结束编号(含)
}

// YahooByPool 6 项(v1 yahooByPool 精确对齐)
var YahooByPool = []YahooByPattern{
	{"mta%04d.mail.otm.ynwp.yahoo.co.jp", 1, 160},       // mta0001-0160.mail.otm
	{"mta%04d.mail.snz.ynwp.yahoo.co.jp", 2001, 2160},   // mta2001-2160.mail.snz
	{"mtaat%04d.mail.otm.ynwp.yahoo.co.jp", 1, 160},     // mtaat0001-0160.mail.otm
	{"mtaat%04d.mail.snz.ynwp.yahoo.co.jp", 2001, 2160}, // mtaat2001-2160.mail.snz
	{"mta%03d.kks.gm.yahoo.co.jp", 1, 160},              // mta001-160.kks.gm
	{"mta%03d.ssk.gm.yahoo.co.jp", 1, 160},              // mta001-160.ssk.gm
}
