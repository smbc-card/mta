package extended

import (
	"encoding/base64"
	"regexp"
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// 固定时间(与 v1-patched 一致):2026-08-06T15:52:01+09:00 JST
var fixedTime = time.Date(2026, 8, 6, 15, 52, 1, 0, time.FixedZone("JST", 9*3600))

func newTestProc(t *testing.T) *Processor {
	t.Helper()
	return New(random.NewFixedSource(42), clock.NewFixedClock(fixedTime))
}

// ===== A. RFC 2822 时间(13 个) =====

func TestProcess_RFC2822_Literals_9(t *testing.T) {
	p := newTestProc(t)
	// 9 个字面变量都应生成合法 RFC 2822 日期
	tokens := []string{
		"{RFC2822_DATE}", "{RFC2822_DATE_JST}", "{RFC2822_DATE_UTC}",
		"{RFC2822_DATE_GMT}", "{RFC2822_DATE_PST}", "{RFC2822_DATE_PDT}",
		"{RFC2822_DATE_EST}", "{RFC2822_DATE_CET}", "{RFC2822_DATE_WITH_JST}",
	}
	// 基本正则:Mon, 02 Jan 2006 15:04:05 -0700(可选后缀 (JST)/(GMT)/(PDT))
	re := regexp.MustCompile(`^[A-Z][a-z]{2}, \d{2} [A-Z][a-z]{2} \d{4} \d{2}:\d{2}:\d{2} [+\-]\d{4}( \([A-Z]{3}\))?$`)
	for _, tok := range tokens {
		t.Run(tok, func(t *testing.T) {
			got := p.Process(tok)
			if !re.MatchString(got) {
				t.Errorf("%q → %q 不匹配 RFC 2822 格式", tok, got)
			}
		})
	}
}

func TestProcess_RFC2822_JST_Content(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RFC2822_DATE_JST}")
	// fixedTime = 2026-08-06T15:52:01+09:00
	if got != "Thu, 06 Aug 2026 15:52:01 +0900" {
		t.Errorf("期望 'Thu, 06 Aug 2026 15:52:01 +0900',得到 %q", got)
	}
}

func TestProcess_RFC2822_UTC_Content(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RFC2822_DATE_UTC}")
	// UTC = JST - 9h = 06:52:01
	if got != "Thu, 06 Aug 2026 06:52:01 +0000" {
		t.Errorf("期望 UTC 版,得到 %q", got)
	}
}

func TestProcess_RFC2822_GMT_HasGMTSuffix(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RFC2822_DATE_GMT}")
	if !strings.HasSuffix(got, " (GMT)") {
		t.Errorf("GMT 应含 ' (GMT)' 后缀,得到 %q", got)
	}
}

func TestProcess_RFC2822_TZ_Param(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RFC2822_DATE_TZ:UTC}")
	// UTC 时区:与 UTC 字面结果一致
	if !strings.HasSuffix(got, "+0000") {
		t.Errorf("TZ:UTC 应以 +0000 结尾,得到 %q", got)
	}
}

func TestProcess_RFC2822_TZ_Fallback(t *testing.T) {
	p := newTestProc(t)
	// 无效时区名 → fallback UTC
	got := p.Process("{RFC2822_DATE_TZ:Invalid/Nonexistent}")
	if !strings.HasSuffix(got, "+0000") {
		t.Errorf("无效 TZ 应 fallback UTC (+0000),得到 %q", got)
	}
}

func TestProcess_RFC2822_Offset(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RFC2822_DATE_OFFSET:+0530}")
	if !strings.HasSuffix(got, "+0530") {
		t.Errorf("OFFSET:+0530 应以 +0530 结尾,得到 %q", got)
	}

	got = p.Process("{RFC2822_DATE_OFFSET:-0800}")
	if !strings.HasSuffix(got, "-0800") {
		t.Errorf("OFFSET:-0800 应以 -0800 结尾,得到 %q", got)
	}
}

func TestProcess_RFC2822_PastSec(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RFC2822_DATE_PAST_SEC:30}")
	// fixedTime - 30s = 15:51:31
	if got != "Thu, 06 Aug 2026 15:51:31 +0900" {
		t.Errorf("PAST_SEC:30 应减 30 秒,得到 %q", got)
	}
}

func TestProcess_RFC2822_PastRand(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RFC2822_DATE_PAST_RAND:1-60}")
	// 应是 JST 时区,时间在 15:51:01 ~ 15:52:00 之间
	re := regexp.MustCompile(`^Thu, 06 Aug 2026 15:5[12]:\d{2} \+0900$`)
	if !re.MatchString(got) {
		t.Errorf("PAST_RAND:1-60 应在合理范围内,得到 %q", got)
	}
}

// ===== B. ID(8 个) =====

func TestProcess_ID_Postfix_Long(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_POSTFIX_LONG}")
	if len(got) != 22 {
		t.Errorf("ID_POSTFIX_LONG 应 22 字符,得到 %d: %q", len(got), got)
	}
	if !regexp.MustCompile(`^[A-Za-z0-9]{22}$`).MatchString(got) {
		t.Errorf("应全为 base62,得到 %q", got)
	}
}

func TestProcess_ID_Gmail(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_GMAIL}")
	// 格式:{12hex}-{11hex}sm{11-13digit}.{1-2digit}
	re := regexp.MustCompile(`^[0-9a-f]{12}-[0-9a-f]{11}sm\d{11,13}\.\d{1,2}$`)
	if !re.MatchString(got) {
		t.Errorf("ID_GMAIL 格式不符,得到 %q", got)
	}
}

func TestProcess_ID_Bounce_Token(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_BOUNCE_TOKEN}")
	re := regexp.MustCompile(`^[A-Z0-9]{26}\.\d{5}$`)
	if !re.MatchString(got) {
		t.Errorf("ID_BOUNCE_TOKEN 格式不符,得到 %q", got)
	}
}

func TestProcess_ID_Amazon_SES(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_AMAZON_SES}")
	re := regexp.MustCompile(`^[0-9a-f]{16}-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}-\d{6}$`)
	if !re.MatchString(got) {
		t.Errorf("ID_AMAZON_SES 格式不符,得到 %q", got)
	}
}

func TestProcess_ID_Biccamera(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_BICCAMERA}")
	re := regexp.MustCompile(`^[a-z0-9]{12}$`)
	if !re.MatchString(got) {
		t.Errorf("ID_BICCAMERA 格式不符,得到 %q", got)
	}
}

func TestProcess_ID_Exim_Queue(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_EXIM_QUEUE}")
	re := regexp.MustCompile(`^1[A-Za-z0-9]{6,7}-[A-Za-z0-9]{6}-[A-Za-z0-9]{2}$`)
	if !re.MatchString(got) {
		t.Errorf("ID_EXIM_QUEUE 格式不符,得到 %q", got)
	}
}

func TestProcess_ID_Queue_Param(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_QUEUE:15}")
	if len(got) != 15 {
		t.Errorf("ID_QUEUE:15 应 15 字符,得到 %d: %q", len(got), got)
	}
	if !regexp.MustCompile(`^[A-Z0-9]{15}$`).MatchString(got) {
		t.Errorf("应全为大写字母 + 数字,得到 %q", got)
	}
}

func TestProcess_ID_Queue_Clamp(t *testing.T) {
	p := newTestProc(t)
	// N=0 → fallback 11
	got := p.Process("{ID_QUEUE:0}")
	if len(got) != 11 {
		t.Errorf("ID_QUEUE:0 应 fallback 为 11,得到 %d", len(got))
	}
	// N=100 → clamp 64
	got = p.Process("{ID_QUEUE:100}")
	if len(got) != 64 {
		t.Errorf("ID_QUEUE:100 应 clamp 为 64,得到 %d", len(got))
	}
}

func TestProcess_ID_Hex_Param(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{ID_HEX:20}")
	if len(got) != 20 {
		t.Errorf("ID_HEX:20 应 20 字符,得到 %d", len(got))
	}
	if !regexp.MustCompile(`^[0-9a-f]{20}$`).MatchString(got) {
		t.Errorf("应全为 hex,得到 %q", got)
	}
}

// ===== C. IP(10 个) =====

var ipv4Re = regexp.MustCompile(`^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$`)

func TestProcess_IP_Loopback(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_LOOPBACK}")
	if got != "127.0.0.1" {
		t.Errorf("IP_LOOPBACK 应为 127.0.0.1,得到 %q", got)
	}
}

func TestProcess_IP_Yahoo_JP(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_YAHOO_JP}")
	if !ipv4Re.MatchString(got) {
		t.Errorf("IP_YAHOO_JP 应为 IPv4,得到 %q", got)
	}
}

func TestProcess_IP_Softbank_172(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_SOFTBANK_172}")
	if !strings.HasPrefix(got, "172.") {
		t.Errorf("IP_SOFTBANK_172 应以 172. 开头,得到 %q", got)
	}
	sub := ipv4Re.FindStringSubmatch(got)
	if len(sub) < 5 {
		t.Fatalf("IPv4 解析失败: %q", got)
	}
	second := sub[2]
	// 第二字节应在 16-31
	if second < "16" || second > "31" {
		t.Errorf("SoftBank 第二字节应在 16-31,得到 %s (完整:%s)", second, got)
	}
}

func TestProcess_IP_Docomo_Internal(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_DOCOMO_INTERNAL}")
	if !strings.HasPrefix(got, "10.200.") {
		t.Errorf("IP_DOCOMO_INTERNAL 应以 10.200. 开头,得到 %q", got)
	}
}

func TestProcess_IP_Private_10(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_PRIVATE_10}")
	if !strings.HasPrefix(got, "10.") {
		t.Errorf("IP_PRIVATE_10 应以 10. 开头,得到 %q", got)
	}
}

func TestProcess_IP_Private_172(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_PRIVATE_172}")
	if !strings.HasPrefix(got, "172.") {
		t.Errorf("IP_PRIVATE_172 应以 172. 开头,得到 %q", got)
	}
}

func TestProcess_IP_Private_192(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_PRIVATE_192}")
	if !strings.HasPrefix(got, "192.168.") {
		t.Errorf("IP_PRIVATE_192 应以 192.168. 开头,得到 %q", got)
	}
}

func TestProcess_IP_Gmail_GW(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_GMAIL_GW}")
	if !ipv4Re.MatchString(got) {
		t.Errorf("IP_GMAIL_GW 应为 IPv4,得到 %q", got)
	}
}

func TestProcess_IP_Aws_SES(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_AWS_SES}")
	if !ipv4Re.MatchString(got) {
		t.Errorf("IP_AWS_SES 应为 IPv4,得到 %q", got)
	}
}

func TestProcess_IP_Public_Global(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{IP_PUBLIC_GLOBAL}")
	if !ipv4Re.MatchString(got) {
		t.Errorf("IP_PUBLIC_GLOBAL 应为 IPv4,得到 %q", got)
	}
	// 不应是 127.x / 10.x / 192.168.x / 172.16-31.x 等私网
	if strings.HasPrefix(got, "127.") || strings.HasPrefix(got, "10.") || strings.HasPrefix(got, "192.168.") {
		t.Errorf("IP_PUBLIC_GLOBAL 不应是私网 IP,得到 %q", got)
	}
}

// ===== D. 域名(15 个) =====

func TestProcess_Domain_YAHOO_MX(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_YAHOO_MX}")
	if !strings.Contains(got, "yahoo.co.jp") {
		t.Errorf("DOMAIN_YAHOO_MX 应含 yahoo.co.jp,得到 %q", got)
	}
}

func TestProcess_Domain_YAHOO_EHLO(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_YAHOO_EHLO}")
	re := regexp.MustCompile(`^mta\d{3}\.(kks|kth|ssk)\.gm\.yahoo\.co\.jp$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_YAHOO_EHLO 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_YAHOO_GW(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_YAHOO_GW}")
	re := regexp.MustCompile(`^smtp-gw-f\d{2}h\d{3}c\d{2}\.prod\.goats\.kks\.ynwl\.yahoo\.co\.jp$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_YAHOO_GW 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_Gmail_Out(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_GMAIL_OUT}")
	// 应含 gmail.com 或 google.com
	if !strings.Contains(got, "gmail.com") && !strings.Contains(got, "google.com") {
		t.Errorf("DOMAIN_GMAIL_OUT 应含 gmail/google 域,得到 %q", got)
	}
}

func TestProcess_Domain_Gmail_Host(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_GMAIL_HOST}")
	re := regexp.MustCompile(`^server-\d+-\d+-\d+-\d+\.da\.direct$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_GMAIL_HOST 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_Docomo_Bill(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_DOCOMO_BILL}")
	re := regexp.MustCompile(`^mail\d{1,2}\.docomo-bill\.ne\.jp$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_DOCOMO_BILL 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_Docomo_Local(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_DOCOMO_LOCAL}")
	if got != "localhost.docomo.ne.jp" {
		t.Errorf("DOMAIN_DOCOMO_LOCAL 应固定,得到 %q", got)
	}
}

func TestProcess_Domain_Docomo_Mfsmax(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_DOCOMO_MFSMAX}")
	if got != "mfsmax.docomo.ne.jp" {
		t.Errorf("DOMAIN_DOCOMO_MFSMAX 应固定,得到 %q", got)
	}
}

func TestProcess_Domain_Softbank(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_SOFTBANK_EBMKY}")
	re := regexp.MustCompile(`^ebmky1\d{2}sc\.softbank\.ad\.jp$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_SOFTBANK_EBMKY 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_AU(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_AU}")
	re := regexp.MustCompile(`^mta-snd-e\d{2}\.au\.com$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_AU 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_Mitsui(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_MITSUI}")
	if !strings.Contains(got, "vpass") && !strings.Contains(got, "smbc") {
		t.Errorf("DOMAIN_MITSUI 应含 vpass 或 smbc,得到 %q", got)
	}
}

func TestProcess_Domain_Biccamera(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_BICCAMERA}")
	re := regexp.MustCompile(`^mta\d{1,2}\.ml\.biccamera\.com$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_BICCAMERA 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_Yodobashi(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_YODOBASHI}")
	re := regexp.MustCompile(`^yctcue\d{2}\.yodobashi\.co\.jp$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_YODOBASHI 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_Ltike(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_LTIKE}")
	re := regexp.MustCompile(`^md\d{1,2}\.l-tike\.com$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_LTIKE 格式不符,得到 %q", got)
	}
}

func TestProcess_Domain_Amazonses_Out(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{DOMAIN_AMAZONSES_OUT}")
	re := regexp.MustCompile(`^[ae]\d+-[a-z0-9]{4,8}\.smtp-out\.amazonses\.com$`)
	if !re.MatchString(got) {
		t.Errorf("DOMAIN_AMAZONSES_OUT 格式不符,得到 %q", got)
	}
}

// ===== E. 协议(6 个) =====

func TestProcess_TLS_Version(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{TLS_VERSION}")
	if got != "TLS1_3" && got != "TLS1_2" {
		t.Errorf("TLS_VERSION 应为 TLS1_2/3,得到 %q", got)
	}
}

func TestProcess_TLS_Cipher(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{TLS_CIPHER}")
	valid := []string{"TLS_AES_256_GCM_SHA384", "TLS_AES_128_GCM_SHA256", "TLS_CHACHA20_POLY1305_SHA256",
		"ECDHE-RSA-AES256-GCM-SHA384", "ECDHE-RSA-AES128-GCM-SHA256", "ECDHE-RSA-CHACHA20-POLY1305",
		"ECDHE-ECDSA-AES256-GCM-SHA384", "ECDHE-ECDSA-CHACHA20-POLY1305"}
	found := false
	for _, v := range valid {
		if got == v {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("TLS_CIPHER 应为已知 cipher 之一,得到 %q", got)
	}
}

func TestProcess_TLS_Bits(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{TLS_BITS}")
	valid := []string{"256/256", "128/128", "256/128"}
	found := false
	for _, v := range valid {
		if got == v {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("TLS_BITS 应为已知比特组合,得到 %q", got)
	}
}

func TestProcess_SMTP_Protocol(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{SMTP_PROTOCOL}")
	valid := []string{"ESMTP", "ESMTPS", "ESMTPSA", "SMTP"}
	found := false
	for _, v := range valid {
		if got == v {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("SMTP_PROTOCOL 应为已知协议之一,得到 %q", got)
	}
}

func TestProcess_MTA_Type(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{MTA_TYPE}")
	valid := []string{"Postfix", "sendmail", "Exim"}
	found := false
	for _, v := range valid {
		if got == v {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("MTA_TYPE 应为已知 MTA,得到 %q", got)
	}
}

func TestProcess_MTA_Version_Banner(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{MTA_VERSION_BANNER}")
	if !strings.HasPrefix(got, "(") || !strings.HasSuffix(got, ")") {
		t.Errorf("MTA_VERSION_BANNER 应用 () 包裹,得到 %q", got)
	}
}

// ===== F. JWT(1 个) =====

func TestProcess_JWT_Token_Structure(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{JWT_TOKEN}")
	// 应是 3 段以 . 分隔
	parts := strings.Split(got, ".")
	if len(parts) != 3 {
		t.Fatalf("JWT 应为 3 段,得到 %d 段: %q", len(parts), got)
	}
	// header 应是已知的 5 个之一
	validHeaders := jwtHeaderPool
	found := false
	for _, h := range validHeaders {
		if parts[0] == h {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("JWT header 应为已知,得到 %q", parts[0])
	}
	// payload 和 signature 都应是合法 base64url(无 padding)
	if _, err := base64.RawURLEncoding.DecodeString(parts[1]); err != nil {
		t.Errorf("JWT payload 应是合法 base64url,得到 %q, err: %v", parts[1], err)
	}
	if _, err := base64.RawURLEncoding.DecodeString(parts[2]); err != nil {
		t.Errorf("JWT signature 应是合法 base64url,得到 %q, err: %v", parts[2], err)
	}
}

func TestProcess_JWT_Token_HS512_SigLen(t *testing.T) {
	// 强制拿 HS512 header 的 case:多跑几次(种子固定,总能命中)
	found := false
	for seed := int64(1); seed < 20; seed++ {
		p := New(random.NewFixedSource(seed), clock.NewFixedClock(fixedTime))
		got := p.Process("{JWT_TOKEN}")
		parts := strings.Split(got, ".")
		if parts[0] == "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9" { // HS512
			sigBytes, _ := base64.RawURLEncoding.DecodeString(parts[2])
			if len(sigBytes) != 64 {
				t.Errorf("HS512 signature 应为 64 字节,得到 %d", len(sigBytes))
			}
			found = true
			break
		}
	}
	if !found {
		t.Skip("20 seeds 内没有命中 HS512,跳过(不影响主逻辑)")
	}
}

// ===== 集成测试 =====

func TestProcess_MultipleExtendedTogether(t *testing.T) {
	p := newTestProc(t)
	template := "IP: {IP_LOOPBACK}, TLS: {TLS_VERSION}, MTA: {MTA_TYPE}, Time: {RFC2822_DATE_JST}"
	got := p.Process(template)
	if !strings.Contains(got, "127.0.0.1") {
		t.Errorf("应含 loopback IP,得到 %q", got)
	}
	if !strings.Contains(got, "Thu, 06 Aug 2026 15:52:01 +0900") {
		t.Errorf("应含固定 JST 时间,得到 %q", got)
	}
}

func TestProcess_EmptyContent(t *testing.T) {
	p := newTestProc(t)
	if p.Process("") != "" {
		t.Error("空 content 应返回空")
	}
}

func TestProcess_NoVariables(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("plain no vars")
	if got != "plain no vars" {
		t.Errorf("无变量应原样返回,得到 %q", got)
	}
}

// ===== 辅助函数单测 =====

func TestReplaceLiteral_MultipleInstances(t *testing.T) {
	// {X} 在同一 content 里出现 3 次,应有 3 个不同结果
	counter := 0
	got := replaceLiteral("{X} {X} {X}", "{X}", func() string {
		counter++
		return string(rune('A' + counter - 1))
	})
	if got != "A B C" {
		t.Errorf("每次 gen 应独立调用,得到 %q", got)
	}
}

func TestReplaceLiteral_CaseSensitive(t *testing.T) {
	// {X} 和 {x} 都应替换
	got := replaceLiteral("{X} and {x}", "{X}", func() string { return "Y" })
	if got != "Y and Y" {
		t.Errorf("大写小写都应替换,得到 %q", got)
	}
}

func TestRandStringFrom_ZeroLength(t *testing.T) {
	rng := random.NewFixedSource(42)
	got := randStringFrom(rng, 0, charsetHex)
	if got != "" {
		t.Errorf("n=0 应返回空,得到 %q", got)
	}
	got = randStringFrom(rng, -5, charsetHex)
	if got != "" {
		t.Errorf("n<0 应返回空,得到 %q", got)
	}
}

func TestCidrRandomIP_Valid(t *testing.T) {
	rng := random.NewFixedSource(42)
	// 124.83.128.0/17 → 应产生 124.83.128.0 ~ 124.83.255.255 内的 IP
	got := cidrRandomIP(rng, "124.83.128.0/17")
	if !ipv4Re.MatchString(got) {
		t.Errorf("应为 IPv4,得到 %q", got)
	}
	if !strings.HasPrefix(got, "124.83.") {
		t.Errorf("应在 CIDR 内,得到 %q", got)
	}
}

func TestCidrRandomIP_Invalid(t *testing.T) {
	rng := random.NewFixedSource(42)
	got := cidrRandomIP(rng, "not-a-cidr")
	if got != "" {
		t.Errorf("非法 CIDR 应返回空,得到 %q", got)
	}
}

func TestIsInAnyCIDR(t *testing.T) {
	cidrs := []string{"10.0.0.0/8", "192.168.0.0/16"}
	if !isInAnyCIDR("10.5.5.5", cidrs) {
		t.Error("10.5.5.5 应在 10.0.0.0/8 内")
	}
	if !isInAnyCIDR("192.168.1.1", cidrs) {
		t.Error("192.168.1.1 应在 192.168.0.0/16 内")
	}
	if isInAnyCIDR("8.8.8.8", cidrs) {
		t.Error("8.8.8.8 不应在私网内")
	}
	if isInAnyCIDR("not-ip", cidrs) {
		t.Error("非 IP 应返回 false")
	}
}

// ===== 复现性 =====

func TestProcess_Deterministic(t *testing.T) {
	p1 := newTestProc(t)
	p2 := newTestProc(t)
	template := "{ID_POSTFIX_LONG} {IP_YAHOO_JP} {DOMAIN_YAHOO_MX} {TLS_CIPHER}"
	got1 := p1.Process(template)
	got2 := p2.Process(template)
	if got1 != got2 {
		t.Errorf("固定种子应复现:\n%q\n%q", got1, got2)
	}
}

// ===== Golden 冻结 =====

func TestProcess_Golden_FullPipeline(t *testing.T) {
	p := newTestProc(t)
	template := "Received: from {DOMAIN_YAHOO_EHLO} ({IP_YAHOO_JP})\n" +
		"        by mail.example.com with {SMTP_PROTOCOL} id {ID_QUEUE:12};\n" +
		"        {RFC2822_DATE_JST}\n" +
		"X-Bounce-Id: {ID_BOUNCE_TOKEN}\n" +
		"X-JWT: {JWT_TOKEN}"

	got := p.Process(template)

	// 关键子串
	if !strings.Contains(got, "yahoo.co.jp") {
		t.Errorf("应含 yahoo.co.jp,得到:\n%s", got)
	}
	if !strings.Contains(got, "Thu, 06 Aug 2026 15:52:01 +0900") {
		t.Errorf("应含固定 JST 时间,得到:\n%s", got)
	}
	// bounce token 格式
	if !regexp.MustCompile(`X-Bounce-Id: [A-Z0-9]{26}\.\d{5}`).MatchString(got) {
		t.Errorf("Bounce-Id 格式应正确,得到:\n%s", got)
	}
	// JWT 3 段
	if !regexp.MustCompile(`X-JWT: [A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+`).MatchString(got) {
		t.Errorf("JWT 格式应正确,得到:\n%s", got)
	}
}
