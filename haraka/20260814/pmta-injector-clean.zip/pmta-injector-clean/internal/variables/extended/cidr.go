package extended

import (
	"encoding/binary"
	"fmt"
	"net"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// cidrRandomIP 从 CIDR 段内随机取一个 IPv4
//
// 【格式】cidr 形如 "124.83.128.0/17"
// 【返回】"124.83.145.87" 形式的 IPv4 字符串;解析失败返回空串
//
// 【实现】
//  1. net.ParseCIDR 解析出 net.IPNet
//  2. mask 转 uint32 掩码
//  3. base IP 转 uint32
//  4. hostBits = 32 - prefixLen,可用主机数 = 1 << hostBits
//  5. random.Source.Int63() % 主机数 → 随机 host 部分
//  6. IP = base | host
func cidrRandomIP(rng random.Source, cidr string) string {
	_, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		return ""
	}
	// 只支持 IPv4
	ip4 := ipnet.IP.To4()
	if ip4 == nil {
		return ""
	}

	baseInt := binary.BigEndian.Uint32(ip4)
	ones, _ := ipnet.Mask.Size()
	hostBits := 32 - ones

	// /32 → 单一 IP,直接返回
	if hostBits == 0 {
		return ip4.String()
	}

	// /31 或宽掩码 → 主机数 = 1 << hostBits
	// hostBits <= 24(/8 最宽)才安全;/0 全公网理论上要 2^32,但 v2 生产的 CIDR 池 prefix ≥ /8
	if hostBits > 24 {
		hostBits = 24 // 兜底:避免溢出
	}
	hostCount := uint32(1) << uint32(hostBits)

	// 用 Int63() % hostCount 生成 host 部分
	hostPart := uint32(rng.Int63() & int64(hostCount-1))

	ipInt := baseInt | hostPart
	var out [4]byte
	binary.BigEndian.PutUint32(out[:], ipInt)
	return fmt.Sprintf("%d.%d.%d.%d", out[0], out[1], out[2], out[3])
}

// isInAnyCIDR 判断 IP 是否落在任一 CIDR 内
//
// 【用途】IP_PUBLIC_GLOBAL 生成后验证是否落在 NonRoutableCidrs 内(排除)
func isInAnyCIDR(ip string, cidrs []string) bool {
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return false
	}
	for _, cidr := range cidrs {
		_, ipnet, err := net.ParseCIDR(cidr)
		if err != nil {
			continue
		}
		if ipnet.Contains(parsed) {
			return true
		}
	}
	return false
}
