package extended

import (
	"strings"

	"__MODULE_PLACEHOLDER__/internal/random"
)

// ===== 字符集常量(与 v1 email/variables_ext.go:194-200 一致)=====

const (
	charsetUpperNum  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	charsetLowerNum  = "abcdefghijklmnopqrstuvwxyz0123456789"
	charsetHex       = "0123456789abcdef"
	charsetBase62    = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
	charsetDigits    = "0123456789"
)

// randStringFrom 从 charset 里生成 n 位随机字符串
//
// 【与 v1 vp.randStringFrom 一致】用注入的 random.Source(而非 v1 的 hg.random)
// 【n <= 0 兜底】返回空串,不 panic
func randStringFrom(rng random.Source, n int, charset string) string {
	if n <= 0 {
		return ""
	}
	b := make([]byte, n)
	for i := range b {
		b[i] = charset[rng.Intn(len(charset))]
	}
	return string(b)
}

// replaceLiteral 将 content 中所有出现的 token(大写 + 小写双形式)替换为 gen() 的输出
//
// 【关键行为】每次替换都调用 gen() → 使每个实例都不同
// (不像 strings.ReplaceAll 那样全用同一个值)
//
// 【与 v1 vp.replaceLiteral 一致】—— 从 v1 移植的完整逻辑
//
// 【为什么大写小写各扫一遍】v1 契约要求 {TOKEN} 和 {token} 都支持;此实现只扫 2 遍
// 不用正则,是因为 token 是 literal(无参数),字符串查找比正则更快
func replaceLiteral(content, token string, gen func() string) string {
	for _, t := range []string{token, strings.ToLower(token)} {
		for {
			idx := strings.Index(content, t)
			if idx < 0 {
				break
			}
			content = content[:idx] + gen() + content[idx+len(t):]
		}
	}
	return content
}
