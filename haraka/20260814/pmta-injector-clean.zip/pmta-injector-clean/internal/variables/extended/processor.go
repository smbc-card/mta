// Package extended 实现 53 个"扩展变量"(依赖 data pool + 时区 + 复杂格式的所有变量)
//
// 【与 v1 对比】
//   - v1 email/variables_ext.go(655 行)
//   - v2 internal/variables/extended/(10 文件)
//
// 【53 变量分组】
//   - A 时间(13):9 字面 RFC2822_DATE_* + 4 参数化(_TZ / _OFFSET / _PAST_SEC / _PAST_RAND)
//   - B ID(8):6 字面(ID_POSTFIX_LONG/GMAIL/BOUNCE_TOKEN/AMAZON_SES/BICCAMERA/EXIM_QUEUE)+ 2 参数化(ID_QUEUE:N / ID_HEX:N)
//   - C IP(10):IP_YAHOO_JP/SOFTBANK_172/DOCOMO_INTERNAL/GMAIL_GW/PRIVATE_10/172/192/LOOPBACK/PUBLIC_GLOBAL/AWS_SES
//   - D 域名(15):DOMAIN_YAHOO_MX/EHLO/GW/GMAIL_OUT/HOST/DOCOMO_BILL/LOCAL/MFSMAX/SOFTBANK_EBMKY/AU/MITSUI/BICCAMERA/YODOBASHI/LTIKE/AMAZONSES_OUT
//   - E 协议(6):TLS_VERSION/TLS_CIPHER/TLS_BITS/SMTP_PROTOCOL/MTA_TYPE/MTA_VERSION_BANNER
//   - F JWT(1):JWT_TOKEN(dummy,与 v1 一致)
//
// 【依赖】
//   - internal/random —— 所有随机变量的种子源
//   - internal/clock —— RFC2822 时间变量的时钟源
//   - internal/data —— YahooCidrsPool / NonRoutableCidrsPool(仅 IP_YAHOO_JP / IP_PUBLIC_GLOBAL 用)
//   - 不依赖 internal/config —— extended 无 config 参数
//   - 不依赖 internal/variables/basic —— 独立包(D15-1=A)
//
// 【线程安全】非并发安全 —— 生产建议每个 worker 一个 Processor 实例(与 v1 一致)
package extended

import (
	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// Processor extended 变量处理器
//
// 【状态】无(所有变量都是 stateless,不像 basic 里的 CUSTOM:seq 计数器)
type Processor struct {
	rng random.Source
	clk clock.Clock
}

// New 创建 extended 处理器
//
// 【参数】
//   - rng:必需(nil 会 panic on first use)
//   - clk:必需(同上,仅时间变量用)
//
// 【与 basic.New 差异】不需要 cfg 参数 —— extended 变量都不依赖运行时配置
func New(rng random.Source, clk clock.Clock) *Processor {
	return &Processor{
		rng: rng,
		clk: clk,
	}
}

// Process 依次处理所有 extended 变量
//
// 【顺序】与 v1 email/variables_ext.go::processExtendedVariables 一致:
//  1. A 时间(参数化先 → 字面后)
//  2. B ID(参数化先 → 字面后)
//  3. C IP 池
//  4. D 域名池
//  5. E SMTP/TLS 协议
//  6. F JWT
//
// 【为什么固定这个顺序】extended 变量不嵌套(v1 一致);顺序主要为可读性,组间无冲突
// 【为什么参数化在字面前】参数化正则可能匹配字面变量的前缀(如 RFC2822_DATE_TZ:name 若在字面后处理,
// 字面 {RFC2822_DATE} 会先被替换,破坏 _TZ 的匹配)
func (p *Processor) Process(content string) string {
	if content == "" {
		return content
	}

	content = p.processRFC2822Variables(content)
	content = p.processIDVariables(content)
	content = p.processExtIPVariables(content)
	content = p.processExtDomainVariables(content)
	content = p.processProtocolVariables(content)
	content = p.processJWTVariables(content)

	return content
}
