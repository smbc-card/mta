package extended

import (
	"fmt"
	"regexp"
	"strconv"
)

// ===== 参数化正则 =====
var (
	// {ID_QUEUE:N} —— N 位大写字母 + 数字(Postfix queue ID 风格)
	reIDQueue = regexp.MustCompile(`(?i)\{ID_QUEUE:(\d+)\}`)

	// {ID_HEX:N} —— N 位 hex
	reIDHex = regexp.MustCompile(`(?i)\{ID_HEX:(\d+)\}`)
)

// processIDVariables 处理 8 个 ID 变量
//
// 【参数化 2 个】
//   - {ID_QUEUE:N}   N 位大写字母 + 数字(默认 11,最大 64)
//   - {ID_HEX:N}     N 位 hex(默认 16,最大 256)
//
// 【字面 6 个】
//   - {ID_POSTFIX_LONG}   22 字符 base62
//   - {ID_GMAIL}          Gmail SMTPSA:{12hex}-{11hex}sm{11-13digit}.{1-2digit}
//   - {ID_BOUNCE_TOKEN}   {26 大写数字}.{5 数字}
//   - {ID_AMAZON_SES}     SES Message-ID:{16}-{8}-{4}-{4}-{4}-{12}-{6}(全 hex 除末段 digit)
//   - {ID_BICCAMERA}      12 字符小写字母 + 数字
//   - {ID_EXIM_QUEUE}     Exim queue:1{6-7 base62}-{6 base62}-{2 base62}
func (p *Processor) processIDVariables(content string) string {
	// === 参数化 ===

	content = reIDQueue.ReplaceAllStringFunc(content, func(match string) string {
		sub := reIDQueue.FindStringSubmatch(match)
		if len(sub) < 2 {
			return match
		}
		n, _ := strconv.Atoi(sub[1])
		if n < 1 {
			n = 11
		}
		if n > 64 {
			n = 64
		}
		return randStringFrom(p.rng, n, charsetUpperNum)
	})

	content = reIDHex.ReplaceAllStringFunc(content, func(match string) string {
		sub := reIDHex.FindStringSubmatch(match)
		if len(sub) < 2 {
			return match
		}
		n, _ := strconv.Atoi(sub[1])
		if n < 1 {
			n = 16
		}
		if n > 256 {
			n = 256
		}
		return randStringFrom(p.rng, n, charsetHex)
	})

	// === 字面(每次替换独立 gen)===

	content = replaceLiteral(content, "{ID_POSTFIX_LONG}", func() string {
		return randStringFrom(p.rng, 22, charsetBase62)
	})

	content = replaceLiteral(content, "{ID_GMAIL}", func() string {
		nDigit := 11 + p.rng.Intn(3) // 11-13
		nTail := 1 + p.rng.Intn(2)   // 1-2
		return fmt.Sprintf("%s-%ssm%s.%s",
			randStringFrom(p.rng, 12, charsetHex),
			randStringFrom(p.rng, 11, charsetHex),
			randStringFrom(p.rng, nDigit, charsetDigits),
			randStringFrom(p.rng, nTail, charsetDigits))
	})

	content = replaceLiteral(content, "{ID_BOUNCE_TOKEN}", func() string {
		return randStringFrom(p.rng, 26, charsetUpperNum) + "." + randStringFrom(p.rng, 5, charsetDigits)
	})

	content = replaceLiteral(content, "{ID_AMAZON_SES}", func() string {
		return fmt.Sprintf("%s-%s-%s-%s-%s-%s-%s",
			randStringFrom(p.rng, 16, charsetHex),
			randStringFrom(p.rng, 8, charsetHex),
			randStringFrom(p.rng, 4, charsetHex),
			randStringFrom(p.rng, 4, charsetHex),
			randStringFrom(p.rng, 4, charsetHex),
			randStringFrom(p.rng, 12, charsetHex),
			randStringFrom(p.rng, 6, charsetDigits))
	})

	content = replaceLiteral(content, "{ID_BICCAMERA}", func() string {
		return randStringFrom(p.rng, 12, charsetLowerNum)
	})

	content = replaceLiteral(content, "{ID_EXIM_QUEUE}", func() string {
		mid := 6 + p.rng.Intn(2) // 6-7 字符
		return fmt.Sprintf("1%s-%s-%s",
			randStringFrom(p.rng, mid, charsetBase62),
			randStringFrom(p.rng, 6, charsetBase62),
			randStringFrom(p.rng, 2, charsetBase62))
	})

	return content
}
