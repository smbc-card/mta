# internal/variables/extended

**用途**:实现 53 个"扩展变量"(依赖 data pool + 时区 + 复杂格式的变量)。basic 部分(55 变量)在 `internal/variables/basic`。

## 文件组织

| 文件 | 变量组 | 数量 |
|------|--------|------|
| `processor.go` | Processor struct + New + Process 主入口 | — |
| `helpers.go` | charset 常量 + randStringFrom + replaceLiteral | — |
| `cidr.go` | cidrRandomIP + isInAnyCIDR(net.ParseCIDR 封装) | — |
| `time.go` | A. RFC 2822 时间(9 字面 + 4 参数化) | **13** |
| `id.go` | B. ID 变量(6 字面 + 2 参数化) | **8** |
| `ip.go` | C. IP 池变量(依赖 data.YahooCidrsPool / NonRoutableCidrsPool) | **10** |
| `domain.go` | D. 域名池变量 | **15** |
| `protocol.go` | E. TLS / SMTP / MTA 协议变量 | **6** |
| `jwt.go` | F. JWT_TOKEN(dummy,与 v1 一致) | **1** |
| `extended_test.go` | 50+ 测试 + Golden 冻结 | — |
| **合计** | | **53 变量** |

## 快速开始

```go
import (
    "__MODULE_PLACEHOLDER__/internal/clock"
    "__MODULE_PLACEHOLDER__/internal/random"
    "__MODULE_PLACEHOLDER__/internal/variables/extended"
)

// 生产用
proc := extended.New(random.NewSystemSource(), clock.NewSystemClock())

// 无 Config 参数(与 basic 不同)—— extended 变量都是 stateless
result := proc.Process("From {DOMAIN_YAHOO_MX} ({IP_YAHOO_JP}), Time: {RFC2822_DATE_JST}")
// → "From mta4321.mail.otm.ynwp.yahoo.co.jp (124.83.145.87), Time: Thu, 06 Aug 2026 15:52:01 +0900"
```

## 53 变量清单

### A. RFC 2822 时间(13)

**字面 9 个**:

- `{RFC2822_DATE}` → 默认 JST
- `{RFC2822_DATE_JST/UTC/GMT/PST/PDT/EST/CET}` → 各时区
- `{RFC2822_DATE_WITH_JST}` → JST + " (JST)" 后缀
- `{RFC2822_DATE_GMT}` → GMT + " (GMT)" 后缀
- `{RFC2822_DATE_PDT}` → PDT + " (PDT)" 后缀

**参数化 4 个**:

- `{RFC2822_DATE_TZ:Asia/Tokyo}` → LoadLocation(失败 fallback UTC)
- `{RFC2822_DATE_OFFSET:+0900}` → 直接构造 FixedZone
- `{RFC2822_DATE_PAST_SEC:30}` → 当前 - 30s(JST)
- `{RFC2822_DATE_PAST_RAND:1-3600}` → 当前 - Rand(1, 3600) s(JST)

### B. ID(8)

**字面 6 个**:

- `{ID_POSTFIX_LONG}` → 22 char base62
- `{ID_GMAIL}` → `{12hex}-{11hex}sm{11-13digit}.{1-2digit}`
- `{ID_BOUNCE_TOKEN}` → `{26 upper/num}.{5 digit}`
- `{ID_AMAZON_SES}` → `{16}-{8}-{4}-{4}-{4}-{12}-{6}`(全 hex 除末段)
- `{ID_BICCAMERA}` → 12 char lower/num
- `{ID_EXIM_QUEUE}` → `1{6-7 base62}-{6 base62}-{2 base62}`

**参数化 2 个**:

- `{ID_QUEUE:N}` → N char upper/num(默认 11,clamp [1, 64])
- `{ID_HEX:N}` → N char hex(默认 16,clamp [1, 256])

### C. IP(10)

- `{IP_YAHOO_JP}` → data.YahooCidrsPool 里随机段 → 段内随机 IP
- `{IP_SOFTBANK_172}` → 172.16-31.x.x
- `{IP_DOCOMO_INTERNAL}` → 10.200.x.x
- `{IP_GMAIL_GW}` → Google 6 个已知出口段
- `{IP_PRIVATE_10}` → 10.x.x.x
- `{IP_PRIVATE_172}` → 172.16-31.x.x
- `{IP_PRIVATE_192}` → 192.168.x.x
- `{IP_LOOPBACK}` → 127.0.0.1(固定)
- `{IP_PUBLIC_GLOBAL}` → 随机公网 IP(排除 NonRoutableCidrsPool)
- `{IP_AWS_SES}` → AWS SES 6 个已知出口段

### D. 域名(15)

Yahoo 3 + Gmail 2 + Docomo 3 + SoftBank/AU/三井/BicCamera/淀桥/L-Tike/Amazon SES 出口 各 1 = **15**

### E. 协议(6)

- `{TLS_VERSION}` / `{TLS_CIPHER}` / `{TLS_BITS}`
- `{SMTP_PROTOCOL}` / `{MTA_TYPE}` / `{MTA_VERSION_BANNER}`

### F. JWT(1)

- `{JWT_TOKEN}` → 3 段 base64url,header 从 5 个 alg 池随机,payload/signature 随机字节(**dummy**,不是真签名 —— 与 v1 一致)

## 关键决策

### D15-1=A:extended 独立(不 import basic)

- 与 basic 无代码依赖
- 复用 `randStringFrom` / `replaceLiteral` 各写一遍(每个包总共 ~20 行,重复可接受)
- **好处**:两个包可独立演进;若未来抽 shared,风险为 0

### D15-2=A:时区硬编码 FixedZone

- 6 个时区 JST/GMT/PST/PDT/EST/CET 全用 `time.FixedZone`
- **不依赖 tzdata**(Windows 生产环境稳定性)
- `{RFC2822_DATE_TZ:name}` 参数化才用 `time.LoadLocation`(失败 fallback UTC,不 panic)

### D15-3=A:JWT_TOKEN dummy 实现

- header:5 元素池随机(HS256/HS384/HS512/RS256/ES256)—— 明文对应 `{"alg":"...","typ":"JWT"}`
- payload:80-160 字节随机 → base64url
- signature:32(HS256/etc)或 64(HS512/RS256)字节随机 → base64url
- **不做真 HMAC-SHA256** —— 反指纹用足够;真签名需要密钥管理不划算

## 依赖

- `internal/random` —— Source 接口(所有随机)
- `internal/clock` —— Clock 接口(时间变量)
- `internal/data` —— YahooCidrsPool / NonRoutableCidrsPool(仅 2 个 IP 变量用)
- Go 标准库:regexp / strings / strconv / fmt / net / encoding/binary / encoding/base64 / time

## 测试

```bash
go test -cover ./internal/variables/extended/...
# 实测:93.1% coverage,50+ 单测全通过
```

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| 位置 | `email/variables_ext.go`(655 行) | `internal/variables/extended/`(10 file, ~900 行) |
| 随机源 | `vp.random`(math/rand) | 注入 `random.Source` |
| 时钟 | `time.Now()` | 注入 `clock.Clock` |
| CIDR 数据 | v1 headers.go 里散落 `yahooCidrStrings` / `nonRoutableCidrs` | v2 集中 `data.YahooCidrsPool` / `NonRoutableCidrsPool`(go:embed .txt) |
| CIDR 段内随机 | v1 headers.go 复杂重试逻辑 | v2 `cidrRandomIP` 简洁:ParseCIDR + host 位随机 |
| 单测 | ❌ 无 | ✅ 50+ 单测,93.1% 覆盖率 |
