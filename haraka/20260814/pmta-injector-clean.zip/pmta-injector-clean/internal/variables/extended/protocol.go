package extended

// ===== 协议池常量(与 v1 email/variables_ext.go:548-573 完全一致)=====

var (
	tlsVersionPool = []string{"TLS1_3", "TLS1_2"}

	tlsCipherPool = []string{
		// TLS 1.3 ciphers(短名)
		"TLS_AES_256_GCM_SHA384",
		"TLS_AES_128_GCM_SHA256",
		"TLS_CHACHA20_POLY1305_SHA256",
		// TLS 1.2 ciphers
		"ECDHE-RSA-AES256-GCM-SHA384",
		"ECDHE-RSA-AES128-GCM-SHA256",
		"ECDHE-RSA-CHACHA20-POLY1305",
		"ECDHE-ECDSA-AES256-GCM-SHA384",
		"ECDHE-ECDSA-CHACHA20-POLY1305",
	}

	tlsBitsPool      = []string{"256/256", "128/128", "256/128"}
	smtpProtocolPool = []string{"ESMTP", "ESMTPS", "ESMTPSA", "SMTP"}
	mtaTypePool      = []string{"Postfix", "sendmail", "Exim"}

	mtaVersionBanners = []string{
		"(Postfix)",
		"(sendmail)",
		"(Exim)",
		"(2.20.1.0.0)",
		"(DOCOMO Mail Server Ver2.0)",
		"(Postfix-2.11.7)",
		"(Microsoft SMTP Server)",
	}
)

// processProtocolVariables 处理 6 个协议变量
//
// 【全部字面】每个变量从对应池随机选一项
func (p *Processor) processProtocolVariables(content string) string {
	content = replaceLiteral(content, "{TLS_VERSION}", func() string {
		return tlsVersionPool[p.rng.Intn(len(tlsVersionPool))]
	})
	content = replaceLiteral(content, "{TLS_CIPHER}", func() string {
		return tlsCipherPool[p.rng.Intn(len(tlsCipherPool))]
	})
	content = replaceLiteral(content, "{TLS_BITS}", func() string {
		return tlsBitsPool[p.rng.Intn(len(tlsBitsPool))]
	})
	content = replaceLiteral(content, "{SMTP_PROTOCOL}", func() string {
		return smtpProtocolPool[p.rng.Intn(len(smtpProtocolPool))]
	})
	content = replaceLiteral(content, "{MTA_TYPE}", func() string {
		return mtaTypePool[p.rng.Intn(len(mtaTypePool))]
	})
	content = replaceLiteral(content, "{MTA_VERSION_BANNER}", func() string {
		return mtaVersionBanners[p.rng.Intn(len(mtaVersionBanners))]
	})
	return content
}
