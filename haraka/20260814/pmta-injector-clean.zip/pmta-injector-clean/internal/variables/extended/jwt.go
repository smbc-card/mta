package extended

import (
	"encoding/base64"
	"strings"
)

// ===== JWT header 池(完整 base64url 编码,与 v1 email/variables_ext.go:609-615 一致)=====
//
// 对应明文:
//   - eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9 = {"alg":"HS256","typ":"JWT"}
//   - eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9 = {"alg":"HS384","typ":"JWT"}
//   - eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9 = {"alg":"HS512","typ":"JWT"}
//   - eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9 = {"alg":"RS256","typ":"JWT"}
//   - eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9 = {"alg":"ES256","typ":"JWT"}
var jwtHeaderPool = []string{
	"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
	"eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9",
	"eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9",
	"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9",
	"eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9",
}

// jwtBase64URL base64.RawURLEncoding(无 padding)编码
func jwtBase64URL(b []byte) string {
	return base64.RawURLEncoding.EncodeToString(b)
}

// processJWTVariables 处理 1 个 JWT 变量({JWT_TOKEN})
//
// 【D15-3=A 决策:dummy JWT 与 v1 完全一致】
//   - header:从 5 元素池随机(HS256/HS384/HS512/RS256/ES256)
//   - payload:80-160 字节随机数据 → base64url(结果约 107-214 字符)
//   - signature:32 字节(HS256 等)或 64 字节(HS512 / RS256 简化)
//
// 【为什么用随机字节而非签名】用于反指纹的 header,不需要真正的 HMAC-SHA256 校验;
// 随机字节 base64 后与真 JWT 视觉一致(足以骗过邮件解析器的启发式判断)
func (p *Processor) processJWTVariables(content string) string {
	content = replaceLiteral(content, "{JWT_TOKEN}", func() string {
		header := jwtHeaderPool[p.rng.Intn(len(jwtHeaderPool))]

		// payload 长度 80-160 字节
		payloadLen := 80 + p.rng.Intn(81)
		payloadBytes := make([]byte, payloadLen)
		_, _ = p.rng.Read(payloadBytes)
		payload := jwtBase64URL(payloadBytes)

		// signature 长度按 header 类型:HS512 → 64 字节;其他 → 32 字节
		// RS256 真实是 256 字节,但 base64url 后 342 字符太长,折中 64 字节(与 v1 一致)
		sigLen := 32
		if strings.Contains(header, "IUzUxMiI") { // HS512
			sigLen = 64
		} else if strings.Contains(header, "JSUzI1NiI") { // RS256(注意:v1 里的 typo bug 保留)
			sigLen = 64
		}
		sigBytes := make([]byte, sigLen)
		_, _ = p.rng.Read(sigBytes)
		signature := jwtBase64URL(sigBytes)

		return header + "." + payload + "." + signature
	})
	return content
}
