package extended

import (
	"regexp"
	"strconv"
	"strings"
	"time"
)

// ===== 参数化正则(与 v1 email/variables_ext.go:36-39 一致)=====
var (
	// {RFC2822_DATE_TZ:Asia/Tokyo}
	reRFC2822TZ = regexp.MustCompile(`(?i)\{RFC2822_DATE_TZ:([A-Za-z][A-Za-z0-9_/+\-]+)\}`)

	// {RFC2822_DATE_OFFSET:+0900} / {RFC2822_DATE_OFFSET:-0700}
	reRFC2822Offset = regexp.MustCompile(`(?i)\{RFC2822_DATE_OFFSET:([+\-]\d{4})\}`)

	// {RFC2822_DATE_PAST_SEC:30} —— 当前时刻往前推 N 秒(JST)
	reRFC2822PastSec = regexp.MustCompile(`(?i)\{RFC2822_DATE_PAST_SEC:(\d+)\}`)

	// {RFC2822_DATE_PAST_RAND:1-3600} —— 当前时刻往前推 [min, max] 秒随机(JST)
	reRFC2822PastRand = regexp.MustCompile(`(?i)\{RFC2822_DATE_PAST_RAND:(\d+)-(\d+)\}`)
)

// ===== 时区常量(D15-2=A 硬编码 FixedZone,不依赖 tzdata)=====
//
// 【与 v1 一致】JST/GMT/PST/PDT/EST/CET 全用 time.FixedZone
// 【为什么不 LoadLocation】Windows 生产环境 tzdata 依赖不稳定,FixedZone 100% 可用
var (
	extTzJST = time.FixedZone("JST", 9*3600)
	extTzGMT = time.FixedZone("GMT", 0)
	extTzPST = time.FixedZone("PST", -8*3600)
	extTzPDT = time.FixedZone("PDT", -7*3600)
	extTzEST = time.FixedZone("EST", -5*3600)
	extTzCET = time.FixedZone("CET", 1*3600)
)

// rfc2822LayoutBase RFC 2822 §3.3 日期时间格式
//
// 例:"Thu, 06 Aug 2026 15:52:01 +0900"
const rfc2822LayoutBase = "Mon, 02 Jan 2006 15:04:05 -0700"

// processRFC2822Variables 处理 13 个 RFC 2822 时间变量
//
// 【顺序】参数化先(避免字面误吞)→ 字面后
//
// 【参数化 4 个】
//   - {RFC2822_DATE_TZ:name}     LoadLocation(失败 fallback UTC)
//   - {RFC2822_DATE_OFFSET:+HHMM} 直接构造 FixedZone
//   - {RFC2822_DATE_PAST_SEC:N}   当前 - N 秒
//   - {RFC2822_DATE_PAST_RAND:N-M} 当前 - Rand(N, M) 秒
//
// 【字面 9 个】
//   - {RFC2822_DATE}          默认 JST
//   - {RFC2822_DATE_JST}      JST
//   - {RFC2822_DATE_UTC}      UTC
//   - {RFC2822_DATE_GMT}      GMT + " (GMT)"
//   - {RFC2822_DATE_PST}      PST
//   - {RFC2822_DATE_PDT}      PDT + " (PDT)"
//   - {RFC2822_DATE_EST}      EST
//   - {RFC2822_DATE_CET}      CET
//   - {RFC2822_DATE_WITH_JST} JST + " (JST)"
func (p *Processor) processRFC2822Variables(content string) string {
	now := p.clk.Now()

	// === 参数化 ===

	content = reRFC2822TZ.ReplaceAllStringFunc(content, func(match string) string {
		sub := reRFC2822TZ.FindStringSubmatch(match)
		if len(sub) < 2 {
			return match
		}
		// D15-2=A:LoadLocation 失败 fallback UTC(不 panic)
		loc, err := time.LoadLocation(sub[1])
		if err != nil || loc == nil {
			loc = time.UTC
		}
		return now.In(loc).Format(rfc2822LayoutBase)
	})

	content = reRFC2822Offset.ReplaceAllStringFunc(content, func(match string) string {
		sub := reRFC2822Offset.FindStringSubmatch(match)
		if len(sub) < 2 {
			return match
		}
		offsetStr := sub[1]
		sign := 1
		if offsetStr[0] == '-' {
			sign = -1
		}
		hh, _ := strconv.Atoi(offsetStr[1:3])
		mm, _ := strconv.Atoi(offsetStr[3:5])
		secs := sign * (hh*3600 + mm*60)
		loc := time.FixedZone(offsetStr, secs)
		return now.In(loc).Format(rfc2822LayoutBase)
	})

	content = reRFC2822PastSec.ReplaceAllStringFunc(content, func(match string) string {
		sub := reRFC2822PastSec.FindStringSubmatch(match)
		if len(sub) < 2 {
			return match
		}
		secs, _ := strconv.Atoi(sub[1])
		t := now.Add(-time.Duration(secs) * time.Second).In(extTzJST)
		return t.Format(rfc2822LayoutBase)
	})

	content = reRFC2822PastRand.ReplaceAllStringFunc(content, func(match string) string {
		sub := reRFC2822PastRand.FindStringSubmatch(match)
		if len(sub) < 3 {
			return match
		}
		minS, _ := strconv.Atoi(sub[1])
		maxS, _ := strconv.Atoi(sub[2])
		if maxS < minS {
			maxS = minS
		}
		gap := maxS - minS + 1
		offset := minS + p.rng.Intn(gap)
		t := now.Add(-time.Duration(offset) * time.Second).In(extTzJST)
		return t.Format(rfc2822LayoutBase)
	})

	// === 字面 ===

	replacements := map[string]string{
		"{RFC2822_DATE}":          now.In(extTzJST).Format(rfc2822LayoutBase),
		"{RFC2822_DATE_JST}":      now.In(extTzJST).Format(rfc2822LayoutBase),
		"{RFC2822_DATE_UTC}":      now.UTC().Format(rfc2822LayoutBase),
		"{RFC2822_DATE_GMT}":      now.In(extTzGMT).Format(rfc2822LayoutBase) + " (GMT)",
		"{RFC2822_DATE_PST}":      now.In(extTzPST).Format(rfc2822LayoutBase),
		"{RFC2822_DATE_PDT}":      now.In(extTzPDT).Format(rfc2822LayoutBase) + " (PDT)",
		"{RFC2822_DATE_EST}":      now.In(extTzEST).Format(rfc2822LayoutBase),
		"{RFC2822_DATE_CET}":      now.In(extTzCET).Format(rfc2822LayoutBase),
		"{RFC2822_DATE_WITH_JST}": now.In(extTzJST).Format(rfc2822LayoutBase) + " (JST)",
	}
	for k, v := range replacements {
		content = strings.ReplaceAll(content, k, v)
		content = strings.ReplaceAll(content, strings.ToLower(k), v)
	}
	return content
}
