package extended

import (
	"fmt"
	"strings"
)

// ===== 域名池常量(与 v1 email/variables_ext.go:406-446 一致)=====
//
// 【为什么硬编码而不用 data 包外置】
//   - 15 个域名池分布在不同变量,每个池 3-10 项,总共 ~60 项
//   - 对比 data 包外置 pool(500+ 项),这里数量小
//   - 大部分是"格式模板 + 数字范围"(如 mta%04d.mail.otm...),不适合纯字符串池
//   - 保持与 v1 完全一致,后续若需要修改可移到 data
type yahooMxPattern struct {
	tpl      string
	numFmt   string
	startNum int
	endNum   int
}

var yahooMxPatterns = []yahooMxPattern{
	{"mta%04d.mail.otm.ynwp.yahoo.co.jp", "%04d", 1, 9999},
	{"mta%04d.mail.snz.ynwp.yahoo.co.jp", "%04d", 1, 9999},
	{"mtaat%04d.mail.otm.ynwp.yahoo.co.jp", "%04d", 1, 9999},
	{"mtaat%04d.mail.snz.ynwp.yahoo.co.jp", "%04d", 1, 9999},
	{"mta%03d.kks.gm.yahoo.co.jp", "%03d", 1, 600},
	{"mta%03d.ssk.gm.yahoo.co.jp", "%03d", 1, 600},
	{"mta%03d.kth.gm.yahoo.co.jp", "%03d", 1, 600},
}

var yahooEhloSubsExt = []string{"kks", "kth", "ssk"}

var gmailOutDomainPool = []string{
	"smtp.gmail.com",
	"mail-yw1-f%d.google.com",
	"mail-ed1-f%d.google.com",
	"mail-pl1-f%d.google.com",
	"mail-lf1-f%d.google.com",
	"mail-pf1-f%d.google.com",
	"mail-pj1-f%d.google.com",
	"mail-ot1-f%d.google.com",
	"mail-qk1-f%d.google.com",
	"mail-vk1-f%d.google.com",
}

var mitsuiDomainPool = []string{
	"mail.vpass.ne.jp",
	"mail.smbc.co.jp",
	"mta.contact.vpass.ne.jp",
	"smtp.smbc.co.jp",
	"mta1.contact.vpass.ne.jp",
	"mta2.contact.vpass.ne.jp",
}

var amazonSesPrefixPool = []string{
	"a8-", "a10-", "a12-", "a15-", "a23-", "a28-", "a30-", "a45-", "a48-", "a52-",
	"e23-", "e45-",
}

// processExtDomainVariables 处理 15 个域名变量
func (p *Processor) processExtDomainVariables(content string) string {
	// {DOMAIN_YAHOO_MX} —— 7 种范式随机
	content = replaceLiteral(content, "{DOMAIN_YAHOO_MX}", func() string {
		pat := yahooMxPatterns[p.rng.Intn(len(yahooMxPatterns))]
		num := pat.startNum + p.rng.Intn(pat.endNum-pat.startNum+1)
		return fmt.Sprintf(pat.tpl, num)
	})

	// {DOMAIN_YAHOO_EHLO} —— mta{001-600}.{kks|kth|ssk}.gm.yahoo.co.jp
	content = replaceLiteral(content, "{DOMAIN_YAHOO_EHLO}", func() string {
		sub := yahooEhloSubsExt[p.rng.Intn(len(yahooEhloSubsExt))]
		num := 1 + p.rng.Intn(600)
		return fmt.Sprintf("mta%03d.%s.gm.yahoo.co.jp", num, sub)
	})

	// {DOMAIN_YAHOO_GW} —— smtp-gw-f{XX}h{XXX}c{XX}.prod.goats.kks.ynwl.yahoo.co.jp
	content = replaceLiteral(content, "{DOMAIN_YAHOO_GW}", func() string {
		f := p.rng.Intn(100)
		h := p.rng.Intn(1000)
		c := p.rng.Intn(100)
		return fmt.Sprintf("smtp-gw-f%02dh%03dc%02d.prod.goats.kks.ynwl.yahoo.co.jp", f, h, c)
	})

	// {DOMAIN_GMAIL_OUT} —— Gmail 出站域池
	content = replaceLiteral(content, "{DOMAIN_GMAIL_OUT}", func() string {
		tpl := gmailOutDomainPool[p.rng.Intn(len(gmailOutDomainPool))]
		if strings.Contains(tpl, "%d") {
			return fmt.Sprintf(tpl, 1+p.rng.Intn(200))
		}
		return tpl
	})

	// {DOMAIN_GMAIL_HOST} —— server-{ip-dashed}.da.direct
	content = replaceLiteral(content, "{DOMAIN_GMAIL_HOST}", func() string {
		return fmt.Sprintf("server-%d-%d-%d-%d.da.direct",
			1+p.rng.Intn(222),
			p.rng.Intn(256),
			p.rng.Intn(256),
			1+p.rng.Intn(254))
	})

	// {DOMAIN_DOCOMO_BILL} —— mail{1-10}.docomo-bill.ne.jp
	content = replaceLiteral(content, "{DOMAIN_DOCOMO_BILL}", func() string {
		return fmt.Sprintf("mail%d.docomo-bill.ne.jp", 1+p.rng.Intn(10))
	})

	// {DOMAIN_DOCOMO_LOCAL} —— 固定
	content = replaceLiteral(content, "{DOMAIN_DOCOMO_LOCAL}", func() string {
		return "localhost.docomo.ne.jp"
	})

	// {DOMAIN_DOCOMO_MFSMAX} —— 固定
	content = replaceLiteral(content, "{DOMAIN_DOCOMO_MFSMAX}", func() string {
		return "mfsmax.docomo.ne.jp"
	})

	// {DOMAIN_SOFTBANK_EBMKY} —— ebmky{101-150}sc.softbank.ad.jp
	content = replaceLiteral(content, "{DOMAIN_SOFTBANK_EBMKY}", func() string {
		return fmt.Sprintf("ebmky%dsc.softbank.ad.jp", 101+p.rng.Intn(50))
	})

	// {DOMAIN_AU} —— mta-snd-e{01-99}.au.com
	content = replaceLiteral(content, "{DOMAIN_AU}", func() string {
		return fmt.Sprintf("mta-snd-e%02d.au.com", 1+p.rng.Intn(99))
	})

	// {DOMAIN_MITSUI} —— 三井相关域名池随机
	content = replaceLiteral(content, "{DOMAIN_MITSUI}", func() string {
		return mitsuiDomainPool[p.rng.Intn(len(mitsuiDomainPool))]
	})

	// {DOMAIN_BICCAMERA} —— mta{1-15}.ml.biccamera.com
	content = replaceLiteral(content, "{DOMAIN_BICCAMERA}", func() string {
		return fmt.Sprintf("mta%d.ml.biccamera.com", 1+p.rng.Intn(15))
	})

	// {DOMAIN_YODOBASHI} —— yctcue{01-99}.yodobashi.co.jp
	content = replaceLiteral(content, "{DOMAIN_YODOBASHI}", func() string {
		return fmt.Sprintf("yctcue%02d.yodobashi.co.jp", 1+p.rng.Intn(99))
	})

	// {DOMAIN_LTIKE} —— md{1-10}.l-tike.com
	content = replaceLiteral(content, "{DOMAIN_LTIKE}", func() string {
		return fmt.Sprintf("md%d.l-tike.com", 1+p.rng.Intn(10))
	})

	// {DOMAIN_AMAZONSES_OUT} —— {prefix}{4-8 字符}.smtp-out.amazonses.com
	content = replaceLiteral(content, "{DOMAIN_AMAZONSES_OUT}", func() string {
		pref := amazonSesPrefixPool[p.rng.Intn(len(amazonSesPrefixPool))]
		tail := randStringFrom(p.rng, 4+p.rng.Intn(5), charsetLowerNum)
		return fmt.Sprintf("%s%s.smtp-out.amazonses.com", pref, tail)
	})

	return content
}
