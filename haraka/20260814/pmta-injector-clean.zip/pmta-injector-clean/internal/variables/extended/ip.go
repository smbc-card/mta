package extended

import (
	"fmt"

	"__MODULE_PLACEHOLDER__/internal/data"
)

// ===== IP 池辅助(v1 headers.go 里散落的常量在 v2 集中到 extended)=====

// gmailGwIPRanges Gmail / Google 出口段(部分知名段)
var gmailGwIPRanges = [][2]int{
	{209, 85},
	{74, 125},
	{173, 194},
	{64, 233},
	{72, 14},
	{216, 58},
}

// awsSesIPRanges AWS SES 已知出口段(第一/第二段)
var awsSesIPRanges = [][2]int{
	{23, 249},
	{54, 240},
	{199, 255},
	{207, 171},
	{52, 95},
	{76, 223},
}

// processExtIPVariables 处理 10 个扩展 IP 变量
//
// 【依赖】data.YahooCidrsPool / data.NonRoutableCidrsPool(仅 2 个变量用)
func (p *Processor) processExtIPVariables(content string) string {
	// {IP_YAHOO_JP} —— 从 data.YahooCidrsPool 随机选段,CIDR 内随机 IP
	content = replaceLiteral(content, "{IP_YAHOO_JP}", func() string {
		cidrs, err := data.YahooCidrsPool.Get()
		if err != nil || len(cidrs) == 0 {
			return "127.0.0.1" // fallback
		}
		cidr := cidrs[p.rng.Intn(len(cidrs))]
		ip := cidrRandomIP(p.rng, cidr)
		if ip == "" {
			return "127.0.0.1"
		}
		return ip
	})

	// {IP_SOFTBANK_172} —— 172.16-31.x.x
	content = replaceLiteral(content, "{IP_SOFTBANK_172}", func() string {
		return fmt.Sprintf("172.%d.%d.%d",
			16+p.rng.Intn(16),
			p.rng.Intn(256),
			1+p.rng.Intn(254))
	})

	// {IP_DOCOMO_INTERNAL} —— 10.200.x.x
	content = replaceLiteral(content, "{IP_DOCOMO_INTERNAL}", func() string {
		return fmt.Sprintf("10.200.%d.%d", p.rng.Intn(256), 1+p.rng.Intn(254))
	})

	// {IP_GMAIL_GW} —— Google 出口段
	content = replaceLiteral(content, "{IP_GMAIL_GW}", func() string {
		r := gmailGwIPRanges[p.rng.Intn(len(gmailGwIPRanges))]
		return fmt.Sprintf("%d.%d.%d.%d", r[0], r[1], p.rng.Intn(256), 1+p.rng.Intn(254))
	})

	// {IP_PRIVATE_10} —— 10.x.x.x
	content = replaceLiteral(content, "{IP_PRIVATE_10}", func() string {
		return fmt.Sprintf("10.%d.%d.%d", p.rng.Intn(256), p.rng.Intn(256), 1+p.rng.Intn(254))
	})

	// {IP_PRIVATE_172} —— 172.16-31.x.x
	content = replaceLiteral(content, "{IP_PRIVATE_172}", func() string {
		return fmt.Sprintf("172.%d.%d.%d", 16+p.rng.Intn(16), p.rng.Intn(256), 1+p.rng.Intn(254))
	})

	// {IP_PRIVATE_192} —— 192.168.x.x
	content = replaceLiteral(content, "{IP_PRIVATE_192}", func() string {
		return fmt.Sprintf("192.168.%d.%d", p.rng.Intn(256), 1+p.rng.Intn(254))
	})

	// {IP_LOOPBACK} —— 固定 127.0.0.1
	content = replaceLiteral(content, "{IP_LOOPBACK}", func() string {
		return "127.0.0.1"
	})

	// {IP_PUBLIC_GLOBAL} —— 全球公网,排除 NonRoutableCidrsPool
	content = replaceLiteral(content, "{IP_PUBLIC_GLOBAL}", func() string {
		return p.generatePublicIP()
	})

	// {IP_AWS_SES} —— AWS SES 已知出口段
	content = replaceLiteral(content, "{IP_AWS_SES}", func() string {
		r := awsSesIPRanges[p.rng.Intn(len(awsSesIPRanges))]
		return fmt.Sprintf("%d.%d.%d.%d", r[0], r[1], p.rng.Intn(256), 1+p.rng.Intn(254))
	})

	return content
}

// generatePublicIP 生成"公网 IP"(排除 NonRoutableCidrs)
//
// 【实现】随机 4 字节 IP,重试直到不在 NonRoutableCidrsPool 内
// 【复杂度】NonRoutable 池只有 9 项,单次命中率极低,平均 1-2 次尝试成功
// 【最多尝试】20 次,失败则返回 8.8.8.8 兜底(Google DNS,永远公网)
func (p *Processor) generatePublicIP() string {
	nonroutable, _ := data.NonRoutableCidrsPool.Get()

	for attempts := 0; attempts < 20; attempts++ {
		// 首字节 1-223(避 224-255 组播/保留)
		a := 1 + p.rng.Intn(223)
		b := p.rng.Intn(256)
		c := p.rng.Intn(256)
		d := 1 + p.rng.Intn(254)
		candidate := fmt.Sprintf("%d.%d.%d.%d", a, b, c, d)
		if !isInAnyCIDR(candidate, nonroutable) {
			return candidate
		}
	}
	return "8.8.8.8" // 兜底
}
