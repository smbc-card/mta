package basic

import (
	"fmt"
	"regexp"
)

// ===== IP 变量正则(与 v1 email/variables.go:45-48 完全一致)=====
var (
	reRandomIP   = regexp.MustCompile(`(?i)\{RANDOM_IP\}`)
	reRandomIPCN = regexp.MustCompile(`(?i)\{RANDOM_IP_CN\}`)
	reRandomIPJP = regexp.MustCompile(`(?i)\{RANDOM_IP_JP\}`)
	reRandomIPUS = regexp.MustCompile(`(?i)\{RANDOM_IP_US\}`)
)

// processIPVariables 处理 4 个 IP 变量
//
// 【实现要点】
//   - 每个变量有若干 first-octet 范围池,先随机选一个范围,再在范围内随机首字节
//   - 后 3 字节:2/3 字节 [0-255],末字节 [1-254](避开 0/255)
//   - 范围来源:v1 email/variables.go:491-501 硬编码,与生产真实 IP 分布一致
//
// 【与 v1 差异】v1 用 safeIntn(random, n) 兜底 n<=0,v2 Source.Intn 已在 mathSource 里保护
func (p *Processor) processIPVariables(content string) string {
	content = reRandomIP.ReplaceAllStringFunc(content, func(match string) string {
		return p.generateRandomIP([][]int{{1, 9}, {11, 126}, {128, 169}, {171, 191}, {193, 223}})
	})
	content = reRandomIPCN.ReplaceAllStringFunc(content, func(match string) string {
		return p.generateRandomIP([][]int{{116, 117}, {119, 120}, {121, 122}, {222, 223}})
	})
	content = reRandomIPJP.ReplaceAllStringFunc(content, func(match string) string {
		return p.generateRandomIP([][]int{{133, 134}, {150, 151}, {157, 158}, {202, 203}})
	})
	content = reRandomIPUS.ReplaceAllStringFunc(content, func(match string) string {
		return p.generateRandomIP([][]int{{64, 65}, {66, 67}, {69, 70}, {98, 99}})
	})
	return content
}

// generateRandomIP 从 ranges 里随机取 first-octet,拼四段 IPv4
//
// 【末字节】1-254 避开 0(网络地址)和 255(广播地址)—— v1 硬编码规则
func (p *Processor) generateRandomIP(ranges [][]int) string {
	r := ranges[p.rng.Intn(len(ranges))]
	first := r[0] + p.rng.Intn(r[1]-r[0]+1)
	return fmt.Sprintf("%d.%d.%d.%d",
		first,
		p.rng.Intn(256),
		p.rng.Intn(256),
		1+p.rng.Intn(254))
}
