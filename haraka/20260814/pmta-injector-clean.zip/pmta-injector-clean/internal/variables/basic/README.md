# internal/variables/basic

**用途**:实现 55 个"基础变量"(不依赖 data pool 的所有 v1 变量)。extended(53 个变量,依赖 data pool)在 Day 15 的 `internal/variables/extended` 包实现。

## 文件组织

| 文件 | 变量组 | 数量 |
|------|--------|------|
| `processor.go` | Processor struct + New + Process 主入口 | — |
| `time.go` | 时间变量({DATE_TIME} / {DATE} / {TIME} / {YEAR} / {MONTH} / {DAY} / {HOUR} / {MINUTE} / {SECOND} / {TIMESTAMP} / {DATE_JP} / {DATE_CN} / {WEEKDAY} / {WEEKDAY_EN}) | 14 |
| `recipient.go` | 收件人变量({TO_EMAIL/USER/DOMAIN/NAME/FIRST/LAST/USER_UPPER/LOWER/CAP/NAME_UPPER/LOWER})+ 自定义 CSV 字段(8 种模式) | 11 + 动态 |
| `sender.go` | 发件人变量({FROM_EMAIL/USER/DOMAIN/NAME}) | 4 |
| `random.go` | 随机变量({RANDOM/RANDOM_LOWER/UPPER/NUM/LOWER_NUM/UPPER_NUM/HEX/CN/JP/HIRA/KATA})+ 长度参数 :N / :N-M | 11 |
| `amount.go` | 金额变量({AMOUNT/AMOUNT:m-M/AMOUNT_JP/AMOUNT_CN/AMOUNT_USD}) | 5 |
| `ip.go` | IP 变量({RANDOM_IP/CN/JP/US})—— 硬编码 first-octet 范围池 | 4 |
| `uuid_hash.go` | UUID/哈希({UUID} / {UUID_SHORT} / {MD5:input} / {MD5_SHORT:input}) | 4 |
| `custom.go` | 自定义变量池({CUSTOM:name(:random\|:seq)?}) | 1 regex |
| `conditional.go` | 条件变量({IF:field=val:true:false}) | 1 regex |
| `processor_test.go` | 33 个测试 + golden 冻结 | — |
| **合计** | | **~55 变量** |

## 快速开始

```go
import (
    "__MODULE_PLACEHOLDER__/internal/clock"
    "__MODULE_PLACEHOLDER__/internal/random"
    "__MODULE_PLACEHOLDER__/internal/variables/basic"
)

// 生产用
proc := basic.New(
    random.NewSystemSource(),
    clock.NewSystemClock(),
    &basic.Config{
        Sender: basic.SenderVars{FromAddress: "hi@example.com", FromName: "Hi"},
        Amount: basic.AmountCfg{Min: 100, Max: 1000, Decimals: 2, UseSeparator: true},
        Custom: map[string][]string{"tag": {"news", "promo"}},
    },
)

rcpt := &basic.Recipient{
    Email: "john@example.co.jp",
    Name:  "John Doe",
    CustomFields: map[string]string{"url": "https://track/xyz"},
}

result := proc.Process("Hi {TO_FIRST}, order {UUID_SHORT} for {AMOUNT_JP:1000-5000}", rcpt)
// → "Hi John Doe, order 5f8c1a2b... for ¥3,247"
```

## Config 设计

**为什么不引 `internal/config`**:
- 避免循环依赖(未来 config 可能引 basic 做校验)
- basic 包独立可复用,不绑定业务 config 结构
- 外层从 config.Config 里挑出 Sender/Amount/Custom 构造 basic.Config

## 变量处理顺序

1. **时间**({DATE_*}, {TIME}, {YEAR}, ...)
2. **收件人**({TO_*}, {custom_field_from_csv})
3. **发件人**({FROM_*})
4. **随机**({RANDOM*(:N-M)?})
5. **金额**({AMOUNT*(:N-M(:D)?)?})
6. **IP**({RANDOM_IP*})
7. **UUID/哈希**({UUID}, {MD5:s})
8. **CUSTOM**({CUSTOM:name(:mode)?})
9. **IF**({IF:field=val:t:f})

**为什么固定这个顺序**(与 v1 一致):
- 时间/收件人/发件人 literal 在前 → {IF:TO_DOMAIN=...} 才能拿到值
- CUSTOM/IF 在最后 → 允许在 CUSTOM 池里放含变量的字符串,但**不嵌套解析**(与 v1 一致)

## 关键实现细节

### 1. 大小写不敏感

所有 literal 变量同时替换大写和小写形式(`{DATE}` 和 `{date}` 都工作)。regex 变量用 `(?i)` 前缀。

### 2. capitalizeFirst 的 UTF-8 安全

首字符大写化用 `utf8.DecodeRuneInString`,正确处理中/日文(与 v1 一致)。

### 3. 随机长度参数

- `{RANDOM}` → 默认 8
- `{RANDOM:12}` → 固定 12
- `{RANDOM:5-15}` → [5, 15] 随机
- `{RANDOM:0}` → fallback 为 1(避免 make(_, 0))

### 4. IP 末字节避开 0/255

`{RANDOM_IP*}` 末字节固定 `1 + Intn(254)` = [1, 254],避开网络地址/广播地址。

### 5. CUSTOM 与收件人字段的优先级

`{CUSTOM:key}` 会**先**被 `recipient.CustomFields` 里的 `key` 拦截(processRecipientVariables 里,与 `{TO_KEY}` 等 8 种模式共处理),**只有** recipient 里没有的 name 才走到 `cfg.Custom` 池。

### 6. IF 支持字段

仅支持 `TO_DOMAIN` / `TO_USER` / `TO_EMAIL` / `TO_NAME`(v1 硬编码,未来 v2 可扩展 FROM_*)。

## 与 v1 的对比

| 场景 | v1 | v2 |
|------|-----|-----|
| 位置 | `email/variables.go`(731 行) | `internal/variables/basic/`(10 file, ~700 行) |
| 随机源 | 混用 `math/rand` + `crypto/rand.Read` | 统一 `random.Source` |
| 时钟 | 直接 `time.Now()` | 注入 `clock.Clock` |
| 变量数量 | ~55(basic 部分) | ~55(1:1 保留)|
| 单测 | ❌ 无 | ✅ 33 单测,95.6% 覆盖率 |
| 依赖 | `types.Recipient` + `config.Config` | 本地 Recipient/Config struct(独立可复用) |

## 依赖

- `internal/random` —— Source 接口
- `internal/clock` —— Clock 接口
- Go 标准库:regexp / strings / fmt / strconv / crypto/md5 / encoding/hex / unicode/utf8
- **不依赖**:config / data / telemetry

## 测试

```bash
go test -cover ./internal/variables/basic/...
# 实测:95.6% coverage,33 单测全通过
```

## 下一步(Day 15)

`internal/variables/extended`(53 变量,依赖 data pool):

- RFC2822 dates(9 变量)—— 用 clock.Clock + timezone
- ID 生成(8 变量)—— gmail/amazon-ses/exim/biccamera 等格式
- IP 池(10 变量)—— IP_YAHOO_JP / IP_SOFTBANK_172 等,查 data pool
- 域名池(15 变量)—— DOMAIN_YAHOO_MX / DOMAIN_GMAIL_HOST 等
- 协议(6 变量)—— TLS_VERSION / TLS_CIPHER / MTA_VERSION_BANNER
- JWT(1 变量)—— HMAC-SHA256 签发
