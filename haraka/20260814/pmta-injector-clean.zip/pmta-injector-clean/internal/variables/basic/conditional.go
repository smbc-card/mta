package basic

import (
	"regexp"
	"strings"
)

// ===== 条件变量正则(与 v1 email/variables.go:60 一致)=====
//
// 【格式】{IF:field=compareValue:trueValue:falseValue}
//   - field:比较字段(TO_DOMAIN / TO_USER / TO_EMAIL / TO_NAME)
//   - compareValue:比较值(不允许含冒号,由正则的 [^:]+ 保证)
//   - trueValue:比较相等时的返回(不允许含冒号)
//   - falseValue:比较不相等时的返回(不允许右花括号)
//
// 【EqualFold】比较大小写不敏感
var reConditional = regexp.MustCompile(`(?i)\{IF:(\w+)=([^:]+):([^:]*):([^}]*)\}`)

// processConditionalVariables 处理 {IF:field=val:t:f}
//
// 【支持字段】仅 TO_* 四个(v1 硬编码,未来 v2 可能扩展 FROM_*)
// 【recipient=nil】所有字段视为空串,除非 compareValue="",否则全走 false 分支
func (p *Processor) processConditionalVariables(content string, rcpt *Recipient) string {
	var email, user, domain, name string
	if rcpt != nil {
		email = rcpt.Email
		name = rcpt.Name
		parts := strings.Split(email, "@")
		user = parts[0]
		if len(parts) > 1 {
			domain = parts[1]
		}
	}

	return reConditional.ReplaceAllStringFunc(content, func(match string) string {
		sub := reConditional.FindStringSubmatch(match)
		if len(sub) < 5 {
			return match
		}

		field := strings.ToUpper(sub[1])
		compareValue := sub[2]
		trueValue := sub[3]
		falseValue := sub[4]

		var actualValue string
		switch field {
		case "TO_DOMAIN":
			actualValue = domain
		case "TO_USER":
			actualValue = user
		case "TO_EMAIL":
			actualValue = email
		case "TO_NAME":
			actualValue = name
		}

		if strings.EqualFold(actualValue, compareValue) {
			return trueValue
		}
		return falseValue
	})
}
