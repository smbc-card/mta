package basic

import (
	"regexp"
	"strings"
)

// ===== 自定义变量正则(与 v1 email/variables.go:57 一致)=====
//
// 【格式】{CUSTOM:name(:mode)?}
//   - name:变量名(大小写不敏感,内部小写查找)
//   - mode:可选,"random" 或 "seq";默认 "random"
//     - random:从池中随机选一项
//     - seq:按顺序循环消费(per-name 计数器)
var reCustomVar = regexp.MustCompile(`(?i)\{CUSTOM:(\w+)(?::(random|seq))?\}`)

// processCustomVariables 处理 {CUSTOM:name(:mode)?}
//
// 【行为】
//   - 池不存在 或 池为空 → 替换为空串
//   - random 模式 → p.rng.Intn(len(池)) 选一个
//   - seq 模式 → 按 p.seqIdx[name] 顺序循环,每次调用递增
//
// 【与收件人自定义字段的关系】
//   - {CUSTOM:key} 首先会被 recipient 里的 CustomFields 拦截(processRecipientVariables 里)
//   - 只有 recipient 里没有的 name,才走到这里的 cfg.Custom 池
//   - 这个顺序与 v1 一致(先 recipient 后 custom)
func (p *Processor) processCustomVariables(content string) string {
	return reCustomVar.ReplaceAllStringFunc(content, func(match string) string {
		sub := reCustomVar.FindStringSubmatch(match)
		if len(sub) < 2 {
			return match
		}

		varName := strings.ToLower(sub[1])
		mode := "random"
		if len(sub) > 2 && sub[2] != "" {
			mode = strings.ToLower(sub[2])
		}

		values, ok := p.cfg.Custom[varName]
		if !ok || len(values) == 0 {
			return ""
		}

		if mode == "seq" {
			idx := p.seqIdx[varName]
			result := values[idx%len(values)]
			p.seqIdx[varName] = idx + 1
			return result
		}
		return values[p.rng.Intn(len(values))]
	})
}
