package basic

import (
	"crypto/md5"
	"encoding/hex"
	"regexp"
	"strings"
	"testing"
	"time"

	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// 固定时间(与 v1-patched 一致):2026-08-06T15:52:01+09:00 JST
var fixedTime = time.Date(2026, 8, 6, 15, 52, 1, 0, time.FixedZone("JST", 9*3600))

func newTestProc(t *testing.T) *Processor {
	t.Helper()
	return New(
		random.NewFixedSource(42),
		clock.NewFixedClock(fixedTime),
		&Config{
			Sender: SenderVars{FromAddress: "hello@example.com", FromName: "Hello"},
			Amount: AmountCfg{Min: 100, Max: 1000, Decimals: 2, UseSeparator: false},
			Custom: map[string][]string{
				"color":  {"red", "green", "blue"},
				"single": {"only"},
			},
		},
	)
}

func newRcpt() *Recipient {
	return &Recipient{
		Email:     "john.doe@example.co.jp",
		Name:      "John Doe",
		FirstName: "John",
		LastName:  "Doe",
		CustomFields: map[string]string{
			"url":  "https://example.com/track/abc",
			"code": "XYZ123",
		},
	}
}

// ===== 时间变量(14 个) =====

func TestProcess_Time_AllTokens(t *testing.T) {
	p := newTestProc(t)
	cases := map[string]string{
		"{DATE_TIME}":  "2026-08-06 15:52:01",
		"{DATE}":       "2026-08-06",
		"{TIME}":       "15:52:01",
		"{YEAR}":       "2026",
		"{MONTH}":      "08",
		"{DAY}":        "06",
		"{HOUR}":       "15",
		"{MINUTE}":     "52",
		"{SECOND}":     "01",
		"{TIMESTAMP}":  "1785999121", // 2026-08-06T15:52:01+09:00 → Unix
		"{DATE_JP}":    "2026年08月06日",
		"{DATE_CN}":    "2026年8月6日",
		"{WEEKDAY}":    "星期四",
		"{WEEKDAY_EN}": "Thursday",
	}
	for token, want := range cases {
		got := p.Process(token, nil)
		if got != want {
			t.Errorf("Process(%q) = %q, 期望 %q", token, got, want)
		}
	}
}

func TestProcess_Time_LowercaseTokensSupported(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{date_time}", nil)
	if got != "2026-08-06 15:52:01" {
		t.Errorf("小写 {date_time} 应等价大写,得到 %q", got)
	}
}

// ===== 收件人变量(11 literal + 8 自定义字段模式) =====

func TestProcess_Recipient_AllLiterals(t *testing.T) {
	p := newTestProc(t)
	rcpt := newRcpt()
	cases := map[string]string{
		"{TO_EMAIL}":      "john.doe@example.co.jp",
		"{TO_USER}":       "john.doe",
		"{TO_DOMAIN}":     "example.co.jp",
		"{TO_NAME}":       "John Doe",
		"{TO_FIRST}":      "John",
		"{TO_LAST}":       "Doe",
		"{TO_USER_UPPER}": "JOHN.DOE",
		"{TO_USER_LOWER}": "john.doe",
		"{TO_USER_CAP}":   "John.doe",
		"{TO_NAME_UPPER}": "JOHN DOE",
		"{TO_NAME_LOWER}": "john doe",
	}
	for token, want := range cases {
		got := p.Process(token, rcpt)
		if got != want {
			t.Errorf("Process(%q, rcpt) = %q, 期望 %q", token, got, want)
		}
	}
}

func TestProcess_Recipient_NilRecipient(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{TO_EMAIL}", nil)
	if got != "" {
		t.Errorf("nil recipient 应替换为空,得到 %q", got)
	}
}

func TestProcess_Recipient_CustomFields(t *testing.T) {
	p := newTestProc(t)
	rcpt := newRcpt()
	cases := map[string]string{
		"{url}":         "https://example.com/track/abc",
		"{URL}":         "https://example.com/track/abc",
		"{CUSTOM:url}":  "https://example.com/track/abc",
		"{CUSTOM:URL}":  "https://example.com/track/abc",
		"{TO_URL}":      "https://example.com/track/abc",
		"{to_url}":      "https://example.com/track/abc",
	}
	for token, want := range cases {
		got := p.Process(token, rcpt)
		if got != want {
			t.Errorf("自定义字段 %q = %q, 期望 %q", token, got, want)
		}
	}
}

func TestProcess_Recipient_CapitalizeFirst_UTF8(t *testing.T) {
	// 日文字符 UTF-8 安全性
	got := capitalizeFirst("こんにちは")
	// 首字符是"こ",不能大写化(平假名无大小写),后续小写化不影响
	if !strings.HasPrefix(got, "こ") {
		t.Errorf("capitalizeFirst 应保留首字符,得到 %q", got)
	}
}

// ===== 发件人变量(4 个) =====

func TestProcess_Sender_AllTokens(t *testing.T) {
	p := newTestProc(t)
	cases := map[string]string{
		"{FROM_EMAIL}":  "hello@example.com",
		"{FROM_USER}":   "hello",
		"{FROM_DOMAIN}": "example.com",
		"{FROM_NAME}":   "Hello",
	}
	for token, want := range cases {
		got := p.Process(token, nil)
		if got != want {
			t.Errorf("Process(%q) = %q, 期望 %q", token, got, want)
		}
	}
}

// ===== 随机变量(11 种) =====

func TestProcess_Random_AllTypes(t *testing.T) {
	tests := []struct {
		token string
		re    *regexp.Regexp
	}{
		{"{RANDOM}", regexp.MustCompile(`^[a-zA-Z0-9]{8}$`)},
		{"{RANDOM_LOWER}", regexp.MustCompile(`^[a-z]{8}$`)},
		{"{RANDOM_UPPER}", regexp.MustCompile(`^[A-Z]{8}$`)},
		{"{RANDOM_NUM}", regexp.MustCompile(`^[0-9]{8}$`)},
		{"{RANDOM_LOWER_NUM}", regexp.MustCompile(`^[a-z0-9]{8}$`)},
		{"{RANDOM_UPPER_NUM}", regexp.MustCompile(`^[A-Z0-9]{8}$`)},
		{"{RANDOM_HEX}", regexp.MustCompile(`^[0-9a-f]{8}$`)},
	}
	for _, tc := range tests {
		t.Run(tc.token, func(t *testing.T) {
			p := newTestProc(t)
			got := p.Process(tc.token, nil)
			if !tc.re.MatchString(got) {
				t.Errorf("%q 输出 %q 不匹配 %s", tc.token, got, tc.re)
			}
		})
	}
}

func TestProcess_Random_FixedLength(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RANDOM:12}", nil)
	if len(got) != 12 {
		t.Errorf("{RANDOM:12} 应产生 12 字符,得到 %d: %q", len(got), got)
	}
}

func TestProcess_Random_RangeLength(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RANDOM:5-15}", nil)
	if len(got) < 5 || len(got) > 15 {
		t.Errorf("{RANDOM:5-15} 长度应在 [5,15],得到 %d: %q", len(got), got)
	}
}

func TestProcess_Random_Chinese(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{RANDOM_CN:5}", nil)
	// CJK 汉字每字符 3 字节
	runes := []rune(got)
	if len(runes) != 5 {
		t.Errorf("{RANDOM_CN:5} 应产生 5 rune,得到 %d: %q", len(runes), got)
	}
	for _, r := range runes {
		if r < 0x4E00 || r > 0x9FFF {
			t.Errorf("字符 U+%04X 不在 CJK 范围", r)
		}
	}
}

func TestProcess_Random_Japanese(t *testing.T) {
	p := newTestProc(t)

	got := p.Process("{RANDOM_HIRA:3}", nil)
	for _, r := range []rune(got) {
		if r < 0x3040 || r > 0x309F {
			t.Errorf("HIRA 字符 U+%04X 不在平假名范围", r)
		}
	}

	got = p.Process("{RANDOM_KATA:3}", nil)
	for _, r := range []rune(got) {
		if r < 0x30A0 || r > 0x30FF {
			t.Errorf("KATA 字符 U+%04X 不在片假名范围", r)
		}
	}

	got = p.Process("{RANDOM_JP:5}", nil)
	for _, r := range []rune(got) {
		inHira := r >= 0x3040 && r <= 0x309F
		inKata := r >= 0x30A0 && r <= 0x30FF
		if !inHira && !inKata {
			t.Errorf("JP 字符 U+%04X 应在平/片假名范围", r)
		}
	}
}

func TestProcess_Random_NoConflict(t *testing.T) {
	// RANDOM 正则不应误吞 RANDOM_LOWER
	p := newTestProc(t)
	got := p.Process("{RANDOM_LOWER:6}", nil)
	if len(got) != 6 {
		t.Errorf("{RANDOM_LOWER:6} 应产生 6 字符(不被 {RANDOM} 吃掉),得到 %d: %q", len(got), got)
	}
	if !regexp.MustCompile(`^[a-z]{6}$`).MatchString(got) {
		t.Errorf("应全为小写,得到 %q", got)
	}
}

func TestProcess_Random_ZeroLength_Fallback(t *testing.T) {
	// :0 应 fallback 为 1
	p := newTestProc(t)
	got := p.Process("{RANDOM:0}", nil)
	if len(got) != 1 {
		t.Errorf("{RANDOM:0} 应 fallback 为长度 1,得到 %d: %q", len(got), got)
	}
}

// ===== 金额变量(5 种) =====

func TestProcess_Amount_Default(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{AMOUNT}", nil)
	// 应是纯数字 + 小数点(默认 min=100, max=1000, decimals=2, useSeparator=false)
	if !regexp.MustCompile(`^\d+\.\d{2}$`).MatchString(got) {
		t.Errorf("{AMOUNT} 格式应为 N.NN,得到 %q", got)
	}
}

func TestProcess_Amount_Range(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{AMOUNT:50-100:0}", nil)
	if !regexp.MustCompile(`^\d+$`).MatchString(got) {
		t.Errorf("{AMOUNT:50-100:0} 应无小数,得到 %q", got)
	}
}

func TestProcess_Amount_JP(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{AMOUNT_JP:1000-5000}", nil)
	if !strings.HasPrefix(got, "¥") {
		t.Errorf("{AMOUNT_JP} 应以 ¥ 开头,得到 %q", got)
	}
	// 应无小数点
	if strings.Contains(got, ".") {
		t.Errorf("{AMOUNT_JP} 不应含小数,得到 %q", got)
	}
	// 应含千分位逗号
	if !strings.Contains(got, ",") {
		t.Errorf("{AMOUNT_JP} 应含千分位,得到 %q", got)
	}
}

func TestProcess_Amount_CN(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{AMOUNT_CN:100-1000}", nil)
	if !strings.HasPrefix(got, "￥") {
		t.Errorf("{AMOUNT_CN} 应以 ￥ 开头,得到 %q", got)
	}
	if !strings.Contains(got, ".") {
		t.Errorf("{AMOUNT_CN} 默认 2 位小数,得到 %q", got)
	}
}

func TestProcess_Amount_USD(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{AMOUNT_USD:1000-5000}", nil)
	if !strings.HasPrefix(got, "$") {
		t.Errorf("{AMOUNT_USD} 应以 $ 开头,得到 %q", got)
	}
	if !strings.Contains(got, ",") {
		t.Errorf("{AMOUNT_USD} 应含千分位,得到 %q", got)
	}
}

func TestAddThousandSeparator(t *testing.T) {
	cases := map[string]string{
		"1000":     "1,000",
		"1234567":  "1,234,567",
		"100":      "100",
		"1000.99":  "1,000.99",
		"12345.67": "12,345.67",
	}
	for in, want := range cases {
		got := addThousandSeparator(in)
		if got != want {
			t.Errorf("addThousandSeparator(%q) = %q, 期望 %q", in, got, want)
		}
	}
}

// ===== IP 变量(4 种) =====

func TestProcess_IP_AllTypes(t *testing.T) {
	tests := []struct {
		token string
	}{
		{"{RANDOM_IP}"},
		{"{RANDOM_IP_CN}"},
		{"{RANDOM_IP_JP}"},
		{"{RANDOM_IP_US}"},
	}
	ipRe := regexp.MustCompile(`^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$`)
	for _, tc := range tests {
		t.Run(tc.token, func(t *testing.T) {
			p := newTestProc(t)
			got := p.Process(tc.token, nil)
			if !ipRe.MatchString(got) {
				t.Errorf("%q 应产生 IPv4 格式,得到 %q", tc.token, got)
			}
			// 末字节应在 [1, 254]
			parts := strings.Split(got, ".")
			last := parts[3]
			if last == "0" || last == "255" {
				t.Errorf("末字节应避开 0/255,得到 %q", got)
			}
		})
	}
}

// ===== UUID/哈希变量(4 种) =====

func TestProcess_UUID(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{UUID}", nil)
	re := regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$`)
	if !re.MatchString(got) {
		t.Errorf("{UUID} 格式不符 v4,得到 %q", got)
	}
}

func TestProcess_UUIDShort(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{UUID_SHORT}", nil)
	re := regexp.MustCompile(`^[0-9a-f]{32}$`)
	if !re.MatchString(got) {
		t.Errorf("{UUID_SHORT} 应为 32 字符 hex,得到 %q", got)
	}
}

func TestProcess_MD5(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{MD5:hello}", nil)
	// "hello" MD5 = 5d41402abc4b2a76b9719d911017c592
	expected := "5d41402abc4b2a76b9719d911017c592"
	if got != expected {
		t.Errorf("{MD5:hello} = %q, 期望 %q", got, expected)
	}
}

func TestProcess_MD5Short(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{MD5_SHORT:hello}", nil)
	// 前 8 位
	expected := "5d41402a"
	if got != expected {
		t.Errorf("{MD5_SHORT:hello} = %q, 期望 %q", got, expected)
	}
}

func TestMD5_Standard(t *testing.T) {
	// sanity check —— MD5 库工作正常
	h := md5.Sum([]byte("hello"))
	got := hex.EncodeToString(h[:])
	if got != "5d41402abc4b2a76b9719d911017c592" {
		t.Errorf("MD5 库输出异常: %q", got)
	}
}

// ===== 自定义变量(1 种,含 random/seq 模式) =====

func TestProcess_Custom_RandomMode(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{CUSTOM:color}", nil)
	found := false
	for _, v := range []string{"red", "green", "blue"} {
		if got == v {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("{CUSTOM:color} 应返回池中任一项,得到 %q", got)
	}
}

func TestProcess_Custom_SeqMode(t *testing.T) {
	// seq 模式应按顺序循环
	p := newTestProc(t)
	got1 := p.Process("{CUSTOM:color:seq}", nil)
	got2 := p.Process("{CUSTOM:color:seq}", nil)
	got3 := p.Process("{CUSTOM:color:seq}", nil)
	got4 := p.Process("{CUSTOM:color:seq}", nil)

	if got1 != "red" || got2 != "green" || got3 != "blue" || got4 != "red" {
		t.Errorf("seq 应顺序循环 red/green/blue/red,得到 %q %q %q %q", got1, got2, got3, got4)
	}
}

func TestProcess_Custom_MissingPool(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("{CUSTOM:missing}", nil)
	if got != "" {
		t.Errorf("{CUSTOM:missing} 应返回空,得到 %q", got)
	}
}

// ===== 条件变量(1 种) =====

func TestProcess_Conditional_True(t *testing.T) {
	p := newTestProc(t)
	rcpt := newRcpt()
	got := p.Process("{IF:TO_DOMAIN=example.co.jp:JP版:其他}", rcpt)
	if got != "JP版" {
		t.Errorf("匹配应走 true 分支,得到 %q", got)
	}
}

func TestProcess_Conditional_False(t *testing.T) {
	p := newTestProc(t)
	rcpt := newRcpt()
	got := p.Process("{IF:TO_DOMAIN=example.com:JP版:其他}", rcpt)
	if got != "其他" {
		t.Errorf("不匹配应走 false 分支,得到 %q", got)
	}
}

func TestProcess_Conditional_CaseInsensitive(t *testing.T) {
	p := newTestProc(t)
	rcpt := newRcpt()
	// EqualFold:JOHN.DOE vs john.doe 应视为相等
	got := p.Process("{IF:TO_USER=JOHN.DOE:matched:not}", rcpt)
	if got != "matched" {
		t.Errorf("EqualFold 应大小写不敏感,得到 %q", got)
	}
}

// ===== 集成测试(多变量组合) =====

func TestProcess_MultipleVariables(t *testing.T) {
	p := newTestProc(t)
	rcpt := newRcpt()
	template := "Hi {TO_FIRST}, on {DATE} at {TIME}, from {FROM_NAME}."
	got := p.Process(template, rcpt)
	want := "Hi John, on 2026-08-06 at 15:52:01, from Hello."
	if got != want {
		t.Errorf("集成:\n期望 %q\n实际 %q", got, want)
	}
}

func TestProcess_EmptyContent(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("", nil)
	if got != "" {
		t.Errorf("空 content 应返回空,得到 %q", got)
	}
}

func TestProcess_NoVariables(t *testing.T) {
	p := newTestProc(t)
	got := p.Process("plain text no vars", nil)
	if got != "plain text no vars" {
		t.Errorf("无变量应原样返回,得到 %q", got)
	}
}

// ===== 复现性(固定种子 + 固定时钟) =====

func TestProcess_Deterministic(t *testing.T) {
	p1 := newTestProc(t)
	p2 := newTestProc(t)
	template := "{RANDOM:10} {UUID} {AMOUNT}"
	got1 := p1.Process(template, nil)
	got2 := p2.Process(template, nil)
	if got1 != got2 {
		t.Errorf("固定种子应完全复现,得到\n%q\n%q", got1, got2)
	}
}

// ===== Config nil 兜底 =====

func TestNew_NilConfig(t *testing.T) {
	// New(nil) 不应 panic
	p := New(random.NewFixedSource(42), clock.NewFixedClock(fixedTime), nil)
	got := p.Process("{FROM_EMAIL}", nil)
	if got != "" {
		t.Errorf("nil Config 时 {FROM_EMAIL} 应为空,得到 %q", got)
	}
}

// ===== Golden 冻结(D14-3=A+C 契约级基准) =====

func TestProcess_Golden_ProductionTemplate(t *testing.T) {
	// 模拟生产模板一封:含时间 + 收件人 + 发件人 + UUID + 金额
	p := newTestProc(t)
	rcpt := newRcpt()
	template := `Dear {TO_NAME},

Order confirmation - {DATE_JP}
Your Order ID: {UUID_SHORT}
Amount: {AMOUNT_JP:1500-5000}
Track: {url}

Best regards,
{FROM_NAME}
Sent at {TIME}`

	got := p.Process(template, rcpt)

	// 验证关键子串
	if !strings.Contains(got, "Dear John Doe") {
		t.Errorf("应含 'Dear John Doe',得到:\n%s", got)
	}
	if !strings.Contains(got, "2026年08月06日") {
		t.Errorf("应含 DATE_JP,得到:\n%s", got)
	}
	if !strings.Contains(got, "¥") {
		t.Errorf("应含 AMOUNT_JP 前缀 ¥,得到:\n%s", got)
	}
	if !strings.Contains(got, "https://example.com/track/abc") {
		t.Errorf("应含 CustomField url,得到:\n%s", got)
	}
	if !strings.Contains(got, "Sent at 15:52:01") {
		t.Errorf("应含 TIME,得到:\n%s", got)
	}
	// UUID_SHORT 32 位 hex
	if !regexp.MustCompile(`Order ID: [0-9a-f]{32}`).MatchString(got) {
		t.Errorf("应含 UUID_SHORT 32 位 hex,得到:\n%s", got)
	}
}
