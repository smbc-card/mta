package basic

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"regexp"
	"strings"
)

// ===== UUID/哈希正则(与 v1 email/variables.go:51-54 完全一致)=====
var (
	reUUID      = regexp.MustCompile(`(?i)\{UUID\}`)
	reUUIDShort = regexp.MustCompile(`(?i)\{UUID_SHORT\}`)
	reMD5       = regexp.MustCompile(`(?i)\{MD5:([^}]+)\}`)
	reMD5Short  = regexp.MustCompile(`(?i)\{MD5_SHORT:([^}]+)\}`)
)

// processUuidHashVariables 处理 4 个 UUID/哈希变量
//
// 【变量清单】
//   - {UUID}           标准 UUIDv4 小写(36 字符,含 4 个 -)
//   - {UUID_SHORT}     UUIDv4 无分隔符(32 字符)
//   - {MD5:input}      input 的 MD5(32 字符小写 hex)
//   - {MD5_SHORT:input} input 的 MD5 前 8 字符
//
// 【MD5:input 的 input】不做嵌套变量解析(v1 一致),如 {MD5:{TO_EMAIL}} 会先经过收件人替换再算 MD5
func (p *Processor) processUuidHashVariables(content string) string {
	content = reUUID.ReplaceAllStringFunc(content, func(match string) string {
		return p.generateUUID()
	})
	content = reUUIDShort.ReplaceAllStringFunc(content, func(match string) string {
		return strings.ReplaceAll(p.generateUUID(), "-", "")
	})
	content = reMD5.ReplaceAllStringFunc(content, func(match string) string {
		sub := reMD5.FindStringSubmatch(match)
		if len(sub) > 1 {
			h := md5.Sum([]byte(sub[1]))
			return hex.EncodeToString(h[:])
		}
		return match
	})
	content = reMD5Short.ReplaceAllStringFunc(content, func(match string) string {
		sub := reMD5Short.FindStringSubmatch(match)
		if len(sub) > 1 {
			h := md5.Sum([]byte(sub[1]))
			return hex.EncodeToString(h[:])[:8]
		}
		return match
	})
	return content
}

// generateUUID 生成 RFC 4122 v4 UUID(小写)
//
// 【与 messageid.uuidV4 逻辑相同】但为了 basic 包独立,不引 messageid
// 【依赖】p.rng.Read
func (p *Processor) generateUUID() string {
	b := make([]byte, 16)
	_, _ = p.rng.Read(b)
	b[6] = (b[6] & 0x0f) | 0x40 // version 4
	b[8] = (b[8] & 0x3f) | 0x80 // variant 10xx
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x",
		b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}
