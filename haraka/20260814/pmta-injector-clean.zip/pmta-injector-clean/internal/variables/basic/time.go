package basic

import (
	"fmt"
	"strconv"
	"strings"
)

// weekdayCN 中文星期名(与 v1 email/variables.go:216 一致)
var weekdayCN = []string{"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"}

// processTimeVariables 处理 14 个时间变量(literal 替换)
//
// 【变量清单】
//   - {DATE_TIME}   "2006-01-02 15:04:05"
//   - {DATE}        "2006-01-02"
//   - {TIME}        "15:04:05"
//   - {YEAR}        "2006"
//   - {MONTH}       "01"
//   - {DAY}         "02"
//   - {HOUR}        "15"
//   - {MINUTE}      "04"
//   - {SECOND}      "05"
//   - {TIMESTAMP}   Unix 秒
//   - {DATE_JP}     "2006年01月02日"
//   - {DATE_CN}     "N年M月D日"(不补零)
//   - {WEEKDAY}     中文星期名
//   - {WEEKDAY_EN}  英文星期名(Monday..)
//
// 【大小写不敏感】每个变量同时替换大写和小写形式(与 v1 一致)
func (p *Processor) processTimeVariables(content string) string {
	now := p.clk.Now()

	replacements := map[string]string{
		"{DATE_TIME}":  now.Format("2006-01-02 15:04:05"),
		"{DATE}":       now.Format("2006-01-02"),
		"{TIME}":       now.Format("15:04:05"),
		"{YEAR}":       now.Format("2006"),
		"{MONTH}":      now.Format("01"),
		"{DAY}":        now.Format("02"),
		"{HOUR}":       now.Format("15"),
		"{MINUTE}":     now.Format("04"),
		"{SECOND}":     now.Format("05"),
		"{TIMESTAMP}":  strconv.FormatInt(now.Unix(), 10),
		"{DATE_JP}":    now.Format("2006年01月02日"),
		"{DATE_CN}":    fmt.Sprintf("%d年%d月%d日", now.Year(), now.Month(), now.Day()),
		"{WEEKDAY}":    weekdayCN[now.Weekday()],
		"{WEEKDAY_EN}": now.Weekday().String(),
	}

	for k, v := range replacements {
		content = strings.ReplaceAll(content, k, v)
		content = strings.ReplaceAll(content, strings.ToLower(k), v)
	}
	return content
}
