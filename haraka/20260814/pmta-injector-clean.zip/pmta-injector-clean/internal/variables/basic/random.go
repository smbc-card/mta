package basic

import (
	"regexp"
	"strconv"
)

// ===== 随机变量正则(与 v1 email/variables.go:25-35 完全一致)=====
//
// 【格式】{RANDOM_XXX} 或 {RANDOM_XXX:N} 或 {RANDOM_XXX:N-M}
//   - 无参数:默认长度 8
//   - :N     固定长度 N
//   - :N-M   随机长度 [N, M]
//
// 【大小写不敏感】(?i) 前缀
var (
	reRandom       = regexp.MustCompile(`(?i)\{RANDOM(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomLower  = regexp.MustCompile(`(?i)\{RANDOM_LOWER(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomUpper  = regexp.MustCompile(`(?i)\{RANDOM_UPPER(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomNum    = regexp.MustCompile(`(?i)\{RANDOM_NUM(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomLowerN = regexp.MustCompile(`(?i)\{RANDOM_LOWER_NUM(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomUpperN = regexp.MustCompile(`(?i)\{RANDOM_UPPER_NUM(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomHex    = regexp.MustCompile(`(?i)\{RANDOM_HEX(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomCN     = regexp.MustCompile(`(?i)\{RANDOM_CN(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomJP     = regexp.MustCompile(`(?i)\{RANDOM_JP(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomHira   = regexp.MustCompile(`(?i)\{RANDOM_HIRA(?::(\d+)(?:-(\d+))?)?\}`)
	reRandomKata   = regexp.MustCompile(`(?i)\{RANDOM_KATA(?::(\d+)(?:-(\d+))?)?\}`)
)

// randomVarDef 正则 + 生成函数配对
type randomVarDef struct {
	re    *regexp.Regexp
	genFn func(p *Processor, length int) string
}

// 11 种随机变量分派表(与 v1 randomVarDefs 一致)
var randomVarDefs = []randomVarDef{
	{reRandom, func(p *Processor, l int) string { return p.generateRandom(l, "alphanumeric") }},
	{reRandomLower, func(p *Processor, l int) string { return p.generateRandom(l, "lower") }},
	{reRandomUpper, func(p *Processor, l int) string { return p.generateRandom(l, "upper") }},
	{reRandomNum, func(p *Processor, l int) string { return p.generateRandom(l, "numeric") }},
	{reRandomLowerN, func(p *Processor, l int) string { return p.generateRandom(l, "lower_num") }},
	{reRandomUpperN, func(p *Processor, l int) string { return p.generateRandom(l, "upper_num") }},
	{reRandomHex, func(p *Processor, l int) string { return p.generateRandom(l, "hex") }},
	{reRandomCN, func(p *Processor, l int) string { return p.generateRandomChinese(l) }},
	{reRandomJP, func(p *Processor, l int) string { return p.generateRandomJapanese(l, true, true) }},
	{reRandomHira, func(p *Processor, l int) string { return p.generateRandomJapanese(l, true, false) }},
	{reRandomKata, func(p *Processor, l int) string { return p.generateRandomJapanese(l, false, true) }},
}

// processRandomVariables 处理 11 种随机变量
//
// 【顺序注意】RANDOM 正则匹配 RANDOM_XXX 的前缀,但因为 RANDOM_XXX 的正则里明确要求 _XXX,
// Go 的正则不会误匹配 —— 不用担心 RANDOM 先跑吃掉 RANDOM_LOWER
// 【实测反证】测试 TestProcess_Random_NoConflict 会验证
func (p *Processor) processRandomVariables(content string) string {
	for _, def := range randomVarDefs {
		def := def
		content = def.re.ReplaceAllStringFunc(content, func(match string) string {
			length := p.parseRandomLength(def.re, match)
			return def.genFn(p, length)
		})
	}
	return content
}

// parseRandomLength 从正则匹配解析长度
//
// 【规则】
//   - 无参数 → 8(默认)
//   - :N     → N
//   - :N-M   → [N, M] 随机
//   - length <= 0 → 1(兜底,避免 make(_, 0/负数))
func (p *Processor) parseRandomLength(re *regexp.Regexp, match string) int {
	length := 8
	submatches := re.FindStringSubmatch(match)
	if len(submatches) > 1 && submatches[1] != "" {
		minV, _ := strconv.Atoi(submatches[1])
		if len(submatches) > 2 && submatches[2] != "" {
			maxV, _ := strconv.Atoi(submatches[2])
			if maxV > minV {
				length = minV + p.rng.Intn(maxV-minV+1)
			} else {
				length = minV
			}
		} else {
			length = minV
		}
	}
	if length <= 0 {
		length = 1
	}
	return length
}

// generateRandom 生成 length 位随机字符串
//
// 【charset 映射】
//   - lower        小写字母
//   - upper        大写字母
//   - numeric      数字
//   - alphanumeric 数字 + 大小写(默认)
//   - lower_num    小写字母 + 数字
//   - upper_num    大写字母 + 数字
//   - hex          十六进制小写(0-9a-f)
func (p *Processor) generateRandom(length int, randType string) string {
	var chars string
	switch randType {
	case "lower":
		chars = "abcdefghijklmnopqrstuvwxyz"
	case "upper":
		chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	case "numeric":
		chars = "0123456789"
	case "alphanumeric":
		chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	case "lower_num":
		chars = "abcdefghijklmnopqrstuvwxyz0123456789"
	case "upper_num":
		chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	case "hex":
		chars = "0123456789abcdef"
	default:
		chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	}

	result := make([]byte, length)
	for i := range result {
		result[i] = chars[p.rng.Intn(len(chars))]
	}
	return string(result)
}

// generateRandomChinese 生成 length 个 CJK 汉字(U+4E00 ~ U+9FFF)
func (p *Processor) generateRandomChinese(length int) string {
	result := make([]rune, length)
	for i := range result {
		result[i] = rune(0x4E00 + p.rng.Intn(0x9FFF-0x4E00+1))
	}
	return string(result)
}

// generateRandomJapanese 生成 length 个日文字符
//
// 【参数】
//   - hiragana=true, katakana=true  → 混合平/片
//   - hiragana=true                 → 仅平假名(U+3040-U+309F)
//   - katakana=true                 → 仅片假名(U+30A0-U+30FF)
func (p *Processor) generateRandomJapanese(length int, hiragana, katakana bool) string {
	result := make([]rune, length)
	for i := range result {
		if hiragana && katakana {
			if p.rng.Intn(2) == 0 {
				result[i] = rune(0x3040 + p.rng.Intn(0x309F-0x3040+1))
			} else {
				result[i] = rune(0x30A0 + p.rng.Intn(0x30FF-0x30A0+1))
			}
		} else if hiragana {
			result[i] = rune(0x3040 + p.rng.Intn(0x309F-0x3040+1))
		} else {
			result[i] = rune(0x30A0 + p.rng.Intn(0x30FF-0x30A0+1))
		}
	}
	return string(result)
}
