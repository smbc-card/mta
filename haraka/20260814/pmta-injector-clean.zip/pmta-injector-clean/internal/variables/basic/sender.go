package basic

import "strings"

// processSenderVariables 处理 4 个发件人 literal 变量
//
// 【变量清单】
//   - {FROM_EMAIL}   = cfg.Sender.FromAddress
//   - {FROM_USER}    = FromAddress @ 前
//   - {FROM_DOMAIN}  = FromAddress @ 后
//   - {FROM_NAME}    = cfg.Sender.FromName
//
// 【大小写】同时替换大小写(与 v1 一致)
func (p *Processor) processSenderVariables(content string) string {
	fromAddr := p.cfg.Sender.FromAddress
	parts := strings.Split(fromAddr, "@")
	user := parts[0]
	domain := ""
	if len(parts) > 1 {
		domain = parts[1]
	}

	replacements := map[string]string{
		"{FROM_EMAIL}":  fromAddr,
		"{FROM_USER}":   user,
		"{FROM_DOMAIN}": domain,
		"{FROM_NAME}":   p.cfg.Sender.FromName,
	}

	for k, v := range replacements {
		content = strings.ReplaceAll(content, k, v)
		content = strings.ReplaceAll(content, strings.ToLower(k), v)
	}
	return content
}
