package basic

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// ===== 金额变量正则(与 v1 email/variables.go:38-42 完全一致)=====
var (
	// {AMOUNT} —— 无参数,用 cfg.Amount 默认
	reAmount = regexp.MustCompile(`(?i)\{AMOUNT\}`)

	// {AMOUNT:min-max(:decimals)?} —— 通用金额
	reAmountR = regexp.MustCompile(`(?i)\{AMOUNT:(\d+)-(\d+)(?::(\d+))?\}`)

	// {AMOUNT_JP:min-max} —— 日元 ¥(整数,带千分位)
	reAmountJP = regexp.MustCompile(`(?i)\{AMOUNT_JP:(\d+)-(\d+)\}`)

	// {AMOUNT_CN:min-max(:decimals)?} —— 人民币 ￥(默认 2 位小数,带千分位)
	reAmountCN = regexp.MustCompile(`(?i)\{AMOUNT_CN:(\d+)-(\d+)(?::(\d+))?\}`)

	// {AMOUNT_USD:min-max(:decimals)?} —— 美元 $(默认 2 位小数,带千分位)
	reAmountUSD = regexp.MustCompile(`(?i)\{AMOUNT_USD:(\d+)-(\d+)(?::(\d+))?\}`)
)

// processAmountVariables 处理 5 种金额变量
//
// 【前缀符号】
//   - {AMOUNT}     无前缀
//   - {AMOUNT_JP}  ¥(全角日元符号)
//   - {AMOUNT_CN}  ￥(全角人民币符号)
//   - {AMOUNT_USD} $
//
// 【千分位】{AMOUNT_JP/CN/USD} 强制带;{AMOUNT} 按 cfg.Amount.UseSeparator
// 【小数位】{AMOUNT_JP} 强制 0;{AMOUNT_CN/USD} 默认 2;可通过 :decimals 覆盖
func (p *Processor) processAmountVariables(content string) string {
	amt := p.cfg.Amount

	content = reAmount.ReplaceAllStringFunc(content, func(match string) string {
		return p.generateAmount(amt.Min, amt.Max, amt.Decimals, amt.UseSeparator, "")
	})

	content = reAmountR.ReplaceAllStringFunc(content, func(match string) string {
		sub := reAmountR.FindStringSubmatch(match)
		minV, _ := strconv.ParseFloat(sub[1], 64)
		maxV, _ := strconv.ParseFloat(sub[2], 64)
		decimals := amt.Decimals
		if len(sub) > 3 && sub[3] != "" {
			decimals, _ = strconv.Atoi(sub[3])
		}
		return p.generateAmount(minV, maxV, decimals, amt.UseSeparator, "")
	})

	content = reAmountJP.ReplaceAllStringFunc(content, func(match string) string {
		sub := reAmountJP.FindStringSubmatch(match)
		minV, _ := strconv.ParseFloat(sub[1], 64)
		maxV, _ := strconv.ParseFloat(sub[2], 64)
		return p.generateAmount(minV, maxV, 0, true, "¥")
	})

	content = reAmountCN.ReplaceAllStringFunc(content, func(match string) string {
		sub := reAmountCN.FindStringSubmatch(match)
		minV, _ := strconv.ParseFloat(sub[1], 64)
		maxV, _ := strconv.ParseFloat(sub[2], 64)
		decimals := 2
		if len(sub) > 3 && sub[3] != "" {
			decimals, _ = strconv.Atoi(sub[3])
		}
		return p.generateAmount(minV, maxV, decimals, true, "￥")
	})

	content = reAmountUSD.ReplaceAllStringFunc(content, func(match string) string {
		sub := reAmountUSD.FindStringSubmatch(match)
		minV, _ := strconv.ParseFloat(sub[1], 64)
		maxV, _ := strconv.ParseFloat(sub[2], 64)
		decimals := 2
		if len(sub) > 3 && sub[3] != "" {
			decimals, _ = strconv.Atoi(sub[3])
		}
		return p.generateAmount(minV, maxV, decimals, true, "$")
	})

	return content
}

// generateAmount 生成金额字符串(prefix + 格式化数字)
func (p *Processor) generateAmount(minV, maxV float64, decimals int, useSeparator bool, prefix string) string {
	amount := minV + p.rng.Float64()*(maxV-minV)

	var formatted string
	if decimals > 0 {
		formatted = fmt.Sprintf("%.*f", decimals, amount)
	} else {
		formatted = fmt.Sprintf("%.0f", amount)
	}

	if useSeparator {
		formatted = addThousandSeparator(formatted)
	}
	return prefix + formatted
}

// addThousandSeparator 给整数部分插入千分位逗号
//
// 【与 v1 一致】处理带小数点或纯整数,逗号只加在整数部分
func addThousandSeparator(s string) string {
	parts := strings.Split(s, ".")
	intPart := parts[0]

	var result []byte
	for i, c := range intPart {
		if i > 0 && (len(intPart)-i)%3 == 0 {
			result = append(result, ',')
		}
		result = append(result, byte(c))
	}
	if len(parts) > 1 {
		return string(result) + "." + parts[1]
	}
	return string(result)
}
