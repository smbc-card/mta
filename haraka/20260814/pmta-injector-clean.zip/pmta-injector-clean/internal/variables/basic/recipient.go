package basic

import (
	"fmt"
	"strings"
	"unicode/utf8"
)

// processRecipientVariables 处理 11 个收件人 literal + N 个自定义字段变量
//
// 【11 个 literal】
//   - {TO_EMAIL}       完整邮箱
//   - {TO_USER}        @ 前部分
//   - {TO_DOMAIN}      @ 后部分
//   - {TO_NAME}        收件人姓名
//   - {TO_FIRST}       名
//   - {TO_LAST}        姓
//   - {TO_USER_UPPER}  {TO_USER} 大写
//   - {TO_USER_LOWER}  {TO_USER} 小写
//   - {TO_USER_CAP}    {TO_USER} 首字母大写(UTF-8 安全,支持中日文)
//   - {TO_NAME_UPPER}  {TO_NAME} 大写
//   - {TO_NAME_LOWER}  {TO_NAME} 小写
//
// 【自定义字段】8 种模式,来自 CSV 额外列:
//   - {key}, {KEY}, {key_lower}
//   - {CUSTOM:key}, {CUSTOM:KEY}, {CUSTOM:key_lower}
//   - {TO_KEY}, {to_key}
//
// 【rcpt=nil】11 literal 全替换为空串;自定义字段跳过
func (p *Processor) processRecipientVariables(content string, rcpt *Recipient) string {
	var email, user, domain, name, first, last string
	var customFields map[string]string

	if rcpt != nil {
		email = rcpt.Email
		name = rcpt.Name
		first = rcpt.FirstName
		last = rcpt.LastName
		customFields = rcpt.CustomFields

		parts := strings.Split(email, "@")
		user = parts[0]
		if len(parts) > 1 {
			domain = parts[1]
		}
	}

	replacements := map[string]string{
		"{TO_EMAIL}":      email,
		"{TO_USER}":       user,
		"{TO_DOMAIN}":     domain,
		"{TO_NAME}":       name,
		"{TO_FIRST}":      first,
		"{TO_LAST}":       last,
		"{TO_USER_UPPER}": strings.ToUpper(user),
		"{TO_USER_LOWER}": strings.ToLower(user),
		"{TO_USER_CAP}":   capitalizeFirst(user),
		"{TO_NAME_UPPER}": strings.ToUpper(name),
		"{TO_NAME_LOWER}": strings.ToLower(name),
	}

	for k, v := range replacements {
		content = strings.ReplaceAll(content, k, v)
		content = strings.ReplaceAll(content, strings.ToLower(k), v)
	}

	// 自定义 CSV 字段(仅当 recipient 非 nil 且有字段时)
	if len(customFields) > 0 {
		for key, value := range customFields {
			patterns := []string{
				fmt.Sprintf("{%s}", key),
				fmt.Sprintf("{%s}", strings.ToUpper(key)),
				fmt.Sprintf("{%s}", strings.ToLower(key)),
				fmt.Sprintf("{CUSTOM:%s}", key),
				fmt.Sprintf("{CUSTOM:%s}", strings.ToUpper(key)),
				fmt.Sprintf("{CUSTOM:%s}", strings.ToLower(key)),
				fmt.Sprintf("{TO_%s}", strings.ToUpper(key)),
				fmt.Sprintf("{to_%s}", strings.ToLower(key)),
			}
			for _, pattern := range patterns {
				if strings.Contains(content, pattern) {
					content = strings.ReplaceAll(content, pattern, value)
				}
			}
		}
	}

	return content
}

// capitalizeFirst 首字母大写(UTF-8 安全)
//
// 【与 v1 一致】用 utf8.DecodeRuneInString,正确处理多字节字符(日文/中文)
// 【行为】首字符大写 + 其余小写(不是仅首字符大写)
func capitalizeFirst(s string) string {
	if len(s) == 0 {
		return s
	}
	r, size := utf8.DecodeRuneInString(s)
	if r == utf8.RuneError {
		return s
	}
	return strings.ToUpper(string(r)) + strings.ToLower(s[size:])
}
