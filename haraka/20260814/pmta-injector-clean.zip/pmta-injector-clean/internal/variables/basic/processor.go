// Package basic 实现"基础变量"(不依赖 data pool 的所有变量,约 55 个)
//
// 【与 v1 对比】
//   - v1 email/variables.go(731 行)—— basic + custom + conditional
//   - v2 internal/variables/basic/ —— 拆分 10 文件,按变量组分文件
//
// 【依赖】
//   - internal/random —— 所有随机变量的种子源
//   - internal/clock —— 所有时间变量的时钟源
//   - 不依赖 internal/data —— basic 变量不读文件池
//   - 不依赖 internal/config —— 通过本地 Config struct 参数注入(避免循环依赖)
//
// 【线程安全】非并发安全 —— 生产建议每个 worker 一个 Processor 实例(与 v1 一致)
package basic

import (
	"__MODULE_PLACEHOLDER__/internal/clock"
	"__MODULE_PLACEHOLDER__/internal/random"
)

// Config basic 处理器需要的运行时配置
//
// 【设计原则】不引用 internal/config 包,避免循环依赖 & 使 basic 包保持独立可复用
// 【填充路径】外层从 config.Config 里挑出 basic 需要的字段构造此 Config
type Config struct {
	// Sender 发件人字段(用于 {FROM_*})
	Sender SenderVars

	// Amount 金额生成默认参数(用于无参数 {AMOUNT})
	Amount AmountCfg

	// Custom 自定义变量池(用于 {CUSTOM:name(:mode)})—— 由 config.Variables.CustomVariableFiles 加载
	Custom map[string][]string
}

// SenderVars 发件人相关字段(基本上映射到 config.SenderConfig 的 4 个字段)
type SenderVars struct {
	FromAddress string
	FromName    string
}

// AmountCfg 金额默认参数(映射到 config.VariablesConfig 的 amount_* 字段)
type AmountCfg struct {
	Min          float64
	Max          float64
	Decimals     int
	UseSeparator bool
}

// Recipient 收件人上下文(用于 {TO_*} + {IF:...} + 自定义字段)
//
// 【设计原则】本地定义,不引 v1 types.Recipient —— basic 包独立自洽
type Recipient struct {
	Email        string
	Name         string
	FirstName    string
	LastName     string
	CustomFields map[string]string
}

// Processor basic 变量处理器
//
// 【状态】seqIdx 是 per-name 的 {CUSTOM:name:seq} 计数器(v1 里叫 customVarIndex)
type Processor struct {
	rng    random.Source
	clk    clock.Clock
	cfg    *Config
	seqIdx map[string]int // {CUSTOM:name:seq} per-name 计数器
}

// New 创建 basic 处理器
//
// 【参数】
//   - rng:必需(nil 会 panic on first use)
//   - clk:必需(同上)
//   - cfg:必需 —— basic 包依赖的运行时配置
func New(rng random.Source, clk clock.Clock, cfg *Config) *Processor {
	if cfg == nil {
		cfg = &Config{} // 兜底:允许空配置,但 {CUSTOM:...} 会返回空串,{FROM_*} 会返回空串
	}
	if cfg.Custom == nil {
		cfg.Custom = make(map[string][]string)
	}
	return &Processor{
		rng:    rng,
		clk:    clk,
		cfg:    cfg,
		seqIdx: make(map[string]int),
	}
}

// Process 依次处理所有 basic 变量
//
// 【顺序】与 v1 email/variables.go::Process 一致:
//  1. 时间变量({DATE_*}, {TIME}, {YEAR}, ...)
//  2. 收件人变量({TO_*}, {custom_field_from_csv})
//  3. 发件人变量({FROM_*})
//  4. 随机变量({RANDOM(_XXX)?(:N-M)?})
//  5. 金额变量({AMOUNT(_XXX)?(:N-M(:D)?)?})
//  6. IP 变量({RANDOM_IP(_XX)?})
//  7. UUID/哈希变量({UUID}, {UUID_SHORT}, {MD5:s}, {MD5_SHORT:s})
//  8. 自定义变量({CUSTOM:name(:mode)?})
//  9. 条件变量({IF:field=val:true:false})
//
// 【为什么固定这个顺序】
//   - 时间/收件人/发件人 literal 替换在前 —— 后面的 {IF:TO_DOMAIN=...} 才能拿到值
//   - 随机在中间 —— {IF} 不判断随机字段
//   - CUSTOM/IF 在最后 —— 允许 CUSTOM 里插入含变量的字符串(v1 也如此,但不做嵌套解析)
//
// 【recipient=nil 处理】
//   - 若为 nil,{TO_*} 全部替换为空串;{IF:TO_XX=...} 走 false 分支
func (p *Processor) Process(content string, rcpt *Recipient) string {
	if content == "" {
		return content
	}

	content = p.processTimeVariables(content)
	content = p.processRecipientVariables(content, rcpt)
	content = p.processSenderVariables(content)
	content = p.processRandomVariables(content)
	content = p.processAmountVariables(content)
	content = p.processIPVariables(content)
	content = p.processUuidHashVariables(content)
	content = p.processCustomVariables(content)
	content = p.processConditionalVariables(content, rcpt)

	return content
}
