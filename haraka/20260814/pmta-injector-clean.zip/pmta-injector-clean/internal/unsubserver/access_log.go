package unsubserver

// Access log —— 契约 §8.6
//
// 【路径】/var/log/pmta-injector-unsub/access.log(硬编码)
// 【格式】<ts> <remote_addr> <method> <host> <path> <status> <bytes> "<user_agent>"
// 【时间】2006-01-02T15:04:05-0700(无冒号时区)
// 【日滚动】每次写前 stat mtime;跨天 → rename + 重开;>7 天归档删

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// accessLogDir 硬编码路径(契约 §8.6);测试内部可覆盖
var accessLogDir = "/var/log/pmta-injector-unsub"

// accessLogger 日滚 + 7 天保留
type accessLogger struct {
	filePath string
	mu       sync.Mutex
	file     *os.File
}

// newAccessLogger 打开 accessLogDir/access.log
//
// 【行为】
//   - MkdirAll(0755) 创建目录 —— 失败则返回 nil(不阻塞 server 启动;写日志变 no-op)
//   - OpenFile(O_APPEND|O_CREATE|O_WRONLY, 0644) —— 失败同上
func newAccessLogger() *accessLogger {
	if err := os.MkdirAll(accessLogDir, 0o755); err != nil {
		return nil
	}
	fp := filepath.Join(accessLogDir, "access.log")
	f, err := os.OpenFile(fp, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return nil
	}
	return &accessLogger{filePath: fp, file: f}
}

// Log 写一行 access log(线程安全,含日滚动检查)
func (l *accessLogger) Log(r *http.Request, status, bytes int) {
	if l == nil || l.file == nil {
		return
	}

	l.mu.Lock()
	defer l.mu.Unlock()

	l.rotateIfNeeded()

	now := time.Now().Format("2006-01-02T15:04:05-0700")
	ua := r.Header.Get("User-Agent")
	if ua == "" {
		ua = "-"
	}
	line := fmt.Sprintf("%s %s %s %s %s %d %d %q\n",
		now, r.RemoteAddr, r.Method, r.Host, r.URL.RequestURI(), status, bytes, ua)
	_, _ = io.WriteString(l.file, line)
}

// Close 关闭文件句柄(server shutdown 时)
func (l *accessLogger) Close() error {
	if l == nil || l.file == nil {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	err := l.file.Close()
	l.file = nil
	return err
}

// rotateIfNeeded 跨天则 rename + 重开;调用方持锁
func (l *accessLogger) rotateIfNeeded() {
	if l.file == nil {
		return
	}
	info, err := l.file.Stat()
	if err != nil {
		return
	}
	today := time.Now().Format("2006-01-02")
	lastMod := info.ModTime().Format("2006-01-02")
	if today == lastMod {
		return
	}

	_ = l.file.Close()
	archived := l.filePath + "." + lastMod
	_ = os.Rename(l.filePath, archived)

	f, err := os.OpenFile(l.filePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		l.file = nil
		return
	}
	l.file = f

	go l.cleanOldLogs()
}

// cleanOldLogs 删 >7 天的归档;异步 goroutine
func (l *accessLogger) cleanOldLogs() {
	dir := filepath.Dir(l.filePath)
	prefix := filepath.Base(l.filePath) + "."
	cutoff := time.Now().Add(-7 * 24 * time.Hour)

	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	for _, e := range entries {
		if !strings.HasPrefix(e.Name(), prefix) {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		if info.ModTime().Before(cutoff) {
			_ = os.Remove(filepath.Join(dir, e.Name()))
		}
	}
}
