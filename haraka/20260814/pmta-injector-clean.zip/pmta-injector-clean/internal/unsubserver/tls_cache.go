package unsubserver

// TLS 证书 5 秒 mtime 缓存 —— 契约 §8.1 v2 增强
//
// 【v1 行为】每次 TLS 握手 GetCertificate 回调都 tls.LoadX509KeyPair 读盘
// 【v2 增强】5 秒 mtime 缓存 + 变化才重读
//   - 支持 acme.sh 自动续期(mtime 一变立即生效)
//   - 高并发下减少盘 IO(热点连接批量握手时)

import (
	"crypto/tls"
	"fmt"
	"os"
	"sync"
	"time"
)

// tlsCertCache 5s mtime 缓存
type tlsCertCache struct {
	certFile string
	keyFile  string

	mu           sync.Mutex
	cachedCert   *tls.Certificate
	certModTime  time.Time
	keyModTime   time.Time
	lastCheck    time.Time
	checkTTL     time.Duration
	nowFn        func() time.Time // 可注入(test)
	loadFn       func(certFile, keyFile string) (tls.Certificate, error)
	statFn       func(name string) (os.FileInfo, error)
}

// newTLSCertCache 创建缓存
func newTLSCertCache(certFile, keyFile string) *tlsCertCache {
	return &tlsCertCache{
		certFile: certFile,
		keyFile:  keyFile,
		checkTTL: 5 * time.Second,
		nowFn:    time.Now,
		loadFn:   tls.LoadX509KeyPair,
		statFn:   os.Stat,
	}
}

// GetCertificate 用于 tls.Config.GetCertificate 回调
//
// 【逻辑】
//  1. 距上次 stat < 5s → 直接返回 cachedCert(即使为 nil 也返回 nil + err;避免击穿)
//  2. 距上次 stat ≥ 5s → stat 两个文件,若 mtime 变化则重读,否则更新 lastCheck 复用 cache
func (c *tlsCertCache) GetCertificate(_ *tls.ClientHelloInfo) (*tls.Certificate, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	now := c.nowFn()

	// 5s 内直接用 cache
	if c.cachedCert != nil && now.Sub(c.lastCheck) < c.checkTTL {
		return c.cachedCert, nil
	}

	// stat 两个文件
	certInfo, err := c.statFn(c.certFile)
	if err != nil {
		return nil, fmt.Errorf("stat cert %s: %w", c.certFile, err)
	}
	keyInfo, err := c.statFn(c.keyFile)
	if err != nil {
		return nil, fmt.Errorf("stat key %s: %w", c.keyFile, err)
	}

	// mtime 未变 → 复用 cache(即使已过 TTL,只要文件没改)
	if c.cachedCert != nil &&
		certInfo.ModTime().Equal(c.certModTime) &&
		keyInfo.ModTime().Equal(c.keyModTime) {
		c.lastCheck = now
		return c.cachedCert, nil
	}

	// 文件变了 → 重读
	cert, err := c.loadFn(c.certFile, c.keyFile)
	if err != nil {
		return nil, fmt.Errorf("load cert/key: %w", err)
	}

	c.cachedCert = &cert
	c.certModTime = certInfo.ModTime()
	c.keyModTime = keyInfo.ModTime()
	c.lastCheck = now
	return c.cachedCert, nil
}
