package unsubserver

import (
	"strings"
	"testing"
)

// ============================================================================
// generateInstanceSignature —— 取值范围
// ============================================================================

func TestGenerateInstanceSignature_Ranges(t *testing.T) {
	// 跑 200 次覆盖池索引
	for i := 0; i < 200; i++ {
		sig := generateInstanceSignature()

		if !containsString(headingColors, sig.HeadingColor) {
			t.Errorf("HeadingColor %q 不在池里", sig.HeadingColor)
		}
		if !containsString(bodyColors, sig.BodyColor) {
			t.Errorf("BodyColor %q 不在池里", sig.BodyColor)
		}
		if !containsString(headingCandidates, sig.HeadingText) {
			t.Errorf("HeadingText %q 不在池里", sig.HeadingText)
		}
		if !containsString(bodyCandidates, sig.BodyText) {
			t.Errorf("BodyText %q 不在池里", sig.BodyText)
		}
		if sig.PaddingLen < 0 || sig.PaddingLen > 32 {
			t.Errorf("PaddingLen=%d 应在 0-32", sig.PaddingLen)
		}
		if len(sig.HtmlComment) != 16 { // 8 字节 hex = 16 字符
			t.Errorf("HtmlComment 长度=%d, want=16 hex", len(sig.HtmlComment))
		}
	}
}

func TestGenerateInstanceSignature_HasEntropy(t *testing.T) {
	// 100 次抽样,HtmlComment 应出现变化
	seen := map[string]bool{}
	for i := 0; i < 100; i++ {
		sig := generateInstanceSignature()
		seen[sig.HtmlComment] = true
	}
	if len(seen) < 50 {
		t.Errorf("100 次 HtmlComment 只出现 %d 种,应 >= 50(熵不足)", len(seen))
	}
}

// ============================================================================
// buildHTML —— 结构 + 反指纹字段注入
// ============================================================================

func TestBuildHTML_ContainsAllSignatureFields(t *testing.T) {
	sig := instanceSignature{
		HeadingColor: "0066cc",
		BodyColor:    "333333",
		HeadingText:  "TESTHEADING",
		BodyText:     "TESTBODY。",
		UseFullStop:  true,
		PaddingLen:   5,
		HtmlComment:  "abcdef0123456789",
	}
	html := string(buildHTML(sig))

	checks := []string{
		"<!DOCTYPE html>",
		`lang="ja"`,
		`meta name="robots" content="noindex, nofollow"`,
		"#0066cc",
		"#333333",
		"TESTHEADING",
		"TESTBODY。",             // UseFullStop=true 保留句号
		"<!-- ref:abcdef0123456789 -->",
		"ご利用ありがとうございました",
	}
	for _, s := range checks {
		if !strings.Contains(html, s) {
			t.Errorf("HTML 未含 %q", s)
		}
	}

	// padding 5 空格应在 </body> 前
	// 检查 <!-- ref:...--> 后跟 5 空格
	needle := "<!-- ref:abcdef0123456789 -->     "
	if !strings.Contains(html, needle) {
		t.Errorf("HTML 未含 5 空格 padding")
	}
}

func TestBuildHTML_UseFullStopFalse_StripsPeriod(t *testing.T) {
	sig := instanceSignature{
		HeadingColor: "0066cc",
		BodyColor:    "333333",
		HeadingText:  "H",
		BodyText:     "BODY。",
		UseFullStop:  false, // 应去掉句号
		PaddingLen:   0,
		HtmlComment:  "aa",
	}
	html := string(buildHTML(sig))
	if strings.Contains(html, "BODY。") {
		t.Error("UseFullStop=false 应去掉句号,仍含 'BODY。'")
	}
	if !strings.Contains(html, "BODY") {
		t.Error("BODY 主体应保留")
	}
}

func TestBuildHTML_SizeUnder2KB(t *testing.T) {
	// 契约 §8.5:HTML < 2 KB
	sig := generateInstanceSignature()
	html := buildHTML(sig)
	if len(html) >= 2048 {
		t.Errorf("HTML 大小=%d, 契约 <2KB", len(html))
	}
	if len(html) < 500 {
		t.Errorf("HTML 大小=%d, 太小应至少 500 字节", len(html))
	}
}

func TestBuildHTML_DeterministicForSameSignature(t *testing.T) {
	// 同一 sig 应生成同一 HTML(反指纹前提)
	sig := instanceSignature{
		HeadingColor: "0066cc",
		BodyColor:    "333333",
		HeadingText:  "H",
		BodyText:     "B",
		UseFullStop:  true,
		PaddingLen:   3,
		HtmlComment:  "aa",
	}
	a := buildHTML(sig)
	b := buildHTML(sig)
	if string(a) != string(b) {
		t.Error("同一 sig 应生成相同 HTML")
	}
}

// ============================================================================
// helper
// ============================================================================

func containsString(pool []string, want string) bool {
	for _, s := range pool {
		if s == want {
			return true
		}
	}
	return false
}
