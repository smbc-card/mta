package unsubserver

import (
	"crypto/tls"
	"errors"
	"os"
	"testing"
	"time"
)

// fakeFileInfo 实现 os.FileInfo,仅返回 mtime
type fakeFileInfo struct {
	name  string
	mtime time.Time
}

func (f fakeFileInfo) Name() string       { return f.name }
func (f fakeFileInfo) Size() int64        { return 0 }
func (f fakeFileInfo) Mode() os.FileMode  { return 0 }
func (f fakeFileInfo) ModTime() time.Time { return f.mtime }
func (f fakeFileInfo) IsDir() bool        { return false }
func (f fakeFileInfo) Sys() interface{}   { return nil }

// ============================================================================
// TTL 5s 内不 stat 不 load
// ============================================================================

func TestTLSCache_WithinTTL_NoStatNoLoad(t *testing.T) {
	statCount, loadCount := 0, 0
	cache := &tlsCertCache{
		certFile: "cert.pem", keyFile: "key.pem",
		checkTTL: 5 * time.Second,
		cachedCert: &tls.Certificate{}, // 预置 cache
		lastCheck:  time.Unix(1000, 0),
		nowFn:      func() time.Time { return time.Unix(1002, 0) }, // +2s
		statFn: func(name string) (os.FileInfo, error) {
			statCount++
			return nil, errors.New("should not be called")
		},
		loadFn: func(c, k string) (tls.Certificate, error) {
			loadCount++
			return tls.Certificate{}, errors.New("should not be called")
		},
	}

	cert, err := cache.GetCertificate(nil)
	if err != nil {
		t.Fatalf("GetCertificate: %v", err)
	}
	if cert == nil {
		t.Fatal("cert 应非 nil")
	}
	if statCount != 0 {
		t.Errorf("5s 内不应 stat,got=%d", statCount)
	}
	if loadCount != 0 {
		t.Errorf("5s 内不应 load,got=%d", loadCount)
	}
}

// ============================================================================
// TTL 过期后 stat,mtime 未变则复用 cache
// ============================================================================

func TestTLSCache_TTLExpired_MtimeUnchanged_ReusesCache(t *testing.T) {
	fixedMtime := time.Unix(500, 0)
	statCount, loadCount := 0, 0

	cache := &tlsCertCache{
		certFile: "cert.pem", keyFile: "key.pem",
		checkTTL:    5 * time.Second,
		cachedCert:  &tls.Certificate{},
		certModTime: fixedMtime,
		keyModTime:  fixedMtime,
		lastCheck:   time.Unix(1000, 0),
		nowFn:       func() time.Time { return time.Unix(1010, 0) }, // +10s 已过 TTL
		statFn: func(name string) (os.FileInfo, error) {
			statCount++
			return fakeFileInfo{name: name, mtime: fixedMtime}, nil
		},
		loadFn: func(c, k string) (tls.Certificate, error) {
			loadCount++
			return tls.Certificate{}, errors.New("should not be called")
		},
	}

	_, err := cache.GetCertificate(nil)
	if err != nil {
		t.Fatalf("GetCertificate: %v", err)
	}
	if statCount != 2 {
		t.Errorf("应 stat cert+key = 2 次,got=%d", statCount)
	}
	if loadCount != 0 {
		t.Errorf("mtime 未变不应 load,got=%d", loadCount)
	}
	if !cache.lastCheck.Equal(time.Unix(1010, 0)) {
		t.Error("lastCheck 应更新")
	}
}

// ============================================================================
// TTL 过期 + mtime 变 → 重读
// ============================================================================

func TestTLSCache_MtimeChanged_Reloads(t *testing.T) {
	oldMtime := time.Unix(500, 0)
	newMtime := time.Unix(2000, 0)
	loadCount := 0

	cache := &tlsCertCache{
		certFile: "cert.pem", keyFile: "key.pem",
		checkTTL:    5 * time.Second,
		cachedCert:  &tls.Certificate{Certificate: [][]byte{{1}}},
		certModTime: oldMtime,
		keyModTime:  oldMtime,
		lastCheck:   time.Unix(1000, 0),
		nowFn:       func() time.Time { return time.Unix(1010, 0) },
		statFn: func(name string) (os.FileInfo, error) {
			return fakeFileInfo{name: name, mtime: newMtime}, nil
		},
		loadFn: func(c, k string) (tls.Certificate, error) {
			loadCount++
			return tls.Certificate{Certificate: [][]byte{{2}}}, nil
		},
	}

	cert, err := cache.GetCertificate(nil)
	if err != nil {
		t.Fatalf("GetCertificate: %v", err)
	}
	if loadCount != 1 {
		t.Errorf("mtime 变应 load 1 次,got=%d", loadCount)
	}
	if len(cert.Certificate) != 1 || cert.Certificate[0][0] != 2 {
		t.Error("cachedCert 未更新为新版本")
	}
	if !cache.certModTime.Equal(newMtime) {
		t.Error("certModTime 未更新")
	}
}

// ============================================================================
// stat cert 失败
// ============================================================================

func TestTLSCache_StatCertFail(t *testing.T) {
	cache := &tlsCertCache{
		certFile: "cert.pem", keyFile: "key.pem",
		checkTTL: 5 * time.Second,
		nowFn:    func() time.Time { return time.Unix(1000, 0) },
		statFn: func(name string) (os.FileInfo, error) {
			return nil, errors.New("no such file")
		},
		loadFn: func(c, k string) (tls.Certificate, error) {
			return tls.Certificate{}, nil
		},
	}
	_, err := cache.GetCertificate(nil)
	if err == nil {
		t.Fatal("stat 失败应 err")
	}
}

// ============================================================================
// load 失败
// ============================================================================

func TestTLSCache_LoadFail(t *testing.T) {
	cache := &tlsCertCache{
		certFile: "cert.pem", keyFile: "key.pem",
		checkTTL: 5 * time.Second,
		nowFn:    func() time.Time { return time.Unix(1000, 0) },
		statFn: func(name string) (os.FileInfo, error) {
			return fakeFileInfo{name: name, mtime: time.Unix(500, 0)}, nil
		},
		loadFn: func(c, k string) (tls.Certificate, error) {
			return tls.Certificate{}, errors.New("invalid pem")
		},
	}
	_, err := cache.GetCertificate(nil)
	if err == nil {
		t.Fatal("load 失败应 err")
	}
}

// ============================================================================
// 首次调用(无 cache)+ load 成功
// ============================================================================

func TestTLSCache_FirstCall_LoadsAndCaches(t *testing.T) {
	mtime := time.Unix(500, 0)
	loadCount := 0
	cache := &tlsCertCache{
		certFile: "cert.pem", keyFile: "key.pem",
		checkTTL: 5 * time.Second,
		nowFn:    func() time.Time { return time.Unix(1000, 0) },
		statFn: func(name string) (os.FileInfo, error) {
			return fakeFileInfo{name: name, mtime: mtime}, nil
		},
		loadFn: func(c, k string) (tls.Certificate, error) {
			loadCount++
			return tls.Certificate{Certificate: [][]byte{{1}}}, nil
		},
	}
	cert, err := cache.GetCertificate(nil)
	if err != nil {
		t.Fatalf("GetCertificate: %v", err)
	}
	if loadCount != 1 {
		t.Errorf("首次应 load 1 次,got=%d", loadCount)
	}
	if cert == nil {
		t.Fatal("cert 应非 nil")
	}
	// 再调用(在 TTL 内)→ 不 load
	_, _ = cache.GetCertificate(nil)
	if loadCount != 1 {
		t.Errorf("TTL 内第 2 次仍应 load=1,got=%d", loadCount)
	}
}

// ============================================================================
// newTLSCertCache 默认字段
// ============================================================================

func TestNewTLSCertCache_Defaults(t *testing.T) {
	c := newTLSCertCache("cert.pem", "key.pem")
	if c.certFile != "cert.pem" || c.keyFile != "key.pem" {
		t.Error("file 字段未设")
	}
	if c.checkTTL != 5*time.Second {
		t.Errorf("checkTTL=%v want=5s", c.checkTTL)
	}
	if c.nowFn == nil || c.loadFn == nil || c.statFn == nil {
		t.Error("默认 fn 未注入")
	}
}
