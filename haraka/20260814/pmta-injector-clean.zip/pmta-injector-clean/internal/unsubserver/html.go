package unsubserver

// HTML 反指纹实例签名 + HTML 生成 —— 契约 §8.5
//
// 【核心思想】启动时用 crypto/rand 一次抽样,进程生命周期内 HTML 稳定
//   - 爬虫多次 GET 内容一致 → 不触发"动态页面"警报
//   - 同一进程重启后不同 → 服务器指纹不聚类

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"strings"
	"time"
)

// instanceSignature 反指纹实例签名(启动时一次生成,进程生命周期内不变)
type instanceSignature struct {
	HeadingColor string
	BodyColor    string
	HtmlComment  string
	UseFullStop  bool
	PaddingLen   int
	HeadingText  string
	BodyText     string
}

// headingCandidates 标题候选池(3 选 1,日语退订完成常见写法)
//
// 【契约 §8.5】候选池可增不可删
var headingCandidates = []string{
	"メール配信停止手続き完了",
	"配信停止が完了しました",
	"メール配信停止が完了しました",
}

// bodyCandidates 正文候选池(3 选 1)
var bodyCandidates = []string{
	"ご登録いただいたメールアドレスへの配信を停止しました。今後、当社からのメールは届きません。",
	"メールマガジンの配信停止を承りました。今後はメールが届きません。",
	"配信停止のお手続きが完了しました。今後このメールアドレスへ配信されることはございません。",
}

// headingColors 蓝色系(7 选 1)
var headingColors = []string{"0055bb", "0066cc", "1d4ed8", "2563eb", "1e40af", "1565c0", "0d47a1"}

// bodyColors 灰色系(5 选 1)
var bodyColors = []string{"333333", "444444", "555555", "2f2f2f", "3a3a3a"}

// generateInstanceSignature 启动时调用一次生成签名
//
// 【逻辑】crypto/rand 16 字节 → 用字节值决定池索引 / bool / len
// 【兜底】rand 失败 → 用 UnixNano 做种子(极罕见)
func generateInstanceSignature() instanceSignature {
	buf := make([]byte, 16)
	if _, err := rand.Read(buf); err != nil {
		copy(buf, []byte(fmt.Sprintf("%d", time.Now().UnixNano())))
	}

	return instanceSignature{
		HeadingColor: headingColors[int(buf[0])%len(headingColors)],
		BodyColor:    bodyColors[int(buf[1])%len(bodyColors)],
		HeadingText:  headingCandidates[int(buf[2])%len(headingCandidates)],
		BodyText:     bodyCandidates[int(buf[3])%len(bodyCandidates)],
		UseFullStop:  buf[4]&1 == 1,
		PaddingLen:   int(buf[5]) % 33,
		HtmlComment:  hex.EncodeToString(buf[6:14]),
	}
}

// buildHTML 根据签名生成退订 HTML(一次生成 + 缓存)
//
// 【契约 §8.5】< 2 KB,含所有反指纹变量注入
func buildHTML(sig instanceSignature) []byte {
	bodyText := sig.BodyText
	if !sig.UseFullStop {
		bodyText = strings.TrimRight(bodyText, "。")
	}
	padding := strings.Repeat(" ", sig.PaddingLen)

	html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>%s</title>
<style>
body { font-family: 'Hiragino Sans', 'Yu Gothic', sans-serif; text-align: center; padding: 60px 20px; color: #%s; max-width: 600px; margin: 0 auto; }
h1 { font-size: 22px; color: #%s; margin-bottom: 16px; }
p { font-size: 14px; line-height: 1.7; margin: 0.8em 0; }
.thanks { margin-top: 24px; color: #888; font-size: 13px; }
</style>
</head>
<body>
<h1>%s</h1>
<p>%s</p>
<p class="thanks">ご利用ありがとうございました</p>
<!-- ref:%s -->%s
</body>
</html>
`,
		sig.HeadingText,
		sig.BodyColor,
		sig.HeadingColor,
		sig.HeadingText,
		bodyText,
		sig.HtmlComment,
		padding,
	)
	return []byte(html)
}
