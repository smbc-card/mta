package unsubserver

// Host 校验 —— 契约 §8.3
//
// 【反扫描】拒绝 Host 头不匹配配置 Domain 的请求(IP 扫描 / 错误 Hostname)
// 邮件 List-Unsubscribe URL 由 Gmail/Yahoo 解析 → DNS A → 请求带 Host: <domain>
// 扫描器扫本机 IP 通常用 IP 作 Host 或留空 → 不匹配 → 404 → 不暴露"这是发件器"

import (
	"strings"
)

// hostMatchesConfigured 剥端口(含 IPv6)+ 大小写不敏感比较
//
// 【行为】
//   - configured == "" → 退化不校验(部署异常兜底,避免误拒)
//   - reqHost == "" → 拒绝(HTTP/1.0 古老客户端可能)
//   - "host:port" → 取 ":" 前
//   - "[::1]:80" → 取 "[" 和 "]" 之间
func hostMatchesConfigured(reqHost, configured string) bool {
	configured = strings.TrimSpace(configured)
	if configured == "" {
		return true
	}
	if reqHost == "" {
		return false
	}

	host := reqHost
	if strings.HasPrefix(host, "[") {
		// IPv6 字面量
		if end := strings.LastIndex(host, "]"); end > 0 {
			host = host[1:end]
		}
	} else if idx := strings.LastIndex(host, ":"); idx >= 0 {
		host = host[:idx]
	}

	return strings.EqualFold(strings.TrimSpace(host), configured)
}
