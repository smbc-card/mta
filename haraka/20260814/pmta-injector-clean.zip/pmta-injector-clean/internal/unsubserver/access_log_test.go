package unsubserver

import (
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"testing"
	"time"
)

// withAccessLogDir 临时覆盖硬编码路径给测试用
func withAccessLogDir(t *testing.T, dir string) {
	t.Helper()
	old := accessLogDir
	accessLogDir = dir
	t.Cleanup(func() { accessLogDir = old })
}

// ============================================================================
// newAccessLogger 打开成功 / 目录不存在(应 nil)
// ============================================================================

func TestNewAccessLogger_Success(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)

	l := newAccessLogger()
	if l == nil {
		t.Fatal("newAccessLogger 应成功")
	}
	defer l.Close()

	if l.filePath != filepath.Join(dir, "access.log") {
		t.Errorf("filePath=%s", l.filePath)
	}
	if _, err := os.Stat(l.filePath); err != nil {
		t.Errorf("access.log 未创建:%v", err)
	}
}

func TestNewAccessLogger_MkdirCreatesDir(t *testing.T) {
	// 用 TempDir 下的子目录(mkdir all 会创建)
	dir := filepath.Join(t.TempDir(), "sub", "sub2")
	withAccessLogDir(t, dir)

	l := newAccessLogger()
	if l == nil {
		t.Fatal("newAccessLogger 应成功(mkdir all)")
	}
	defer l.Close()

	if _, err := os.Stat(dir); err != nil {
		t.Errorf("目录应被创建:%v", err)
	}
}

// ============================================================================
// Log —— 格式契约 §8.6
// ============================================================================

func TestAccessLog_LineFormat(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)
	l := newAccessLogger()
	defer l.Close()

	r := httptest.NewRequest("GET", "/unsub?u=xyz", nil)
	r.RemoteAddr = "1.2.3.4:54321"
	r.Host = "example.com"
	r.Header.Set("User-Agent", "Mozilla/5.0 (test)")
	l.Log(r, 200, 1847)

	data, err := os.ReadFile(l.filePath)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	line := strings.TrimSpace(string(data))

	// 契约格式:<ts> <remote> <method> <host> <path> <status> <bytes> "<ua>"
	// ts:2026-01-02T15:04:05±HHMM (无冒号时区)
	re := regexp.MustCompile(`^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{4} 1\.2\.3\.4:54321 GET example\.com /unsub\?u=xyz 200 1847 "Mozilla/5\.0 \(test\)"$`)
	if !re.MatchString(line) {
		t.Errorf("行格式:%s", line)
	}
}

func TestAccessLog_EmptyUserAgent_DashPlaceholder(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)
	l := newAccessLogger()
	defer l.Close()

	r := httptest.NewRequest("GET", "/", nil)
	r.RemoteAddr = "1.1.1.1:1"
	r.Host = "h"
	// 不设 User-Agent
	l.Log(r, 200, 0)

	data, _ := os.ReadFile(l.filePath)
	if !strings.Contains(string(data), ` "-"`) {
		t.Errorf("空 UA 应用 '-',got:%s", string(data))
	}
}

func TestAccessLog_NilLoggerNoOp(t *testing.T) {
	var l *accessLogger
	// 不 panic
	l.Log(httptest.NewRequest("GET", "/", nil), 200, 0)
	if err := l.Close(); err != nil {
		t.Errorf("nil Close 应 nil,got:%v", err)
	}
}

// ============================================================================
// 并发写线程安全
// ============================================================================

func TestAccessLog_Concurrent(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)
	l := newAccessLogger()
	defer l.Close()

	var wg sync.WaitGroup
	const total = 50
	for i := 0; i < total; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := httptest.NewRequest("GET", "/", nil)
			r.RemoteAddr = "1.2.3.4:1"
			r.Host = "h"
			l.Log(r, 200, 0)
		}()
	}
	wg.Wait()

	data, _ := os.ReadFile(l.filePath)
	lines := strings.Split(strings.TrimRight(string(data), "\n"), "\n")
	if len(lines) != total {
		t.Errorf("行数=%d, want=%d", len(lines), total)
	}
}

// ============================================================================
// rotateIfNeeded —— 同日不 rotate
// ============================================================================

func TestRotate_SameDay_NoRotate(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)
	l := newAccessLogger()
	defer l.Close()

	r := httptest.NewRequest("GET", "/", nil)
	r.RemoteAddr = "1.1.1.1:1"
	r.Host = "h"
	l.Log(r, 200, 0)

	// 同日再 log,不应有 rotate 归档
	l.Log(r, 200, 0)

	entries, _ := os.ReadDir(dir)
	for _, e := range entries {
		if strings.HasPrefix(e.Name(), "access.log.") {
			t.Errorf("同日不应 rotate,found:%s", e.Name())
		}
	}
}

// ============================================================================
// rotateIfNeeded —— 手动模拟跨天(通过 Chtimes 改 mtime)
// ============================================================================

func TestRotate_CrossDay_Rotates(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)
	l := newAccessLogger()
	defer l.Close()

	// 手动写一条建立 mtime
	r := httptest.NewRequest("GET", "/", nil)
	r.RemoteAddr = "1.1.1.1:1"
	r.Host = "h"
	l.Log(r, 200, 0)

	// 关闭文件,把 mtime 改为昨天(Windows Chtimes 可行);再重开重跑 log
	l.mu.Lock()
	_ = l.file.Close()
	l.file = nil
	yesterday := time.Now().Add(-24 * time.Hour)
	_ = os.Chtimes(l.filePath, yesterday, yesterday)
	f, _ := os.OpenFile(l.filePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	l.file = f
	l.mu.Unlock()

	// 再 log 应触发 rotate
	l.Log(r, 200, 0)

	// 应有 access.log.YYYY-MM-DD(昨天)归档
	found := false
	entries, _ := os.ReadDir(dir)
	for _, e := range entries {
		if strings.HasPrefix(e.Name(), "access.log."+yesterday.Format("2006-01-02")) {
			found = true
		}
	}
	if !found {
		t.Error("跨天应 rotate 出 access.log.YYYY-MM-DD 归档")
	}
	// 主 access.log 仍应存在
	if _, err := os.Stat(l.filePath); err != nil {
		t.Errorf("rotate 后 access.log 应重开:%v", err)
	}
}

// ============================================================================
// LogAccess 500 状态 + 特殊字符 UA
// ============================================================================

func TestAccessLog_HandlesSpecialChars(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)
	l := newAccessLogger()
	defer l.Close()

	r := httptest.NewRequest("GET", "/path", nil)
	r.RemoteAddr = "1.1.1.1:1"
	r.Host = "h"
	r.Header.Set("User-Agent", `"quoted" \backslash`)
	l.Log(r, http.StatusInternalServerError, 0)

	data, _ := os.ReadFile(l.filePath)
	// %q 会转义引号和反斜杠
	if !strings.Contains(string(data), `"\"quoted\" \\backslash"`) {
		t.Errorf("特殊字符未正确转义:%s", string(data))
	}
}
