package unsubserver

// Server —— HTTP 退订服务器(契约 §8 完整实现)
//
// 【用途】serve 子命令启动的长期运行服务;仅 ListUnsubMode="real" 部署时用
//
// 【架构】
//   - HTTPS 主入口(端口默认 :443)—— 通配符路由,返回同一日文退订页
//   - HTTP  301(端口默认 :80)—— 301 → HTTPS
//   - 反指纹:实例签名启动时一次生成 + X-Robots-Tag noindex
//   - Host 校验:防 IP 扫描
//   - TLS:GetCertificate 5s mtime 缓存(v2 增强,支持 acme.sh 续期)
//   - Access log:硬编码 /var/log/pmta-injector-unsub/access.log + 日滚 7 天保留

import (
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/internal/config"
)

// Server HTTP 退订服务器
type Server struct {
	cfg config.UnsubscribeServerConfig

	httpSrv  *http.Server
	httpsSrv *http.Server

	// 实例签名 + 缓存 HTML(启动时生成,进程内不变)
	instanceSig instanceSignature
	cachedHTML  []byte

	// TLS 5s mtime cache
	tlsCache *tlsCertCache

	// access log
	accessLog *accessLogger
}

// New 创建 Server(不启动)
//
// 【读】cfg.UnsubscribeServer.{ListenHTTP, ListenHTTPS, CertFile, KeyFile, Domain}
//
// 【错误】
//   - CertFile == "" || KeyFile == "" → err(HTTPS 必需)
//
// 【契约 §2.4】Enabled=false 判定由 cmd 层做(New 之前提前 exit 0),此处不判
func New(cfg *config.Config) (*Server, error) {
	uc := cfg.UnsubscribeServer

	if uc.CertFile == "" || uc.KeyFile == "" {
		return nil, fmt.Errorf("unsubserver: cert_file 和 key_file 必填(HTTPS 必需)")
	}

	if uc.ListenHTTP == "" {
		uc.ListenHTTP = ":80"
	}
	if uc.ListenHTTPS == "" {
		uc.ListenHTTPS = ":443"
	}

	sig := generateInstanceSignature()
	s := &Server{
		cfg:         uc,
		instanceSig: sig,
		cachedHTML:  buildHTML(sig),
		tlsCache:    newTLSCertCache(uc.CertFile, uc.KeyFile),
		accessLog:   newAccessLogger(),
	}
	return s, nil
}

// Start 启动 HTTPS + HTTP 双 server,阻塞至 ctx.Done() 或错误
//
// 【契约 §8.1】TLS min v1.2 + timeouts(read_header 10s / read 20s / write 20s / idle 60s)
//
// 【返回】
//   - nil:正常 shutdown
//   - err:严重错误(端口占用等)
func (s *Server) Start(ctx context.Context) error {
	// === HTTPS ===
	httpsMux := http.NewServeMux()
	httpsMux.HandleFunc("/", s.handleUnsubscribe)

	tlsConfig := &tls.Config{
		MinVersion:     tls.VersionTLS12,
		GetCertificate: s.tlsCache.GetCertificate,
	}

	s.httpsSrv = &http.Server{
		Addr:              s.cfg.ListenHTTPS,
		Handler:           httpsMux,
		TLSConfig:         tlsConfig,
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       20 * time.Second,
		WriteTimeout:      20 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	// === HTTP 80 → 301 → HTTPS ===
	httpMux := http.NewServeMux()
	httpMux.HandleFunc("/", s.handleHTTPRedirect)

	s.httpSrv = &http.Server{
		Addr:              s.cfg.ListenHTTP,
		Handler:           httpMux,
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       20 * time.Second,
		WriteTimeout:      20 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	errCh := make(chan error, 2)

	go func() {
		log.Printf("[unsubserver] HTTPS listening on %s (cert=%s)", s.cfg.ListenHTTPS, s.cfg.CertFile)
		// GetCertificate 已配置 → ListenAndServeTLS 参数留空
		if err := s.httpsSrv.ListenAndServeTLS("", ""); err != nil && err != http.ErrServerClosed {
			errCh <- fmt.Errorf("https server: %w", err)
		}
	}()

	go func() {
		log.Printf("[unsubserver] HTTP listening on %s (301 → HTTPS)", s.cfg.ListenHTTP)
		if err := s.httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			errCh <- fmt.Errorf("http server: %w", err)
		}
	}()

	select {
	case err := <-errCh:
		s.shutdown()
		return err
	case <-ctx.Done():
		log.Println("[unsubserver] received shutdown signal, gracefully shutting down...")
		s.shutdown()
		return nil
	}
}

// Shutdown 外部主动关闭(等价于 ctx.Cancel;5s 超时)
func (s *Server) Shutdown(_ context.Context) error {
	s.shutdown()
	return nil
}

// shutdown 内部关闭:两个 server + access log
func (s *Server) shutdown() {
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if s.httpsSrv != nil {
		_ = s.httpsSrv.Shutdown(shutdownCtx)
	}
	if s.httpSrv != nil {
		_ = s.httpSrv.Shutdown(shutdownCtx)
	}
	if s.accessLog != nil {
		_ = s.accessLog.Close()
	}
}

// handleUnsubscribe HTTPS 主 handler —— 契约 §8.3
//
// 【全 method】GET/POST/PUT/HEAD/其他 —— 都返回同一 HTML(HEAD 不写 body)
//
// 【Host 校验失败】404 + X-Robots-Tag noindex + 记 log
func (s *Server) handleUnsubscribe(w http.ResponseWriter, r *http.Request) {
	if !hostMatchesConfigured(r.Host, s.cfg.Domain) {
		w.Header().Set("X-Robots-Tag", "noindex, nofollow")
		http.NotFound(w, r)
		s.accessLog.Log(r, http.StatusNotFound, 0)
		return
	}

	// 反指纹响应头(契约 §8.3)
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("X-Robots-Tag", "noindex, nofollow")
	w.Header().Set("Cache-Control", "no-store, max-age=0")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(s.cachedHTML)))

	if r.Method == http.MethodHead {
		w.WriteHeader(http.StatusOK)
		s.accessLog.Log(r, http.StatusOK, 0)
		return
	}

	w.WriteHeader(http.StatusOK)
	n, _ := w.Write(s.cachedHTML)
	s.accessLog.Log(r, http.StatusOK, n)
}

// handleHTTPRedirect HTTP 80 → 301 → HTTPS —— 契约 §8.4
func (s *Server) handleHTTPRedirect(w http.ResponseWriter, r *http.Request) {
	if !hostMatchesConfigured(r.Host, s.cfg.Domain) {
		w.Header().Set("X-Robots-Tag", "noindex, nofollow")
		http.NotFound(w, r)
		s.accessLog.Log(r, http.StatusNotFound, 0)
		return
	}

	host := r.Host
	if idx := strings.Index(host, ":"); idx >= 0 {
		host = host[:idx]
	}
	if host == "" {
		host = s.cfg.Domain
	}
	target := "https://" + host + r.URL.RequestURI()

	w.Header().Set("X-Robots-Tag", "noindex, nofollow")
	http.Redirect(w, r, target, http.StatusMovedPermanently)

	s.accessLog.Log(r, http.StatusMovedPermanently, 0)
}
