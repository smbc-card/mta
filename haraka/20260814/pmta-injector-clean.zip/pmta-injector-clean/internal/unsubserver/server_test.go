package unsubserver

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"__MODULE_PLACEHOLDER__/internal/config"
)

// ============================================================================
// New —— 边界
// ============================================================================

func TestNew_MissingCertKey(t *testing.T) {
	cfg := &config.Config{}
	cfg.UnsubscribeServer.Enabled = true
	// CertFile 空
	if _, err := New(cfg); err == nil {
		t.Error("空 CertFile 应 err")
	}

	cfg.UnsubscribeServer.CertFile = "cert.pem"
	// KeyFile 空
	if _, err := New(cfg); err == nil {
		t.Error("空 KeyFile 应 err")
	}
}

func TestNew_DefaultsListenAddrs(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)

	cfg := &config.Config{}
	cfg.UnsubscribeServer.Enabled = true
	cfg.UnsubscribeServer.CertFile = "cert.pem"
	cfg.UnsubscribeServer.KeyFile = "key.pem"
	// ListenHTTP / ListenHTTPS 空 → 默认 :80/:443
	s, err := New(cfg)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	t.Cleanup(func() { _ = s.accessLog.Close() })
	if s.cfg.ListenHTTP != ":80" {
		t.Errorf("默认 ListenHTTP=%s want=:80", s.cfg.ListenHTTP)
	}
	if s.cfg.ListenHTTPS != ":443" {
		t.Errorf("默认 ListenHTTPS=%s want=:443", s.cfg.ListenHTTPS)
	}
	if len(s.cachedHTML) == 0 {
		t.Error("cachedHTML 应生成")
	}
	if s.tlsCache == nil {
		t.Error("tlsCache 应创建")
	}
}

func TestNew_CustomListenAddrs(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)

	cfg := &config.Config{}
	cfg.UnsubscribeServer.Enabled = true
	cfg.UnsubscribeServer.CertFile = "cert.pem"
	cfg.UnsubscribeServer.KeyFile = "key.pem"
	cfg.UnsubscribeServer.ListenHTTP = ":8080"
	cfg.UnsubscribeServer.ListenHTTPS = ":8443"
	s, _ := New(cfg)
	t.Cleanup(func() { _ = s.accessLog.Close() })
	if s.cfg.ListenHTTP != ":8080" || s.cfg.ListenHTTPS != ":8443" {
		t.Errorf("custom listen 未生效")
	}
}

// ============================================================================
// handleUnsubscribe —— 响应头 + HEAD / GET / POST / Host 校验
// ============================================================================

func newTestServer(t *testing.T, domain string) *Server {
	t.Helper()
	dir := t.TempDir()
	withAccessLogDir(t, dir)

	cfg := &config.Config{}
	cfg.UnsubscribeServer.Enabled = true
	cfg.UnsubscribeServer.CertFile = "cert.pem"
	cfg.UnsubscribeServer.KeyFile = "key.pem"
	cfg.UnsubscribeServer.Domain = domain
	s, err := New(cfg)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	// 关键:关闭 access.log 句柄避免 Windows TempDir cleanup 失败(P13)
	t.Cleanup(func() { _ = s.accessLog.Close() })
	return s
}

func TestHandleUnsubscribe_GET_ReturnsHTML(t *testing.T) {
	s := newTestServer(t, "example.com")

	req := httptest.NewRequest("GET", "/unsub?u=xxx", nil)
	req.Host = "example.com"
	w := httptest.NewRecorder()
	s.handleUnsubscribe(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("status=%d want=200", w.Code)
	}
	if ct := w.Header().Get("Content-Type"); ct != "text/html; charset=utf-8" {
		t.Errorf("Content-Type=%s", ct)
	}
	if xr := w.Header().Get("X-Robots-Tag"); xr != "noindex, nofollow" {
		t.Errorf("X-Robots-Tag=%s", xr)
	}
	if cc := w.Header().Get("Cache-Control"); cc != "no-store, max-age=0" {
		t.Errorf("Cache-Control=%s", cc)
	}
	if xcto := w.Header().Get("X-Content-Type-Options"); xcto != "nosniff" {
		t.Errorf("X-Content-Type-Options=%s", xcto)
	}
	body, _ := io.ReadAll(w.Body)
	if len(body) == 0 {
		t.Error("body 空")
	}
	if !strings.Contains(string(body), "<!DOCTYPE html>") {
		t.Error("body 应含 HTML doctype")
	}
}

func TestHandleUnsubscribe_HEAD_NoBody(t *testing.T) {
	s := newTestServer(t, "example.com")

	req := httptest.NewRequest("HEAD", "/", nil)
	req.Host = "example.com"
	w := httptest.NewRecorder()
	s.handleUnsubscribe(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("status=%d", w.Code)
	}
	body, _ := io.ReadAll(w.Body)
	if len(body) != 0 {
		t.Errorf("HEAD 应无 body,got %d bytes", len(body))
	}
	// Content-Length 头仍应设(反指纹稳定)
	cl := w.Header().Get("Content-Length")
	if cl == "" || cl == "0" {
		t.Errorf("HEAD 应设 Content-Length(反指纹),got=%q", cl)
	}
}

func TestHandleUnsubscribe_POST_ReturnsHTML(t *testing.T) {
	// Gmail One-Click 用 POST
	s := newTestServer(t, "example.com")

	req := httptest.NewRequest("POST", "/unsub", strings.NewReader("List-Unsubscribe=One-Click"))
	req.Host = "example.com"
	w := httptest.NewRecorder()
	s.handleUnsubscribe(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("POST status=%d want=200", w.Code)
	}
	body, _ := io.ReadAll(w.Body)
	if !strings.Contains(string(body), "<!DOCTYPE html>") {
		t.Error("POST 应返回 HTML")
	}
}

func TestHandleUnsubscribe_HostMismatch_404(t *testing.T) {
	s := newTestServer(t, "example.com")

	req := httptest.NewRequest("GET", "/", nil)
	req.Host = "attacker.com"
	w := httptest.NewRecorder()
	s.handleUnsubscribe(w, req)

	if w.Code != http.StatusNotFound {
		t.Errorf("Host 不匹配 status=%d want=404", w.Code)
	}
	if xr := w.Header().Get("X-Robots-Tag"); xr != "noindex, nofollow" {
		t.Errorf("404 也应有 X-Robots-Tag,got=%s", xr)
	}
}

func TestHandleUnsubscribe_HostEmptyCfg_NoValidation(t *testing.T) {
	// cfg.Domain 空 → 退化不校验
	s := newTestServer(t, "")

	req := httptest.NewRequest("GET", "/", nil)
	req.Host = "anyhost.com"
	w := httptest.NewRecorder()
	s.handleUnsubscribe(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("Domain 空应放行,status=%d", w.Code)
	}
}

func TestHandleUnsubscribe_CachedHTML_Stable(t *testing.T) {
	// 契约 §8.5:HTML 进程内不变
	s := newTestServer(t, "example.com")

	var bodies []string
	for i := 0; i < 3; i++ {
		req := httptest.NewRequest("GET", "/", nil)
		req.Host = "example.com"
		w := httptest.NewRecorder()
		s.handleUnsubscribe(w, req)
		b, _ := io.ReadAll(w.Body)
		bodies = append(bodies, string(b))
	}
	if bodies[0] != bodies[1] || bodies[1] != bodies[2] {
		t.Error("HTML 应进程内稳定,3 次响应不同")
	}
}

// ============================================================================
// handleHTTPRedirect —— 301 + Host 校验
// ============================================================================

func TestHandleHTTPRedirect_301_ToHTTPS(t *testing.T) {
	s := newTestServer(t, "example.com")

	req := httptest.NewRequest("GET", "/unsub?u=xxx", nil)
	req.Host = "example.com"
	w := httptest.NewRecorder()
	s.handleHTTPRedirect(w, req)

	if w.Code != http.StatusMovedPermanently {
		t.Errorf("status=%d want=301", w.Code)
	}
	loc := w.Header().Get("Location")
	want := "https://example.com/unsub?u=xxx"
	if loc != want {
		t.Errorf("Location=%s want=%s", loc, want)
	}
	if xr := w.Header().Get("X-Robots-Tag"); xr != "noindex, nofollow" {
		t.Errorf("X-Robots-Tag 应设")
	}
}

func TestHandleHTTPRedirect_HostMismatch_404(t *testing.T) {
	s := newTestServer(t, "example.com")

	req := httptest.NewRequest("GET", "/", nil)
	req.Host = "192.168.1.1"
	w := httptest.NewRecorder()
	s.handleHTTPRedirect(w, req)

	if w.Code != http.StatusNotFound {
		t.Errorf("Host 不匹配 status=%d want=404", w.Code)
	}
}

func TestHandleHTTPRedirect_HostWithPort_StripsPort(t *testing.T) {
	s := newTestServer(t, "example.com")

	req := httptest.NewRequest("GET", "/", nil)
	req.Host = "example.com:80"
	w := httptest.NewRecorder()
	s.handleHTTPRedirect(w, req)

	if w.Code != http.StatusMovedPermanently {
		t.Errorf("status=%d", w.Code)
	}
	loc := w.Header().Get("Location")
	if !strings.HasPrefix(loc, "https://example.com/") {
		t.Errorf("Location 应去端口,got=%s", loc)
	}
}

// ============================================================================
// Shutdown 幂等(未 Start 直接 Shutdown)
// ============================================================================

func TestShutdown_Idempotent_NotStarted(t *testing.T) {
	dir := t.TempDir()
	withAccessLogDir(t, dir)

	cfg := &config.Config{}
	cfg.UnsubscribeServer.Enabled = true
	cfg.UnsubscribeServer.CertFile = "cert.pem"
	cfg.UnsubscribeServer.KeyFile = "key.pem"

	s, _ := New(cfg)
	// Shutdown 会关 accessLog,不需要额外 Cleanup
	// 未 Start 直接 Shutdown 应不 panic
	if err := s.Shutdown(context.Background()); err != nil {
		t.Errorf("未 Start Shutdown 应 nil,got:%v", err)
	}
	if err := s.Shutdown(context.Background()); err != nil {
		t.Errorf("重复 Shutdown 应 nil,got:%v", err)
	}
}
