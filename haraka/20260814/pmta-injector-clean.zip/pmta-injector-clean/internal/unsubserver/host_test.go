package unsubserver

import "testing"

func TestHostMatchesConfigured(t *testing.T) {
	cases := []struct {
		name       string
		reqHost    string
		configured string
		want       bool
	}{
		{"配置空 → 不校验(退化 true)", "example.com", "", true},
		{"reqHost 空 → 拒绝", "", "example.com", false},
		{"精确匹配", "example.com", "example.com", true},
		{"大小写不敏感", "EXAMPLE.COM", "example.com", true},
		{"剥端口 IPv4/主机名", "example.com:443", "example.com", true},
		{"不匹配", "other.com", "example.com", false},
		{"带端口且不匹配", "attacker.com:80", "example.com", false},
		{"IPv6 字面量剥括号", "[::1]:443", "::1", true},
		{"IPv6 字面量不匹配", "[::1]:443", "::2", false},
		{"IP 直连(常见扫描)", "192.168.1.1:80", "example.com", false},
		{"configured 前后空格", "example.com", "  example.com  ", true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got := hostMatchesConfigured(c.reqHost, c.configured)
			if got != c.want {
				t.Errorf("hostMatchesConfigured(%q,%q)=%v want=%v",
					c.reqHost, c.configured, got, c.want)
			}
		})
	}
}
