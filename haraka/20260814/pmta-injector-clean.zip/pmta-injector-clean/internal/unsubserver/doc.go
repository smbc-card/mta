// Package unsubserver HTTP 退订服务器(List-Unsubscribe real 模式配套)
//
// 【契约】v2 与 v1 unsubserver/server.go(479 行)语义等价
//
// 【职责】
//   - 监听 cfg.UnsubServer.{Host, Port}(默认 0.0.0.0:8080)
//   - TLS 可选(cfg.UnsubServer.TLSCert / TLSKey 非空时启用)
//   - 4 route:
//     - GET  /unsubscribe?token=... — 显示退订确认页
//     - POST /unsubscribe (One-Click,RFC 8058)— 直接退订
//     - GET  /health — 健康检查
//     - GET  /  — 首页/redirect
//   - Host 校验:请求 Host 必须在 cfg.UnsubServer.AllowedHosts 白名单
//   - access log 硬编码写 cfg.Output.OutputDir/access.log(Q9 决策)
//   - HTML 反指纹:退订页 HTML 内嵌零宽字符 + BiDi(与邮件内容一致套路)
//
// 【生命周期】
//   - Start(ctx):非阻塞,内部启协程 http.ListenAndServe
//   - Shutdown(ctx):graceful shutdown(等 in-flight 请求完成)
//
// 【线程安全】http.Server 内部保证
//
// 【依赖】config + 标准库 net/http + crypto/tls
package unsubserver
